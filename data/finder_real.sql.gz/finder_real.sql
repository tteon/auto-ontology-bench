--
-- PostgreSQL database dump
--

\restrict mQzcu8AAXDWdfamAqfsKBqY6t2YsfdjzmCOUkYfpiJKlwjDcpp98xWbk0zOwtRq

-- Dumped from database version 16.16 (Debian 16.16-1.pgdg13+1)
-- Dumped by pg_dump version 16.16 (Debian 16.16-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    company_id integer NOT NULL,
    cik integer,
    ticker text,
    name text NOT NULL,
    sic_code text,
    sic_description text,
    state_of_incorporation text,
    country text,
    fiscal_year_end text,
    is_sec_filer boolean NOT NULL,
    annual_report_form text,
    entity_type text DEFAULT 'company'::text NOT NULL,
    CONSTRAINT companies_entity_type_check CHECK ((entity_type = ANY (ARRAY['company'::text, 'government'::text])))
);


--
-- Name: TABLE companies; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.companies IS 'Company Overview: issuers that file with the SEC plus counterparties named in their filings.';


--
-- Name: companies_company_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.companies_company_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: companies_company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.companies_company_id_seq OWNED BY public.companies.company_id;


--
-- Name: company_executives; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_executives (
    company_executive_id integer NOT NULL,
    company_id integer NOT NULL,
    person_id integer NOT NULL,
    is_director boolean DEFAULT false NOT NULL,
    is_officer boolean DEFAULT false NOT NULL,
    is_ten_percent_owner boolean DEFAULT false NOT NULL,
    officer_title text,
    first_seen_date date NOT NULL,
    last_seen_date date NOT NULL,
    source_filing_id integer
);


--
-- Name: TABLE company_executives; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.company_executives IS 'Governance: a person''s board/officer role at a company. A person with rows at two companies is a board interlock.';


--
-- Name: company_executives_company_executive_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.company_executives_company_executive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: company_executives_company_executive_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.company_executives_company_executive_id_seq OWNED BY public.company_executives.company_executive_id;


--
-- Name: filings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filings (
    filing_id integer NOT NULL,
    accession_no text NOT NULL,
    filer_cik integer NOT NULL,
    company_id integer,
    form_type text NOT NULL,
    filing_date date NOT NULL,
    report_date date,
    primary_doc text
);


--
-- Name: TABLE filings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.filings IS 'Source documents (provenance) for every fact row.';


--
-- Name: filings_filing_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.filings_filing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: filings_filing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.filings_filing_id_seq OWNED BY public.filings.filing_id;


--
-- Name: financial_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_metrics (
    financial_metric_id integer NOT NULL,
    company_id integer NOT NULL,
    metric_id integer NOT NULL,
    fiscal_year integer NOT NULL,
    fiscal_period text NOT NULL,
    period_start date,
    period_end date NOT NULL,
    value numeric(24,4) NOT NULL,
    unit text NOT NULL,
    xbrl_tag text NOT NULL,
    source_filing_id integer,
    CONSTRAINT financial_metrics_fiscal_period_check CHECK ((fiscal_period = ANY (ARRAY['FY'::text, 'Q1'::text, 'Q2'::text, 'Q3'::text, 'Q4'::text])))
);


--
-- Name: TABLE financial_metrics; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.financial_metrics IS 'Financials: one reported XBRL value of one metric for one company and fiscal period. Values are in the reporting currency (unit).';


--
-- Name: financial_metrics_financial_metric_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.financial_metrics_financial_metric_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: financial_metrics_financial_metric_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.financial_metrics_financial_metric_id_seq OWNED BY public.financial_metrics.financial_metric_id;


--
-- Name: footnote_related_parties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.footnote_related_parties (
    related_party_id integer NOT NULL,
    company_id integer NOT NULL,
    filing_id integer NOT NULL,
    related_party_name text NOT NULL,
    related_company_id integer,
    related_person_id integer,
    relationship text NOT NULL,
    transaction_type text NOT NULL,
    amount_usd numeric(20,2),
    fiscal_year integer,
    description text NOT NULL
);


--
-- Name: TABLE footnote_related_parties; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.footnote_related_parties IS 'Footnotes: related-party transactions disclosed in the notes.';


--
-- Name: footnote_related_parties_related_party_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.footnote_related_parties_related_party_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: footnote_related_parties_related_party_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.footnote_related_parties_related_party_id_seq OWNED BY public.footnote_related_parties.related_party_id;


--
-- Name: institutional_holders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.institutional_holders (
    institution_id integer NOT NULL,
    cik integer NOT NULL,
    name text NOT NULL
);


--
-- Name: TABLE institutional_holders; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.institutional_holders IS 'Shareholder Return: investment managers that file Form 13F-HR.';


--
-- Name: institutional_holders_institution_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.institutional_holders_institution_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: institutional_holders_institution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.institutional_holders_institution_id_seq OWNED BY public.institutional_holders.institution_id;


--
-- Name: institutional_holdings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.institutional_holdings (
    holding_id integer NOT NULL,
    institution_id integer NOT NULL,
    company_id integer NOT NULL,
    report_period date NOT NULL,
    shares bigint NOT NULL,
    value_usd numeric(20,2) NOT NULL,
    source_filing_id integer
);


--
-- Name: TABLE institutional_holdings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.institutional_holdings IS 'Shareholder Return: position of one 13F filer in one company at a quarter end.';


--
-- Name: institutional_holdings_holding_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.institutional_holdings_holding_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: institutional_holdings_holding_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.institutional_holdings_holding_id_seq OWNED BY public.institutional_holdings.holding_id;


--
-- Name: legal_proceedings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.legal_proceedings (
    legal_proceeding_id integer NOT NULL,
    company_id integer NOT NULL,
    filing_id integer NOT NULL,
    case_name text NOT NULL,
    proceeding_type text NOT NULL,
    forum text,
    counterparty text,
    counterparty_company_id integer,
    status text NOT NULL,
    amount_usd numeric(20,2),
    description text NOT NULL,
    CONSTRAINT legal_proceedings_proceeding_type_check CHECK ((proceeding_type = ANY (ARRAY['securities'::text, 'regulatory'::text, 'product_liability'::text, 'contract'::text, 'intellectual_property'::text, 'employment'::text, 'environmental'::text, 'government_investigation'::text, 'other'::text]))),
    CONSTRAINT legal_proceedings_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'settled'::text, 'dismissed'::text, 'judgment'::text, 'appeal'::text, 'unknown'::text])))
);


--
-- Name: TABLE legal_proceedings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.legal_proceedings IS 'Legal: proceedings disclosed in Item 3 / contingencies notes.';


--
-- Name: legal_proceedings_legal_proceeding_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.legal_proceedings_legal_proceeding_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: legal_proceedings_legal_proceeding_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.legal_proceedings_legal_proceeding_id_seq OWNED BY public.legal_proceedings.legal_proceeding_id;


--
-- Name: metric_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metric_definitions (
    metric_id integer NOT NULL,
    metric_code text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    unit text NOT NULL,
    description text NOT NULL,
    us_gaap_tags text[] NOT NULL,
    ifrs_tags text[] NOT NULL,
    CONSTRAINT metric_definitions_category_check CHECK ((category = ANY (ARRAY['Financials'::text, 'Accounting'::text, 'Shareholder Return'::text])))
);


--
-- Name: TABLE metric_definitions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.metric_definitions IS 'Normalized metric catalog that unifies US-GAAP (10-K) and IFRS (20-F) XBRL tags.';


--
-- Name: metric_definitions_metric_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.metric_definitions_metric_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: metric_definitions_metric_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.metric_definitions_metric_id_seq OWNED BY public.metric_definitions.metric_id;


--
-- Name: persons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.persons (
    person_id integer NOT NULL,
    owner_cik integer,
    full_name text NOT NULL
);


--
-- Name: TABLE persons; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.persons IS 'Governance: directors, officers and 10% owners reported on Forms 3/4/5.';


--
-- Name: persons_person_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.persons_person_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: persons_person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.persons_person_id_seq OWNED BY public.persons.person_id;


--
-- Name: risk_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.risk_categories (
    risk_category_id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL
);


--
-- Name: TABLE risk_categories; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.risk_categories IS 'Risk: shared taxonomy; two companies citing the same category share exposure.';


--
-- Name: risk_categories_risk_category_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.risk_categories_risk_category_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: risk_categories_risk_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.risk_categories_risk_category_id_seq OWNED BY public.risk_categories.risk_category_id;


--
-- Name: risk_factors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.risk_factors (
    risk_factor_id integer NOT NULL,
    company_id integer NOT NULL,
    risk_category_id integer NOT NULL,
    filing_id integer NOT NULL,
    title text NOT NULL,
    summary text NOT NULL,
    mentioned_company_id integer
);


--
-- Name: TABLE risk_factors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.risk_factors IS 'Risk: one Item 1A (10-K) / Item 3.D (20-F) / S-1 risk factor.';


--
-- Name: risk_factors_risk_factor_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.risk_factors_risk_factor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: risk_factors_risk_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.risk_factors_risk_factor_id_seq OWNED BY public.risk_factors.risk_factor_id;


--
-- Name: supply_chain_relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supply_chain_relations (
    relation_id integer NOT NULL,
    supplier_company_id integer NOT NULL,
    customer_company_id integer NOT NULL,
    relation_type text NOT NULL,
    product_category text NOT NULL,
    contract_value_usd numeric(20,2),
    since_year integer,
    evidence text NOT NULL,
    source_filing_id integer,
    CONSTRAINT supply_chain_relations_check CHECK ((supplier_company_id <> customer_company_id)),
    CONSTRAINT supply_chain_relations_relation_type_check CHECK ((relation_type = ANY (ARRAY['supplier'::text, 'manufacturing_partner'::text, 'joint_venture'::text, 'licensor'::text, 'launch_provider'::text])))
);


--
-- Name: TABLE supply_chain_relations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.supply_chain_relations IS 'Company Overview: supplier_company_id supplies customer_company_id. Chains of these rows are multi-hop supply paths.';


--
-- Name: supply_chain_relations_relation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.supply_chain_relations_relation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: supply_chain_relations_relation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.supply_chain_relations_relation_id_seq OWNED BY public.supply_chain_relations.relation_id;


--
-- Name: companies company_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies ALTER COLUMN company_id SET DEFAULT nextval('public.companies_company_id_seq'::regclass);


--
-- Name: company_executives company_executive_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_executives ALTER COLUMN company_executive_id SET DEFAULT nextval('public.company_executives_company_executive_id_seq'::regclass);


--
-- Name: filings filing_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filings ALTER COLUMN filing_id SET DEFAULT nextval('public.filings_filing_id_seq'::regclass);


--
-- Name: financial_metrics financial_metric_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_metrics ALTER COLUMN financial_metric_id SET DEFAULT nextval('public.financial_metrics_financial_metric_id_seq'::regclass);


--
-- Name: footnote_related_parties related_party_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.footnote_related_parties ALTER COLUMN related_party_id SET DEFAULT nextval('public.footnote_related_parties_related_party_id_seq'::regclass);


--
-- Name: institutional_holders institution_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_holders ALTER COLUMN institution_id SET DEFAULT nextval('public.institutional_holders_institution_id_seq'::regclass);


--
-- Name: institutional_holdings holding_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_holdings ALTER COLUMN holding_id SET DEFAULT nextval('public.institutional_holdings_holding_id_seq'::regclass);


--
-- Name: legal_proceedings legal_proceeding_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legal_proceedings ALTER COLUMN legal_proceeding_id SET DEFAULT nextval('public.legal_proceedings_legal_proceeding_id_seq'::regclass);


--
-- Name: metric_definitions metric_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metric_definitions ALTER COLUMN metric_id SET DEFAULT nextval('public.metric_definitions_metric_id_seq'::regclass);


--
-- Name: persons person_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persons ALTER COLUMN person_id SET DEFAULT nextval('public.persons_person_id_seq'::regclass);


--
-- Name: risk_categories risk_category_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_categories ALTER COLUMN risk_category_id SET DEFAULT nextval('public.risk_categories_risk_category_id_seq'::regclass);


--
-- Name: risk_factors risk_factor_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_factors ALTER COLUMN risk_factor_id SET DEFAULT nextval('public.risk_factors_risk_factor_id_seq'::regclass);


--
-- Name: supply_chain_relations relation_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_chain_relations ALTER COLUMN relation_id SET DEFAULT nextval('public.supply_chain_relations_relation_id_seq'::regclass);


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.companies (company_id, cik, ticker, name, sic_code, sic_description, state_of_incorporation, country, fiscal_year_end, is_sec_filer, annual_report_form, entity_type) FROM stdin;
1	1318605	TSLA	Tesla, Inc.	3711	Motor Vehicles & Passenger Car Bodies	TX	TX	1231	t	10-K	company
2	1181412	SPCX	SPACE EXPLORATION TECHNOLOGIES CORP	7370	Services-Computer Programming, Data Processing, Etc.	TX	TX	1231	t	S-1/A	company
3	1819994	RKLB	Rocket Lab Corp	3760	Guided Missiles & Space Vehicles & Parts	\N	CA	1231	t	10-K	company
4	936468	LMT	LOCKHEED MARTIN CORP	3760	Guided Missiles & Space Vehicles & Parts	MD	MD	1231	t	10-K	company
5	12927	BA	BOEING CO	3721	Aircraft	DE	VA	1231	t	10-K	company
6	1045810	NVDA	NVIDIA CORP	3674	Semiconductors & Related Devices	DE	CA	0131	t	10-K	company
7	915913	ALB	ALBEMARLE CORP	2821	Plastic Materials, Synth Resins & Nonvulcan Elastomers	VA	NC	1231	t	10-K	company
8	18230	CAT	CATERPILLAR INC	3531	Construction Machinery & Equip	DE	TX	1231	t	10-K	company
9	1046179	TSM	TAIWAN SEMICONDUCTOR MANUFACTURING CO LTD	3674	Semiconductors & Related Devices	\N	\N	1231	t	20-F	company
10	932787	STM	STMicroelectronics N.V.	3674	Semiconductors & Related Devices	P7	Netherlands	1231	t	20-F	company
152	\N	\N	Panasonic	\N	\N	\N	\N	\N	f	\N	company
153	\N	\N	xAI	\N	\N	\N	\N	\N	f	\N	company
154	\N	\N	CATL	\N	\N	\N	\N	\N	f	\N	company
155	\N	\N	EchoStar	\N	\N	\N	\N	\N	f	\N	company
156	\N	\N	Valor	\N	\N	\N	\N	\N	f	\N	company
157	\N	\N	Valor Equity Partners	\N	\N	\N	\N	\N	f	\N	company
158	\N	\N	Intel	\N	\N	\N	\N	\N	f	\N	company
159	\N	\N	Cursor	\N	\N	\N	\N	\N	f	\N	company
160	\N	\N	Solaris Energy Infrastructure, Inc.	\N	\N	\N	\N	\N	f	\N	company
161	\N	\N	GEOST	\N	\N	\N	\N	\N	f	\N	company
162	\N	\N	United States Department of Commerce	\N	\N	\N	\N	\N	f	\N	government
163	\N	\N	the Trust	\N	\N	\N	\N	\N	f	\N	company
164	\N	\N	Blacksky Holdings	\N	\N	\N	\N	\N	f	\N	company
165	\N	\N	Canon	\N	\N	\N	\N	\N	f	\N	company
166	\N	\N	Kinéis	\N	\N	\N	\N	\N	f	\N	company
167	\N	\N	Capella Space	\N	\N	\N	\N	\N	f	\N	company
168	\N	\N	Planet	\N	\N	\N	\N	\N	f	\N	company
169	\N	\N	OHB Group	\N	\N	\N	\N	\N	f	\N	company
170	\N	\N	Synspective	\N	\N	\N	\N	\N	f	\N	company
171	\N	\N	Sinclair Interplanetary	\N	\N	\N	\N	\N	f	\N	company
172	\N	\N	Advanced Solutions, Incorporated	\N	\N	\N	\N	\N	f	\N	company
173	\N	\N	Planetary Systems Corporation	\N	\N	\N	\N	\N	f	\N	company
174	\N	\N	SolAero Technologies Corp.	\N	\N	\N	\N	\N	f	\N	company
175	\N	\N	Space Development Agency	\N	\N	\N	\N	\N	f	\N	government
176	\N	\N	Spirit AeroSystems	\N	\N	\N	\N	\N	f	\N	company
177	\N	\N	U.S. Department of Defense	\N	\N	\N	\N	\N	f	\N	government
178	\N	\N	NASA	\N	\N	\N	\N	\N	f	\N	government
179	\N	\N	Thoma Bravo	\N	\N	\N	\N	\N	f	\N	company
180	\N	\N	Groq, Inc.	\N	\N	\N	\N	\N	f	\N	company
181	\N	\N	Microsoft	\N	\N	\N	\N	\N	f	\N	company
182	\N	\N	OpenAI	\N	\N	\N	\N	\N	f	\N	company
183	\N	\N	Samsung Electronics	\N	\N	\N	\N	\N	f	\N	company
184	\N	\N	SK hynix	\N	\N	\N	\N	\N	f	\N	company
185	\N	\N	Micron Technology	\N	\N	\N	\N	\N	f	\N	company
186	\N	\N	Foxconn (Hon Hai)	\N	\N	\N	\N	\N	f	\N	company
187	\N	\N	Wistron Corporation	\N	\N	\N	\N	\N	f	\N	company
188	\N	\N	Fabrinet	\N	\N	\N	\N	\N	f	\N	company
189	\N	\N	JBC	\N	\N	\N	\N	\N	f	\N	company
190	\N	\N	Windfield	\N	\N	\N	\N	\N	f	\N	company
191	\N	\N	MRL	\N	\N	\N	\N	\N	f	\N	company
192	\N	\N	Mitsui Chemicals, Inc.	\N	\N	\N	\N	\N	f	\N	company
193	\N	\N	Sumitomo Metal Mining Company Limited	\N	\N	\N	\N	\N	f	\N	company
194	\N	\N	Axens Group	\N	\N	\N	\N	\N	f	\N	company
195	\N	\N	Petrobras Quimica S.A. - PETROQUISA	\N	\N	\N	\N	\N	f	\N	company
196	\N	\N	National Development Fund of the R.O.C.	\N	\N	\N	\N	\N	f	\N	company
197	\N	\N	Associates	\N	\N	\N	\N	\N	f	\N	company
198	\N	\N	GUC	\N	\N	\N	\N	\N	f	\N	company
199	\N	\N	VIS	\N	\N	\N	\N	\N	f	\N	company
200	\N	\N	Xintec	\N	\N	\N	\N	\N	f	\N	company
201	\N	\N	Key management personnel	\N	\N	\N	\N	\N	f	\N	company
202	\N	\N	Vanguard International Semiconductor Corporation (VIS)	\N	\N	\N	\N	\N	f	\N	company
203	\N	\N	Philips	\N	\N	\N	\N	\N	f	\N	company
204	\N	\N	EDB Investments	\N	\N	\N	\N	\N	f	\N	company
205	\N	\N	NXP Semiconductors	\N	\N	\N	\N	\N	f	\N	company
206	\N	\N	OmniVision Technologies Inc.	\N	\N	\N	\N	\N	f	\N	company
207	\N	\N	Sony Semiconductor Solution Corporation	\N	\N	\N	\N	\N	f	\N	company
208	\N	\N	DENSO Corporation	\N	\N	\N	\N	\N	f	\N	company
209	\N	\N	Toyota Motor Corporation	\N	\N	\N	\N	\N	f	\N	company
210	\N	\N	Robert Bosch GmbH	\N	\N	\N	\N	\N	f	\N	company
211	\N	\N	Infineon Technologies AG	\N	\N	\N	\N	\N	f	\N	company
212	\N	\N	Apple	\N	\N	\N	\N	\N	f	\N	company
213	\N	\N	Capgemini, Dassault Systèmes, Orange, Politecnico di Milano and Sopra Steria	\N	\N	\N	\N	\N	f	\N	company
214	\N	\N	ST Foundation	\N	\N	\N	\N	\N	f	\N	company
215	\N	\N	GlobalFoundries	\N	\N	\N	\N	\N	f	\N	company
216	\N	\N	Sanan Optoelectronics	\N	\N	\N	\N	\N	f	\N	company
217	\N	\N	Shenzhen SEG Hi-Tech Industrial Company Limited	\N	\N	\N	\N	\N	f	\N	company
218	\N	\N	Tower Semiconductor	\N	\N	\N	\N	\N	f	\N	company
\.


--
-- Data for Name: company_executives; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_executives (company_executive_id, company_id, person_id, is_director, is_officer, is_ten_percent_owner, officer_title, first_seen_date, last_seen_date, source_filing_id) FROM stdin;
1	1	1	t	f	f	\N	2024-02-23	2025-05-08	247
2	1	2	t	f	f	\N	2024-11-13	2026-05-04	269
3	1	3	t	t	t	CEO	2024-12-31	2026-06-17	272
4	1	4	f	t	f	Chief Financial Officer	2024-09-25	2026-09-09	273
5	1	5	t	f	f	\N	2025-05-01	2025-05-29	249
6	1	6	t	f	f	\N	2024-11-05	2025-12-11	262
7	1	7	t	f	f	\N	2024-06-05	2026-01-06	264
8	1	8	t	f	f	\N	2025-04-28	2025-04-28	291
9	1	9	t	f	f	\N	2025-06-04	2025-06-04	295
10	1	10	f	t	f	SVP Powertrain and Energy Eng.	2024-02-02	2024-04-03	298
11	1	11	f	t	f	SVP	2024-03-07	2026-04-02	305
12	2	12	t	f	f	\N	2026-06-11	2026-09-15	306
13	2	3	t	t	t	CEO, CTO & Chairman	2026-06-11	2026-06-17	316
14	2	13	t	t	f	President and COO	2026-06-11	2026-09-24	318
15	2	14	f	t	f	Chief Financial Officer	2026-06-11	2026-06-11	309
16	2	5	t	f	f	\N	2026-06-11	2026-06-11	310
17	2	15	t	f	f	\N	2026-06-11	2026-06-11	311
18	2	16	t	f	f	\N	2026-06-11	2026-06-11	313
19	2	17	t	f	f	\N	2026-06-11	2026-06-11	314
20	2	18	t	f	f	\N	2026-06-11	2026-06-11	315
21	2	19	t	f	f	\N	2026-06-18	2026-06-18	317
22	3	20	f	t	f	SVP & General Counsel	2024-01-09	2026-08-28	450
23	3	21	f	t	f	Chief Financial Officer	2024-03-07	2026-11-03	455
24	3	22	f	f	t	\N	2024-03-13	2024-08-28	341
25	3	23	f	f	t	\N	2024-03-13	2024-08-28	341
26	3	24	f	f	t	\N	2024-03-13	2024-08-28	341
27	3	25	f	f	t	\N	2024-03-13	2025-07-25	377
28	3	26	f	f	t	\N	2024-03-13	2025-07-25	377
29	3	27	f	f	t	\N	2024-03-13	2025-07-25	377
30	3	28	f	f	t	\N	2024-03-13	2025-07-25	377
31	3	29	t	f	f	\N	2024-03-13	2024-05-13	325
32	3	30	t	f	f	\N	2024-06-14	2026-06-02	436
33	3	31	t	f	f	\N	2024-06-14	2026-05-22	423
34	3	32	t	f	f	\N	2024-06-14	2026-09-02	452
35	3	33	t	f	f	\N	2024-06-14	2026-06-05	441
36	3	34	t	f	f	\N	2024-06-14	2024-08-26	340
37	3	35	t	f	f	\N	2024-06-14	2026-11-03	456
38	3	36	t	f	f	\N	2024-08-23	2026-05-22	424
39	3	37	f	t	f	Chief Operations Officer	2024-09-20	2026-08-28	451
40	3	38	t	f	f	\N	2024-11-18	2025-09-18	378
41	3	39	t	t	t	CEO	2024-12-05	2026-07-08	443
42	3	40	f	f	t	\N	2024-12-05	2025-09-17	385
43	3	41	f	f	t	\N	2024-12-05	2025-09-17	385
44	3	42	f	f	t	\N	2024-12-05	2025-09-17	385
45	3	43	f	f	t	\N	2024-12-05	2025-09-17	385
46	3	44	f	t	f	President, Rocket Lab USA, Inc	2026-04-06	2026-08-26	445
47	3	45	f	t	f	VP Corp Controller & CAO	2026-06-05	2026-08-26	448
48	4	46	t	f	f	\N	2024-01-03	2026-10-27	605
49	4	47	t	f	f	\N	2024-01-03	2026-10-01	603
50	4	48	t	f	f	\N	2024-01-03	2026-04-06	594
51	4	49	f	t	f	VP, Treasurer & Investor Rel.	2024-01-11	2026-02-24	577
52	4	50	t	f	f	\N	2024-02-20	2024-02-20	461
53	4	51	t	f	f	\N	2024-02-20	2025-02-19	521
54	4	52	t	f	f	\N	2024-02-20	2026-04-02	593
55	4	53	t	f	f	\N	2024-02-20	2026-02-18	567
56	4	54	t	f	f	\N	2024-02-20	2024-04-03	499
57	4	55	t	f	f	\N	2024-02-20	2024-02-20	469
58	4	56	t	f	f	\N	2024-02-20	2026-02-18	569
59	4	57	t	f	f	\N	2024-02-20	2026-02-18	571
60	4	58	t	f	f	\N	2024-02-20	2024-04-03	498
61	4	59	f	t	f	Pres. Missiles & Fire Control	2024-02-26	2026-03-13	590
62	4	60	t	t	f	Chairman, President & CEO	2024-02-26	2026-02-27	589
63	4	61	f	t	f	Chief Operating Officer	2024-02-26	2026-10-27	604
64	4	62	f	t	f	Chief Financial Officer	2024-02-26	2025-02-28	540
65	4	63	f	t	f	Pres. Rotary & Mission Systems	2024-02-26	2026-06-15	596
66	4	64	f	t	f	President Space	2024-02-26	2026-08-13	600
67	4	65	f	t	f	President Aeronautics	2024-02-26	2026-02-27	581
68	4	66	f	t	f	SVP & General Counsel	2024-02-26	2024-12-10	511
69	4	67	f	t	f	Vice President & Controller	2024-02-26	2026-02-27	586
70	4	68	t	f	f	\N	2024-06-04	2026-02-18	570
71	4	69	t	f	f	\N	2024-12-26	2026-02-18	563
72	4	70	f	t	f	SVP & General Counsel	2025-01-16	2026-02-27	582
73	4	71	f	t	f	Chief Financial Officer	2025-04-25	2026-02-27	587
74	4	72	f	t	f	President Aeronautics	2026-06-10	2026-06-10	595
75	5	73	t	f	f	\N	2024-04-03	2026-07-06	788
76	5	74	f	t	f	EVP and Chief HR Officer	2024-04-08	2026-02-26	772
77	5	75	t	f	f	\N	2024-07-03	2025-04-03	676
78	5	76	t	f	f	\N	2024-07-03	2026-07-06	797
79	5	77	t	f	f	\N	2024-07-03	2026-11-03	803
80	5	78	t	f	f	\N	2024-07-03	2026-07-06	795
81	5	79	t	f	f	\N	2024-07-03	2026-07-06	794
82	5	80	t	f	f	\N	2024-07-03	2026-07-06	793
83	5	81	t	f	f	\N	2024-07-03	2026-07-06	792
84	5	82	t	f	f	\N	2024-07-03	2026-07-06	791
85	5	83	t	f	f	\N	2024-07-03	2026-07-06	790
86	5	84	t	t	f	President & CEO	2024-08-09	2026-08-12	799
87	5	85	f	t	f	EVP & Chief Financial Officer	2024-08-29	2025-02-21	660
88	5	86	f	t	f	EVP, Pres. & CEO, BGS	2024-09-05	2026-11-12	805
89	5	87	f	t	f	EVP, Pres. & CEO, BCA	2024-12-04	2026-02-23	764
90	5	88	f	t	f	Chief Engineer & EVP, ET&T	2024-12-04	2026-02-23	767
91	5	89	f	t	f	Controller	2024-12-04	2026-02-23	770
92	5	90	f	t	f	SVP, Chief Com & Brand Officer	2025-01-02	2026-02-23	762
93	5	91	f	t	f	CIDO, SVP IDT&S	2025-01-03	2026-02-23	769
94	5	92	t	f	f	\N	2025-01-06	2026-11-03	804
95	5	93	f	t	f	CLO & EVP, Global Compliance	2025-02-20	2026-02-23	768
96	5	94	f	t	f	SVP, President, Boeing Global	2025-02-21	2026-02-19	749
97	5	95	f	t	f	EVP, Gov Ops, GPP & CS	2025-02-26	2026-02-26	773
98	5	96	f	t	f	EVP, Pres. & CEO, BDS	2025-07-10	2026-09-01	802
99	5	62	f	t	f	EVP and CFO	2025-08-19	2026-08-19	801
100	5	97	t	f	f	\N	2025-12-12	2026-07-06	798
101	5	98	f	t	f	Chief Aerospace Safety Officer	2026-06-26	2026-06-26	787
102	6	99	t	t	f	President and CEO	2024-09-24	2026-09-18	912
103	6	100	t	f	f	\N	2024-09-26	2026-09-22	931
104	6	101	t	f	f	\N	2024-11-12	2025-06-30	866
105	6	102	t	f	f	\N	2024-11-27	2026-06-29	1002
106	6	103	f	t	f	EVP, Worldwide Field Ops	2024-12-13	2026-08-24	960
107	6	104	f	t	f	Principal Accounting Officer	2024-12-13	2026-03-20	967
108	6	105	f	t	f	EVP, Operations	2024-12-13	2026-09-18	948
109	6	106	f	t	f	EVP, General Counsel and Sec	2024-12-13	2026-09-23	992
110	6	107	f	t	f	EVP & Chief Financial Officer	2024-12-13	2026-09-18	981
111	6	108	t	f	f	\N	2025-03-17	2025-06-30	859
112	6	109	t	f	f	\N	2025-03-21	2026-06-29	994
113	6	110	t	f	f	\N	2025-06-24	2026-06-29	920
114	6	111	t	f	f	\N	2025-06-30	2026-06-29	998
115	6	112	t	f	f	\N	2025-06-30	2026-01-23	983
116	6	113	t	f	f	\N	2025-06-30	2026-06-29	949
117	6	114	t	f	f	\N	2025-06-30	2026-06-29	933
118	6	115	t	f	f	\N	2025-06-30	2026-06-29	915
119	6	116	t	f	f	\N	2024-12-18	2026-11-06	879
120	6	117	f	t	f	Principal Accounting Officer	2026-05-14	2026-09-18	939
121	6	118	t	f	f	\N	2026-07-15	2026-08-12	951
122	6	119	f	t	f	EVP, Worldwide Field Ops	2026-09-03	2026-09-11	1004
123	7	120	f	t	f	VP, Controller & CAO	2024-01-03	2024-05-14	1032
124	7	121	f	t	f	Chief Operations Officer	2024-01-03	2025-03-03	1069
125	7	122	f	t	f	Chief Capital Projects Officer	2024-01-03	2024-03-01	1028
126	7	123	f	t	f	Chief Commercial Officer	2024-01-03	2026-09-16	1101
127	7	124	t	t	f	Chairman & CEO	2024-01-03	2026-05-19	1094
128	7	125	f	t	f	Chief Bus..Transformation Off.	2024-02-21	2026-03-04	1125
129	7	126	f	t	f	EVP, General Counsel	2024-02-26	2024-02-28	1027
130	7	127	f	t	f	Chief Financial Officer	2024-02-26	2026-11-10	1103
131	7	128	f	t	f	SVP, Ext. Affairs & Comm.	2024-02-28	2026-03-04	1131
132	7	129	f	t	f	Chief Operations Officer	2024-05-14	2026-09-16	1100
133	7	130	t	f	f	\N	2024-07-03	2026-07-06	1112
134	7	131	t	f	f	\N	2024-07-03	2026-07-06	1104
135	7	132	t	f	f	\N	2024-07-03	2025-07-03	1078
136	7	133	t	f	f	\N	2024-07-03	2026-07-06	1126
137	7	134	t	f	f	\N	2024-07-03	2025-07-03	1082
138	7	135	t	f	f	\N	2024-07-03	2026-10-02	1102
139	7	136	t	f	f	\N	2024-07-03	2026-07-06	1106
140	7	137	t	f	f	\N	2024-07-03	2026-07-06	1127
141	7	138	t	f	f	\N	2024-07-03	2026-07-06	1105
142	7	139	f	t	f	General Counsel & Sec	2024-10-16	2025-03-03	1071
143	7	140	f	t	f	VP, Corporate Controller & CAO	2024-11-19	2026-03-04	1115
144	7	141	f	t	f	General Counsel & Sec	2025-08-08	2026-03-04	1141
145	7	142	f	t	f	Chief People Officer	2025-08-21	2026-09-16	1099
146	7	143	t	f	f	\N	2026-03-02	2026-07-06	1108
147	7	144	t	f	f	\N	2026-07-23	2026-07-23	1096
148	7	145	f	t	f	Chief Accounting Officer	2026-08-25	2026-09-03	1098
149	7	146	t	f	f	\N	2026-03-02	2026-07-06	1137
150	8	147	f	t	f	Group President	2024-12-27	2026-05-15	1311
151	8	148	f	t	f	Group President	2024-12-27	2026-10-27	1339
152	8	149	f	t	f	Chief Executive Officer	2024-12-27	2026-10-27	1340
153	8	150	t	f	f	\N	2025-01-02	2026-06-11	1320
154	8	151	t	f	f	\N	2025-01-02	2026-11-13	1344
155	8	152	f	t	f	Group President	2025-01-14	2026-05-12	1306
156	8	153	f	t	f	Group President	2025-01-14	2026-05-07	1304
157	8	154	f	t	f	CFO Emeritus	2025-01-17	2026-05-07	1302
158	8	155	t	f	f	\N	2025-02-05	2026-06-11	1315
159	8	156	f	t	f	Chief Human Resources Officer	2025-02-13	2025-03-05	1167
160	8	157	f	t	f	Chief Legal Officer	2025-02-13	2026-03-06	1286
161	8	158	f	t	f	Chief Accounting Officer	2025-02-13	2026-05-14	1309
162	8	159	t	t	f	Executive Chairman	2025-02-13	2026-03-06	1289
163	8	160	f	t	f	Chief Human Resources Officer	2025-05-02	2026-05-12	1307
164	8	161	t	f	f	\N	2025-06-13	2026-06-11	1316
165	8	162	t	f	f	\N	2025-06-13	2026-06-11	1318
166	8	56	t	f	f	\N	2025-06-13	2026-06-11	1319
167	8	163	t	f	f	\N	2025-06-13	2026-06-11	1321
168	8	164	t	f	f	\N	2025-06-13	2026-11-03	1343
169	8	165	f	t	f	Group President	2026-02-06	2026-05-06	1300
170	8	166	f	t	f	Chief Financial Officer	2026-05-04	2026-10-27	1341
171	8	81	t	f	f	\N	2026-08-05	2026-10-01	1338
172	8	167	f	t	f	Group President	2026-11-02	2026-11-02	1342
173	9	168	f	t	f	VP and CIO	2026-06-09	2026-11-10	1537
174	9	169	f	t	f	VP	2026-06-09	2026-11-10	1538
175	9	170	f	t	f	SVP	2026-06-09	2026-11-10	1544
176	9	171	t	t	f	Chairman and CEO	2026-06-09	2026-11-10	1535
177	9	172	f	t	f	EVP and Co-COO	2026-06-09	2026-11-10	1527
178	9	173	f	t	f	SVP	2026-06-09	2026-11-10	1531
179	9	174	f	t	f	VP	2026-06-09	2026-11-10	1543
180	9	175	f	t	f	SVP	2026-06-09	2026-11-10	1542
181	9	176	f	t	f	VP	2026-06-09	2026-11-10	1539
182	9	177	f	t	f	VP	2026-06-09	2026-11-10	1540
183	9	178	f	t	f	SVP and Deputy Co-COO	2026-06-09	2026-11-10	1541
184	9	179	f	t	f	VP	2026-06-24	2026-11-10	1525
185	9	180	f	t	f	SVP	2026-07-06	2026-11-10	1517
186	9	181	f	t	f	VP	2026-07-09	2026-11-10	1536
187	9	182	f	t	f	VP	2026-07-09	2026-11-10	1530
188	9	183	f	t	f	VP	2026-07-09	2026-11-10	1529
189	9	184	f	t	f	VP	2026-07-09	2026-11-10	1515
190	9	185	f	t	f	VP	2026-07-09	2026-11-10	1532
191	9	186	f	t	f	SVP and CFO	2026-07-09	2026-11-10	1526
192	9	187	f	t	f	VP	2026-07-09	2026-11-10	1521
193	9	188	f	t	f	SVP and GC	2026-07-09	2026-11-10	1523
194	9	189	f	t	f	VP	2026-07-09	2026-08-05	1399
195	9	190	f	t	f	Controller	2026-07-09	2026-11-10	1518
196	9	191	f	t	f	VP	2026-07-09	2026-11-10	1524
197	9	192	f	t	f	EVP and Co-COO	2026-07-09	2026-11-10	1516
198	9	193	f	t	f	SVP and Deputy Co-COO	2026-07-09	2026-11-10	1522
199	9	194	f	t	f	VP	2026-07-09	2026-11-10	1519
200	9	195	f	t	f	SVP	2026-07-09	2026-11-10	1528
201	9	196	f	t	f	VP	2026-07-09	2026-11-10	1520
202	9	197	f	t	f	VP	2026-07-09	2026-11-10	1533
203	9	198	f	t	f	VP	2026-07-09	2026-11-10	1534
204	9	199	t	f	f	\N	2026-07-31	2026-07-31	1397
205	9	200	t	f	f	\N	2026-11-09	2026-11-09	1514
\.


--
-- Data for Name: filings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filings (filing_id, accession_no, filer_cik, company_id, form_type, filing_date, report_date, primary_doc) FROM stdin;
1	0001628280-26-003952	1318605	1	10-K	2026-01-29	2025-12-31	tsla-20251231.htm
2	0001628280-26-040364	1181412	2	S-1/A	2026-06-03	\N	spaceexplorationtechnologib.htm
3	0001819994-26-000013	1819994	3	10-K	2026-02-26	2025-12-31	rklb-20251231.htm
4	0001628280-26-004195	936468	4	10-K	2026-01-29	2025-12-31	lmt-20251231.htm
5	0001628280-26-004357	12927	5	10-K	2026-01-30	2025-12-31	ba-20251231.htm
6	0001045810-26-000021	1045810	6	10-K	2026-02-25	2026-01-25	nvda-20260125.htm
7	0000915913-26-000018	915913	7	10-K	2026-02-11	2025-12-31	alb-20251231.htm
8	0000018230-26-000008	18230	8	10-K	2026-02-13	2025-12-31	cat-20251231.htm
9	0001628280-26-025362	1046179	9	20-F	2026-04-16	2025-12-31	tsm-20251231.htm
10	0000932787-26-000009	932787	10	20-F	2026-02-26	2025-12-31	stm-20251231.htm
11	0001564590-21-004599	1318605	1	10-K	2021-02-08	\N	\N
12	0000950170-22-000796	1318605	1	10-K	2022-02-07	\N	\N
13	0000950170-21-000046	1318605	1	10-Q	2021-04-28	\N	\N
14	0000950170-21-000524	1318605	1	10-Q	2021-07-27	\N	\N
15	0000950170-21-002253	1318605	1	10-Q	2021-10-25	\N	\N
16	0000950170-23-001409	1318605	1	10-K	2023-01-31	\N	\N
17	0000950170-22-006034	1318605	1	10-Q	2022-04-25	\N	\N
18	0000950170-22-012936	1318605	1	10-Q	2022-07-25	\N	\N
19	0000950170-22-019867	1318605	1	10-Q	2022-10-24	\N	\N
20	0001628280-24-002390	1318605	1	10-K	2024-01-29	\N	\N
21	0000950170-23-013890	1318605	1	10-Q	2023-04-24	\N	\N
22	0000950170-23-033872	1318605	1	10-Q	2023-07-24	\N	\N
23	0001628280-23-034847	1318605	1	10-Q	2023-10-23	\N	\N
24	0001628280-25-003063	1318605	1	10-K	2025-01-30	\N	\N
25	0001628280-24-017503	1318605	1	10-Q	2024-04-24	\N	\N
26	0001628280-24-032662	1318605	1	10-Q	2024-07-24	\N	\N
27	0001628280-24-043486	1318605	1	10-Q	2024-10-24	\N	\N
28	0001628280-25-018911	1318605	1	10-Q	2025-04-23	\N	\N
29	0001628280-25-035806	1318605	1	10-Q	2025-07-24	\N	\N
30	0001628280-25-045968	1318605	1	10-Q	2025-10-23	\N	\N
31	0001628280-26-026673	1318605	1	10-Q	2026-04-23	\N	\N
32	0001628280-26-049270	1318605	1	10-Q	2026-07-23	\N	\N
33	0001628280-26-066775	1318605	1	10-Q	2026-10-22	\N	\N
34	0001564590-20-019931	1318605	1	10-Q	2020-04-30	\N	\N
35	0001564590-20-033670	1318605	1	10-Q	2020-07-28	\N	\N
36	0001564590-20-047486	1318605	1	10-Q	2020-10-26	\N	\N
37	0001104659-26-116700	1318605	1	DEF 14A	2026-10-19	\N	\N
38	0001564590-19-013462	1318605	1	10-Q	2019-04-29	\N	\N
39	0001564590-19-026445	1318605	1	10-Q	2019-07-29	\N	\N
40	0001564590-19-038256	1318605	1	10-Q	2019-10-29	\N	\N
41	0001628280-26-052535	1181412	2	10-Q	2026-08-04	\N	\N
42	0001628280-26-066880	1181412	2	10-Q	2026-10-22	\N	\N
43	0001193125-21-330184	1819994	3	10-Q	2021-11-15	\N	\N
44	0000950170-23-006499	1819994	3	10-K	2023-03-07	\N	\N
45	0000950170-22-010114	1819994	3	10-Q	2022-05-16	\N	\N
46	0000950170-22-016921	1819994	3	10-Q	2022-08-11	\N	\N
47	0000950170-22-023923	1819994	3	10-Q	2022-11-09	\N	\N
48	0000950170-24-022160	1819994	3	10-K	2024-02-28	\N	\N
49	0000950170-23-019756	1819994	3	10-Q	2023-05-09	\N	\N
50	0000950170-23-039896	1819994	3	10-Q	2023-08-08	\N	\N
51	0000950170-23-061189	1819994	3	10-Q	2023-11-08	\N	\N
52	0001628280-25-008724	1819994	3	10-K	2025-02-27	\N	\N
53	0000950170-24-053646	1819994	3	10-Q	2024-05-06	\N	\N
54	0000950170-24-094122	1819994	3	10-Q	2024-08-08	\N	\N
55	0000950170-24-125529	1819994	3	10-Q	2024-11-12	\N	\N
56	0001628280-25-023857	1819994	3	10-Q	2025-05-08	\N	\N
57	0001628280-25-038936	1819994	3	10-Q	2025-08-07	\N	\N
58	0001819994-25-000021	1819994	3	10-Q	2025-11-10	\N	\N
59	0001819994-26-000028	1819994	3	10-Q	2026-05-07	\N	\N
60	0001819994-26-000062	1819994	3	10-Q	2026-08-10	\N	\N
61	0001819994-26-000074	1819994	3	10-Q	2026-11-09	\N	\N
62	0001628280-26-023922	1819994	3	DEF 14A	2026-04-06	\N	\N
63	0001213900-20-037159	1819994	3	10-Q	2020-11-16	\N	\N
64	0000950170-22-004458	1819994	3	10-K	2022-03-24	\N	\N
65	0001213900-21-028778	1819994	3	10-Q	2021-05-24	\N	\N
66	0001193125-21-234954	1819994	3	10-Q	2021-08-03	\N	\N
67	0000936468-21-000013	936468	4	10-K	2021-01-28	\N	\N
68	0000936468-22-000008	936468	4	10-K	2022-01-25	\N	\N
69	0000936468-21-000044	936468	4	10-Q	2021-04-21	\N	\N
70	0000936468-21-000072	936468	4	10-Q	2021-07-26	\N	\N
71	0000936468-21-000101	936468	4	10-Q	2021-10-26	\N	\N
72	0000936468-23-000009	936468	4	10-K	2023-01-26	\N	\N
73	0000936468-22-000048	936468	4	10-Q	2022-04-20	\N	\N
74	0000936468-22-000096	936468	4	10-Q	2022-07-19	\N	\N
75	0000936468-22-000120	936468	4	10-Q	2022-10-18	\N	\N
76	0000936468-24-000010	936468	4	10-K	2024-01-23	\N	\N
77	0000936468-23-000051	936468	4	10-Q	2023-04-18	\N	\N
78	0000936468-23-000099	936468	4	10-Q	2023-07-19	\N	\N
79	0000936468-23-000123	936468	4	10-Q	2023-10-17	\N	\N
80	0000936468-25-000009	936468	4	10-K	2025-01-28	\N	\N
81	0000936468-24-000052	936468	4	10-Q	2024-04-23	\N	\N
82	0000936468-24-000095	936468	4	10-Q	2024-07-23	\N	\N
83	0000936468-24-000110	936468	4	10-Q	2024-10-22	\N	\N
84	0000936468-25-000035	936468	4	10-Q	2025-04-22	\N	\N
85	0001628280-25-035565	936468	4	10-Q	2025-07-22	\N	\N
86	0001628280-25-045693	936468	4	10-Q	2025-10-21	\N	\N
87	0001628280-26-026836	936468	4	10-Q	2026-04-23	\N	\N
88	0001628280-26-049411	936468	4	10-Q	2026-07-23	\N	\N
89	0001628280-26-066928	936468	4	10-Q	2026-10-22	\N	\N
90	0000936468-20-000056	936468	4	10-Q	2020-04-22	\N	\N
91	0000936468-20-000115	936468	4	10-Q	2020-07-21	\N	\N
92	0000936468-20-000125	936468	4	10-Q	2020-10-22	\N	\N
93	0000936468-19-000022	936468	4	10-Q	2019-04-24	\N	\N
94	0000936468-19-000058	936468	4	10-Q	2019-07-23	\N	\N
95	0000936468-19-000069	936468	4	10-Q	2019-10-24	\N	\N
96	0000936468-20-000016	936468	4	10-K	2020-02-07	\N	\N
97	0000012927-21-000011	12927	5	10-K	2021-02-01	\N	\N
98	0000012927-22-000010	12927	5	10-K	2022-01-31	\N	\N
99	0000012927-21-000040	12927	5	10-Q	2021-04-28	\N	\N
100	0000012927-21-000073	12927	5	10-Q	2021-07-28	\N	\N
101	0000012927-21-000094	12927	5	10-Q	2021-10-27	\N	\N
102	0000012927-23-000007	12927	5	10-K	2023-01-27	\N	\N
103	0000012927-22-000022	12927	5	10-Q	2022-04-27	\N	\N
104	0000012927-22-000058	12927	5	10-Q	2022-07-27	\N	\N
105	0000012927-22-000073	12927	5	10-Q	2022-10-26	\N	\N
106	0000012927-24-000010	12927	5	10-K	2024-01-31	\N	\N
107	0000012927-23-000029	12927	5	10-Q	2023-04-26	\N	\N
108	0000012927-23-000048	12927	5	10-Q	2023-07-26	\N	\N
109	0000012927-23-000062	12927	5	10-Q	2023-10-25	\N	\N
110	0000012927-25-000015	12927	5	10-K	2025-02-03	\N	\N
111	0000012927-24-000025	12927	5	10-Q	2024-04-24	\N	\N
112	0000012927-24-000055	12927	5	10-Q	2024-07-31	\N	\N
113	0000012927-24-000082	12927	5	10-Q	2024-10-23	\N	\N
114	0000012927-25-000031	12927	5	10-Q	2025-04-23	\N	\N
115	0000012927-25-000062	12927	5	10-Q	2025-07-29	\N	\N
116	0001628280-25-047023	12927	5	10-Q	2025-10-29	\N	\N
117	0001628280-26-026458	12927	5	10-Q	2026-04-22	\N	\N
118	0001628280-26-050038	12927	5	10-Q	2026-07-28	\N	\N
119	0001628280-26-067508	12927	5	10-Q	2026-10-27	\N	\N
120	0000012927-20-000045	12927	5	10-Q	2020-04-29	\N	\N
121	0000012927-20-000065	12927	5	10-Q	2020-07-29	\N	\N
122	0000012927-20-000076	12927	5	10-Q	2020-10-28	\N	\N
123	0000012927-19-000030	12927	5	10-Q	2019-04-24	\N	\N
124	0000012927-19-000063	12927	5	10-Q	2019-07-24	\N	\N
125	0000012927-19-000077	12927	5	10-Q	2019-10-23	\N	\N
126	0001045810-20-000065	1045810	6	10-Q	2020-05-21	\N	\N
127	0001045810-20-000147	1045810	6	10-Q	2020-08-19	\N	\N
128	0001045810-20-000189	1045810	6	10-Q	2020-11-18	\N	\N
129	0001045810-22-000036	1045810	6	10-K	2022-03-18	\N	\N
130	0001045810-21-000064	1045810	6	10-Q	2021-05-26	\N	\N
131	0001045810-21-000131	1045810	6	10-Q	2021-08-20	\N	\N
132	0001045810-21-000163	1045810	6	10-Q	2021-11-22	\N	\N
133	0001045810-23-000017	1045810	6	10-K	2023-02-24	\N	\N
134	0001045810-22-000079	1045810	6	10-Q	2022-05-27	\N	\N
135	0001045810-22-000147	1045810	6	10-Q	2022-08-31	\N	\N
136	0001045810-22-000166	1045810	6	10-Q	2022-11-18	\N	\N
137	0001045810-24-000029	1045810	6	10-K	2024-02-21	\N	\N
138	0001045810-23-000093	1045810	6	10-Q	2023-05-26	\N	\N
139	0001045810-23-000175	1045810	6	10-Q	2023-08-28	\N	\N
140	0001045810-23-000227	1045810	6	10-Q	2023-11-21	\N	\N
141	0001045810-25-000023	1045810	6	10-K	2025-02-26	\N	\N
142	0001045810-24-000124	1045810	6	10-Q	2024-05-29	\N	\N
143	0001045810-24-000264	1045810	6	10-Q	2024-08-28	\N	\N
144	0001045810-24-000316	1045810	6	10-Q	2024-11-20	\N	\N
145	0001045810-25-000116	1045810	6	10-Q	2025-05-28	\N	\N
146	0001045810-25-000209	1045810	6	10-Q	2025-08-27	\N	\N
147	0001045810-25-000230	1045810	6	10-Q	2025-11-19	\N	\N
148	0001045810-26-000052	1045810	6	10-Q	2026-05-20	\N	\N
149	0001045810-26-000075	1045810	6	10-Q	2026-08-26	\N	\N
150	0001045810-20-000010	1045810	6	10-K	2020-02-20	\N	\N
151	0001045810-26-000036	1045810	6	DEF 14A	2026-05-12	\N	\N
152	0001045810-19-000079	1045810	6	10-Q	2019-05-16	\N	\N
153	0001045810-19-000144	1045810	6	10-Q	2019-08-15	\N	\N
154	0001045810-19-000170	1045810	6	10-Q	2019-11-14	\N	\N
155	0001045810-21-000010	1045810	6	10-K	2021-02-26	\N	\N
156	0000915913-20-000105	915913	7	10-Q	2020-05-11	\N	\N
157	0000915913-20-000143	915913	7	10-Q	2020-08-05	\N	\N
158	0000915913-20-000165	915913	7	10-Q	2020-11-04	\N	\N
159	0000915913-22-000027	915913	7	10-K	2022-02-22	\N	\N
160	0000915913-20-000040	915913	7	10-K	2020-02-26	\N	\N
161	0000915913-21-000098	915913	7	10-Q	2021-05-05	\N	\N
162	0000915913-21-000149	915913	7	10-Q	2021-08-04	\N	\N
163	0000915913-21-000181	915913	7	10-Q	2021-11-04	\N	\N
164	0000915913-23-000039	915913	7	10-K	2023-02-15	\N	\N
165	0000915913-22-000103	915913	7	10-Q	2022-05-04	\N	\N
166	0000915913-22-000137	915913	7	10-Q	2022-08-03	\N	\N
167	0000915913-22-000167	915913	7	10-Q	2022-11-02	\N	\N
168	0000915913-24-000016	915913	7	10-K	2024-02-15	\N	\N
169	0000915913-23-000115	915913	7	10-Q	2023-05-03	\N	\N
170	0000915913-23-000166	915913	7	10-Q	2023-08-02	\N	\N
171	0000915913-23-000180	915913	7	10-Q	2023-11-01	\N	\N
172	0000915913-25-000026	915913	7	10-K	2025-02-12	\N	\N
173	0000915913-24-000100	915913	7	10-Q	2024-05-01	\N	\N
174	0000915913-24-000139	915913	7	10-Q	2024-07-31	\N	\N
175	0000915913-24-000158	915913	7	10-Q	2024-11-06	\N	\N
176	0000915913-25-000084	915913	7	10-Q	2025-04-30	\N	\N
177	0000915913-25-000133	915913	7	10-Q	2025-08-04	\N	\N
178	0000915913-25-000162	915913	7	10-Q	2025-11-05	\N	\N
179	0000915913-26-000072	915913	7	10-Q	2026-05-06	\N	\N
180	0000915913-26-000102	915913	7	10-Q	2026-08-05	\N	\N
181	0000915913-26-000129	915913	7	10-Q	2026-11-04	\N	\N
182	0000915913-19-000043	915913	7	10-Q	2019-05-08	\N	\N
183	0000915913-19-000078	915913	7	10-Q	2019-08-07	\N	\N
184	0000915913-19-000099	915913	7	10-Q	2019-11-06	\N	\N
185	0000915913-21-000018	915913	7	10-K	2021-02-19	\N	\N
186	0000018230-21-000063	18230	8	10-K	2021-02-17	\N	\N
187	0000018230-22-000050	18230	8	10-K	2022-02-16	\N	\N
188	0000018230-21-000151	18230	8	10-Q	2021-05-05	\N	\N
189	0000018230-21-000221	18230	8	10-Q	2021-08-04	\N	\N
190	0000018230-21-000260	18230	8	10-Q	2021-11-03	\N	\N
191	0000018230-23-000011	18230	8	10-K	2023-02-15	\N	\N
192	0000018230-22-000112	18230	8	10-Q	2022-05-04	\N	\N
193	0000018230-22-000183	18230	8	10-Q	2022-08-03	\N	\N
194	0000018230-22-000223	18230	8	10-Q	2022-11-02	\N	\N
195	0000018230-24-000009	18230	8	10-K	2024-02-16	\N	\N
196	0000018230-23-000022	18230	8	10-Q	2023-05-03	\N	\N
197	0000018230-23-000047	18230	8	10-Q	2023-08-02	\N	\N
198	0000018230-23-000056	18230	8	10-Q	2023-11-01	\N	\N
199	0000018230-25-000008	18230	8	10-K	2025-02-14	\N	\N
200	0000018230-24-000020	18230	8	10-Q	2024-05-01	\N	\N
201	0000018230-24-000045	18230	8	10-Q	2024-08-07	\N	\N
202	0000018230-24-000053	18230	8	10-Q	2024-11-06	\N	\N
203	0000018230-26-000013	18230	8	8-K	2026-03-26	\N	\N
204	0000018230-26-000021	18230	8	10-Q	2026-05-06	\N	\N
205	0000018230-26-000046	18230	8	10-Q	2026-08-05	\N	\N
206	0000018230-26-000057	18230	8	10-Q	2026-11-04	\N	\N
207	0000018230-25-000016	18230	8	10-Q	2025-05-07	\N	\N
208	0000018230-25-000040	18230	8	10-Q	2025-08-06	\N	\N
209	0000018230-25-000048	18230	8	10-Q	2025-11-03	\N	\N
210	0000018230-20-000155	18230	8	10-Q	2020-05-06	\N	\N
211	0000018230-20-000214	18230	8	10-Q	2020-08-05	\N	\N
212	0000018230-20-000297	18230	8	10-Q	2020-11-04	\N	\N
213	0001308179-26-000358	18230	8	DEF 14A	2026-04-30	\N	\N
214	0000018230-19-000153	18230	8	10-Q	2019-05-06	\N	\N
215	0000018230-19-000224	18230	8	10-Q	2019-08-01	\N	\N
216	0000018230-19-000281	18230	8	10-Q	2019-10-31	\N	\N
217	0001193125-22-104891	1046179	9	20-F	2022-04-14	\N	\N
218	0001193125-23-107214	1046179	9	20-F	2023-04-20	\N	\N
219	0001193125-24-099840	1046179	9	20-F	2024-04-18	\N	\N
220	0001193125-25-083423	1046179	9	20-F	2025-04-17	\N	\N
221	0001193125-20-107579	1046179	9	20-F	2020-04-15	\N	\N
222	0001193125-21-118512	1046179	9	20-F	2021-04-16	\N	\N
223	0001193125-21-301021	1046179	9	6-K	2021-10-18	\N	\N
224	0001564590-22-006712	932787	10	20-F	2022-02-24	\N	\N
225	0001564590-23-002312	932787	10	20-F	2023-02-23	\N	\N
226	0001628280-24-006353	932787	10	20-F	2024-02-22	\N	\N
227	0000932787-25-000006	932787	10	20-F	2025-02-27	\N	\N
228	0001564590-21-008102	932787	10	20-F	2021-02-24	\N	\N
229	0001564590-20-006795	932787	10	20-F	2020-02-26	\N	\N
230	0000950170-24-054842	1318605	1	4	2024-05-07	\N	\N
231	0000950170-24-087441	1318605	1	4	2024-07-29	\N	\N
232	0000950170-24-126580	1318605	1	4	2024-11-13	\N	\N
233	0000950170-24-128931	1318605	1	4	2024-11-19	\N	\N
234	0000950170-24-133415	1318605	1	4	2024-12-04	\N	\N
235	0000950170-24-134264	1318605	1	4	2024-12-06	\N	\N
236	0000950170-24-141705	1318605	1	4	2024-12-31	\N	\N
237	0000950170-25-003585	1318605	1	4	2025-01-08	\N	\N
238	0000950170-25-014794	1318605	1	4	2025-02-05	\N	\N
239	0001104659-25-021023	1318605	1	4	2025-03-05	\N	\N
240	0001104659-25-021101	1318605	1	4	2025-03-05	\N	\N
241	0001104659-25-043625	1318605	1	4	2025-05-01	\N	\N
242	0001104659-25-043635	1318605	1	4	2025-05-01	\N	\N
243	0001104659-25-043636	1318605	1	4	2025-05-01	\N	\N
244	0001104659-25-043637	1318605	1	4	2025-05-01	\N	\N
245	0001104659-25-043638	1318605	1	4	2025-05-01	\N	\N
246	0001104659-25-043639	1318605	1	4	2025-05-01	\N	\N
247	0001104659-25-046296	1318605	1	4	2025-05-08	\N	\N
248	0001104659-25-054371	1318605	1	4	2025-05-29	\N	\N
249	0001104659-25-054372	1318605	1	4	2025-05-29	\N	\N
250	0001104659-25-056561	1318605	1	4	2025-06-04	\N	\N
251	0001104659-25-057932	1318605	1	4	2025-06-09	\N	\N
252	0001104659-25-066775	1318605	1	4	2025-07-09	\N	\N
253	0001104659-25-068165	1318605	1	4	2025-07-15	\N	\N
254	0001104659-25-073753	1318605	1	4	2025-08-04	\N	\N
255	0001104659-25-084935	1318605	1	4	2025-08-28	\N	\N
256	0001104659-25-088703	1318605	1	4	2025-09-09	\N	\N
257	0001104659-25-089693	1318605	1	4	2025-09-15	\N	\N
258	0001104659-25-090923	1318605	1	4	2025-09-17	\N	\N
259	0001104659-25-109263	1318605	1	4	2025-11-10	\N	\N
260	0001104659-25-110597	1318605	1	4	2025-11-12	\N	\N
261	0001104659-25-119764	1318605	1	4	2025-12-09	\N	\N
262	0001104659-25-120387	1318605	1	4	2025-12-11	\N	\N
263	0001104659-25-125703	1318605	1	4	2025-12-31	\N	\N
264	0001104659-26-001460	1318605	1	4	2026-01-06	\N	\N
265	0001104659-26-021746	1318605	1	4	2026-02-27	\N	\N
266	0001104659-26-025379	1318605	1	4	2026-03-09	\N	\N
267	0001104659-26-038682	1318605	1	4	2026-04-01	\N	\N
268	0001104659-26-047678	1318605	1	4	2026-04-23	\N	\N
269	0001104659-26-055079	1318605	1	4	2026-05-04	\N	\N
270	0001104659-26-062860	1318605	1	4	2026-05-15	\N	\N
271	0001104659-26-071970	1318605	1	4	2026-06-09	\N	\N
272	0001104659-26-075213	1318605	1	4	2026-06-17	\N	\N
273	0001104659-26-106432	1318605	1	4	2026-09-09	\N	\N
274	0001494731-24-000001	1318605	1	4	2024-11-05	\N	\N
275	0001494731-24-000002	1318605	1	4	2024-12-13	\N	\N
276	0001494731-25-000001	1318605	1	4	2025-02-10	\N	\N
277	0001771340-24-000001	1318605	1	4	2024-02-23	\N	\N
278	0001771340-24-000002	1318605	1	4	2024-03-14	\N	\N
279	0001771340-24-000003	1318605	1	4	2024-06-05	\N	\N
280	0001771340-24-000004	1318605	1	4	2024-09-25	\N	\N
281	0001771340-24-000005	1318605	1	4	2024-10-28	\N	\N
282	0001771340-24-000006	1318605	1	4	2024-11-04	\N	\N
283	0001771340-24-000007	1318605	1	4	2024-11-13	\N	\N
284	0001771340-24-000008	1318605	1	4	2024-12-04	\N	\N
285	0001771340-24-000009	1318605	1	4	2024-12-09	\N	\N
286	0001771340-25-000001	1318605	1	4	2025-01-08	\N	\N
287	0001771340-25-000002	1318605	1	4	2025-02-05	\N	\N
288	0001771340-25-000003	1318605	1	4	2025-03-06	\N	\N
289	0001771340-25-000004	1318605	1	4	2025-03-12	\N	\N
290	0001771340-25-000005	1318605	1	4	2025-04-09	\N	\N
291	0001771340-25-000006	1318605	1	4	2025-04-28	\N	\N
292	0001771340-25-000007	1318605	1	4	2025-05-05	\N	\N
293	0001771340-25-000008	1318605	1	4	2025-05-13	\N	\N
294	0001771340-25-000009	1318605	1	4	2025-05-20	\N	\N
295	0001771340-25-000012	1318605	1	3	2025-06-04	\N	\N
296	0001790565-24-000001	1318605	1	4	2024-02-02	\N	\N
297	0001790565-24-000002	1318605	1	4	2024-03-04	\N	\N
298	0001790565-24-000003	1318605	1	4	2024-04-03	\N	\N
299	0001972928-24-000001	1318605	1	4	2024-03-07	\N	\N
300	0001972928-24-000002	1318605	1	4	2024-06-07	\N	\N
301	0001972928-24-000003	1318605	1	4	2024-09-09	\N	\N
302	0001972928-25-000003	1318605	1	4	2025-06-16	\N	\N
303	0001972928-25-000004	1318605	1	4	2025-09-12	\N	\N
304	0001972928-26-000001	1318605	1	4	2026-01-12	\N	\N
305	0001972928-26-000002	1318605	1	4	2026-04-02	\N	\N
306	0001213900-26-100186	1181412	2	4	2026-09-15	\N	\N
307	0001628280-26-042628	1181412	2	3	2026-06-11	\N	\N
308	0001628280-26-042629	1181412	2	3	2026-06-11	\N	\N
309	0001628280-26-042630	1181412	2	3	2026-06-11	\N	\N
310	0001628280-26-042631	1181412	2	3	2026-06-11	\N	\N
311	0001628280-26-042632	1181412	2	3	2026-06-11	\N	\N
312	0001628280-26-042633	1181412	2	3	2026-06-11	\N	\N
313	0001628280-26-042634	1181412	2	3	2026-06-11	\N	\N
314	0001628280-26-042635	1181412	2	3	2026-06-11	\N	\N
315	0001628280-26-042636	1181412	2	3	2026-06-11	\N	\N
316	0001628280-26-044069	1181412	2	4	2026-06-17	\N	\N
317	0001628280-26-044455	1181412	2	3	2026-06-18	\N	\N
318	0001628280-26-063378	1181412	2	4	2026-09-24	\N	\N
319	0000950170-24-003486	1819994	3	4	2024-01-09	\N	\N
320	0000950170-24-028259	1819994	3	4	2024-03-07	\N	\N
321	0000950170-24-028260	1819994	3	4	2024-03-07	\N	\N
322	0000950170-24-030871	1819994	3	4	2024-03-13	\N	\N
323	0000950170-24-031034	1819994	3	4	2024-03-13	\N	\N
324	0000950170-24-058623	1819994	3	4	2024-05-13	\N	\N
325	0000950170-24-058909	1819994	3	4	2024-05-13	\N	\N
326	0000950170-24-065490	1819994	3	4	2024-05-28	\N	\N
327	0000950170-24-065492	1819994	3	4	2024-05-28	\N	\N
328	0000950170-24-073927	1819994	3	4	2024-06-14	\N	\N
329	0000950170-24-073933	1819994	3	4	2024-06-14	\N	\N
330	0000950170-24-073934	1819994	3	4	2024-06-14	\N	\N
331	0000950170-24-073940	1819994	3	4	2024-06-14	\N	\N
332	0000950170-24-073941	1819994	3	4	2024-06-14	\N	\N
333	0000950170-24-073944	1819994	3	4	2024-06-14	\N	\N
334	0000950170-24-097037	1819994	3	4	2024-08-14	\N	\N
335	0000950170-24-098220	1819994	3	4	2024-08-16	\N	\N
336	0000950170-24-100256	1819994	3	3	2024-08-23	\N	\N
337	0000950170-24-100259	1819994	3	4	2024-08-23	\N	\N
338	0000950170-24-100710	1819994	3	4	2024-08-26	\N	\N
339	0000950170-24-100736	1819994	3	4	2024-08-26	\N	\N
340	0000950170-24-100739	1819994	3	4	2024-08-26	\N	\N
341	0000950170-24-101379	1819994	3	4	2024-08-28	\N	\N
342	0000950170-24-108570	1819994	3	3	2024-09-20	\N	\N
343	0000950170-24-108572	1819994	3	4	2024-09-20	\N	\N
344	0000950170-24-108829	1819994	3	4	2024-09-23	\N	\N
345	0000950170-24-108830	1819994	3	4	2024-09-23	\N	\N
346	0000950170-24-128168	1819994	3	4	2024-11-18	\N	\N
347	0000950170-24-129771	1819994	3	4	2024-11-21	\N	\N
348	0000950170-24-131564	1819994	3	4	2024-11-27	\N	\N
349	0000950170-24-131573	1819994	3	4	2024-11-27	\N	\N
350	0000950170-24-131578	1819994	3	4	2024-11-27	\N	\N
351	0000950170-24-131622	1819994	3	4	2024-11-27	\N	\N
352	0000950170-24-132993	1819994	3	4	2024-12-03	\N	\N
353	0000950170-24-133514	1819994	3	4	2024-12-04	\N	\N
354	0000950170-24-133516	1819994	3	4	2024-12-04	\N	\N
355	0000950170-24-133823	1819994	3	4	2024-12-05	\N	\N
356	0000950170-24-135859	1819994	3	4	2024-12-12	\N	\N
357	0000950170-25-004338	1819994	3	4	2025-01-10	\N	\N
358	0000950170-25-005363	1819994	3	4	2025-01-14	\N	\N
359	0000950170-25-011955	1819994	3	4	2025-01-31	\N	\N
360	0000950170-25-014481	1819994	3	4	2025-02-05	\N	\N
361	0000950170-25-015763	1819994	3	4	2025-02-06	\N	\N
362	0000950170-25-041662	1819994	3	4	2025-03-18	\N	\N
363	0000950170-25-041663	1819994	3	4	2025-03-18	\N	\N
364	0000950170-25-041670	1819994	3	4	2025-03-18	\N	\N
365	0000950170-25-079896	1819994	3	4	2025-05-30	\N	\N
366	0000950170-25-079900	1819994	3	4	2025-05-30	\N	\N
367	0000950170-25-081268	1819994	3	4	2025-06-03	\N	\N
368	0000950170-25-081272	1819994	3	4	2025-06-03	\N	\N
369	0000950170-25-081285	1819994	3	4	2025-06-03	\N	\N
370	0000950170-25-084575	1819994	3	4	2025-06-10	\N	\N
371	0000950170-25-084576	1819994	3	4	2025-06-10	\N	\N
372	0000950170-25-087606	1819994	3	4	2025-06-17	\N	\N
373	0000950170-25-087771	1819994	3	4	2025-06-18	\N	\N
374	0000950170-25-088961	1819994	3	4	2025-06-23	\N	\N
375	0000950170-25-089947	1819994	3	4	2025-06-25	\N	\N
376	0000950170-25-094409	1819994	3	4	2025-07-07	\N	\N
377	0000950170-25-098787	1819994	3	4	2025-07-25	\N	\N
378	0001104659-25-091375	1819994	3	4	2025-09-18	\N	\N
379	0002001011-25-000062	1819994	3	4	2025-08-29	\N	\N
380	0002001011-25-000063	1819994	3	4	2025-08-29	\N	\N
381	0002001011-25-000064	1819994	3	4	2025-08-29	\N	\N
382	0002001011-25-000065	1819994	3	4	2025-08-29	\N	\N
383	0002001011-25-000066	1819994	3	4	2025-08-29	\N	\N
384	0002001011-25-000067	1819994	3	4	2025-08-29	\N	\N
385	0002001011-25-000072	1819994	3	4	2025-09-17	\N	\N
386	0002001011-25-000076	1819994	3	4	2025-09-18	\N	\N
387	0002001011-25-000077	1819994	3	4	2025-09-18	\N	\N
388	0002001011-25-000078	1819994	3	4	2025-09-18	\N	\N
389	0002001011-25-000079	1819994	3	4	2025-09-22	\N	\N
390	0002001011-25-000080	1819994	3	4	2025-09-22	\N	\N
391	0002001011-25-000101	1819994	3	4	2025-11-21	\N	\N
392	0002001011-25-000106	1819994	3	4	2025-11-25	\N	\N
393	0002001011-25-000107	1819994	3	4	2025-11-25	\N	\N
394	0002001011-25-000108	1819994	3	4	2025-11-25	\N	\N
395	0002001011-25-000109	1819994	3	4	2025-11-25	\N	\N
396	0002001011-25-000110	1819994	3	4	2025-11-26	\N	\N
397	0002001011-25-000111	1819994	3	4	2025-11-26	\N	\N
398	0002001011-25-000114	1819994	3	4	2025-12-05	\N	\N
399	0002001011-25-000124	1819994	3	4	2025-12-16	\N	\N
400	0002001011-25-000126	1819994	3	4	2025-12-16	\N	\N
401	0002001011-25-000128	1819994	3	4	2025-12-18	\N	\N
402	0002001011-25-000129	1819994	3	4	2025-12-22	\N	\N
403	0002001011-25-000130	1819994	3	4	2025-12-22	\N	\N
404	0002001011-25-000131	1819994	3	4	2025-12-23	\N	\N
405	0002001011-25-000132	1819994	3	4	2025-12-30	\N	\N
406	0002001011-25-000133	1819994	3	4	2025-12-30	\N	\N
407	0002001011-25-000134	1819994	3	4	2025-12-30	\N	\N
408	0002001011-26-000001	1819994	3	4	2026-01-06	\N	\N
409	0002001011-26-000002	1819994	3	4	2026-01-06	\N	\N
410	0002001011-26-000005	1819994	3	4	2026-01-15	\N	\N
411	0002001011-26-000006	1819994	3	4	2026-01-22	\N	\N
412	0002001011-26-000019	1819994	3	4	2026-03-04	\N	\N
413	0002001011-26-000020	1819994	3	4	2026-03-04	\N	\N
414	0002001011-26-000021	1819994	3	4	2026-03-04	\N	\N
415	0002001011-26-000022	1819994	3	4	2026-03-04	\N	\N
416	0002001011-26-000025	1819994	3	4	2026-03-09	\N	\N
417	0002001011-26-000029	1819994	3	4	2026-03-24	\N	\N
418	0002001011-26-000031	1819994	3	4	2026-03-26	\N	\N
419	0002001011-26-000040	1819994	3	3	2026-04-06	\N	\N
420	0002001011-26-000048	1819994	3	4	2026-05-14	\N	\N
421	0002001011-26-000057	1819994	3	4	2026-05-22	\N	\N
422	0002001011-26-000058	1819994	3	4	2026-05-22	\N	\N
423	0002001011-26-000059	1819994	3	4	2026-05-22	\N	\N
424	0002001011-26-000060	1819994	3	4	2026-05-22	\N	\N
425	0002001011-26-000061	1819994	3	4	2026-05-22	\N	\N
426	0002001011-26-000062	1819994	3	4	2026-05-22	\N	\N
427	0002001011-26-000072	1819994	3	4	2026-05-28	\N	\N
428	0002001011-26-000073	1819994	3	4	2026-05-28	\N	\N
429	0002001011-26-000074	1819994	3	4	2026-05-28	\N	\N
430	0002001011-26-000076	1819994	3	4	2026-05-28	\N	\N
431	0002001011-26-000077	1819994	3	4	2026-05-28	\N	\N
432	0002001011-26-000079	1819994	3	4	2026-06-01	\N	\N
433	0002001011-26-000080	1819994	3	4	2026-06-01	\N	\N
434	0002001011-26-000081	1819994	3	4	2026-06-01	\N	\N
435	0002001011-26-000082	1819994	3	4	2026-06-01	\N	\N
436	0002001011-26-000084	1819994	3	4	2026-06-02	\N	\N
437	0002001011-26-000085	1819994	3	4	2026-06-02	\N	\N
438	0002001011-26-000092	1819994	3	3	2026-06-05	\N	\N
439	0002001011-26-000093	1819994	3	4	2026-06-05	\N	\N
440	0002001011-26-000094	1819994	3	4	2026-06-05	\N	\N
441	0002001011-26-000095	1819994	3	4	2026-06-05	\N	\N
442	0002001011-26-000105	1819994	3	4	2026-06-18	\N	\N
443	0002001011-26-000109	1819994	3	4	2026-07-08	\N	\N
444	0002001011-26-000116	1819994	3	4	2026-08-18	\N	\N
445	0002001011-26-000125	1819994	3	4	2026-08-26	\N	\N
446	0002001011-26-000126	1819994	3	4	2026-08-26	\N	\N
447	0002001011-26-000127	1819994	3	4	2026-08-26	\N	\N
448	0002001011-26-000128	1819994	3	4	2026-08-26	\N	\N
449	0002001011-26-000129	1819994	3	4	2026-08-26	\N	\N
450	0002001011-26-000132	1819994	3	4	2026-08-28	\N	\N
451	0002001011-26-000133	1819994	3	4	2026-08-28	\N	\N
452	0002001011-26-000135	1819994	3	4	2026-09-02	\N	\N
453	0002001011-26-000136	1819994	3	4	2026-09-04	\N	\N
454	0002001011-26-000143	1819994	3	4	2026-10-02	\N	\N
455	0002001011-26-000144	1819994	3	4	2026-11-03	\N	\N
456	0002001011-26-000145	1819994	3	4	2026-11-03	\N	\N
457	0001225208-24-000180	936468	4	4	2024-01-03	\N	\N
458	0001225208-24-000181	936468	4	4	2024-01-03	\N	\N
459	0001225208-24-000182	936468	4	4	2024-01-03	\N	\N
460	0001225208-24-000778	936468	4	3	2024-01-11	\N	\N
461	0001225208-24-002545	936468	4	4	2024-02-20	\N	\N
462	0001225208-24-002546	936468	4	4	2024-02-20	\N	\N
463	0001225208-24-002547	936468	4	4	2024-02-20	\N	\N
464	0001225208-24-002548	936468	4	4	2024-02-20	\N	\N
465	0001225208-24-002549	936468	4	4	2024-02-20	\N	\N
466	0001225208-24-002550	936468	4	4	2024-02-20	\N	\N
467	0001225208-24-002551	936468	4	4	2024-02-20	\N	\N
468	0001225208-24-002552	936468	4	4	2024-02-20	\N	\N
469	0001225208-24-002553	936468	4	4	2024-02-20	\N	\N
470	0001225208-24-002554	936468	4	4	2024-02-20	\N	\N
471	0001225208-24-002555	936468	4	4	2024-02-20	\N	\N
472	0001225208-24-002556	936468	4	4	2024-02-20	\N	\N
473	0001225208-24-002984	936468	4	4	2024-02-26	\N	\N
474	0001225208-24-002985	936468	4	4	2024-02-26	\N	\N
475	0001225208-24-002986	936468	4	4	2024-02-26	\N	\N
476	0001225208-24-002987	936468	4	4	2024-02-26	\N	\N
477	0001225208-24-002988	936468	4	4	2024-02-26	\N	\N
478	0001225208-24-002989	936468	4	4	2024-02-26	\N	\N
479	0001225208-24-002990	936468	4	4	2024-02-26	\N	\N
480	0001225208-24-002991	936468	4	4	2024-02-26	\N	\N
481	0001225208-24-002992	936468	4	4	2024-02-26	\N	\N
482	0001225208-24-002993	936468	4	4	2024-02-26	\N	\N
483	0001225208-24-003160	936468	4	4	2024-02-27	\N	\N
484	0001225208-24-003161	936468	4	4	2024-02-27	\N	\N
485	0001225208-24-003162	936468	4	4	2024-02-27	\N	\N
486	0001225208-24-003163	936468	4	4	2024-02-27	\N	\N
487	0001225208-24-003164	936468	4	4	2024-02-27	\N	\N
488	0001225208-24-003165	936468	4	4	2024-02-27	\N	\N
489	0001225208-24-003166	936468	4	4	2024-02-27	\N	\N
490	0001225208-24-003167	936468	4	4	2024-02-27	\N	\N
491	0001225208-24-003718	936468	4	4	2024-03-05	\N	\N
492	0001225208-24-003889	936468	4	4	2024-03-07	\N	\N
493	0001225208-24-003890	936468	4	4	2024-03-07	\N	\N
494	0001225208-24-003891	936468	4	4	2024-03-07	\N	\N
495	0001225208-24-003892	936468	4	4	2024-03-07	\N	\N
496	0001225208-24-004845	936468	4	4	2024-04-02	\N	\N
497	0001225208-24-004846	936468	4	4	2024-04-02	\N	\N
498	0001225208-24-004932	936468	4	4	2024-04-03	\N	\N
499	0001225208-24-004933	936468	4	4	2024-04-03	\N	\N
500	0001225208-24-005373	936468	4	4	2024-04-29	\N	\N
501	0001225208-24-006636	936468	4	3	2024-06-04	\N	\N
502	0001225208-24-006639	936468	4	4	2024-06-05	\N	\N
503	0001225208-24-007242	936468	4	4	2024-07-02	\N	\N
504	0001225208-24-007243	936468	4	4	2024-07-02	\N	\N
505	0001225208-24-007579	936468	4	4	2024-07-25	\N	\N
506	0001225208-24-007828	936468	4	4	2024-08-05	\N	\N
507	0001225208-24-009036	936468	4	4	2024-10-02	\N	\N
508	0001225208-24-009037	936468	4	4	2024-10-02	\N	\N
509	0001225208-24-009531	936468	4	4	2024-10-28	\N	\N
510	0001225208-24-010689	936468	4	4	2024-12-10	\N	\N
511	0001225208-24-010690	936468	4	4	2024-12-10	\N	\N
512	0001225208-24-010691	936468	4	4	2024-12-10	\N	\N
513	0001225208-24-010692	936468	4	4	2024-12-10	\N	\N
514	0001225208-24-010693	936468	4	4	2024-12-10	\N	\N
515	0001225208-24-011012	936468	4	3	2024-12-26	\N	\N
516	0001225208-25-000158	936468	4	4	2025-01-03	\N	\N
517	0001225208-25-000159	936468	4	4	2025-01-03	\N	\N
518	0001225208-25-000696	936468	4	3	2025-01-16	\N	\N
519	0001225208-25-002017	936468	4	4	2025-02-19	\N	\N
520	0001225208-25-002018	936468	4	4	2025-02-19	\N	\N
521	0001225208-25-002019	936468	4	4	2025-02-19	\N	\N
522	0001225208-25-002020	936468	4	4	2025-02-19	\N	\N
523	0001225208-25-002021	936468	4	4	2025-02-19	\N	\N
524	0001225208-25-002022	936468	4	4	2025-02-19	\N	\N
525	0001225208-25-002023	936468	4	4	2025-02-19	\N	\N
526	0001225208-25-002024	936468	4	4	2025-02-19	\N	\N
527	0001225208-25-002025	936468	4	4	2025-02-19	\N	\N
528	0001225208-25-002026	936468	4	4	2025-02-19	\N	\N
529	0001225208-25-002422	936468	4	4	2025-02-25	\N	\N
530	0001225208-25-002423	936468	4	4	2025-02-25	\N	\N
531	0001225208-25-002424	936468	4	4	2025-02-25	\N	\N
532	0001225208-25-002425	936468	4	4	2025-02-25	\N	\N
533	0001225208-25-002426	936468	4	4	2025-02-25	\N	\N
534	0001225208-25-002427	936468	4	4	2025-02-25	\N	\N
535	0001225208-25-002428	936468	4	4	2025-02-25	\N	\N
536	0001225208-25-002429	936468	4	4	2025-02-25	\N	\N
537	0001225208-25-002629	936468	4	4	2025-02-28	\N	\N
538	0001225208-25-002630	936468	4	4	2025-02-28	\N	\N
539	0001225208-25-002631	936468	4	4	2025-02-28	\N	\N
540	0001225208-25-002632	936468	4	4	2025-02-28	\N	\N
541	0001225208-25-002633	936468	4	4	2025-02-28	\N	\N
542	0001225208-25-002634	936468	4	4	2025-02-28	\N	\N
543	0001225208-25-002635	936468	4	4	2025-02-28	\N	\N
544	0001225208-25-002636	936468	4	4	2025-02-28	\N	\N
545	0001225208-25-002637	936468	4	4	2025-02-28	\N	\N
546	0001225208-25-002638	936468	4	4	2025-02-28	\N	\N
547	0001225208-25-003940	936468	4	4	2025-04-02	\N	\N
548	0001225208-25-003941	936468	4	4	2025-04-02	\N	\N
549	0001225208-25-004432	936468	4	3	2025-04-25	\N	\N
550	0001225208-25-006422	936468	4	4	2025-07-02	\N	\N
551	0001225208-25-006423	936468	4	4	2025-07-02	\N	\N
552	0001225208-25-008225	936468	4	4	2025-10-02	\N	\N
553	0001225208-25-008226	936468	4	4	2025-10-02	\N	\N
554	0001225208-25-008746	936468	4	4	2025-10-27	\N	\N
555	0001225208-25-008753	936468	4	4	2025-10-28	\N	\N
556	0001225208-25-009808	936468	4	4	2025-12-09	\N	\N
557	0001225208-25-009809	936468	4	4	2025-12-09	\N	\N
558	0001225208-25-009810	936468	4	4	2025-12-09	\N	\N
559	0001225208-25-009811	936468	4	4	2025-12-09	\N	\N
560	0001225208-25-009812	936468	4	4	2025-12-09	\N	\N
561	0001225208-26-000144	936468	4	4	2026-01-05	\N	\N
562	0001225208-26-000145	936468	4	4	2026-01-05	\N	\N
563	0001225208-26-002077	936468	4	4	2026-02-18	\N	\N
564	0001225208-26-002078	936468	4	4	2026-02-18	\N	\N
565	0001225208-26-002079	936468	4	4	2026-02-18	\N	\N
566	0001225208-26-002080	936468	4	4	2026-02-18	\N	\N
567	0001225208-26-002081	936468	4	4	2026-02-18	\N	\N
568	0001225208-26-002082	936468	4	4	2026-02-18	\N	\N
569	0001225208-26-002083	936468	4	4	2026-02-18	\N	\N
570	0001225208-26-002084	936468	4	4	2026-02-18	\N	\N
571	0001225208-26-002085	936468	4	4	2026-02-18	\N	\N
572	0001225208-26-002576	936468	4	4	2026-02-24	\N	\N
573	0001225208-26-002577	936468	4	4	2026-02-24	\N	\N
574	0001225208-26-002578	936468	4	4	2026-02-24	\N	\N
575	0001225208-26-002579	936468	4	4	2026-02-24	\N	\N
576	0001225208-26-002580	936468	4	4	2026-02-24	\N	\N
577	0001225208-26-002581	936468	4	4	2026-02-24	\N	\N
578	0001225208-26-002582	936468	4	4	2026-02-24	\N	\N
579	0001225208-26-002583	936468	4	4	2026-02-24	\N	\N
580	0001225208-26-002584	936468	4	4	2026-02-24	\N	\N
581	0001225208-26-002766	936468	4	4	2026-02-27	\N	\N
582	0001225208-26-002767	936468	4	4	2026-02-27	\N	\N
583	0001225208-26-002768	936468	4	4	2026-02-27	\N	\N
584	0001225208-26-002769	936468	4	4	2026-02-27	\N	\N
585	0001225208-26-002770	936468	4	4	2026-02-27	\N	\N
586	0001225208-26-002771	936468	4	4	2026-02-27	\N	\N
587	0001225208-26-002772	936468	4	4	2026-02-27	\N	\N
588	0001225208-26-002773	936468	4	4	2026-02-27	\N	\N
589	0001225208-26-002774	936468	4	4	2026-02-27	\N	\N
590	0001225208-26-003644	936468	4	4	2026-03-13	\N	\N
591	0001225208-26-004196	936468	4	4	2026-04-02	\N	\N
592	0001225208-26-004197	936468	4	4	2026-04-02	\N	\N
593	0001225208-26-004198	936468	4	4	2026-04-02	\N	\N
594	0001225208-26-004406	936468	4	4	2026-04-06	\N	\N
595	0001225208-26-005909	936468	4	3	2026-06-10	\N	\N
596	0001225208-26-006049	936468	4	4	2026-06-15	\N	\N
597	0001225208-26-006398	936468	4	4	2026-07-02	\N	\N
598	0001225208-26-006399	936468	4	4	2026-07-02	\N	\N
599	0001225208-26-006930	936468	4	4	2026-08-04	\N	\N
600	0001225208-26-007101	936468	4	4	2026-08-13	\N	\N
601	0001225208-26-007142	936468	4	4	2026-08-17	\N	\N
602	0001225208-26-008066	936468	4	4	2026-10-01	\N	\N
603	0001225208-26-008067	936468	4	4	2026-10-01	\N	\N
604	0001225208-26-008537	936468	4	4	2026-10-27	\N	\N
605	0001225208-26-008538	936468	4	4	2026-10-27	\N	\N
606	0001225208-24-004955	12927	5	4	2024-04-03	\N	\N
607	0001225208-24-005007	12927	5	3	2024-04-08	\N	\N
608	0001225208-24-007296	12927	5	4	2024-07-03	\N	\N
609	0001225208-24-007298	12927	5	4	2024-07-03	\N	\N
610	0001225208-24-007299	12927	5	4	2024-07-03	\N	\N
611	0001225208-24-007300	12927	5	4	2024-07-03	\N	\N
612	0001225208-24-007301	12927	5	4	2024-07-03	\N	\N
613	0001225208-24-007302	12927	5	4	2024-07-03	\N	\N
614	0001225208-24-007303	12927	5	4	2024-07-03	\N	\N
615	0001225208-24-007304	12927	5	4	2024-07-03	\N	\N
616	0001225208-24-007305	12927	5	4	2024-07-03	\N	\N
617	0001225208-24-007306	12927	5	4	2024-07-03	\N	\N
618	0001225208-24-007964	12927	5	3	2024-08-09	\N	\N
619	0001225208-24-007965	12927	5	4	2024-08-09	\N	\N
620	0001225208-24-008307	12927	5	4	2024-08-29	\N	\N
621	0001225208-24-008493	12927	5	4	2024-09-05	\N	\N
622	0001225208-24-009132	12927	5	4	2024-10-03	\N	\N
623	0001225208-24-009133	12927	5	4	2024-10-03	\N	\N
624	0001225208-24-009134	12927	5	4	2024-10-03	\N	\N
625	0001225208-24-009136	12927	5	4	2024-10-03	\N	\N
626	0001225208-24-009137	12927	5	4	2024-10-03	\N	\N
627	0001225208-24-009138	12927	5	4	2024-10-03	\N	\N
628	0001225208-24-009139	12927	5	4	2024-10-03	\N	\N
629	0001225208-24-009140	12927	5	4	2024-10-03	\N	\N
630	0001225208-24-009141	12927	5	4	2024-10-03	\N	\N
631	0001225208-24-009142	12927	5	4	2024-10-03	\N	\N
632	0001225208-24-010538	12927	5	4	2024-12-04	\N	\N
633	0001225208-24-010540	12927	5	4	2024-12-04	\N	\N
634	0001225208-24-010541	12927	5	4	2024-12-04	\N	\N
635	0001225208-24-010542	12927	5	4	2024-12-04	\N	\N
636	0001225208-25-000062	12927	5	3	2025-01-02	\N	\N
637	0001225208-25-000296	12927	5	3	2025-01-03	\N	\N
638	0001225208-25-000297	12927	5	4	2025-01-03	\N	\N
639	0001225208-25-000398	12927	5	3	2025-01-06	\N	\N
640	0001225208-25-000399	12927	5	4	2025-01-06	\N	\N
641	0001225208-25-000400	12927	5	4	2025-01-06	\N	\N
642	0001225208-25-000401	12927	5	4	2025-01-06	\N	\N
643	0001225208-25-000402	12927	5	4	2025-01-06	\N	\N
644	0001225208-25-000403	12927	5	4	2025-01-06	\N	\N
645	0001225208-25-000404	12927	5	4	2025-01-06	\N	\N
646	0001225208-25-000405	12927	5	4	2025-01-06	\N	\N
647	0001225208-25-000406	12927	5	4	2025-01-06	\N	\N
648	0001225208-25-000407	12927	5	4	2025-01-06	\N	\N
649	0001225208-25-000408	12927	5	4	2025-01-06	\N	\N
650	0001225208-25-000409	12927	5	4	2025-01-06	\N	\N
651	0001225208-25-000717	12927	5	4	2025-01-17	\N	\N
652	0001225208-25-002127	12927	5	4	2025-02-20	\N	\N
653	0001225208-25-002128	12927	5	4	2025-02-20	\N	\N
654	0001225208-25-002129	12927	5	4	2025-02-20	\N	\N
655	0001225208-25-002130	12927	5	4	2025-02-20	\N	\N
656	0001225208-25-002131	12927	5	4	2025-02-20	\N	\N
657	0001225208-25-002132	12927	5	4	2025-02-20	\N	\N
658	0001225208-25-002133	12927	5	4	2025-02-20	\N	\N
659	0001225208-25-002134	12927	5	4	2025-02-20	\N	\N
660	0001225208-25-002181	12927	5	4	2025-02-21	\N	\N
661	0001225208-25-002182	12927	5	4	2025-02-21	\N	\N
662	0001225208-25-002183	12927	5	4	2025-02-21	\N	\N
663	0001225208-25-002184	12927	5	4	2025-02-21	\N	\N
664	0001225208-25-002185	12927	5	4	2025-02-21	\N	\N
665	0001225208-25-002186	12927	5	4	2025-02-21	\N	\N
666	0001225208-25-002187	12927	5	4	2025-02-21	\N	\N
667	0001225208-25-002188	12927	5	4	2025-02-21	\N	\N
668	0001225208-25-002189	12927	5	4	2025-02-21	\N	\N
669	0001225208-25-002190	12927	5	4	2025-02-21	\N	\N
670	0001225208-25-002193	12927	5	4	2025-02-21	\N	\N
671	0001225208-25-002506	12927	5	3	2025-02-26	\N	\N
672	0001225208-25-002509	12927	5	4	2025-02-26	\N	\N
673	0001225208-25-002628	12927	5	4	2025-02-28	\N	\N
674	0001225208-25-003250	12927	5	4	2025-03-11	\N	\N
675	0001225208-25-004029	12927	5	4	2025-04-03	\N	\N
676	0001225208-25-004030	12927	5	4	2025-04-03	\N	\N
677	0001225208-25-004031	12927	5	4	2025-04-03	\N	\N
678	0001225208-25-004032	12927	5	4	2025-04-03	\N	\N
679	0001225208-25-004033	12927	5	4	2025-04-03	\N	\N
680	0001225208-25-004034	12927	5	4	2025-04-03	\N	\N
681	0001225208-25-004035	12927	5	4	2025-04-03	\N	\N
682	0001225208-25-004036	12927	5	4	2025-04-03	\N	\N
683	0001225208-25-004037	12927	5	4	2025-04-03	\N	\N
684	0001225208-25-004038	12927	5	4	2025-04-03	\N	\N
685	0001225208-25-004039	12927	5	4	2025-04-03	\N	\N
686	0001225208-25-004040	12927	5	4	2025-04-03	\N	\N
687	0001225208-25-004762	12927	5	4	2025-05-05	\N	\N
688	0001225208-25-004763	12927	5	4	2025-05-05	\N	\N
689	0001225208-25-004764	12927	5	4	2025-05-05	\N	\N
690	0001225208-25-004871	12927	5	4	2025-05-08	\N	\N
691	0001225208-25-005180	12927	5	4	2025-05-15	\N	\N
692	0001225208-25-005300	12927	5	4	2025-05-19	\N	\N
693	0001225208-25-006552	12927	5	4	2025-07-03	\N	\N
694	0001225208-25-006553	12927	5	4	2025-07-03	\N	\N
695	0001225208-25-006554	12927	5	4	2025-07-03	\N	\N
696	0001225208-25-006555	12927	5	4	2025-07-03	\N	\N
697	0001225208-25-006556	12927	5	4	2025-07-03	\N	\N
698	0001225208-25-006557	12927	5	4	2025-07-03	\N	\N
699	0001225208-25-006558	12927	5	4	2025-07-03	\N	\N
700	0001225208-25-006559	12927	5	4	2025-07-03	\N	\N
701	0001225208-25-006560	12927	5	4	2025-07-03	\N	\N
702	0001225208-25-006561	12927	5	4	2025-07-03	\N	\N
703	0001225208-25-006624	12927	5	3	2025-07-10	\N	\N
704	0001225208-25-006914	12927	5	4	2025-07-31	\N	\N
705	0001225208-25-006915	12927	5	4	2025-07-31	\N	\N
706	0001225208-25-006916	12927	5	4	2025-07-31	\N	\N
707	0001225208-25-006917	12927	5	4	2025-07-31	\N	\N
708	0001225208-25-006918	12927	5	4	2025-07-31	\N	\N
709	0001225208-25-006919	12927	5	4	2025-07-31	\N	\N
710	0001225208-25-007215	12927	5	4	2025-08-12	\N	\N
711	0001225208-25-007216	12927	5	4	2025-08-12	\N	\N
712	0001225208-25-007360	12927	5	3	2025-08-19	\N	\N
713	0001225208-25-007361	12927	5	4	2025-08-19	\N	\N
714	0001225208-25-007405	12927	5	4	2025-08-21	\N	\N
715	0001225208-25-007730	12927	5	4	2025-09-03	\N	\N
716	0001225208-25-008490	12927	5	4	2025-10-03	\N	\N
717	0001225208-25-008491	12927	5	4	2025-10-03	\N	\N
718	0001225208-25-008492	12927	5	4	2025-10-03	\N	\N
719	0001225208-25-008493	12927	5	4	2025-10-03	\N	\N
720	0001225208-25-008494	12927	5	4	2025-10-03	\N	\N
721	0001225208-25-008495	12927	5	4	2025-10-03	\N	\N
722	0001225208-25-008496	12927	5	4	2025-10-03	\N	\N
723	0001225208-25-008497	12927	5	4	2025-10-03	\N	\N
724	0001225208-25-008498	12927	5	4	2025-10-03	\N	\N
725	0001225208-25-008499	12927	5	4	2025-10-03	\N	\N
726	0001225208-25-009064	12927	5	4	2025-11-10	\N	\N
727	0001225208-25-009455	12927	5	4	2025-11-25	\N	\N
728	0001225208-25-009632	12927	5	4	2025-12-03	\N	\N
729	0001225208-25-009633	12927	5	4	2025-12-03	\N	\N
730	0001225208-25-009634	12927	5	4	2025-12-03	\N	\N
731	0001225208-25-009635	12927	5	4	2025-12-03	\N	\N
732	0001225208-25-009636	12927	5	4	2025-12-03	\N	\N
733	0001225208-25-009637	12927	5	4	2025-12-03	\N	\N
734	0001225208-25-009924	12927	5	3	2025-12-12	\N	\N
735	0001225208-26-000156	12927	5	4	2026-01-05	\N	\N
736	0001225208-26-000415	12927	5	4	2026-01-06	\N	\N
737	0001225208-26-000416	12927	5	4	2026-01-06	\N	\N
738	0001225208-26-000417	12927	5	4	2026-01-06	\N	\N
739	0001225208-26-000418	12927	5	4	2026-01-06	\N	\N
740	0001225208-26-000419	12927	5	4	2026-01-06	\N	\N
741	0001225208-26-000421	12927	5	4	2026-01-06	\N	\N
742	0001225208-26-000422	12927	5	4	2026-01-06	\N	\N
743	0001225208-26-000423	12927	5	4	2026-01-06	\N	\N
744	0001225208-26-000424	12927	5	4	2026-01-06	\N	\N
745	0001225208-26-000425	12927	5	4	2026-01-06	\N	\N
746	0001225208-26-000426	12927	5	4	2026-01-06	\N	\N
747	0001225208-26-001368	12927	5	4	2026-02-05	\N	\N
748	0001225208-26-001369	12927	5	4	2026-02-05	\N	\N
749	0001225208-26-002196	12927	5	4	2026-02-19	\N	\N
750	0001225208-26-002197	12927	5	4	2026-02-19	\N	\N
751	0001225208-26-002198	12927	5	4	2026-02-19	\N	\N
752	0001225208-26-002199	12927	5	4	2026-02-19	\N	\N
753	0001225208-26-002200	12927	5	4	2026-02-19	\N	\N
754	0001225208-26-002201	12927	5	4	2026-02-19	\N	\N
755	0001225208-26-002202	12927	5	4	2026-02-19	\N	\N
756	0001225208-26-002203	12927	5	4	2026-02-19	\N	\N
757	0001225208-26-002204	12927	5	4	2026-02-19	\N	\N
758	0001225208-26-002205	12927	5	4	2026-02-19	\N	\N
759	0001225208-26-002206	12927	5	4	2026-02-19	\N	\N
760	0001225208-26-002207	12927	5	4	2026-02-19	\N	\N
761	0001225208-26-002208	12927	5	4	2026-02-19	\N	\N
762	0001225208-26-002424	12927	5	4	2026-02-23	\N	\N
763	0001225208-26-002425	12927	5	4	2026-02-23	\N	\N
764	0001225208-26-002426	12927	5	4	2026-02-23	\N	\N
765	0001225208-26-002427	12927	5	4	2026-02-23	\N	\N
766	0001225208-26-002428	12927	5	4	2026-02-23	\N	\N
767	0001225208-26-002429	12927	5	4	2026-02-23	\N	\N
768	0001225208-26-002430	12927	5	4	2026-02-23	\N	\N
769	0001225208-26-002431	12927	5	4	2026-02-23	\N	\N
770	0001225208-26-002432	12927	5	4	2026-02-23	\N	\N
771	0001225208-26-002433	12927	5	4	2026-02-23	\N	\N
772	0001225208-26-002709	12927	5	4	2026-02-26	\N	\N
773	0001225208-26-002710	12927	5	4	2026-02-26	\N	\N
774	0001225208-26-003296	12927	5	4	2026-03-05	\N	\N
775	0001225208-26-004376	12927	5	4	2026-04-03	\N	\N
776	0001225208-26-004377	12927	5	4	2026-04-03	\N	\N
777	0001225208-26-004378	12927	5	4	2026-04-03	\N	\N
778	0001225208-26-004379	12927	5	4	2026-04-03	\N	\N
779	0001225208-26-004380	12927	5	4	2026-04-03	\N	\N
780	0001225208-26-004381	12927	5	4	2026-04-03	\N	\N
781	0001225208-26-004382	12927	5	4	2026-04-03	\N	\N
782	0001225208-26-004383	12927	5	4	2026-04-03	\N	\N
783	0001225208-26-004384	12927	5	4	2026-04-03	\N	\N
784	0001225208-26-004385	12927	5	4	2026-04-03	\N	\N
785	0001225208-26-004386	12927	5	4	2026-04-03	\N	\N
786	0001225208-26-005552	12927	5	4	2026-05-22	\N	\N
787	0001225208-26-006200	12927	5	3	2026-06-26	\N	\N
788	0001225208-26-006504	12927	5	4	2026-07-06	\N	\N
789	0001225208-26-006505	12927	5	4	2026-07-06	\N	\N
790	0001225208-26-006506	12927	5	4	2026-07-06	\N	\N
791	0001225208-26-006507	12927	5	4	2026-07-06	\N	\N
792	0001225208-26-006508	12927	5	4	2026-07-06	\N	\N
793	0001225208-26-006509	12927	5	4	2026-07-06	\N	\N
794	0001225208-26-006510	12927	5	4	2026-07-06	\N	\N
795	0001225208-26-006511	12927	5	4	2026-07-06	\N	\N
796	0001225208-26-006512	12927	5	4	2026-07-06	\N	\N
797	0001225208-26-006513	12927	5	4	2026-07-06	\N	\N
798	0001225208-26-006514	12927	5	4	2026-07-06	\N	\N
799	0001225208-26-007098	12927	5	4	2026-08-12	\N	\N
800	0001225208-26-007192	12927	5	4	2026-08-18	\N	\N
801	0001225208-26-007209	12927	5	4	2026-08-19	\N	\N
802	0001225208-26-007500	12927	5	4	2026-09-01	\N	\N
803	0001225208-26-008641	12927	5	4	2026-11-03	\N	\N
804	0001225208-26-008642	12927	5	4	2026-11-03	\N	\N
805	0001225208-26-008886	12927	5	4	2026-11-12	\N	\N
806	0001045810-24-000290	1045810	6	4	2024-09-24	\N	\N
807	0001045810-24-000292	1045810	6	4	2024-09-26	\N	\N
808	0001045810-24-000294	1045810	6	4	2024-10-01	\N	\N
809	0001045810-24-000296	1045810	6	4	2024-10-07	\N	\N
810	0001045810-24-000298	1045810	6	4	2024-10-11	\N	\N
811	0001045810-24-000302	1045810	6	3	2024-11-12	\N	\N
812	0001045810-24-000318	1045810	6	4	2024-11-27	\N	\N
813	0001045810-24-000320	1045810	6	4	2024-12-09	\N	\N
814	0001045810-24-000327	1045810	6	4	2024-12-13	\N	\N
815	0001045810-24-000330	1045810	6	4	2024-12-13	\N	\N
816	0001045810-24-000331	1045810	6	4	2024-12-13	\N	\N
817	0001045810-24-000332	1045810	6	4	2024-12-13	\N	\N
818	0001045810-24-000333	1045810	6	4	2024-12-13	\N	\N
819	0001045810-24-000335	1045810	6	4	2024-12-13	\N	\N
820	0001045810-24-000337	1045810	6	4	2024-12-20	\N	\N
821	0001045810-25-000002	1045810	6	4	2025-01-08	\N	\N
822	0001045810-25-000027	1045810	6	4	2025-03-04	\N	\N
823	0001045810-25-000033	1045810	6	4	2025-03-05	\N	\N
824	0001045810-25-000034	1045810	6	4	2025-03-05	\N	\N
825	0001045810-25-000035	1045810	6	4	2025-03-05	\N	\N
826	0001045810-25-000036	1045810	6	4	2025-03-05	\N	\N
827	0001045810-25-000037	1045810	6	4	2025-03-05	\N	\N
828	0001045810-25-000047	1045810	6	4	2025-03-12	\N	\N
829	0001045810-25-000048	1045810	6	4	2025-03-12	\N	\N
830	0001045810-25-000049	1045810	6	4	2025-03-12	\N	\N
831	0001045810-25-000050	1045810	6	4	2025-03-12	\N	\N
832	0001045810-25-000051	1045810	6	4	2025-03-12	\N	\N
833	0001045810-25-000052	1045810	6	4	2025-03-12	\N	\N
834	0001045810-25-000056	1045810	6	4	2025-03-17	\N	\N
835	0001045810-25-000065	1045810	6	4	2025-03-21	\N	\N
836	0001045810-25-000066	1045810	6	4	2025-03-21	\N	\N
837	0001045810-25-000067	1045810	6	4	2025-03-21	\N	\N
838	0001045810-25-000068	1045810	6	4	2025-03-21	\N	\N
839	0001045810-25-000069	1045810	6	4	2025-03-21	\N	\N
840	0001045810-25-000071	1045810	6	4	2025-03-21	\N	\N
841	0001045810-25-000072	1045810	6	4	2025-03-21	\N	\N
842	0001045810-25-000074	1045810	6	4	2025-03-25	\N	\N
843	0001045810-25-000123	1045810	6	4	2025-06-03	\N	\N
844	0001045810-25-000124	1045810	6	4	2025-06-03	\N	\N
845	0001045810-25-000127	1045810	6	4	2025-06-04	\N	\N
846	0001045810-25-000128	1045810	6	4	2025-06-04	\N	\N
847	0001045810-25-000130	1045810	6	4	2025-06-10	\N	\N
848	0001045810-25-000138	1045810	6	4	2025-06-23	\N	\N
849	0001045810-25-000139	1045810	6	4	2025-06-23	\N	\N
850	0001045810-25-000140	1045810	6	4	2025-06-23	\N	\N
851	0001045810-25-000141	1045810	6	4	2025-06-23	\N	\N
852	0001045810-25-000143	1045810	6	4	2025-06-23	\N	\N
853	0001045810-25-000144	1045810	6	4	2025-06-23	\N	\N
854	0001045810-25-000146	1045810	6	4	2025-06-24	\N	\N
855	0001045810-25-000148	1045810	6	4	2025-06-26	\N	\N
856	0001045810-25-000151	1045810	6	4	2025-06-27	\N	\N
857	0001045810-25-000152	1045810	6	4	2025-06-27	\N	\N
858	0001045810-25-000168	1045810	6	4	2025-06-30	\N	\N
859	0001045810-25-000169	1045810	6	4	2025-06-30	\N	\N
860	0001045810-25-000170	1045810	6	4	2025-06-30	\N	\N
861	0001045810-25-000171	1045810	6	4	2025-06-30	\N	\N
862	0001045810-25-000172	1045810	6	4	2025-06-30	\N	\N
863	0001045810-25-000173	1045810	6	4	2025-06-30	\N	\N
864	0001045810-25-000174	1045810	6	4	2025-06-30	\N	\N
865	0001045810-25-000175	1045810	6	4	2025-06-30	\N	\N
866	0001045810-25-000176	1045810	6	4	2025-06-30	\N	\N
867	0001045810-25-000177	1045810	6	4	2025-06-30	\N	\N
868	0001045810-25-000178	1045810	6	4	2025-06-30	\N	\N
869	0001045810-25-000182	1045810	6	4	2025-07-01	\N	\N
870	0001045810-25-000183	1045810	6	4	2025-07-01	\N	\N
871	0001045810-25-000186	1045810	6	4	2025-07-07	\N	\N
872	0001045810-25-000188	1045810	6	4	2025-07-10	\N	\N
873	0001045810-25-000190	1045810	6	4	2025-07-15	\N	\N
874	0001197647-26-000003	1045810	6	4	2026-06-29	\N	\N
875	0001197647-26-000005	1045810	6	4	2026-07-06	\N	\N
876	0001197647-26-000007	1045810	6	4	2026-08-07	\N	\N
877	0001197647-26-000009	1045810	6	4	2026-09-04	\N	\N
878	0001197647-26-000011	1045810	6	4	2026-10-09	\N	\N
879	0001197647-26-000013	1045810	6	4	2026-11-06	\N	\N
880	0001197649-25-000004	1045810	6	4	2025-07-07	\N	\N
881	0001197649-25-000006	1045810	6	4	2025-07-10	\N	\N
882	0001197649-25-000008	1045810	6	4	2025-07-15	\N	\N
883	0001197649-25-000010	1045810	6	4	2025-07-18	\N	\N
884	0001197649-25-000012	1045810	6	4	2025-07-23	\N	\N
885	0001197649-25-000014	1045810	6	4	2025-07-28	\N	\N
886	0001197649-25-000017	1045810	6	4	2025-07-31	\N	\N
887	0001197649-25-000019	1045810	6	4	2025-08-05	\N	\N
888	0001197649-25-000021	1045810	6	4	2025-08-08	\N	\N
889	0001197649-25-000023	1045810	6	4	2025-08-13	\N	\N
890	0001197649-25-000025	1045810	6	4	2025-08-18	\N	\N
891	0001197649-25-000027	1045810	6	4	2025-09-03	\N	\N
892	0001197649-25-000029	1045810	6	4	2025-09-08	\N	\N
893	0001197649-25-000031	1045810	6	4	2025-09-11	\N	\N
894	0001197649-25-000034	1045810	6	4	2025-09-16	\N	\N
895	0001197649-25-000036	1045810	6	4	2025-09-19	\N	\N
896	0001197649-25-000038	1045810	6	4	2025-09-24	\N	\N
897	0001197649-25-000040	1045810	6	4	2025-09-29	\N	\N
898	0001197649-25-000042	1045810	6	4	2025-10-02	\N	\N
899	0001197649-25-000044	1045810	6	4	2025-10-07	\N	\N
900	0001197649-25-000046	1045810	6	4	2025-10-10	\N	\N
901	0001197649-25-000048	1045810	6	4	2025-10-15	\N	\N
902	0001197649-25-000050	1045810	6	4	2025-10-20	\N	\N
903	0001197649-25-000052	1045810	6	4	2025-10-23	\N	\N
904	0001197649-25-000054	1045810	6	4	2025-10-28	\N	\N
905	0001197649-25-000056	1045810	6	4	2025-10-31	\N	\N
906	0001197649-25-000058	1045810	6	4	2025-12-12	\N	\N
907	0001197649-25-000061	1045810	6	4	2025-12-19	\N	\N
908	0001197649-26-000003	1045810	6	4	2026-03-04	\N	\N
909	0001197649-26-000005	1045810	6	4	2026-03-20	\N	\N
910	0001197649-26-000008	1045810	6	4	2026-06-18	\N	\N
911	0001197649-26-000010	1045810	6	4	2026-06-23	\N	\N
912	0001197649-26-000012	1045810	6	4	2026-09-18	\N	\N
913	0001197650-25-000007	1045810	6	4	2025-09-22	\N	\N
914	0001197650-25-000009	1045810	6	4	2025-12-17	\N	\N
915	0001197650-26-000002	1045810	6	4	2026-06-29	\N	\N
916	0001197652-25-000005	1045810	6	4	2025-09-03	\N	\N
917	0001197652-25-000007	1045810	6	4	2025-11-26	\N	\N
918	0001197652-25-000009	1045810	6	4	2025-12-04	\N	\N
919	0001197652-26-000003	1045810	6	4	2026-03-19	\N	\N
920	0001197652-26-000007	1045810	6	4	2026-06-29	\N	\N
921	0001199039-25-000007	1045810	6	4	2025-09-15	\N	\N
922	0001199039-25-000010	1045810	6	4	2025-09-23	\N	\N
923	0001199039-25-000012	1045810	6	4	2025-12-09	\N	\N
924	0001199039-25-000015	1045810	6	4	2025-12-22	\N	\N
925	0001199039-26-000003	1045810	6	4	2026-03-24	\N	\N
926	0001199039-26-000005	1045810	6	4	2026-06-04	\N	\N
927	0001199039-26-000007	1045810	6	4	2026-06-23	\N	\N
928	0001199039-26-000009	1045810	6	4	2026-06-29	\N	\N
929	0001199039-26-000012	1045810	6	4	2026-09-02	\N	\N
930	0001199039-26-000014	1045810	6	4	2026-09-08	\N	\N
931	0001199039-26-000016	1045810	6	4	2026-09-22	\N	\N
932	0001219888-25-000005	1045810	6	4	2025-09-04	\N	\N
933	0001219888-26-000002	1045810	6	4	2026-06-29	\N	\N
934	0001225208-24-010914	1045810	6	4	2024-12-18	\N	\N
935	0001225208-25-005831	1045810	6	4	2025-06-10	\N	\N
936	0001225208-25-006216	1045810	6	4	2025-06-30	\N	\N
937	0001243821-26-000003	1045810	6	3	2026-05-14	\N	\N
938	0001243821-26-000005	1045810	6	4	2026-06-10	\N	\N
939	0001243821-26-000007	1045810	6	4	2026-09-18	\N	\N
940	0001283854-25-000004	1045810	6	4	2025-09-03	\N	\N
941	0001283854-25-000006	1045810	6	4	2025-09-19	\N	\N
942	0001283854-25-000009	1045810	6	4	2025-12-10	\N	\N
943	0001283854-25-000011	1045810	6	4	2025-12-12	\N	\N
944	0001283854-26-000002	1045810	6	4	2026-03-04	\N	\N
945	0001283854-26-000004	1045810	6	4	2026-03-11	\N	\N
946	0001283854-26-000006	1045810	6	4	2026-03-20	\N	\N
947	0001283854-26-000008	1045810	6	4	2026-06-23	\N	\N
948	0001283854-26-000010	1045810	6	4	2026-09-18	\N	\N
949	0001284116-26-000004	1045810	6	4	2026-06-29	\N	\N
950	0001310264-26-000002	1045810	6	3	2026-07-15	\N	\N
951	0001310264-26-000008	1045810	6	4	2026-08-12	\N	\N
952	0001347842-25-000005	1045810	6	4	2025-09-19	\N	\N
953	0001347842-25-000007	1045810	6	4	2025-12-12	\N	\N
954	0001347842-26-000002	1045810	6	4	2026-01-09	\N	\N
955	0001347842-26-000004	1045810	6	4	2026-01-23	\N	\N
956	0001347842-26-000007	1045810	6	4	2026-03-04	\N	\N
957	0001347842-26-000009	1045810	6	4	2026-03-11	\N	\N
958	0001347842-26-000011	1045810	6	4	2026-03-20	\N	\N
959	0001347842-26-000013	1045810	6	4	2026-06-23	\N	\N
960	0001347842-26-000015	1045810	6	4	2026-08-24	\N	\N
961	0001415889-25-024119	1045810	6	4	2025-09-10	\N	\N
962	0001526111-25-000003	1045810	6	4	2025-06-23	\N	\N
963	0001526111-25-000006	1045810	6	4	2025-09-19	\N	\N
964	0001526111-25-000008	1045810	6	4	2025-12-12	\N	\N
965	0001526111-25-000011	1045810	6	4	2025-12-22	\N	\N
966	0001526111-26-000002	1045810	6	4	2026-01-06	\N	\N
967	0001526111-26-000005	1045810	6	4	2026-03-20	\N	\N
968	0001588670-25-000003	1045810	6	4	2025-07-17	\N	\N
969	0001588670-25-000006	1045810	6	4	2025-08-06	\N	\N
970	0001588670-25-000009	1045810	6	4	2025-09-19	\N	\N
971	0001588670-25-000011	1045810	6	4	2025-10-23	\N	\N
972	0001588670-25-000013	1045810	6	4	2025-11-05	\N	\N
973	0001588670-25-000015	1045810	6	4	2025-12-12	\N	\N
974	0001588670-25-000017	1045810	6	4	2025-12-19	\N	\N
975	0001588670-26-000002	1045810	6	4	2026-01-15	\N	\N
976	0001588670-26-000004	1045810	6	4	2026-02-06	\N	\N
977	0001588670-26-000006	1045810	6	4	2026-03-04	\N	\N
978	0001588670-26-000008	1045810	6	4	2026-03-11	\N	\N
979	0001588670-26-000010	1045810	6	4	2026-03-20	\N	\N
980	0001588670-26-000012	1045810	6	4	2026-06-23	\N	\N
981	0001588670-26-000014	1045810	6	4	2026-09-18	\N	\N
982	0001636665-25-000006	1045810	6	4	2025-09-23	\N	\N
983	0001636665-26-000002	1045810	6	4	2026-01-23	\N	\N
984	0001696841-25-000004	1045810	6	4	2025-09-19	\N	\N
985	0001696841-25-000006	1045810	6	4	2025-12-12	\N	\N
986	0001696841-26-000002	1045810	6	4	2026-03-04	\N	\N
987	0001696841-26-000004	1045810	6	4	2026-03-11	\N	\N
988	0001696841-26-000006	1045810	6	4	2026-03-20	\N	\N
989	0001696841-26-000008	1045810	6	4	2026-06-23	\N	\N
990	0001696841-26-000010	1045810	6	4	2026-09-02	\N	\N
991	0001696841-26-000012	1045810	6	4	2026-09-18	\N	\N
992	0001696841-26-000014	1045810	6	4	2026-09-23	\N	\N
993	0001725292-26-000002	1045810	6	4	2026-03-20	\N	\N
994	0001725292-26-000004	1045810	6	4	2026-06-29	\N	\N
995	0001768670-25-000005	1045810	6	4	2025-09-03	\N	\N
996	0001768670-25-000008	1045810	6	4	2025-09-16	\N	\N
997	0001768670-26-000002	1045810	6	4	2026-06-05	\N	\N
998	0001768670-26-000004	1045810	6	4	2026-06-29	\N	\N
999	0001818224-25-000005	1045810	6	4	2025-11-26	\N	\N
1000	0001818224-26-000002	1045810	6	4	2026-03-17	\N	\N
1001	0001818224-26-000004	1045810	6	4	2026-05-29	\N	\N
1002	0001818224-26-000006	1045810	6	4	2026-06-29	\N	\N
1003	0002152188-26-000003	1045810	6	3	2026-09-03	\N	\N
1004	0002152188-26-000005	1045810	6	4	2026-09-11	\N	\N
1005	0000915913-24-000006	915913	7	4	2024-01-03	\N	\N
1006	0000915913-24-000007	915913	7	4	2024-01-03	\N	\N
1007	0000915913-24-000008	915913	7	4	2024-01-03	\N	\N
1008	0000915913-24-000009	915913	7	4	2024-01-03	\N	\N
1009	0000915913-24-000010	915913	7	4	2024-01-03	\N	\N
1010	0000915913-24-000018	915913	7	4	2024-02-21	\N	\N
1011	0000915913-24-000028	915913	7	4	2024-02-26	\N	\N
1012	0000915913-24-000030	915913	7	4	2024-02-26	\N	\N
1013	0000915913-24-000031	915913	7	4	2024-02-26	\N	\N
1014	0000915913-24-000033	915913	7	4	2024-02-26	\N	\N
1015	0000915913-24-000035	915913	7	4	2024-02-26	\N	\N
1016	0000915913-24-000037	915913	7	4	2024-02-26	\N	\N
1017	0000915913-24-000039	915913	7	4	2024-02-26	\N	\N
1018	0000915913-24-000041	915913	7	4	2024-02-26	\N	\N
1019	0000915913-24-000051	915913	7	4	2024-02-28	\N	\N
1020	0000915913-24-000052	915913	7	4	2024-02-28	\N	\N
1021	0000915913-24-000053	915913	7	4	2024-02-28	\N	\N
1022	0000915913-24-000055	915913	7	4	2024-02-28	\N	\N
1023	0000915913-24-000057	915913	7	4	2024-02-28	\N	\N
1024	0000915913-24-000059	915913	7	4	2024-02-28	\N	\N
1025	0000915913-24-000061	915913	7	4	2024-02-28	\N	\N
1026	0000915913-24-000062	915913	7	4	2024-02-28	\N	\N
1027	0000915913-24-000064	915913	7	4	2024-02-28	\N	\N
1028	0000915913-24-000069	915913	7	4	2024-03-01	\N	\N
1029	0000915913-24-000070	915913	7	4	2024-03-01	\N	\N
1030	0000915913-24-000071	915913	7	4	2024-03-01	\N	\N
1031	0000915913-24-000072	915913	7	4	2024-03-01	\N	\N
1032	0000915913-24-000110	915913	7	4	2024-05-14	\N	\N
1033	0000915913-24-000111	915913	7	3	2024-05-14	\N	\N
1034	0000915913-24-000113	915913	7	4	2024-05-15	\N	\N
1035	0000915913-24-000125	915913	7	4	2024-07-03	\N	\N
1036	0000915913-24-000126	915913	7	4	2024-07-03	\N	\N
1037	0000915913-24-000127	915913	7	4	2024-07-03	\N	\N
1038	0000915913-24-000128	915913	7	4	2024-07-03	\N	\N
1039	0000915913-24-000129	915913	7	4	2024-07-03	\N	\N
1040	0000915913-24-000130	915913	7	4	2024-07-03	\N	\N
1041	0000915913-24-000131	915913	7	4	2024-07-03	\N	\N
1042	0000915913-24-000132	915913	7	4	2024-07-03	\N	\N
1043	0000915913-24-000133	915913	7	4	2024-07-03	\N	\N
1044	0000915913-24-000149	915913	7	3	2024-10-16	\N	\N
1045	0000915913-24-000160	915913	7	4	2024-11-08	\N	\N
1046	0000915913-24-000164	915913	7	3	2024-11-19	\N	\N
1047	0000915913-24-000166	915913	7	4	2024-11-20	\N	\N
1048	0000915913-24-000168	915913	7	4	2024-12-06	\N	\N
1049	0000915913-25-000007	915913	7	4	2025-01-03	\N	\N
1050	0000915913-25-000008	915913	7	4	2025-01-03	\N	\N
1051	0000915913-25-000009	915913	7	4	2025-01-03	\N	\N
1052	0000915913-25-000010	915913	7	4	2025-01-03	\N	\N
1053	0000915913-25-000011	915913	7	4	2025-01-03	\N	\N
1054	0000915913-25-000012	915913	7	4	2025-01-03	\N	\N
1055	0000915913-25-000014	915913	7	4	2025-01-30	\N	\N
1056	0000915913-25-000033	915913	7	4	2025-02-27	\N	\N
1057	0000915913-25-000034	915913	7	4	2025-02-27	\N	\N
1058	0000915913-25-000035	915913	7	4	2025-02-27	\N	\N
1059	0000915913-25-000036	915913	7	4	2025-02-27	\N	\N
1060	0000915913-25-000037	915913	7	4	2025-02-27	\N	\N
1061	0000915913-25-000044	915913	7	4	2025-02-28	\N	\N
1062	0000915913-25-000045	915913	7	4	2025-02-28	\N	\N
1063	0000915913-25-000046	915913	7	4	2025-02-28	\N	\N
1064	0000915913-25-000047	915913	7	4	2025-02-28	\N	\N
1065	0000915913-25-000048	915913	7	4	2025-02-28	\N	\N
1066	0000915913-25-000049	915913	7	4	2025-02-28	\N	\N
1067	0000915913-25-000059	915913	7	4	2025-03-03	\N	\N
1068	0000915913-25-000060	915913	7	4	2025-03-03	\N	\N
1069	0000915913-25-000061	915913	7	4	2025-03-03	\N	\N
1070	0000915913-25-000062	915913	7	4	2025-03-03	\N	\N
1071	0000915913-25-000063	915913	7	4	2025-03-03	\N	\N
1072	0000915913-25-000064	915913	7	4	2025-03-03	\N	\N
1073	0000915913-25-000065	915913	7	4	2025-03-03	\N	\N
1074	0000915913-25-000066	915913	7	4	2025-03-03	\N	\N
1075	0000915913-25-000067	915913	7	4	2025-03-03	\N	\N
1076	0000915913-25-000117	915913	7	4	2025-07-03	\N	\N
1077	0000915913-25-000118	915913	7	4	2025-07-03	\N	\N
1078	0000915913-25-000119	915913	7	4	2025-07-03	\N	\N
1079	0000915913-25-000120	915913	7	4	2025-07-03	\N	\N
1080	0000915913-25-000121	915913	7	4	2025-07-03	\N	\N
1081	0000915913-25-000122	915913	7	4	2025-07-03	\N	\N
1082	0000915913-25-000123	915913	7	4	2025-07-03	\N	\N
1083	0000915913-25-000124	915913	7	4	2025-07-03	\N	\N
1084	0000915913-25-000125	915913	7	4	2025-07-03	\N	\N
1085	0000915913-25-000138	915913	7	3	2025-08-08	\N	\N
1086	0000915913-25-000139	915913	7	4	2025-08-08	\N	\N
1087	0000915913-25-000146	915913	7	3	2025-08-21	\N	\N
1088	0000915913-25-000154	915913	7	4	2025-10-28	\N	\N
1089	0000915913-25-000163	915913	7	4	2025-11-10	\N	\N
1090	0000915913-26-000003	915913	7	4	2026-01-02	\N	\N
1091	0000915913-26-000020	915913	7	4	2026-02-20	\N	\N
1092	0000915913-26-000026	915913	7	4	2026-03-02	\N	\N
1093	0000915913-26-000062	915913	7	4	2026-04-02	\N	\N
1094	0000915913-26-000080	915913	7	4	2026-05-19	\N	\N
1095	0000915913-26-000096	915913	7	3	2026-07-23	\N	\N
1096	0000915913-26-000097	915913	7	4	2026-07-23	\N	\N
1097	0000915913-26-000109	915913	7	3	2026-08-25	\N	\N
1098	0000915913-26-000111	915913	7	4	2026-09-03	\N	\N
1099	0000915913-26-000113	915913	7	4	2026-09-16	\N	\N
1100	0000915913-26-000114	915913	7	4	2026-09-16	\N	\N
1101	0000915913-26-000115	915913	7	4	2026-09-16	\N	\N
1102	0000915913-26-000120	915913	7	4	2026-10-02	\N	\N
1103	0000915913-26-000131	915913	7	4	2026-11-10	\N	\N
1104	0001143210-26-000003	915913	7	4	2026-07-06	\N	\N
1105	0001235612-26-000002	915913	7	4	2026-07-06	\N	\N
1106	0001254782-26-000002	915913	7	4	2026-07-06	\N	\N
1107	0001362208-26-000001	915913	7	3	2026-03-02	\N	\N
1108	0001362208-26-000003	915913	7	4	2026-07-06	\N	\N
1109	0001396415-26-000003	915913	7	4	2026-03-02	\N	\N
1110	0001396415-26-000006	915913	7	4	2026-03-04	\N	\N
1111	0001396415-26-000010	915913	7	4	2026-03-12	\N	\N
1112	0001414921-26-000002	915913	7	4	2026-07-06	\N	\N
1113	0001568721-26-000002	915913	7	4	2026-02-26	\N	\N
1114	0001568721-26-000003	915913	7	4	2026-03-02	\N	\N
1115	0001568721-26-000005	915913	7	4	2026-03-04	\N	\N
1116	0001585657-26-000004	915913	7	4	2026-03-10	\N	\N
1117	0001585657-26-000007	915913	7	4	2026-07-06	\N	\N
1118	0001624621-26-000002	915913	7	4	2026-02-23	\N	\N
1119	0001624621-26-000004	915913	7	4	2026-02-26	\N	\N
1120	0001624621-26-000006	915913	7	4	2026-03-02	\N	\N
1121	0001624621-26-000008	915913	7	4	2026-03-04	\N	\N
1122	0001631925-26-000002	915913	7	4	2026-02-18	\N	\N
1123	0001631925-26-000004	915913	7	4	2026-02-26	\N	\N
1124	0001631925-26-000005	915913	7	4	2026-03-02	\N	\N
1125	0001631925-26-000008	915913	7	4	2026-03-04	\N	\N
1126	0001730941-26-000002	915913	7	4	2026-07-06	\N	\N
1127	0001913598-26-000002	915913	7	4	2026-07-06	\N	\N
1128	0001998940-26-000003	915913	7	4	2026-03-04	\N	\N
1129	0002001108-26-000002	915913	7	4	2026-02-26	\N	\N
1130	0002001108-26-000003	915913	7	4	2026-03-02	\N	\N
1131	0002001108-26-000005	915913	7	4	2026-03-04	\N	\N
1132	0002014946-26-000002	915913	7	4	2026-02-26	\N	\N
1133	0002014946-26-000003	915913	7	4	2026-03-02	\N	\N
1134	0002014946-26-000005	915913	7	4	2026-03-04	\N	\N
1135	0002047429-26-000005	915913	7	3	2026-03-02	\N	\N
1136	0002047429-26-000006	915913	7	4	2026-03-02	\N	\N
1137	0002047429-26-000010	915913	7	4	2026-07-06	\N	\N
1138	0002077449-25-000003	915913	7	4	2025-10-14	\N	\N
1139	0002077449-26-000002	915913	7	4	2026-02-26	\N	\N
1140	0002077449-26-000003	915913	7	4	2026-03-02	\N	\N
1141	0002077449-26-000005	915913	7	4	2026-03-04	\N	\N
1142	0002082528-26-000001	915913	7	4	2026-02-26	\N	\N
1143	0002082528-26-000002	915913	7	4	2026-03-02	\N	\N
1144	0002082528-26-000004	915913	7	4	2026-03-04	\N	\N
1145	0001104659-24-132196	18230	8	4	2024-12-27	\N	\N
1146	0001104659-24-132197	18230	8	4	2024-12-27	\N	\N
1147	0001104659-24-132198	18230	8	4	2024-12-27	\N	\N
1148	0001104659-25-000359	18230	8	4	2025-01-02	\N	\N
1149	0001104659-25-000361	18230	8	4	2025-01-02	\N	\N
1150	0001104659-25-003505	18230	8	4	2025-01-14	\N	\N
1151	0001104659-25-003508	18230	8	4	2025-01-14	\N	\N
1152	0001104659-25-003509	18230	8	4	2025-01-14	\N	\N
1153	0001104659-25-004336	18230	8	4	2025-01-17	\N	\N
1154	0001104659-25-009475	18230	8	4	2025-02-05	\N	\N
1155	0001104659-25-012842	18230	8	4	2025-02-13	\N	\N
1156	0001104659-25-012844	18230	8	4	2025-02-13	\N	\N
1157	0001104659-25-012846	18230	8	4	2025-02-13	\N	\N
1158	0001104659-25-012847	18230	8	4	2025-02-13	\N	\N
1159	0001104659-25-012848	18230	8	4	2025-02-13	\N	\N
1160	0001104659-25-012849	18230	8	4	2025-02-13	\N	\N
1161	0001104659-25-012851	18230	8	4	2025-02-13	\N	\N
1162	0001104659-25-012853	18230	8	4	2025-02-13	\N	\N
1163	0001104659-25-012854	18230	8	4	2025-02-13	\N	\N
1164	0001104659-25-012855	18230	8	4	2025-02-13	\N	\N
1165	0001104659-25-015034	18230	8	4	2025-02-19	\N	\N
1166	0001104659-25-021006	18230	8	4	2025-03-05	\N	\N
1167	0001104659-25-021007	18230	8	4	2025-03-05	\N	\N
1168	0001104659-25-021009	18230	8	4	2025-03-05	\N	\N
1169	0001104659-25-021010	18230	8	4	2025-03-05	\N	\N
1170	0001104659-25-021011	18230	8	4	2025-03-05	\N	\N
1171	0001104659-25-021012	18230	8	4	2025-03-05	\N	\N
1172	0001104659-25-021013	18230	8	4	2025-03-05	\N	\N
1173	0001104659-25-021014	18230	8	4	2025-03-05	\N	\N
1174	0001104659-25-021037	18230	8	4	2025-03-05	\N	\N
1175	0001104659-25-021038	18230	8	4	2025-03-05	\N	\N
1176	0001104659-25-022229	18230	8	4	2025-03-10	\N	\N
1177	0001104659-25-022231	18230	8	4	2025-03-10	\N	\N
1178	0001104659-25-022232	18230	8	4	2025-03-10	\N	\N
1179	0001104659-25-024441	18230	8	4	2025-03-17	\N	\N
1180	0001104659-25-024448	18230	8	4	2025-03-17	\N	\N
1181	0001104659-25-024452	18230	8	4	2025-03-17	\N	\N
1182	0001104659-25-030979	18230	8	4	2025-04-02	\N	\N
1183	0001104659-25-037325	18230	8	4	2025-04-22	\N	\N
1184	0001104659-25-040159	18230	8	4	2025-04-28	\N	\N
1185	0001104659-25-044015	18230	8	3	2025-05-02	\N	\N
1186	0001104659-25-044528	18230	8	4	2025-05-05	\N	\N
1187	0001104659-25-045921	18230	8	4	2025-05-08	\N	\N
1188	0001104659-25-047824	18230	8	4	2025-05-13	\N	\N
1189	0001104659-25-047827	18230	8	4	2025-05-13	\N	\N
1190	0001104659-25-052916	18230	8	4	2025-05-27	\N	\N
1191	0001104659-25-052918	18230	8	4	2025-05-27	\N	\N
1192	0001104659-25-059316	18230	8	4	2025-06-13	\N	\N
1193	0001104659-25-059317	18230	8	4	2025-06-13	\N	\N
1194	0001104659-25-059319	18230	8	4	2025-06-13	\N	\N
1195	0001104659-25-059320	18230	8	4	2025-06-13	\N	\N
1196	0001104659-25-059321	18230	8	4	2025-06-13	\N	\N
1197	0001104659-25-059322	18230	8	4	2025-06-13	\N	\N
1198	0001104659-25-059323	18230	8	4	2025-06-13	\N	\N
1199	0001104659-25-059332	18230	8	4	2025-06-13	\N	\N
1200	0001104659-25-063558	18230	8	4	2025-06-27	\N	\N
1201	0001104659-25-063559	18230	8	4	2025-06-27	\N	\N
1202	0001104659-25-063560	18230	8	4	2025-06-27	\N	\N
1203	0001104659-25-065163	18230	8	4	2025-07-02	\N	\N
1204	0001104659-25-069308	18230	8	4	2025-07-21	\N	\N
1205	0001104659-25-071150	18230	8	4	2025-07-28	\N	\N
1206	0001104659-25-071152	18230	8	4	2025-07-28	\N	\N
1207	0001104659-25-071158	18230	8	4	2025-07-28	\N	\N
1208	0001104659-25-075705	18230	8	4	2025-08-08	\N	\N
1209	0001104659-25-077411	18230	8	4	2025-08-13	\N	\N
1210	0001104659-25-080182	18230	8	4	2025-08-19	\N	\N
1211	0001104659-25-080277	18230	8	4	2025-08-19	\N	\N
1212	0001104659-25-083977	18230	8	4	2025-08-27	\N	\N
1213	0001104659-25-083979	18230	8	4	2025-08-27	\N	\N
1214	0001104659-25-083981	18230	8	4	2025-08-27	\N	\N
1215	0001104659-25-087153	18230	8	4	2025-09-03	\N	\N
1216	0001104659-25-092496	18230	8	4	2025-09-23	\N	\N
1217	0001104659-25-094513	18230	8	4	2025-09-29	\N	\N
1218	0001104659-25-094519	18230	8	4	2025-09-29	\N	\N
1219	0001104659-25-094525	18230	8	4	2025-09-29	\N	\N
1220	0001104659-25-095765	18230	8	4	2025-10-01	\N	\N
1221	0001104659-25-099169	18230	8	4	2025-10-14	\N	\N
1222	0001104659-25-102540	18230	8	4	2025-10-27	\N	\N
1223	0001104659-25-102542	18230	8	4	2025-10-27	\N	\N
1224	0001104659-25-102544	18230	8	4	2025-10-27	\N	\N
1225	0001104659-25-107670	18230	8	4	2025-11-06	\N	\N
1226	0001104659-25-107671	18230	8	4	2025-11-06	\N	\N
1227	0001104659-25-108358	18230	8	4	2025-11-07	\N	\N
1228	0001104659-25-110257	18230	8	4	2025-11-12	\N	\N
1229	0001104659-25-111091	18230	8	4	2025-11-13	\N	\N
1230	0001104659-25-112198	18230	8	4	2025-11-14	\N	\N
1231	0001104659-25-114576	18230	8	4	2025-11-20	\N	\N
1232	0001104659-25-116333	18230	8	4	2025-11-26	\N	\N
1233	0001104659-25-117255	18230	8	4	2025-12-01	\N	\N
1234	0001104659-25-117256	18230	8	4	2025-12-01	\N	\N
1235	0001104659-25-117569	18230	8	4	2025-12-02	\N	\N
1236	0001104659-25-117686	18230	8	4	2025-12-02	\N	\N
1237	0001104659-25-123644	18230	8	4	2025-12-22	\N	\N
1238	0001104659-25-124749	18230	8	4	2025-12-29	\N	\N
1239	0001104659-25-124750	18230	8	4	2025-12-29	\N	\N
1240	0001104659-26-000564	18230	8	4	2026-01-05	\N	\N
1241	0001104659-26-000797	18230	8	4	2026-01-05	\N	\N
1242	0001104659-26-003275	18230	8	4	2026-01-13	\N	\N
1243	0001104659-26-003277	18230	8	4	2026-01-13	\N	\N
1244	0001104659-26-003280	18230	8	4	2026-01-13	\N	\N
1245	0001104659-26-009704	18230	8	4	2026-02-03	\N	\N
1246	0001104659-26-009707	18230	8	4	2026-02-03	\N	\N
1247	0001104659-26-010372	18230	8	4	2026-02-04	\N	\N
1248	0001104659-26-010849	18230	8	4	2026-02-05	\N	\N
1249	0001104659-26-011396	18230	8	4	2026-02-06	\N	\N
1250	0001104659-26-011484	18230	8	3	2026-02-06	\N	\N
1251	0001104659-26-011941	18230	8	4	2026-02-09	\N	\N
1252	0001104659-26-011945	18230	8	4	2026-02-09	\N	\N
1253	0001104659-26-014511	18230	8	4	2026-02-12	\N	\N
1254	0001104659-26-014514	18230	8	4	2026-02-12	\N	\N
1255	0001104659-26-014516	18230	8	4	2026-02-12	\N	\N
1256	0001104659-26-014518	18230	8	4	2026-02-12	\N	\N
1257	0001104659-26-014520	18230	8	4	2026-02-12	\N	\N
1258	0001104659-26-014522	18230	8	4	2026-02-12	\N	\N
1259	0001104659-26-014524	18230	8	4	2026-02-12	\N	\N
1260	0001104659-26-014525	18230	8	4	2026-02-12	\N	\N
1261	0001104659-26-014526	18230	8	4	2026-02-12	\N	\N
1262	0001104659-26-014528	18230	8	4	2026-02-12	\N	\N
1263	0001104659-26-015109	18230	8	4	2026-02-13	\N	\N
1264	0001104659-26-015112	18230	8	4	2026-02-13	\N	\N
1265	0001104659-26-016072	18230	8	4	2026-02-17	\N	\N
1266	0001104659-26-016981	18230	8	4	2026-02-18	\N	\N
1267	0001104659-26-016984	18230	8	4	2026-02-18	\N	\N
1268	0001104659-26-019298	18230	8	4	2026-02-24	\N	\N
1269	0001104659-26-023593	18230	8	4	2026-03-04	\N	\N
1270	0001104659-26-023595	18230	8	4	2026-03-04	\N	\N
1271	0001104659-26-023596	18230	8	4	2026-03-04	\N	\N
1272	0001104659-26-023598	18230	8	4	2026-03-04	\N	\N
1273	0001104659-26-023599	18230	8	4	2026-03-04	\N	\N
1274	0001104659-26-023600	18230	8	4	2026-03-04	\N	\N
1275	0001104659-26-023601	18230	8	4	2026-03-04	\N	\N
1276	0001104659-26-023604	18230	8	4	2026-03-04	\N	\N
1277	0001104659-26-023605	18230	8	4	2026-03-04	\N	\N
1278	0001104659-26-023607	18230	8	4	2026-03-04	\N	\N
1279	0001104659-26-023609	18230	8	4	2026-03-04	\N	\N
1280	0001104659-26-024552	18230	8	4	2026-03-06	\N	\N
1281	0001104659-26-024553	18230	8	4	2026-03-06	\N	\N
1282	0001104659-26-024554	18230	8	4	2026-03-06	\N	\N
1283	0001104659-26-024556	18230	8	4	2026-03-06	\N	\N
1284	0001104659-26-024557	18230	8	4	2026-03-06	\N	\N
1285	0001104659-26-024558	18230	8	4	2026-03-06	\N	\N
1286	0001104659-26-024559	18230	8	4	2026-03-06	\N	\N
1287	0001104659-26-024561	18230	8	4	2026-03-06	\N	\N
1288	0001104659-26-024563	18230	8	4	2026-03-06	\N	\N
1289	0001104659-26-024564	18230	8	4	2026-03-06	\N	\N
1290	0001104659-26-025676	18230	8	4	2026-03-10	\N	\N
1291	0001104659-26-025678	18230	8	4	2026-03-10	\N	\N
1292	0001104659-26-028585	18230	8	4	2026-03-16	\N	\N
1293	0001104659-26-028590	18230	8	4	2026-03-16	\N	\N
1294	0001104659-26-035977	18230	8	4	2026-03-27	\N	\N
1295	0001104659-26-038394	18230	8	4	2026-04-01	\N	\N
1296	0001104659-26-049316	18230	8	4	2026-04-27	\N	\N
1297	0001104659-26-054593	18230	8	3	2026-05-04	\N	\N
1298	0001104659-26-055493	18230	8	4	2026-05-05	\N	\N
1299	0001104659-26-055795	18230	8	4	2026-05-05	\N	\N
1300	0001104659-26-056435	18230	8	4	2026-05-06	\N	\N
1301	0001104659-26-056437	18230	8	4	2026-05-06	\N	\N
1302	0001104659-26-057309	18230	8	4	2026-05-07	\N	\N
1303	0001104659-26-057311	18230	8	4	2026-05-07	\N	\N
1304	0001104659-26-057313	18230	8	4	2026-05-07	\N	\N
1305	0001104659-26-059232	18230	8	4	2026-05-12	\N	\N
1306	0001104659-26-059243	18230	8	4	2026-05-12	\N	\N
1307	0001104659-26-059445	18230	8	4	2026-05-12	\N	\N
1308	0001104659-26-059449	18230	8	4	2026-05-12	\N	\N
1309	0001104659-26-060916	18230	8	4	2026-05-14	\N	\N
1310	0001104659-26-061036	18230	8	4	2026-05-14	\N	\N
1311	0001104659-26-062809	18230	8	4	2026-05-15	\N	\N
1312	0001104659-26-066858	18230	8	4	2026-05-27	\N	\N
1313	0001104659-26-066860	18230	8	4	2026-05-27	\N	\N
1314	0001104659-26-072891	18230	8	4	2026-06-11	\N	\N
1315	0001104659-26-072894	18230	8	4	2026-06-11	\N	\N
1316	0001104659-26-072897	18230	8	4	2026-06-11	\N	\N
1317	0001104659-26-072898	18230	8	4	2026-06-11	\N	\N
1318	0001104659-26-072902	18230	8	4	2026-06-11	\N	\N
1319	0001104659-26-072907	18230	8	4	2026-06-11	\N	\N
1320	0001104659-26-072910	18230	8	4	2026-06-11	\N	\N
1321	0001104659-26-072911	18230	8	4	2026-06-11	\N	\N
1322	0001104659-26-078798	18230	8	4	2026-06-29	\N	\N
1323	0001104659-26-078800	18230	8	4	2026-06-29	\N	\N
1324	0001104659-26-078801	18230	8	4	2026-06-29	\N	\N
1325	0001104659-26-079826	18230	8	4	2026-07-01	\N	\N
1326	0001104659-26-087023	18230	8	4	2026-07-27	\N	\N
1327	0001104659-26-087024	18230	8	4	2026-07-27	\N	\N
1328	0001104659-26-087156	18230	8	4	2026-07-27	\N	\N
1329	0001104659-26-090832	18230	8	3	2026-08-05	\N	\N
1330	0001104659-26-102417	18230	8	4	2026-08-27	\N	\N
1331	0001104659-26-102419	18230	8	4	2026-08-27	\N	\N
1332	0001104659-26-102420	18230	8	4	2026-08-27	\N	\N
1333	0001104659-26-104202	18230	8	4	2026-09-01	\N	\N
1334	0001104659-26-111312	18230	8	4	2026-09-28	\N	\N
1335	0001104659-26-111313	18230	8	4	2026-09-28	\N	\N
1336	0001104659-26-111315	18230	8	4	2026-09-28	\N	\N
1337	0001104659-26-112891	18230	8	4	2026-10-01	\N	\N
1338	0001104659-26-112893	18230	8	4	2026-10-01	\N	\N
1339	0001104659-26-119131	18230	8	4	2026-10-27	\N	\N
1340	0001104659-26-119132	18230	8	4	2026-10-27	\N	\N
1341	0001104659-26-119134	18230	8	4	2026-10-27	\N	\N
1342	0001104659-26-121054	18230	8	3	2026-11-02	\N	\N
1343	0001104659-26-121809	18230	8	4	2026-11-03	\N	\N
1344	0001104659-26-127088	18230	8	4	2026-11-13	\N	\N
1345	0001046179-26-000355	1046179	9	4	2026-06-09	\N	\N
1346	0001046179-26-000356	1046179	9	4	2026-06-09	\N	\N
1347	0001046179-26-000357	1046179	9	4	2026-06-09	\N	\N
1348	0001046179-26-000358	1046179	9	4	2026-06-09	\N	\N
1349	0001046179-26-000359	1046179	9	4	2026-06-09	\N	\N
1350	0001046179-26-000360	1046179	9	4	2026-06-09	\N	\N
1351	0001046179-26-000361	1046179	9	4	2026-06-09	\N	\N
1352	0001046179-26-000362	1046179	9	4	2026-06-09	\N	\N
1353	0001046179-26-000363	1046179	9	4	2026-06-09	\N	\N
1354	0001046179-26-000364	1046179	9	4	2026-06-09	\N	\N
1355	0001046179-26-000365	1046179	9	4	2026-06-09	\N	\N
1356	0001046179-26-000369	1046179	9	4	2026-06-16	\N	\N
1357	0001046179-26-000371	1046179	9	4	2026-06-23	\N	\N
1358	0001046179-26-000375	1046179	9	4	2026-06-24	\N	\N
1359	0001046179-26-000379	1046179	9	4	2026-06-30	\N	\N
1360	0001046179-26-000383	1046179	9	4	2026-07-06	\N	\N
1361	0001046179-26-000415	1046179	9	4	2026-07-09	\N	\N
1362	0001046179-26-000416	1046179	9	4	2026-07-09	\N	\N
1363	0001046179-26-000417	1046179	9	4	2026-07-09	\N	\N
1364	0001046179-26-000418	1046179	9	4	2026-07-09	\N	\N
1365	0001046179-26-000419	1046179	9	4	2026-07-09	\N	\N
1366	0001046179-26-000420	1046179	9	4	2026-07-09	\N	\N
1367	0001046179-26-000421	1046179	9	4	2026-07-09	\N	\N
1368	0001046179-26-000422	1046179	9	4	2026-07-09	\N	\N
1369	0001046179-26-000423	1046179	9	4	2026-07-09	\N	\N
1370	0001046179-26-000424	1046179	9	4	2026-07-09	\N	\N
1371	0001046179-26-000425	1046179	9	4	2026-07-09	\N	\N
1372	0001046179-26-000426	1046179	9	4	2026-07-09	\N	\N
1373	0001046179-26-000427	1046179	9	4	2026-07-09	\N	\N
1374	0001046179-26-000428	1046179	9	4	2026-07-09	\N	\N
1375	0001046179-26-000429	1046179	9	4	2026-07-09	\N	\N
1376	0001046179-26-000430	1046179	9	4	2026-07-09	\N	\N
1377	0001046179-26-000431	1046179	9	4	2026-07-09	\N	\N
1378	0001046179-26-000432	1046179	9	4	2026-07-09	\N	\N
1379	0001046179-26-000433	1046179	9	4	2026-07-09	\N	\N
1380	0001046179-26-000434	1046179	9	4	2026-07-09	\N	\N
1381	0001046179-26-000435	1046179	9	4	2026-07-09	\N	\N
1382	0001046179-26-000436	1046179	9	4	2026-07-09	\N	\N
1383	0001046179-26-000437	1046179	9	4	2026-07-09	\N	\N
1384	0001046179-26-000438	1046179	9	4	2026-07-09	\N	\N
1385	0001046179-26-000439	1046179	9	4	2026-07-09	\N	\N
1386	0001046179-26-000440	1046179	9	4	2026-07-09	\N	\N
1387	0001046179-26-000441	1046179	9	4	2026-07-09	\N	\N
1388	0001046179-26-000442	1046179	9	4	2026-07-09	\N	\N
1389	0001046179-26-000443	1046179	9	4	2026-07-09	\N	\N
1390	0001046179-26-000444	1046179	9	4	2026-07-09	\N	\N
1391	0001046179-26-000445	1046179	9	4	2026-07-09	\N	\N
1392	0001046179-26-000449	1046179	9	4	2026-07-16	\N	\N
1393	0001046179-26-000453	1046179	9	4	2026-07-21	\N	\N
1394	0001046179-26-000455	1046179	9	4	2026-07-22	\N	\N
1395	0001046179-26-000457	1046179	9	4	2026-07-23	\N	\N
1396	0001046179-26-000461	1046179	9	4	2026-07-30	\N	\N
1397	0001046179-26-000463	1046179	9	4	2026-07-31	\N	\N
1398	0001046179-26-000465	1046179	9	4	2026-08-04	\N	\N
1399	0001046179-26-000468	1046179	9	4	2026-08-05	\N	\N
1400	0001046179-26-000479	1046179	9	4	2026-08-10	\N	\N
1401	0001046179-26-000480	1046179	9	4	2026-08-10	\N	\N
1402	0001046179-26-000481	1046179	9	4	2026-08-10	\N	\N
1403	0001046179-26-000482	1046179	9	4	2026-08-10	\N	\N
1404	0001046179-26-000483	1046179	9	4	2026-08-10	\N	\N
1405	0001046179-26-000489	1046179	9	4	2026-08-10	\N	\N
1406	0001046179-26-000490	1046179	9	4	2026-08-10	\N	\N
1407	0001046179-26-000491	1046179	9	4	2026-08-10	\N	\N
1408	0001046179-26-000492	1046179	9	4	2026-08-10	\N	\N
1409	0001046179-26-000493	1046179	9	4	2026-08-10	\N	\N
1410	0001046179-26-000499	1046179	9	4	2026-08-10	\N	\N
1411	0001046179-26-000500	1046179	9	4	2026-08-10	\N	\N
1412	0001046179-26-000501	1046179	9	4	2026-08-10	\N	\N
1413	0001046179-26-000502	1046179	9	4	2026-08-10	\N	\N
1414	0001046179-26-000503	1046179	9	4	2026-08-10	\N	\N
1415	0001046179-26-000509	1046179	9	4	2026-08-10	\N	\N
1416	0001046179-26-000510	1046179	9	4	2026-08-10	\N	\N
1417	0001046179-26-000511	1046179	9	4	2026-08-10	\N	\N
1418	0001046179-26-000512	1046179	9	4	2026-08-10	\N	\N
1419	0001046179-26-000513	1046179	9	4	2026-08-10	\N	\N
1420	0001046179-26-000519	1046179	9	4	2026-08-10	\N	\N
1421	0001046179-26-000520	1046179	9	4	2026-08-10	\N	\N
1422	0001046179-26-000521	1046179	9	4	2026-08-10	\N	\N
1423	0001046179-26-000522	1046179	9	4	2026-08-10	\N	\N
1424	0001046179-26-000523	1046179	9	4	2026-08-10	\N	\N
1425	0001046179-26-000529	1046179	9	4	2026-08-10	\N	\N
1426	0001046179-26-000530	1046179	9	4	2026-08-10	\N	\N
1427	0001046179-26-000531	1046179	9	4	2026-08-10	\N	\N
1428	0001046179-26-000532	1046179	9	4	2026-08-10	\N	\N
1429	0001046179-26-000533	1046179	9	4	2026-08-10	\N	\N
1430	0001046179-26-000543	1046179	9	4	2026-08-20	\N	\N
1431	0001046179-26-000574	1046179	9	4	2026-09-02	\N	\N
1432	0001046179-26-000575	1046179	9	4	2026-09-02	\N	\N
1433	0001046179-26-000576	1046179	9	4	2026-09-02	\N	\N
1434	0001046179-26-000577	1046179	9	4	2026-09-02	\N	\N
1435	0001046179-26-000578	1046179	9	4	2026-09-02	\N	\N
1436	0001046179-26-000579	1046179	9	4	2026-09-02	\N	\N
1437	0001046179-26-000580	1046179	9	4	2026-09-02	\N	\N
1438	0001046179-26-000581	1046179	9	4	2026-09-02	\N	\N
1439	0001046179-26-000582	1046179	9	4	2026-09-02	\N	\N
1440	0001046179-26-000583	1046179	9	4	2026-09-02	\N	\N
1441	0001046179-26-000584	1046179	9	4	2026-09-02	\N	\N
1442	0001046179-26-000585	1046179	9	4	2026-09-02	\N	\N
1443	0001046179-26-000586	1046179	9	4	2026-09-02	\N	\N
1444	0001046179-26-000587	1046179	9	4	2026-09-02	\N	\N
1445	0001046179-26-000588	1046179	9	4	2026-09-02	\N	\N
1446	0001046179-26-000589	1046179	9	4	2026-09-02	\N	\N
1447	0001046179-26-000590	1046179	9	4	2026-09-02	\N	\N
1448	0001046179-26-000591	1046179	9	4	2026-09-02	\N	\N
1449	0001046179-26-000592	1046179	9	4	2026-09-02	\N	\N
1450	0001046179-26-000593	1046179	9	4	2026-09-02	\N	\N
1451	0001046179-26-000594	1046179	9	4	2026-09-02	\N	\N
1452	0001046179-26-000596	1046179	9	4	2026-09-04	\N	\N
1453	0001046179-26-000602	1046179	9	4	2026-09-09	\N	\N
1454	0001046179-26-000603	1046179	9	4	2026-09-09	\N	\N
1455	0001046179-26-000604	1046179	9	4	2026-09-09	\N	\N
1456	0001046179-26-000605	1046179	9	4	2026-09-09	\N	\N
1457	0001046179-26-000606	1046179	9	4	2026-09-09	\N	\N
1458	0001046179-26-000612	1046179	9	4	2026-09-09	\N	\N
1459	0001046179-26-000613	1046179	9	4	2026-09-09	\N	\N
1460	0001046179-26-000614	1046179	9	4	2026-09-09	\N	\N
1461	0001046179-26-000615	1046179	9	4	2026-09-09	\N	\N
1462	0001046179-26-000616	1046179	9	4	2026-09-09	\N	\N
1463	0001046179-26-000622	1046179	9	4	2026-09-09	\N	\N
1464	0001046179-26-000623	1046179	9	4	2026-09-09	\N	\N
1465	0001046179-26-000624	1046179	9	4	2026-09-09	\N	\N
1466	0001046179-26-000626	1046179	9	4	2026-09-09	\N	\N
1467	0001046179-26-000628	1046179	9	4	2026-09-09	\N	\N
1468	0001046179-26-000632	1046179	9	4	2026-09-09	\N	\N
1469	0001046179-26-000633	1046179	9	4	2026-09-09	\N	\N
1470	0001046179-26-000635	1046179	9	4	2026-09-09	\N	\N
1471	0001046179-26-000637	1046179	9	4	2026-09-09	\N	\N
1472	0001046179-26-000640	1046179	9	4	2026-09-09	\N	\N
1473	0001046179-26-000642	1046179	9	4	2026-09-09	\N	\N
1474	0001046179-26-000643	1046179	9	4	2026-09-09	\N	\N
1475	0001046179-26-000644	1046179	9	4	2026-09-09	\N	\N
1476	0001046179-26-000646	1046179	9	4	2026-09-09	\N	\N
1477	0001046179-26-000648	1046179	9	4	2026-09-09	\N	\N
1478	0001046179-26-000652	1046179	9	4	2026-09-09	\N	\N
1479	0001046179-26-000653	1046179	9	4	2026-09-09	\N	\N
1480	0001046179-26-000654	1046179	9	4	2026-09-09	\N	\N
1481	0001046179-26-000655	1046179	9	4	2026-09-09	\N	\N
1482	0001046179-26-000656	1046179	9	4	2026-09-09	\N	\N
1483	0001046179-26-000672	1046179	9	4	2026-10-08	\N	\N
1484	0001046179-26-000673	1046179	9	4	2026-10-08	\N	\N
1485	0001046179-26-000674	1046179	9	4	2026-10-08	\N	\N
1486	0001046179-26-000675	1046179	9	4	2026-10-08	\N	\N
1487	0001046179-26-000676	1046179	9	4	2026-10-08	\N	\N
1488	0001046179-26-000677	1046179	9	4	2026-10-08	\N	\N
1489	0001046179-26-000678	1046179	9	4	2026-10-08	\N	\N
1490	0001046179-26-000679	1046179	9	4	2026-10-08	\N	\N
1491	0001046179-26-000684	1046179	9	4	2026-10-08	\N	\N
1492	0001046179-26-000685	1046179	9	4	2026-10-08	\N	\N
1493	0001046179-26-000686	1046179	9	4	2026-10-08	\N	\N
1494	0001046179-26-000690	1046179	9	4	2026-10-08	\N	\N
1495	0001046179-26-000691	1046179	9	4	2026-10-08	\N	\N
1496	0001046179-26-000692	1046179	9	4	2026-10-08	\N	\N
1497	0001046179-26-000696	1046179	9	4	2026-10-08	\N	\N
1498	0001046179-26-000697	1046179	9	4	2026-10-08	\N	\N
1499	0001046179-26-000698	1046179	9	4	2026-10-08	\N	\N
1500	0001046179-26-000702	1046179	9	4	2026-10-08	\N	\N
1501	0001046179-26-000703	1046179	9	4	2026-10-08	\N	\N
1502	0001046179-26-000704	1046179	9	4	2026-10-08	\N	\N
1503	0001046179-26-000708	1046179	9	4	2026-10-08	\N	\N
1504	0001046179-26-000709	1046179	9	4	2026-10-08	\N	\N
1505	0001046179-26-000710	1046179	9	4	2026-10-08	\N	\N
1506	0001046179-26-000714	1046179	9	4	2026-10-08	\N	\N
1507	0001046179-26-000715	1046179	9	4	2026-10-08	\N	\N
1508	0001046179-26-000716	1046179	9	4	2026-10-08	\N	\N
1509	0001046179-26-000721	1046179	9	4	2026-10-08	\N	\N
1510	0001046179-26-000722	1046179	9	4	2026-10-08	\N	\N
1511	0001046179-26-000723	1046179	9	4	2026-10-08	\N	\N
1512	0001046179-26-000724	1046179	9	4	2026-10-08	\N	\N
1513	0001046179-26-000732	1046179	9	4	2026-11-03	\N	\N
1514	0001046179-26-000734	1046179	9	4	2026-11-09	\N	\N
1515	0001046179-26-000741	1046179	9	4	2026-11-10	\N	\N
1516	0001046179-26-000742	1046179	9	4	2026-11-10	\N	\N
1517	0001046179-26-000743	1046179	9	4	2026-11-10	\N	\N
1518	0001046179-26-000744	1046179	9	4	2026-11-10	\N	\N
1519	0001046179-26-000745	1046179	9	4	2026-11-10	\N	\N
1520	0001046179-26-000746	1046179	9	4	2026-11-10	\N	\N
1521	0001046179-26-000753	1046179	9	4	2026-11-10	\N	\N
1522	0001046179-26-000754	1046179	9	4	2026-11-10	\N	\N
1523	0001046179-26-000755	1046179	9	4	2026-11-10	\N	\N
1524	0001046179-26-000756	1046179	9	4	2026-11-10	\N	\N
1525	0001046179-26-000757	1046179	9	4	2026-11-10	\N	\N
1526	0001046179-26-000758	1046179	9	4	2026-11-10	\N	\N
1527	0001046179-26-000771	1046179	9	4	2026-11-10	\N	\N
1528	0001046179-26-000772	1046179	9	4	2026-11-10	\N	\N
1529	0001046179-26-000773	1046179	9	4	2026-11-10	\N	\N
1530	0001046179-26-000774	1046179	9	4	2026-11-10	\N	\N
1531	0001046179-26-000775	1046179	9	4	2026-11-10	\N	\N
1532	0001046179-26-000776	1046179	9	4	2026-11-10	\N	\N
1533	0001046179-26-000777	1046179	9	4	2026-11-10	\N	\N
1534	0001046179-26-000778	1046179	9	4	2026-11-10	\N	\N
1535	0001046179-26-000779	1046179	9	4	2026-11-10	\N	\N
1536	0001046179-26-000780	1046179	9	4	2026-11-10	\N	\N
1537	0001046179-26-000781	1046179	9	4	2026-11-10	\N	\N
1538	0001046179-26-000782	1046179	9	4	2026-11-10	\N	\N
1539	0001046179-26-000789	1046179	9	4	2026-11-10	\N	\N
1540	0001046179-26-000790	1046179	9	4	2026-11-10	\N	\N
1541	0001046179-26-000791	1046179	9	4	2026-11-10	\N	\N
1542	0001046179-26-000792	1046179	9	4	2026-11-10	\N	\N
1543	0001046179-26-000793	1046179	9	4	2026-11-10	\N	\N
1544	0001046179-26-000794	1046179	9	4	2026-11-10	\N	\N
1545	0000102909-26-000031	102909	\N	13F-HR	2026-01-29	2025-12-31	\N
1546	0000102909-25-000353	102909	\N	13F-HR	2025-11-07	2025-09-30	\N
1547	0001086364-24-008417	1364742	\N	13F-HR	2024-08-13	2024-06-30	\N
1548	0001086364-24-007638	1364742	\N	13F-HR	2024-05-10	2024-03-31	\N
1549	0000093751-26-000747	93751	\N	13F-HR	2026-11-12	2026-09-30	\N
1550	0000093751-26-000507	93751	\N	13F-HR	2026-08-07	2026-06-30	\N
1551	0000315066-26-002964	315066	\N	13F-HR	2026-11-10	2026-09-30	\N
1552	0000315066-26-002260	315066	\N	13F-HR	2026-08-13	2026-06-30	\N
1553	0001214717-26-000012	1214717	\N	13F-HR	2026-11-06	2026-09-30	\N
1554	0001214717-26-000008	1214717	\N	13F-HR	2026-08-12	2026-06-30	\N
1555	0000895421-26-000309	895421	\N	13F-HR	2026-11-13	2026-09-30	\N
1556	0000895421-26-000243	895421	\N	13F-HR	2026-08-13	2026-06-30	\N
1557	0000019617-26-000404	19617	\N	13F-HR	2026-11-12	2026-09-30	\N
1558	0000019617-26-000325	19617	\N	13F-HR	2026-08-12	2026-06-30	\N
1559	0001422849-26-000169	1422849	\N	13F-HR	2026-11-12	2026-09-30	\N
1560	0001422849-26-000113	1422849	\N	13F-HR	2026-08-12	2026-06-30	\N
1561	0000080255-26-000519	80255	\N	13F-HR	2026-08-14	2026-06-30	\N
1562	0000080255-26-000381	80255	\N	13F-HR	2026-05-15	2026-03-31	\N
1563	0000073124-26-000053	73124	\N	13F-HR	2026-08-13	2026-06-30	\N
1564	0000073124-26-000036	73124	\N	13F-HR	2026-05-14	2026-03-31	\N
1565	0000886982-26-000519	886982	\N	13F-HR	2026-08-14	2026-06-30	\N
1566	0000886982-26-000274	886982	\N	13F-HR	2026-05-15	2026-03-31	\N
1567	0000070858-26-000442	70858	\N	13F-HR	2026-08-14	2026-06-30	\N
1568	0000070858-26-000315	70858	\N	13F-HR	2026-05-18	2026-03-31	\N
1569	0001374170-26-000090	1374170	\N	13F-HR	2026-11-13	2026-09-30	\N
1570	0001374170-26-000069	1374170	\N	13F-HR	2026-08-12	2026-06-30	\N
1571	0000902219-26-000311	902219	\N	13F-HR	2026-08-14	2026-06-30	\N
1572	0000902219-26-000209	902219	\N	13F-HR	2026-05-15	2026-03-31	\N
1573	0001104659-26-126785	1697748	\N	13F-HR	2026-11-13	2026-09-30	\N
1574	0001104659-26-096910	1697748	\N	13F-HR	2026-08-14	2026-06-30	\N
1575	0001088875-26-000074	1088875	\N	13F-HR	2026-11-09	2026-09-30	\N
1576	0001088875-26-000057	1088875	\N	13F-HR	2026-08-06	2026-06-30	\N
1577	0000914208-26-000462	914208	\N	13F-HR	2026-11-12	2026-09-30	\N
1578	0000914208-26-000343	914208	\N	13F-HR	2026-08-14	2026-06-30	\N
1579	0001037389-26-000062	1037389	\N	13F-HR	2026-11-12	2026-09-30	\N
1580	0001037389-26-000059	1037389	\N	13F-HR	2026-08-13	2026-06-30	\N
1581	0001104659-26-097200	1423053	\N	13F-HR	2026-08-14	2026-06-30	\N
1582	0001104659-26-062477	1423053	\N	13F-HR	2026-05-15	2026-03-31	\N
1583	0001350694-26-000003	1350694	\N	13F-HR	2026-08-14	2026-06-30	\N
1584	0001350694-26-000002	1350694	\N	13F-HR	2026-05-15	2026-03-31	\N
\.


--
-- Data for Name: financial_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_metrics (financial_metric_id, company_id, metric_id, fiscal_year, fiscal_period, period_start, period_end, value, unit, xbrl_tag, source_filing_id) FROM stdin;
1	1	1	2019	Q1	2019-01-01	2019-03-31	4541000000.0000	USD	us-gaap:Revenues	11
2	1	1	2019	Q2	2019-04-01	2019-06-30	6350000000.0000	USD	us-gaap:Revenues	11
3	1	1	2019	Q3	2019-07-01	2019-09-30	6303000000.0000	USD	us-gaap:Revenues	11
4	1	1	2019	FY	2019-01-01	2019-12-31	24578000000.0000	USD	us-gaap:Revenues	12
5	1	1	2019	Q4	2019-10-01	2019-12-31	7384000000.0000	USD	us-gaap:Revenues	11
6	1	1	2020	Q1	2020-01-01	2020-03-31	5985000000.0000	USD	us-gaap:Revenues	13
7	1	1	2020	Q2	2020-04-01	2020-06-30	6036000000.0000	USD	us-gaap:Revenues	14
8	1	1	2020	Q3	2020-07-01	2020-09-30	8771000000.0000	USD	us-gaap:Revenues	15
9	1	1	2020	FY	2020-01-01	2020-12-31	31536000000.0000	USD	us-gaap:Revenues	16
10	1	1	2020	Q4	2020-10-01	2020-12-31	10744000000.0000	USD	us-gaap:Revenues	11
11	1	1	2021	Q1	2021-01-01	2021-03-31	10389000000.0000	USD	us-gaap:Revenues	17
12	1	1	2021	Q2	2021-04-01	2021-06-30	11958000000.0000	USD	us-gaap:Revenues	18
13	1	1	2021	Q3	2021-07-01	2021-09-30	13757000000.0000	USD	us-gaap:Revenues	19
14	1	1	2021	FY	2021-01-01	2021-12-31	53823000000.0000	USD	us-gaap:Revenues	20
15	1	1	2022	Q1	2022-01-01	2022-03-31	18756000000.0000	USD	us-gaap:Revenues	21
16	1	1	2022	Q2	2022-04-01	2022-06-30	16934000000.0000	USD	us-gaap:Revenues	22
17	1	1	2022	Q3	2022-07-01	2022-09-30	21454000000.0000	USD	us-gaap:Revenues	23
18	1	1	2022	FY	2022-01-01	2022-12-31	81462000000.0000	USD	us-gaap:Revenues	24
19	1	1	2023	Q1	2023-01-01	2023-03-31	23329000000.0000	USD	us-gaap:Revenues	25
20	1	1	2023	Q2	2023-04-01	2023-06-30	24927000000.0000	USD	us-gaap:Revenues	26
21	1	1	2023	Q3	2023-07-01	2023-09-30	23350000000.0000	USD	us-gaap:Revenues	27
22	1	1	2023	FY	2023-01-01	2023-12-31	96773000000.0000	USD	us-gaap:Revenues	1
23	1	1	2024	Q1	2024-01-01	2024-03-31	21301000000.0000	USD	us-gaap:Revenues	28
24	1	1	2024	Q2	2024-04-01	2024-06-30	25500000000.0000	USD	us-gaap:Revenues	29
25	1	1	2024	Q3	2024-07-01	2024-09-30	25182000000.0000	USD	us-gaap:Revenues	30
26	1	1	2024	FY	2024-01-01	2024-12-31	97690000000.0000	USD	us-gaap:Revenues	1
27	1	1	2025	Q1	2025-01-01	2025-03-31	19335000000.0000	USD	us-gaap:Revenues	31
28	1	1	2025	Q2	2025-04-01	2025-06-30	22496000000.0000	USD	us-gaap:Revenues	32
29	1	1	2025	Q3	2025-07-01	2025-09-30	28095000000.0000	USD	us-gaap:Revenues	33
30	1	1	2025	FY	2025-01-01	2025-12-31	94827000000.0000	USD	us-gaap:Revenues	1
31	1	1	2026	Q1	2026-01-01	2026-03-31	22387000000.0000	USD	us-gaap:Revenues	31
32	1	1	2026	Q2	2026-04-01	2026-06-30	28236000000.0000	USD	us-gaap:Revenues	32
33	1	1	2026	Q3	2026-07-01	2026-09-30	28046000000.0000	USD	us-gaap:Revenues	33
34	1	2	2019	Q1	2019-01-01	2019-03-31	3975000000.0000	USD	us-gaap:CostOfRevenue	34
35	1	2	2019	Q2	2019-04-01	2019-06-30	5429000000.0000	USD	us-gaap:CostOfRevenue	35
36	1	2	2019	Q3	2019-07-01	2019-09-30	5112000000.0000	USD	us-gaap:CostOfRevenue	36
37	1	2	2019	FY	2019-01-01	2019-12-31	20509000000.0000	USD	us-gaap:CostOfRevenue	12
38	1	2	2020	Q1	2020-01-01	2020-03-31	4751000000.0000	USD	us-gaap:CostOfRevenue	13
39	1	2	2020	Q2	2020-04-01	2020-06-30	4769000000.0000	USD	us-gaap:CostOfRevenue	14
40	1	2	2020	Q3	2020-07-01	2020-09-30	6708000000.0000	USD	us-gaap:CostOfRevenue	15
41	1	2	2020	FY	2020-01-01	2020-12-31	24906000000.0000	USD	us-gaap:CostOfRevenue	16
42	1	2	2021	Q1	2021-01-01	2021-03-31	8174000000.0000	USD	us-gaap:CostOfRevenue	17
43	1	2	2021	Q2	2021-04-01	2021-06-30	9074000000.0000	USD	us-gaap:CostOfRevenue	18
44	1	2	2021	Q3	2021-07-01	2021-09-30	10097000000.0000	USD	us-gaap:CostOfRevenue	19
45	1	2	2021	FY	2021-01-01	2021-12-31	40217000000.0000	USD	us-gaap:CostOfRevenue	20
46	1	2	2022	Q1	2022-01-01	2022-03-31	13296000000.0000	USD	us-gaap:CostOfRevenue	21
47	1	2	2022	Q2	2022-04-01	2022-06-30	12700000000.0000	USD	us-gaap:CostOfRevenue	22
48	1	2	2022	Q3	2022-07-01	2022-09-30	16072000000.0000	USD	us-gaap:CostOfRevenue	23
49	1	2	2022	FY	2022-01-01	2022-12-31	60609000000.0000	USD	us-gaap:CostOfRevenue	24
50	1	2	2023	Q1	2023-01-01	2023-03-31	18818000000.0000	USD	us-gaap:CostOfRevenue	25
51	1	2	2023	Q2	2023-04-01	2023-06-30	20394000000.0000	USD	us-gaap:CostOfRevenue	26
52	1	2	2023	Q3	2023-07-01	2023-09-30	19172000000.0000	USD	us-gaap:CostOfRevenue	27
53	1	2	2023	FY	2023-01-01	2023-12-31	79113000000.0000	USD	us-gaap:CostOfRevenue	1
54	1	2	2024	Q1	2024-01-01	2024-03-31	17605000000.0000	USD	us-gaap:CostOfRevenue	28
55	1	2	2024	Q2	2024-04-01	2024-06-30	20922000000.0000	USD	us-gaap:CostOfRevenue	29
56	1	2	2024	Q3	2024-07-01	2024-09-30	20185000000.0000	USD	us-gaap:CostOfRevenue	30
57	1	2	2024	FY	2024-01-01	2024-12-31	80240000000.0000	USD	us-gaap:CostOfRevenue	1
58	1	2	2025	Q1	2025-01-01	2025-03-31	16182000000.0000	USD	us-gaap:CostOfRevenue	31
59	1	2	2025	Q2	2025-04-01	2025-06-30	18618000000.0000	USD	us-gaap:CostOfRevenue	32
60	1	2	2025	Q3	2025-07-01	2025-09-30	23041000000.0000	USD	us-gaap:CostOfRevenue	33
61	1	2	2025	FY	2025-01-01	2025-12-31	77733000000.0000	USD	us-gaap:CostOfRevenue	1
62	1	2	2026	Q1	2026-01-01	2026-03-31	17667000000.0000	USD	us-gaap:CostOfRevenue	31
63	1	2	2026	Q2	2026-04-01	2026-06-30	23485000000.0000	USD	us-gaap:CostOfRevenue	32
64	1	2	2026	Q3	2026-07-01	2026-09-30	22552000000.0000	USD	us-gaap:CostOfRevenue	33
65	1	3	2019	Q1	2019-01-01	2019-03-31	566000000.0000	USD	us-gaap:GrossProfit	11
66	1	3	2019	Q2	2019-04-01	2019-06-30	921000000.0000	USD	us-gaap:GrossProfit	11
67	1	3	2019	Q3	2019-07-01	2019-09-30	1191000000.0000	USD	us-gaap:GrossProfit	11
68	1	3	2019	FY	2019-01-01	2019-12-31	4069000000.0000	USD	us-gaap:GrossProfit	12
69	1	3	2019	Q4	2019-10-01	2019-12-31	1391000000.0000	USD	us-gaap:GrossProfit	11
70	1	3	2020	Q1	2020-01-01	2020-03-31	1234000000.0000	USD	us-gaap:GrossProfit	13
71	1	3	2020	Q2	2020-04-01	2020-06-30	1267000000.0000	USD	us-gaap:GrossProfit	14
72	1	3	2020	Q3	2020-07-01	2020-09-30	2063000000.0000	USD	us-gaap:GrossProfit	15
73	1	3	2020	FY	2020-01-01	2020-12-31	6630000000.0000	USD	us-gaap:GrossProfit	16
74	1	3	2020	Q4	2020-10-01	2020-12-31	2066000000.0000	USD	us-gaap:GrossProfit	11
75	1	3	2021	Q1	2021-01-01	2021-03-31	2215000000.0000	USD	us-gaap:GrossProfit	17
76	1	3	2021	Q2	2021-04-01	2021-06-30	2884000000.0000	USD	us-gaap:GrossProfit	18
77	1	3	2021	Q3	2021-07-01	2021-09-30	3660000000.0000	USD	us-gaap:GrossProfit	19
78	1	3	2021	FY	2021-01-01	2021-12-31	13606000000.0000	USD	us-gaap:GrossProfit	20
79	1	3	2022	Q1	2022-01-01	2022-03-31	5460000000.0000	USD	us-gaap:GrossProfit	21
80	1	3	2022	Q2	2022-04-01	2022-06-30	4234000000.0000	USD	us-gaap:GrossProfit	22
81	1	3	2022	Q3	2022-07-01	2022-09-30	5382000000.0000	USD	us-gaap:GrossProfit	23
82	1	3	2022	FY	2022-01-01	2022-12-31	20853000000.0000	USD	us-gaap:GrossProfit	24
83	1	3	2023	Q1	2023-01-01	2023-03-31	4511000000.0000	USD	us-gaap:GrossProfit	25
84	1	3	2023	Q2	2023-04-01	2023-06-30	4533000000.0000	USD	us-gaap:GrossProfit	26
85	1	3	2023	Q3	2023-07-01	2023-09-30	4178000000.0000	USD	us-gaap:GrossProfit	27
86	1	3	2023	FY	2023-01-01	2023-12-31	17660000000.0000	USD	us-gaap:GrossProfit	1
87	1	3	2024	Q1	2024-01-01	2024-03-31	3696000000.0000	USD	us-gaap:GrossProfit	28
88	1	3	2024	Q2	2024-04-01	2024-06-30	4578000000.0000	USD	us-gaap:GrossProfit	29
89	1	3	2024	Q3	2024-07-01	2024-09-30	4997000000.0000	USD	us-gaap:GrossProfit	30
90	1	3	2024	FY	2024-01-01	2024-12-31	17450000000.0000	USD	us-gaap:GrossProfit	1
91	1	3	2025	Q1	2025-01-01	2025-03-31	3153000000.0000	USD	us-gaap:GrossProfit	31
92	1	3	2025	Q2	2025-04-01	2025-06-30	3878000000.0000	USD	us-gaap:GrossProfit	32
93	1	3	2025	Q3	2025-07-01	2025-09-30	5054000000.0000	USD	us-gaap:GrossProfit	33
94	1	3	2025	FY	2025-01-01	2025-12-31	17094000000.0000	USD	us-gaap:GrossProfit	1
95	1	3	2026	Q1	2026-01-01	2026-03-31	4720000000.0000	USD	us-gaap:GrossProfit	31
96	1	3	2026	Q2	2026-04-01	2026-06-30	4751000000.0000	USD	us-gaap:GrossProfit	32
97	1	3	2026	Q3	2026-07-01	2026-09-30	5494000000.0000	USD	us-gaap:GrossProfit	33
98	1	4	2019	Q1	2019-01-01	2019-03-31	-522000000.0000	USD	us-gaap:OperatingIncomeLoss	34
99	1	4	2019	Q2	2019-04-01	2019-06-30	-167000000.0000	USD	us-gaap:OperatingIncomeLoss	35
100	1	4	2019	Q3	2019-07-01	2019-09-30	261000000.0000	USD	us-gaap:OperatingIncomeLoss	36
101	1	4	2019	FY	2019-01-01	2019-12-31	-69000000.0000	USD	us-gaap:OperatingIncomeLoss	12
102	1	4	2020	Q1	2020-01-01	2020-03-31	283000000.0000	USD	us-gaap:OperatingIncomeLoss	13
103	1	4	2020	Q2	2020-04-01	2020-06-30	327000000.0000	USD	us-gaap:OperatingIncomeLoss	14
104	1	4	2020	Q3	2020-07-01	2020-09-30	809000000.0000	USD	us-gaap:OperatingIncomeLoss	15
105	1	4	2020	FY	2020-01-01	2020-12-31	1994000000.0000	USD	us-gaap:OperatingIncomeLoss	16
106	1	4	2021	Q1	2021-01-01	2021-03-31	594000000.0000	USD	us-gaap:OperatingIncomeLoss	17
107	1	4	2021	Q2	2021-04-01	2021-06-30	1312000000.0000	USD	us-gaap:OperatingIncomeLoss	18
108	1	4	2021	Q3	2021-07-01	2021-09-30	2004000000.0000	USD	us-gaap:OperatingIncomeLoss	19
109	1	4	2021	FY	2021-01-01	2021-12-31	6523000000.0000	USD	us-gaap:OperatingIncomeLoss	20
110	1	4	2022	Q1	2022-01-01	2022-03-31	3603000000.0000	USD	us-gaap:OperatingIncomeLoss	21
111	1	4	2022	Q2	2022-04-01	2022-06-30	2464000000.0000	USD	us-gaap:OperatingIncomeLoss	22
112	1	4	2022	Q3	2022-07-01	2022-09-30	3688000000.0000	USD	us-gaap:OperatingIncomeLoss	23
113	1	4	2022	FY	2022-01-01	2022-12-31	13656000000.0000	USD	us-gaap:OperatingIncomeLoss	24
114	1	4	2023	Q1	2023-01-01	2023-03-31	2664000000.0000	USD	us-gaap:OperatingIncomeLoss	25
115	1	4	2023	Q2	2023-04-01	2023-06-30	2399000000.0000	USD	us-gaap:OperatingIncomeLoss	26
116	1	4	2023	Q3	2023-07-01	2023-09-30	1764000000.0000	USD	us-gaap:OperatingIncomeLoss	27
117	1	4	2023	FY	2023-01-01	2023-12-31	8891000000.0000	USD	us-gaap:OperatingIncomeLoss	1
118	1	4	2024	Q1	2024-01-01	2024-03-31	1171000000.0000	USD	us-gaap:OperatingIncomeLoss	28
119	1	4	2024	Q2	2024-04-01	2024-06-30	1605000000.0000	USD	us-gaap:OperatingIncomeLoss	29
120	1	4	2024	Q3	2024-07-01	2024-09-30	2717000000.0000	USD	us-gaap:OperatingIncomeLoss	30
121	1	4	2024	FY	2024-01-01	2024-12-31	7076000000.0000	USD	us-gaap:OperatingIncomeLoss	1
122	1	4	2025	Q1	2025-01-01	2025-03-31	399000000.0000	USD	us-gaap:OperatingIncomeLoss	31
123	1	4	2025	Q2	2025-04-01	2025-06-30	923000000.0000	USD	us-gaap:OperatingIncomeLoss	32
124	1	4	2025	Q3	2025-07-01	2025-09-30	1624000000.0000	USD	us-gaap:OperatingIncomeLoss	33
125	1	4	2025	FY	2025-01-01	2025-12-31	4355000000.0000	USD	us-gaap:OperatingIncomeLoss	1
126	1	4	2026	Q1	2026-01-01	2026-03-31	941000000.0000	USD	us-gaap:OperatingIncomeLoss	31
127	1	4	2026	Q2	2026-04-01	2026-06-30	398000000.0000	USD	us-gaap:OperatingIncomeLoss	32
128	1	4	2026	Q3	2026-07-01	2026-09-30	718000000.0000	USD	us-gaap:OperatingIncomeLoss	33
129	1	5	2019	Q1	2019-01-01	2019-03-31	-702000000.0000	USD	us-gaap:NetIncomeLoss	11
130	1	5	2019	Q2	2019-04-01	2019-06-30	-408000000.0000	USD	us-gaap:NetIncomeLoss	11
131	1	5	2019	Q3	2019-07-01	2019-09-30	143000000.0000	USD	us-gaap:NetIncomeLoss	11
132	1	5	2019	FY	2019-01-01	2019-12-31	-862000000.0000	USD	us-gaap:NetIncomeLoss	12
133	1	5	2019	Q4	2019-10-01	2019-12-31	105000000.0000	USD	us-gaap:NetIncomeLoss	11
134	1	5	2020	Q1	2020-01-01	2020-03-31	16000000.0000	USD	us-gaap:NetIncomeLoss	13
135	1	5	2020	Q2	2020-04-01	2020-06-30	104000000.0000	USD	us-gaap:NetIncomeLoss	14
136	1	5	2020	Q3	2020-07-01	2020-09-30	331000000.0000	USD	us-gaap:NetIncomeLoss	15
137	1	5	2020	FY	2020-01-01	2020-12-31	721000000.0000	USD	us-gaap:NetIncomeLoss	16
138	1	5	2020	Q4	2020-10-01	2020-12-31	270000000.0000	USD	us-gaap:NetIncomeLoss	11
139	1	5	2021	Q1	2021-01-01	2021-03-31	438000000.0000	USD	us-gaap:NetIncomeLoss	17
140	1	5	2021	Q2	2021-04-01	2021-06-30	1142000000.0000	USD	us-gaap:NetIncomeLoss	18
141	1	5	2021	Q3	2021-07-01	2021-09-30	1618000000.0000	USD	us-gaap:NetIncomeLoss	19
142	1	5	2021	FY	2021-01-01	2021-12-31	5644000000.0000	USD	us-gaap:NetIncomeLoss	37
143	1	5	2022	Q1	2022-01-01	2022-03-31	3318000000.0000	USD	us-gaap:NetIncomeLoss	21
144	1	5	2022	Q2	2022-04-01	2022-06-30	2259000000.0000	USD	us-gaap:NetIncomeLoss	22
145	1	5	2022	Q3	2022-07-01	2022-09-30	3292000000.0000	USD	us-gaap:NetIncomeLoss	23
146	1	5	2022	FY	2022-01-01	2022-12-31	12587000000.0000	USD	us-gaap:NetIncomeLoss	37
147	1	5	2023	Q1	2023-01-01	2023-03-31	2513000000.0000	USD	us-gaap:NetIncomeLoss	25
148	1	5	2023	Q2	2023-04-01	2023-06-30	2703000000.0000	USD	us-gaap:NetIncomeLoss	26
149	1	5	2023	Q3	2023-07-01	2023-09-30	1853000000.0000	USD	us-gaap:NetIncomeLoss	27
150	1	5	2023	FY	2023-01-01	2023-12-31	14974000000.0000	USD	us-gaap:NetIncomeLoss	37
151	1	5	2024	Q1	2024-01-01	2024-03-31	1390000000.0000	USD	us-gaap:NetIncomeLoss	28
152	1	5	2024	Q2	2024-04-01	2024-06-30	1400000000.0000	USD	us-gaap:NetIncomeLoss	29
153	1	5	2024	Q3	2024-07-01	2024-09-30	2173000000.0000	USD	us-gaap:NetIncomeLoss	30
154	1	5	2024	FY	2024-01-01	2024-12-31	7153000000.0000	USD	us-gaap:NetIncomeLoss	37
155	1	5	2025	Q1	2025-01-01	2025-03-31	409000000.0000	USD	us-gaap:NetIncomeLoss	31
156	1	5	2025	Q2	2025-04-01	2025-06-30	1172000000.0000	USD	us-gaap:NetIncomeLoss	32
157	1	5	2025	Q3	2025-07-01	2025-09-30	1373000000.0000	USD	us-gaap:NetIncomeLoss	33
158	1	5	2025	FY	2025-01-01	2025-12-31	3855000000.0000	USD	us-gaap:NetIncomeLoss	37
159	1	5	2026	Q1	2026-01-01	2026-03-31	477000000.0000	USD	us-gaap:NetIncomeLoss	31
160	1	5	2026	Q2	2026-04-01	2026-06-30	1114000000.0000	USD	us-gaap:NetIncomeLoss	32
161	1	5	2026	Q3	2026-07-01	2026-09-30	787000000.0000	USD	us-gaap:NetIncomeLoss	33
162	1	6	2019	Q1	2019-01-01	2019-03-31	-640000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	34
163	1	6	2019	FY	2019-01-01	2019-12-31	2405000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	12
164	1	6	2020	Q1	2020-01-01	2020-03-31	-440000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	13
165	1	6	2020	FY	2020-01-01	2020-12-31	5943000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	16
166	1	6	2021	Q1	2021-01-01	2021-03-31	1641000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	17
167	1	6	2021	FY	2021-01-01	2021-12-31	11497000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	20
168	1	6	2022	Q1	2022-01-01	2022-03-31	3995000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	21
169	1	6	2022	FY	2022-01-01	2022-12-31	14724000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	24
170	1	6	2023	Q1	2023-01-01	2023-03-31	2513000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	25
171	1	6	2023	FY	2023-01-01	2023-12-31	13256000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	1
172	1	6	2024	Q1	2024-01-01	2024-03-31	242000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	28
173	1	6	2024	FY	2024-01-01	2024-12-31	14923000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	1
174	1	6	2025	Q1	2025-01-01	2025-03-31	2156000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	31
175	1	6	2025	FY	2025-01-01	2025-12-31	14747000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	1
176	1	6	2026	Q1	2026-01-01	2026-03-31	3937000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	31
177	1	7	2019	Q1	2019-01-01	2019-03-31	280000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	34
178	1	7	2019	FY	2019-01-01	2019-12-31	1327000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	12
179	1	7	2020	Q1	2020-01-01	2020-03-31	455000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	13
180	1	7	2020	FY	2020-01-01	2020-12-31	3157000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	16
181	1	7	2021	Q1	2021-01-01	2021-03-31	1348000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	17
182	1	7	2021	FY	2021-01-01	2021-12-31	6482000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	20
183	1	7	2022	Q1	2022-01-01	2022-03-31	1767000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	21
184	1	7	2022	FY	2022-01-01	2022-12-31	7158000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	24
185	1	7	2023	Q1	2023-01-01	2023-03-31	2072000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	25
186	1	7	2023	FY	2023-01-01	2023-12-31	8899000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	1
187	1	7	2024	Q1	2024-01-01	2024-03-31	2777000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	28
188	1	7	2024	FY	2024-01-01	2024-12-31	11342000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	1
189	1	7	2025	Q1	2025-01-01	2025-03-31	1492000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	31
190	1	7	2025	FY	2025-01-01	2025-12-31	8527000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	1
191	1	7	2026	Q1	2026-01-01	2026-03-31	2493000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	31
192	1	8	2019	Q1	\N	2019-03-31	28912524000.0000	USD	us-gaap:Assets	38
193	1	8	2019	Q2	\N	2019-06-30	31872597000.0000	USD	us-gaap:Assets	39
194	1	8	2019	Q3	\N	2019-09-30	32795000000.0000	USD	us-gaap:Assets	40
195	1	8	2019	FY	\N	2019-12-31	34309000000.0000	USD	us-gaap:Assets	11
196	1	8	2020	Q1	\N	2020-03-31	37250000000.0000	USD	us-gaap:Assets	34
197	1	8	2020	Q2	\N	2020-06-30	38135000000.0000	USD	us-gaap:Assets	35
198	1	8	2020	Q3	\N	2020-09-30	45691000000.0000	USD	us-gaap:Assets	36
199	1	8	2020	FY	\N	2020-12-31	52148000000.0000	USD	us-gaap:Assets	12
200	1	8	2021	Q1	\N	2021-03-31	52972000000.0000	USD	us-gaap:Assets	13
201	1	8	2021	Q2	\N	2021-06-30	55146000000.0000	USD	us-gaap:Assets	14
202	1	8	2021	Q3	\N	2021-09-30	57834000000.0000	USD	us-gaap:Assets	15
203	1	8	2021	FY	\N	2021-12-31	62131000000.0000	USD	us-gaap:Assets	16
204	1	8	2022	Q1	\N	2022-03-31	66038000000.0000	USD	us-gaap:Assets	17
205	1	8	2022	Q2	\N	2022-06-30	68513000000.0000	USD	us-gaap:Assets	18
206	1	8	2022	Q3	\N	2022-09-30	74426000000.0000	USD	us-gaap:Assets	19
207	1	8	2022	FY	\N	2022-12-31	82338000000.0000	USD	us-gaap:Assets	20
208	1	8	2023	Q1	\N	2023-03-31	86833000000.0000	USD	us-gaap:Assets	21
209	1	8	2023	Q2	\N	2023-06-30	90591000000.0000	USD	us-gaap:Assets	22
210	1	8	2023	Q3	\N	2023-09-30	93941000000.0000	USD	us-gaap:Assets	23
211	1	8	2023	FY	\N	2023-12-31	106618000000.0000	USD	us-gaap:Assets	24
212	1	8	2024	Q1	\N	2024-03-31	109226000000.0000	USD	us-gaap:Assets	25
213	1	8	2024	Q2	\N	2024-06-30	112832000000.0000	USD	us-gaap:Assets	26
214	1	8	2024	Q3	\N	2024-09-30	119852000000.0000	USD	us-gaap:Assets	27
215	1	8	2024	FY	\N	2024-12-31	122070000000.0000	USD	us-gaap:Assets	1
216	1	8	2025	Q1	\N	2025-03-31	125111000000.0000	USD	us-gaap:Assets	28
217	1	8	2025	Q2	\N	2025-06-30	128567000000.0000	USD	us-gaap:Assets	29
218	1	8	2025	Q3	\N	2025-09-30	133735000000.0000	USD	us-gaap:Assets	30
219	1	8	2025	FY	\N	2025-12-31	137806000000.0000	USD	us-gaap:Assets	33
220	1	8	2026	Q1	\N	2026-03-31	143724000000.0000	USD	us-gaap:Assets	31
221	1	8	2026	Q2	\N	2026-06-30	148524000000.0000	USD	us-gaap:Assets	32
222	1	8	2026	Q3	\N	2026-09-30	157517000000.0000	USD	us-gaap:Assets	33
223	1	9	2019	Q1	\N	2019-03-31	22874618000.0000	USD	us-gaap:Liabilities	38
224	1	9	2019	Q2	\N	2019-06-30	24722136000.0000	USD	us-gaap:Liabilities	39
225	1	9	2019	Q3	\N	2019-09-30	25313000000.0000	USD	us-gaap:Liabilities	40
226	1	9	2019	FY	\N	2019-12-31	26199000000.0000	USD	us-gaap:Liabilities	11
227	1	9	2020	Q1	\N	2020-03-31	26518000000.0000	USD	us-gaap:Liabilities	34
228	1	9	2020	Q2	\N	2020-06-30	26754000000.0000	USD	us-gaap:Liabilities	35
229	1	9	2020	Q3	\N	2020-09-30	28143000000.0000	USD	us-gaap:Liabilities	36
230	1	9	2020	FY	\N	2020-12-31	28418000000.0000	USD	us-gaap:Liabilities	12
231	1	9	2021	Q1	\N	2021-03-31	28507000000.0000	USD	us-gaap:Liabilities	13
232	1	9	2021	Q2	\N	2021-06-30	28896000000.0000	USD	us-gaap:Liabilities	14
233	1	9	2021	Q3	\N	2021-09-30	29340000000.0000	USD	us-gaap:Liabilities	15
234	1	9	2021	FY	\N	2021-12-31	30548000000.0000	USD	us-gaap:Liabilities	16
235	1	9	2022	Q1	\N	2022-03-31	30632000000.0000	USD	us-gaap:Liabilities	17
236	1	9	2022	Q2	\N	2022-06-30	30855000000.0000	USD	us-gaap:Liabilities	18
237	1	9	2022	Q3	\N	2022-09-30	33302000000.0000	USD	us-gaap:Liabilities	19
238	1	9	2022	FY	\N	2022-12-31	36440000000.0000	USD	us-gaap:Liabilities	20
239	1	9	2023	Q1	\N	2023-03-31	37598000000.0000	USD	us-gaap:Liabilities	21
240	1	9	2023	Q2	\N	2023-06-30	38409000000.0000	USD	us-gaap:Liabilities	22
241	1	9	2023	Q3	\N	2023-09-30	39446000000.0000	USD	us-gaap:Liabilities	23
242	1	9	2023	FY	\N	2023-12-31	43009000000.0000	USD	us-gaap:Liabilities	24
243	1	9	2024	Q1	\N	2024-03-31	44046000000.0000	USD	us-gaap:Liabilities	25
244	1	9	2024	Q2	\N	2024-06-30	45569000000.0000	USD	us-gaap:Liabilities	26
245	1	9	2024	Q3	\N	2024-09-30	49142000000.0000	USD	us-gaap:Liabilities	27
246	1	9	2024	FY	\N	2024-12-31	48390000000.0000	USD	us-gaap:Liabilities	1
247	1	9	2025	Q1	\N	2025-03-31	49693000000.0000	USD	us-gaap:Liabilities	28
248	1	9	2025	Q2	\N	2025-06-30	50495000000.0000	USD	us-gaap:Liabilities	29
249	1	9	2025	Q3	\N	2025-09-30	53019000000.0000	USD	us-gaap:Liabilities	30
250	1	9	2025	FY	\N	2025-12-31	54941000000.0000	USD	us-gaap:Liabilities	33
251	1	9	2026	Q1	\N	2026-03-31	58922000000.0000	USD	us-gaap:Liabilities	31
252	1	9	2026	Q2	\N	2026-06-30	61005000000.0000	USD	us-gaap:Liabilities	32
253	1	9	2026	Q3	\N	2026-09-30	67628000000.0000	USD	us-gaap:Liabilities	33
254	1	10	2019	Q1	\N	2019-03-31	4605596000.0000	USD	us-gaap:StockholdersEquity	38
255	1	10	2019	Q2	\N	2019-06-30	5715393000.0000	USD	us-gaap:StockholdersEquity	39
256	1	10	2019	Q3	\N	2019-09-30	6040000000.0000	USD	us-gaap:StockholdersEquity	40
257	1	10	2019	FY	\N	2019-12-31	6618000000.0000	USD	us-gaap:StockholdersEquity	11
258	1	10	2020	Q1	\N	2020-03-31	9173000000.0000	USD	us-gaap:StockholdersEquity	34
259	1	10	2020	Q2	\N	2020-06-30	9855000000.0000	USD	us-gaap:StockholdersEquity	35
260	1	10	2020	Q3	\N	2020-09-30	16031000000.0000	USD	us-gaap:StockholdersEquity	36
261	1	10	2020	FY	\N	2020-12-31	22225000000.0000	USD	us-gaap:StockholdersEquity	12
262	1	10	2021	Q1	\N	2021-03-31	23017000000.0000	USD	us-gaap:StockholdersEquity	13
263	1	10	2021	Q2	\N	2021-06-30	24804000000.0000	USD	us-gaap:StockholdersEquity	14
264	1	10	2021	Q3	\N	2021-09-30	27053000000.0000	USD	us-gaap:StockholdersEquity	15
265	1	10	2021	FY	\N	2021-12-31	30189000000.0000	USD	us-gaap:StockholdersEquity	16
266	1	10	2022	Q1	\N	2022-03-31	34085000000.0000	USD	us-gaap:StockholdersEquity	17
267	1	10	2022	Q2	\N	2022-06-30	36376000000.0000	USD	us-gaap:StockholdersEquity	18
268	1	10	2022	Q3	\N	2022-09-30	39851000000.0000	USD	us-gaap:StockholdersEquity	19
269	1	10	2022	FY	\N	2022-12-31	44704000000.0000	USD	us-gaap:StockholdersEquity	20
270	1	10	2023	Q1	\N	2023-03-31	48054000000.0000	USD	us-gaap:StockholdersEquity	21
271	1	10	2023	Q2	\N	2023-06-30	51130000000.0000	USD	us-gaap:StockholdersEquity	22
272	1	10	2023	Q3	\N	2023-09-30	53466000000.0000	USD	us-gaap:StockholdersEquity	23
273	1	10	2023	FY	\N	2023-12-31	62634000000.0000	USD	us-gaap:StockholdersEquity	24
274	1	10	2024	Q1	\N	2024-03-31	64378000000.0000	USD	us-gaap:StockholdersEquity	25
275	1	10	2024	Q2	\N	2024-06-30	66468000000.0000	USD	us-gaap:StockholdersEquity	26
276	1	10	2024	Q3	\N	2024-09-30	69931000000.0000	USD	us-gaap:StockholdersEquity	27
277	1	10	2024	FY	\N	2024-12-31	72913000000.0000	USD	us-gaap:StockholdersEquity	1
278	1	10	2025	Q1	\N	2025-03-31	74653000000.0000	USD	us-gaap:StockholdersEquity	28
279	1	10	2025	Q2	\N	2025-06-30	77314000000.0000	USD	us-gaap:StockholdersEquity	29
280	1	10	2025	Q3	\N	2025-09-30	79970000000.0000	USD	us-gaap:StockholdersEquity	30
281	1	10	2025	FY	\N	2025-12-31	82137000000.0000	USD	us-gaap:StockholdersEquity	33
282	1	10	2026	Q1	\N	2026-03-31	84116000000.0000	USD	us-gaap:StockholdersEquity	31
283	1	10	2026	Q2	\N	2026-06-30	86858000000.0000	USD	us-gaap:StockholdersEquity	32
284	1	10	2026	Q3	\N	2026-09-30	89289000000.0000	USD	us-gaap:StockholdersEquity	33
285	1	11	2019	Q1	\N	2019-03-31	2198000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	34
286	1	11	2019	Q2	\N	2019-06-30	4955000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	35
287	1	11	2019	Q3	\N	2019-09-30	5338000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	36
288	1	11	2019	FY	\N	2019-12-31	6268000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	12
289	1	11	2020	Q1	\N	2020-03-31	8080000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	13
290	1	11	2020	Q2	\N	2020-06-30	8615000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	14
291	1	11	2020	Q3	\N	2020-09-30	14531000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	15
292	1	11	2020	FY	\N	2020-12-31	19384000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	16
293	1	11	2021	Q1	\N	2021-03-31	17141000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	17
294	1	11	2021	Q2	\N	2021-06-30	16229000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	18
295	1	11	2021	Q3	\N	2021-09-30	16065000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	19
296	1	11	2021	FY	\N	2021-12-31	17576000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	20
297	1	11	2022	Q1	\N	2022-03-31	17505000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	21
298	1	11	2022	Q2	\N	2022-06-30	18324000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	22
299	1	11	2022	Q3	\N	2022-09-30	19532000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	23
300	1	11	2022	FY	\N	2022-12-31	16253000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	24
301	1	11	2023	Q1	\N	2023-03-31	16048000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	25
302	1	11	2023	Q2	\N	2023-06-30	15296000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	26
303	1	11	2023	Q3	\N	2023-09-30	15932000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	27
304	1	11	2023	FY	\N	2023-12-31	16398000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	1
305	1	11	2024	Q1	\N	2024-03-31	11805000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	28
306	1	11	2024	Q2	\N	2024-06-30	14635000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	29
307	1	11	2024	Q3	\N	2024-09-30	18111000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	30
308	1	11	2024	FY	\N	2024-12-31	16139000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	33
309	1	11	2025	Q1	\N	2025-03-31	16352000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	31
310	1	11	2025	Q2	\N	2025-06-30	15587000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	32
311	1	11	2025	Q3	\N	2025-09-30	18289000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	33
312	1	11	2025	FY	\N	2025-12-31	16513000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	33
313	1	11	2026	Q1	\N	2026-03-31	16603000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	31
314	1	11	2026	Q2	\N	2026-06-30	15219000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	32
315	1	11	2026	Q3	\N	2026-09-30	17853000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	33
316	1	12	2019	Q1	\N	2019-03-31	8650023000.0000	USD	us-gaap:LongTermDebt	38
317	1	12	2019	Q2	\N	2019-06-30	9905847000.0000	USD	us-gaap:LongTermDebt	39
318	1	12	2019	Q3	\N	2019-09-30	10096000000.0000	USD	us-gaap:LongTermDebt	40
319	1	12	2019	FY	\N	2019-12-31	10402000000.0000	USD	us-gaap:LongTermDebt	11
320	1	12	2020	Q1	\N	2020-03-31	9479000000.0000	USD	us-gaap:LongTermDebt	34
321	1	12	2020	Q2	\N	2020-06-30	9247000000.0000	USD	us-gaap:LongTermDebt	35
322	1	12	2020	Q3	\N	2020-09-30	9428000000.0000	USD	us-gaap:LongTermDebt	36
323	1	12	2020	FY	\N	2020-12-31	8462000000.0000	USD	us-gaap:LongTermDebt	12
324	1	12	2021	Q1	\N	2021-03-31	8019000000.0000	USD	us-gaap:LongTermDebt	13
325	1	12	2021	Q2	\N	2021-06-30	6878000000.0000	USD	us-gaap:LongTermDebt	14
326	1	12	2021	Q3	\N	2021-09-30	5439000000.0000	USD	us-gaap:LongTermDebt	15
327	1	12	2021	FY	\N	2021-12-31	4254000000.0000	USD	us-gaap:LongTermDebt	16
328	1	12	2022	Q1	\N	2022-03-31	2253000000.0000	USD	us-gaap:LongTermDebt	17
329	1	12	2022	Q2	\N	2022-06-30	2095000000.0000	USD	us-gaap:LongTermDebt	18
330	1	12	2022	Q3	\N	2022-09-30	1418000000.0000	USD	us-gaap:LongTermDebt	19
331	1	12	2022	FY	\N	2022-12-31	1029000000.0000	USD	us-gaap:LongTermDebt	20
332	1	12	2023	Q1	\N	2023-03-31	817000000.0000	USD	us-gaap:LongTermDebt	21
333	1	12	2023	Q2	\N	2023-06-30	504000000.0000	USD	us-gaap:LongTermDebt	22
334	1	12	2023	Q3	\N	2023-09-30	2152000000.0000	USD	us-gaap:LongTermDebt	23
335	1	12	2023	FY	\N	2023-12-31	2682000000.0000	USD	us-gaap:LongTermDebt	24
336	1	12	2024	Q1	\N	2024-03-31	2739000000.0000	USD	us-gaap:LongTermDebt	25
337	1	12	2024	Q2	\N	2024-06-30	5338000000.0000	USD	us-gaap:LongTermDebt	26
338	1	12	2024	Q3	\N	2024-09-30	5275000000.0000	USD	us-gaap:LongTermDebt	27
339	1	12	2024	FY	\N	2024-12-31	5535000000.0000	USD	us-gaap:LongTermDebt	1
340	1	12	2025	Q1	\N	2025-03-31	5080000000.0000	USD	us-gaap:LongTermDebt	28
341	1	12	2025	Q2	\N	2025-06-30	4994000000.0000	USD	us-gaap:LongTermDebt	29
342	1	12	2025	Q3	\N	2025-09-30	5609000000.0000	USD	us-gaap:LongTermDebt	30
343	1	12	2025	FY	\N	2025-12-31	6584000000.0000	USD	us-gaap:LongTermDebt	33
344	1	12	2026	Q1	\N	2026-03-31	7645000000.0000	USD	us-gaap:LongTermDebt	31
345	1	12	2026	Q2	\N	2026-06-30	7721000000.0000	USD	us-gaap:LongTermDebt	32
346	1	12	2026	Q3	\N	2026-09-30	7956000000.0000	USD	us-gaap:LongTermDebt	33
347	1	13	2019	Q1	\N	2019-03-31	3836850000.0000	USD	us-gaap:InventoryNet	38
348	1	13	2019	Q2	\N	2019-06-30	3382358000.0000	USD	us-gaap:InventoryNet	39
349	1	13	2019	Q3	\N	2019-09-30	3581000000.0000	USD	us-gaap:InventoryNet	40
350	1	13	2019	FY	\N	2019-12-31	3552000000.0000	USD	us-gaap:InventoryNet	11
351	1	13	2020	Q1	\N	2020-03-31	4494000000.0000	USD	us-gaap:InventoryNet	34
352	1	13	2020	Q2	\N	2020-06-30	4018000000.0000	USD	us-gaap:InventoryNet	35
353	1	13	2020	Q3	\N	2020-09-30	4218000000.0000	USD	us-gaap:InventoryNet	36
354	1	13	2020	FY	\N	2020-12-31	4101000000.0000	USD	us-gaap:InventoryNet	12
355	1	13	2021	Q1	\N	2021-03-31	4132000000.0000	USD	us-gaap:InventoryNet	13
356	1	13	2021	Q2	\N	2021-06-30	4733000000.0000	USD	us-gaap:InventoryNet	14
357	1	13	2021	Q3	\N	2021-09-30	5199000000.0000	USD	us-gaap:InventoryNet	15
358	1	13	2021	FY	\N	2021-12-31	5757000000.0000	USD	us-gaap:InventoryNet	16
359	1	13	2022	Q1	\N	2022-03-31	6691000000.0000	USD	us-gaap:InventoryNet	17
360	1	13	2022	Q2	\N	2022-06-30	8108000000.0000	USD	us-gaap:InventoryNet	18
361	1	13	2022	Q3	\N	2022-09-30	10327000000.0000	USD	us-gaap:InventoryNet	19
362	1	13	2022	FY	\N	2022-12-31	12839000000.0000	USD	us-gaap:InventoryNet	20
363	1	13	2023	Q1	\N	2023-03-31	14375000000.0000	USD	us-gaap:InventoryNet	21
364	1	13	2023	Q2	\N	2023-06-30	14356000000.0000	USD	us-gaap:InventoryNet	22
365	1	13	2023	Q3	\N	2023-09-30	13721000000.0000	USD	us-gaap:InventoryNet	23
366	1	13	2023	FY	\N	2023-12-31	13626000000.0000	USD	us-gaap:InventoryNet	24
367	1	13	2024	Q1	\N	2024-03-31	16033000000.0000	USD	us-gaap:InventoryNet	25
368	1	13	2024	Q2	\N	2024-06-30	14195000000.0000	USD	us-gaap:InventoryNet	26
369	1	13	2024	Q3	\N	2024-09-30	14530000000.0000	USD	us-gaap:InventoryNet	27
370	1	13	2024	FY	\N	2024-12-31	12017000000.0000	USD	us-gaap:InventoryNet	1
371	1	13	2025	Q1	\N	2025-03-31	13706000000.0000	USD	us-gaap:InventoryNet	28
372	1	13	2025	Q2	\N	2025-06-30	14570000000.0000	USD	us-gaap:InventoryNet	29
373	1	13	2025	Q3	\N	2025-09-30	12276000000.0000	USD	us-gaap:InventoryNet	30
374	1	13	2025	FY	\N	2025-12-31	12392000000.0000	USD	us-gaap:InventoryNet	33
375	1	13	2026	Q1	\N	2026-03-31	14434000000.0000	USD	us-gaap:InventoryNet	31
376	1	13	2026	Q2	\N	2026-06-30	13752000000.0000	USD	us-gaap:InventoryNet	32
377	1	13	2026	Q3	\N	2026-09-30	14092000000.0000	USD	us-gaap:InventoryNet	33
378	1	14	2019	Q1	2019-01-01	2019-03-31	340000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	34
379	1	14	2019	Q2	2019-04-01	2019-06-30	324000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	35
380	1	14	2019	Q3	2019-07-01	2019-09-30	334000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	36
381	1	14	2019	FY	2019-01-01	2019-12-31	1343000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	12
382	1	14	2020	Q1	2020-01-01	2020-03-31	324000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	13
383	1	14	2020	Q2	2020-04-01	2020-06-30	279000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	14
384	1	14	2020	Q3	2020-07-01	2020-09-30	366000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	15
385	1	14	2020	FY	2020-01-01	2020-12-31	1491000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	16
386	1	14	2021	Q1	2021-01-01	2021-03-31	666000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	17
387	1	14	2021	Q2	2021-04-01	2021-06-30	576000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	18
388	1	14	2021	Q3	2021-07-01	2021-09-30	611000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	19
389	1	14	2021	FY	2021-01-01	2021-12-31	2593000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	20
390	1	14	2022	Q1	2022-01-01	2022-03-31	865000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	21
391	1	14	2022	Q2	2022-04-01	2022-06-30	667000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	22
392	1	14	2022	Q3	2022-07-01	2022-09-30	733000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	23
393	1	14	2022	FY	2022-01-01	2022-12-31	3075000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	24
394	1	14	2023	Q1	2023-01-01	2023-03-31	771000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	25
395	1	14	2023	Q2	2023-04-01	2023-06-30	943000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	26
396	1	14	2023	Q3	2023-07-01	2023-09-30	1161000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	27
397	1	14	2023	FY	2023-01-01	2023-12-31	3969000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	1
398	1	14	2024	Q1	2024-01-01	2024-03-31	1151000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	28
399	1	14	2024	Q2	2024-04-01	2024-06-30	1074000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	29
400	1	14	2024	Q3	2024-07-01	2024-09-30	1039000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	30
401	1	14	2024	FY	2024-01-01	2024-12-31	4540000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	1
402	1	14	2025	Q1	2025-01-01	2025-03-31	1409000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	31
403	1	14	2025	Q2	2025-04-01	2025-06-30	1589000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	32
404	1	14	2025	Q3	2025-07-01	2025-09-30	1630000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	33
405	1	14	2025	FY	2025-01-01	2025-12-31	6411000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	1
406	1	14	2026	Q1	2026-01-01	2026-03-31	1946000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	31
407	1	14	2026	Q2	2026-04-01	2026-06-30	2371000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	32
408	1	14	2026	Q3	2026-07-01	2026-09-30	2761000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	33
409	1	15	2019	Q1	2019-01-01	2019-03-31	208000000.0000	USD	us-gaap:ShareBasedCompensation	34
410	1	15	2019	FY	2019-01-01	2019-12-31	898000000.0000	USD	us-gaap:ShareBasedCompensation	12
411	1	15	2020	Q1	2020-01-01	2020-03-31	211000000.0000	USD	us-gaap:ShareBasedCompensation	13
412	1	15	2020	FY	2020-01-01	2020-12-31	1734000000.0000	USD	us-gaap:ShareBasedCompensation	16
413	1	15	2021	Q1	2021-01-01	2021-03-31	614000000.0000	USD	us-gaap:ShareBasedCompensation	17
414	1	15	2021	FY	2021-01-01	2021-12-31	2121000000.0000	USD	us-gaap:ShareBasedCompensation	20
415	1	15	2022	Q1	2022-01-01	2022-03-31	418000000.0000	USD	us-gaap:ShareBasedCompensation	21
416	1	15	2022	FY	2022-01-01	2022-12-31	1560000000.0000	USD	us-gaap:ShareBasedCompensation	24
417	1	15	2023	Q1	2023-01-01	2023-03-31	418000000.0000	USD	us-gaap:ShareBasedCompensation	25
418	1	15	2023	FY	2023-01-01	2023-12-31	1812000000.0000	USD	us-gaap:ShareBasedCompensation	1
419	1	15	2024	Q1	2024-01-01	2024-03-31	524000000.0000	USD	us-gaap:ShareBasedCompensation	28
420	1	15	2024	FY	2024-01-01	2024-12-31	1999000000.0000	USD	us-gaap:ShareBasedCompensation	1
421	1	15	2025	Q1	2025-01-01	2025-03-31	573000000.0000	USD	us-gaap:ShareBasedCompensation	31
422	1	15	2025	FY	2025-01-01	2025-12-31	2825000000.0000	USD	us-gaap:ShareBasedCompensation	1
423	1	15	2026	Q1	2026-01-01	2026-03-31	1030000000.0000	USD	us-gaap:ShareBasedCompensation	31
424	1	15	2019	Q2	2019-04-01	2019-06-30	210000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	35
425	1	15	2019	Q3	2019-07-01	2019-09-30	199000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	36
426	1	15	2020	Q2	2020-04-01	2020-06-30	347000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	14
427	1	15	2020	Q3	2020-07-01	2020-09-30	543000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	15
428	1	15	2021	Q2	2021-04-01	2021-06-30	474000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	18
429	1	15	2021	Q3	2021-07-01	2021-09-30	475000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	19
430	1	15	2022	Q2	2022-04-01	2022-06-30	361000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	22
431	1	15	2022	Q3	2022-07-01	2022-09-30	362000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	23
432	1	15	2023	Q2	2023-04-01	2023-06-30	445000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	26
433	1	15	2023	Q3	2023-07-01	2023-09-30	465000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	27
434	1	15	2024	Q2	2024-04-01	2024-06-30	439000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	29
435	1	15	2024	Q3	2024-07-01	2024-09-30	457000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	30
436	1	15	2025	Q2	2025-04-01	2025-06-30	635000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	32
437	1	15	2025	Q3	2025-07-01	2025-09-30	663000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	33
438	1	15	2026	Q2	2026-04-01	2026-06-30	1151000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	32
439	1	15	2026	Q3	2026-07-01	2026-09-30	1165000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	33
440	1	17	2019	Q1	2019-01-01	2019-03-31	23000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	34
441	1	17	2019	Q2	2019-04-01	2019-06-30	19000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	35
442	1	17	2019	Q3	2019-07-01	2019-09-30	26000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	36
443	1	17	2019	FY	2019-01-01	2019-12-31	110000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	12
444	1	17	2020	Q1	2020-01-01	2020-03-31	2000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	13
445	1	17	2020	Q2	2020-04-01	2020-06-30	21000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	14
446	1	17	2020	Q3	2020-07-01	2020-09-30	186000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	15
447	1	17	2020	FY	2020-01-01	2020-12-31	292000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	16
448	1	17	2021	Q1	2021-01-01	2021-03-31	69000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	17
449	1	17	2021	Q2	2021-04-01	2021-06-30	115000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	18
450	1	17	2021	Q3	2021-07-01	2021-09-30	223000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	19
451	1	17	2021	FY	2021-01-01	2021-12-31	699000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	20
452	1	17	2022	Q1	2022-01-01	2022-03-31	346000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	21
453	1	17	2022	Q2	2022-04-01	2022-06-30	205000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	22
454	1	17	2022	Q3	2022-07-01	2022-09-30	305000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	23
455	1	17	2022	FY	2022-01-01	2022-12-31	1132000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	24
456	1	17	2023	Q1	2023-01-01	2023-03-31	261000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	25
457	1	17	2023	Q2	2023-04-01	2023-06-30	323000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	26
458	1	17	2023	Q3	2023-07-01	2023-09-30	167000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	27
459	1	17	2023	FY	2023-01-01	2023-12-31	-5001000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	1
460	1	17	2024	Q1	2024-01-01	2024-03-31	483000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	28
461	1	17	2024	Q2	2024-04-01	2024-06-30	371000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	29
462	1	17	2024	Q3	2024-07-01	2024-09-30	602000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	30
463	1	17	2024	FY	2024-01-01	2024-12-31	1837000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	1
464	1	17	2025	Q1	2025-01-01	2025-03-31	169000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	31
465	1	17	2025	Q2	2025-04-01	2025-06-30	359000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	32
466	1	17	2025	Q3	2025-07-01	2025-09-30	570000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	33
467	1	17	2025	FY	2025-01-01	2025-12-31	1423000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	1
468	1	17	2026	Q1	2026-01-01	2026-03-31	257000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	31
469	1	17	2026	Q2	2026-04-01	2026-06-30	201000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	32
470	1	17	2026	Q3	2026-07-01	2026-09-30	152000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	33
471	1	18	2019	Q1	2019-01-01	2019-03-31	-4.1000	USD/shares	us-gaap:EarningsPerShareDiluted	34
472	1	18	2019	Q2	2019-04-01	2019-06-30	-2.3100	USD/shares	us-gaap:EarningsPerShareDiluted	35
473	1	18	2019	Q3	2019-07-01	2019-09-30	0.1600	USD/shares	us-gaap:EarningsPerShareDiluted	36
474	1	18	2019	FY	2019-01-01	2019-12-31	-0.9800	USD/shares	us-gaap:EarningsPerShareDiluted	12
475	1	18	2020	Q1	2020-01-01	2020-03-31	0.0200	USD/shares	us-gaap:EarningsPerShareDiluted	13
476	1	18	2020	Q2	2020-04-01	2020-06-30	0.1000	USD/shares	us-gaap:EarningsPerShareDiluted	14
477	1	18	2020	Q3	2020-07-01	2020-09-30	0.2700	USD/shares	us-gaap:EarningsPerShareDiluted	15
478	1	18	2020	FY	2020-01-01	2020-12-31	0.2100	USD/shares	us-gaap:EarningsPerShareDiluted	16
479	1	18	2021	Q1	2021-01-01	2021-03-31	0.3900	USD/shares	us-gaap:EarningsPerShareDiluted	17
480	1	18	2021	Q2	2021-04-01	2021-06-30	1.0200	USD/shares	us-gaap:EarningsPerShareDiluted	18
481	1	18	2021	Q3	2021-07-01	2021-09-30	0.4800	USD/shares	us-gaap:EarningsPerShareDiluted	19
482	1	18	2021	FY	2021-01-01	2021-12-31	1.6300	USD/shares	us-gaap:EarningsPerShareDiluted	20
483	1	18	2022	Q1	2022-01-01	2022-03-31	0.9500	USD/shares	us-gaap:EarningsPerShareDiluted	21
484	1	18	2022	Q2	2022-04-01	2022-06-30	0.6500	USD/shares	us-gaap:EarningsPerShareDiluted	22
485	1	18	2022	Q3	2022-07-01	2022-09-30	0.9500	USD/shares	us-gaap:EarningsPerShareDiluted	23
486	1	18	2022	FY	2022-01-01	2022-12-31	3.6200	USD/shares	us-gaap:EarningsPerShareDiluted	24
487	1	18	2023	Q1	2023-01-01	2023-03-31	0.7300	USD/shares	us-gaap:EarningsPerShareDiluted	25
488	1	18	2023	Q2	2023-04-01	2023-06-30	0.7800	USD/shares	us-gaap:EarningsPerShareDiluted	26
489	1	18	2023	Q3	2023-07-01	2023-09-30	0.5300	USD/shares	us-gaap:EarningsPerShareDiluted	27
490	1	18	2023	FY	2023-01-01	2023-12-31	4.3000	USD/shares	us-gaap:EarningsPerShareDiluted	1
491	1	18	2024	Q1	2024-01-01	2024-03-31	0.4100	USD/shares	us-gaap:EarningsPerShareDiluted	28
492	1	18	2024	Q2	2024-04-01	2024-06-30	0.4000	USD/shares	us-gaap:EarningsPerShareDiluted	29
493	1	18	2024	Q3	2024-07-01	2024-09-30	0.6200	USD/shares	us-gaap:EarningsPerShareDiluted	30
494	1	18	2024	FY	2024-01-01	2024-12-31	2.0400	USD/shares	us-gaap:EarningsPerShareDiluted	1
495	1	18	2025	Q1	2025-01-01	2025-03-31	0.1200	USD/shares	us-gaap:EarningsPerShareDiluted	31
496	1	18	2025	Q2	2025-04-01	2025-06-30	0.3300	USD/shares	us-gaap:EarningsPerShareDiluted	32
497	1	18	2025	Q3	2025-07-01	2025-09-30	0.3900	USD/shares	us-gaap:EarningsPerShareDiluted	33
498	1	18	2025	FY	2025-01-01	2025-12-31	1.0800	USD/shares	us-gaap:EarningsPerShareDiluted	1
499	1	18	2026	Q1	2026-01-01	2026-03-31	0.1300	USD/shares	us-gaap:EarningsPerShareDiluted	31
500	1	18	2026	Q2	2026-04-01	2026-06-30	0.3200	USD/shares	us-gaap:EarningsPerShareDiluted	32
501	1	18	2026	Q3	2026-07-01	2026-09-30	0.2200	USD/shares	us-gaap:EarningsPerShareDiluted	33
502	2	1	2025	Q2	2025-04-01	2025-06-30	4071000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	41
503	2	1	2025	Q3	2025-07-01	2025-09-30	5576000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	42
504	2	1	2026	Q2	2026-04-01	2026-06-30	7814000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	41
505	2	1	2026	Q3	2026-07-01	2026-09-30	14575000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	42
506	2	2	2025	Q2	2025-04-01	2025-06-30	2282000000.0000	USD	us-gaap:CostOfRevenue	41
507	2	2	2025	Q3	2025-07-01	2025-09-30	2705000000.0000	USD	us-gaap:CostOfRevenue	42
508	2	2	2026	Q2	2026-04-01	2026-06-30	3495000000.0000	USD	us-gaap:CostOfRevenue	41
509	2	2	2026	Q3	2026-07-01	2026-09-30	5478000000.0000	USD	us-gaap:CostOfRevenue	42
510	2	4	2025	Q2	2025-04-01	2025-06-30	-970000000.0000	USD	us-gaap:OperatingIncomeLoss	41
511	2	4	2025	Q3	2025-07-01	2025-09-30	-273000000.0000	USD	us-gaap:OperatingIncomeLoss	42
512	2	4	2026	Q2	2026-04-01	2026-06-30	-143000000.0000	USD	us-gaap:OperatingIncomeLoss	41
513	2	4	2026	Q3	2026-07-01	2026-09-30	2791000000.0000	USD	us-gaap:OperatingIncomeLoss	42
514	2	5	2025	Q2	2025-04-01	2025-06-30	-1008000000.0000	USD	us-gaap:NetIncomeLoss	41
515	2	5	2025	Q3	2025-07-01	2025-09-30	-1054000000.0000	USD	us-gaap:NetIncomeLoss	42
516	2	5	2026	Q2	2026-04-01	2026-06-30	-541000000.0000	USD	us-gaap:NetIncomeLoss	41
517	2	5	2026	Q3	2026-07-01	2026-09-30	4404000000.0000	USD	us-gaap:NetIncomeLoss	42
518	2	8	2025	FY	\N	2025-12-31	92079000000.0000	USD	us-gaap:Assets	42
519	2	8	2026	Q2	\N	2026-06-30	192770000000.0000	USD	us-gaap:Assets	41
520	2	8	2026	Q3	\N	2026-09-30	254045000000.0000	USD	us-gaap:Assets	42
521	2	9	2025	FY	\N	2025-12-31	50754000000.0000	USD	us-gaap:Liabilities	42
522	2	9	2026	Q2	\N	2026-06-30	65546000000.0000	USD	us-gaap:Liabilities	41
523	2	9	2026	Q3	\N	2026-09-30	77277000000.0000	USD	us-gaap:Liabilities	42
524	2	10	2024	FY	\N	2024-12-31	4863000000.0000	USD	us-gaap:StockholdersEquity	42
525	2	10	2025	Q1	\N	2025-03-31	5319000000.0000	USD	us-gaap:StockholdersEquity	41
526	2	10	2025	Q2	\N	2025-06-30	5217000000.0000	USD	us-gaap:StockholdersEquity	42
527	2	10	2025	Q3	\N	2025-09-30	4655000000.0000	USD	us-gaap:StockholdersEquity	42
528	2	10	2025	FY	\N	2025-12-31	2573000000.0000	USD	us-gaap:StockholdersEquity	42
529	2	10	2026	Q1	\N	2026-03-31	34533000000.0000	USD	us-gaap:StockholdersEquity	41
530	2	10	2026	Q2	\N	2026-06-30	127224000000.0000	USD	us-gaap:StockholdersEquity	42
531	2	10	2026	Q3	\N	2026-09-30	176768000000.0000	USD	us-gaap:StockholdersEquity	42
532	2	11	2025	FY	\N	2025-12-31	24747000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	42
533	2	11	2026	Q2	\N	2026-06-30	93522000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	41
534	2	11	2026	Q3	\N	2026-09-30	51294000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	42
535	2	12	2025	FY	\N	2025-12-31	21659000000.0000	USD	us-gaap:LongTermDebt	42
536	2	12	2026	Q2	\N	2026-06-30	38285000000.0000	USD	us-gaap:LongTermDebt	41
537	2	12	2026	Q3	\N	2026-09-30	37861000000.0000	USD	us-gaap:LongTermDebt	42
538	2	13	2025	FY	\N	2025-12-31	2416000000.0000	USD	us-gaap:InventoryNet	42
539	2	13	2026	Q2	\N	2026-06-30	2718000000.0000	USD	us-gaap:InventoryNet	41
540	2	13	2026	Q3	\N	2026-09-30	2891000000.0000	USD	us-gaap:InventoryNet	42
541	2	14	2025	Q2	2025-04-01	2025-06-30	1958000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	41
542	2	14	2025	Q3	2025-07-01	2025-09-30	2291000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	42
543	2	14	2026	Q2	2026-04-01	2026-06-30	3548000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	41
544	2	14	2026	Q3	2026-07-01	2026-09-30	4596000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	42
545	2	15	2025	Q2	2025-04-01	2025-06-30	463000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	41
546	2	15	2025	Q3	2025-07-01	2025-09-30	350000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	42
547	2	15	2026	Q2	2026-04-01	2026-06-30	831000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	41
548	2	15	2026	Q3	2026-07-01	2026-09-30	2363000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	42
549	2	17	2025	Q2	2025-04-01	2025-06-30	138000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	41
550	2	17	2025	Q3	2025-07-01	2025-09-30	562000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	42
551	2	17	2026	Q2	2026-04-01	2026-06-30	23000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	41
552	2	17	2026	Q3	2026-07-01	2026-09-30	-390000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	42
553	2	18	2025	Q2	2025-04-01	2025-06-30	-0.3400	USD/shares	us-gaap:EarningsPerShareDiluted	41
554	2	18	2025	Q3	2025-07-01	2025-09-30	-0.3600	USD/shares	us-gaap:EarningsPerShareDiluted	42
555	2	18	2026	Q2	2026-04-01	2026-06-30	-0.0900	USD/shares	us-gaap:EarningsPerShareDiluted	41
556	2	18	2026	Q3	2026-07-01	2026-09-30	0.3500	USD/shares	us-gaap:EarningsPerShareDiluted	42
557	3	1	2020	Q3	2020-07-01	2020-09-30	10670000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	43
558	3	1	2020	FY	2020-01-01	2020-12-31	35160000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	44
559	3	1	2021	Q1	2021-01-01	2021-03-31	18192000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	45
560	3	1	2021	Q2	2021-04-01	2021-06-30	11280000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	46
561	3	1	2021	Q3	2021-07-01	2021-09-30	5287000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	47
562	3	1	2021	FY	2021-01-01	2021-12-31	62237000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	48
563	3	1	2022	Q1	2022-01-01	2022-03-31	40703000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	49
564	3	1	2022	Q2	2022-04-01	2022-06-30	55474000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	50
565	3	1	2022	Q3	2022-07-01	2022-09-30	63057000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	51
566	3	1	2022	FY	2022-01-01	2022-12-31	210996000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	52
567	3	1	2023	Q1	2023-01-01	2023-03-31	54895000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	53
568	3	1	2023	Q2	2023-04-01	2023-06-30	62045000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	54
569	3	1	2023	Q3	2023-07-01	2023-09-30	67661000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	55
570	3	1	2023	FY	2023-01-01	2023-12-31	244592000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	3
571	3	1	2024	Q1	2024-01-01	2024-03-31	92767000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	56
572	3	1	2024	Q2	2024-04-01	2024-06-30	106251000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	57
573	3	1	2024	Q3	2024-07-01	2024-09-30	104808000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	58
574	3	1	2024	FY	2024-01-01	2024-12-31	436214000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	3
575	3	1	2025	Q1	2025-01-01	2025-03-31	122569000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	59
576	3	1	2025	Q2	2025-04-01	2025-06-30	144498000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	60
577	3	1	2025	Q3	2025-07-01	2025-09-30	155080000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	61
578	3	1	2025	FY	2025-01-01	2025-12-31	601799000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	3
579	3	1	2026	Q1	2026-01-01	2026-03-31	200348000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	59
580	3	1	2026	Q2	2026-04-01	2026-06-30	234066000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	60
581	3	1	2026	Q3	2026-07-01	2026-09-30	267834000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	61
582	3	2	2020	Q3	2020-07-01	2020-09-30	12555000.0000	USD	us-gaap:CostOfRevenue	43
583	3	2	2020	FY	2020-01-01	2020-12-31	46977000.0000	USD	us-gaap:CostOfRevenue	44
584	3	2	2021	Q1	2021-01-01	2021-03-31	16781000.0000	USD	us-gaap:CostOfRevenue	45
585	3	2	2021	Q2	2021-04-01	2021-06-30	8817000.0000	USD	us-gaap:CostOfRevenue	46
586	3	2	2021	Q3	2021-07-01	2021-09-30	17738000.0000	USD	us-gaap:CostOfRevenue	47
587	3	2	2021	FY	2021-01-01	2021-12-31	64130000.0000	USD	us-gaap:CostOfRevenue	48
588	3	2	2022	Q1	2022-01-01	2022-03-31	36968000.0000	USD	us-gaap:CostOfRevenue	49
589	3	2	2022	Q2	2022-04-01	2022-06-30	50516000.0000	USD	us-gaap:CostOfRevenue	50
590	3	2	2022	Q3	2022-07-01	2022-09-30	54590000.0000	USD	us-gaap:CostOfRevenue	51
591	3	2	2022	FY	2022-01-01	2022-12-31	192006000.0000	USD	us-gaap:CostOfRevenue	52
592	3	2	2023	Q1	2023-01-01	2023-03-31	48538000.0000	USD	us-gaap:CostOfRevenue	53
593	3	2	2023	Q2	2023-04-01	2023-06-30	47452000.0000	USD	us-gaap:CostOfRevenue	54
594	3	2	2023	Q3	2023-07-01	2023-09-30	52694000.0000	USD	us-gaap:CostOfRevenue	55
595	3	2	2023	FY	2023-01-01	2023-12-31	193183000.0000	USD	us-gaap:CostOfRevenue	3
596	3	2	2024	Q1	2024-01-01	2024-03-31	68593000.0000	USD	us-gaap:CostOfRevenue	56
597	3	2	2024	Q2	2024-04-01	2024-06-30	79089000.0000	USD	us-gaap:CostOfRevenue	57
598	3	2	2024	Q3	2024-07-01	2024-09-30	76812000.0000	USD	us-gaap:CostOfRevenue	58
599	3	2	2024	FY	2024-01-01	2024-12-31	320065000.0000	USD	us-gaap:CostOfRevenue	3
600	3	2	2025	Q1	2025-01-01	2025-03-31	87322000.0000	USD	us-gaap:CostOfRevenue	59
601	3	2	2025	Q2	2025-04-01	2025-06-30	98110000.0000	USD	us-gaap:CostOfRevenue	60
602	3	2	2025	Q3	2025-07-01	2025-09-30	97766000.0000	USD	us-gaap:CostOfRevenue	61
603	3	2	2025	FY	2025-01-01	2025-12-31	394618000.0000	USD	us-gaap:CostOfRevenue	3
604	3	2	2026	Q1	2026-01-01	2026-03-31	123855000.0000	USD	us-gaap:CostOfRevenue	59
605	3	2	2026	Q2	2026-04-01	2026-06-30	149490000.0000	USD	us-gaap:CostOfRevenue	60
606	3	2	2026	Q3	2026-07-01	2026-09-30	177763000.0000	USD	us-gaap:CostOfRevenue	61
607	3	3	2020	Q3	2020-07-01	2020-09-30	-1885000.0000	USD	us-gaap:GrossProfit	43
608	3	3	2020	FY	2020-01-01	2020-12-31	-11817000.0000	USD	us-gaap:GrossProfit	44
609	3	3	2021	Q1	2021-01-01	2021-03-31	1411000.0000	USD	us-gaap:GrossProfit	45
610	3	3	2021	Q2	2021-04-01	2021-06-30	2463000.0000	USD	us-gaap:GrossProfit	46
611	3	3	2021	Q3	2021-07-01	2021-09-30	-12451000.0000	USD	us-gaap:GrossProfit	47
612	3	3	2021	FY	2021-01-01	2021-12-31	-1893000.0000	USD	us-gaap:GrossProfit	48
613	3	3	2022	Q1	2022-01-01	2022-03-31	3735000.0000	USD	us-gaap:GrossProfit	49
614	3	3	2022	Q2	2022-04-01	2022-06-30	4958000.0000	USD	us-gaap:GrossProfit	50
615	3	3	2022	Q3	2022-07-01	2022-09-30	8467000.0000	USD	us-gaap:GrossProfit	51
616	3	3	2022	FY	2022-01-01	2022-12-31	18990000.0000	USD	us-gaap:GrossProfit	52
617	3	3	2023	Q1	2023-01-01	2023-03-31	6357000.0000	USD	us-gaap:GrossProfit	53
618	3	3	2023	Q2	2023-04-01	2023-06-30	14593000.0000	USD	us-gaap:GrossProfit	54
619	3	3	2023	Q3	2023-07-01	2023-09-30	14967000.0000	USD	us-gaap:GrossProfit	55
620	3	3	2023	FY	2023-01-01	2023-12-31	51409000.0000	USD	us-gaap:GrossProfit	3
621	3	3	2024	Q1	2024-01-01	2024-03-31	24174000.0000	USD	us-gaap:GrossProfit	56
622	3	3	2024	Q2	2024-04-01	2024-06-30	27162000.0000	USD	us-gaap:GrossProfit	57
623	3	3	2024	Q3	2024-07-01	2024-09-30	27996000.0000	USD	us-gaap:GrossProfit	58
624	3	3	2024	FY	2024-01-01	2024-12-31	116149000.0000	USD	us-gaap:GrossProfit	3
625	3	3	2025	Q1	2025-01-01	2025-03-31	35247000.0000	USD	us-gaap:GrossProfit	59
626	3	3	2025	Q2	2025-04-01	2025-06-30	46388000.0000	USD	us-gaap:GrossProfit	60
627	3	3	2025	Q3	2025-07-01	2025-09-30	57314000.0000	USD	us-gaap:GrossProfit	61
628	3	3	2025	FY	2025-01-01	2025-12-31	207181000.0000	USD	us-gaap:GrossProfit	3
629	3	3	2026	Q1	2026-01-01	2026-03-31	76493000.0000	USD	us-gaap:GrossProfit	59
630	3	3	2026	Q2	2026-04-01	2026-06-30	84576000.0000	USD	us-gaap:GrossProfit	60
631	3	3	2026	Q3	2026-07-01	2026-09-30	90071000.0000	USD	us-gaap:GrossProfit	61
632	3	4	2020	Q3	2020-07-01	2020-09-30	-12845000.0000	USD	us-gaap:OperatingIncomeLoss	43
633	3	4	2020	FY	2020-01-01	2020-12-31	-54952000.0000	USD	us-gaap:OperatingIncomeLoss	44
634	3	4	2021	Q1	2021-01-01	2021-03-31	-12291000.0000	USD	us-gaap:OperatingIncomeLoss	45
635	3	4	2021	Q2	2021-04-01	2021-06-30	-13134000.0000	USD	us-gaap:OperatingIncomeLoss	46
636	3	4	2021	Q3	2021-07-01	2021-09-30	-52295000.0000	USD	us-gaap:OperatingIncomeLoss	47
637	3	4	2021	FY	2021-01-01	2021-12-31	-102053000.0000	USD	us-gaap:OperatingIncomeLoss	48
638	3	4	2022	Q1	2022-01-01	2022-03-31	-32820000.0000	USD	us-gaap:OperatingIncomeLoss	49
639	3	4	2022	Q2	2022-04-01	2022-06-30	-33159000.0000	USD	us-gaap:OperatingIncomeLoss	50
640	3	4	2022	Q3	2022-07-01	2022-09-30	-32002000.0000	USD	us-gaap:OperatingIncomeLoss	51
641	3	4	2022	FY	2022-01-01	2022-12-31	-135204000.0000	USD	us-gaap:OperatingIncomeLoss	52
642	3	4	2023	Q1	2023-01-01	2023-03-31	-46017000.0000	USD	us-gaap:OperatingIncomeLoss	53
643	3	4	2023	Q2	2023-04-01	2023-06-30	-45159000.0000	USD	us-gaap:OperatingIncomeLoss	54
644	3	4	2023	Q3	2023-07-01	2023-09-30	-38859000.0000	USD	us-gaap:OperatingIncomeLoss	55
645	3	4	2023	FY	2023-01-01	2023-12-31	-177918000.0000	USD	us-gaap:OperatingIncomeLoss	3
646	3	4	2024	Q1	2024-01-01	2024-03-31	-43079000.0000	USD	us-gaap:OperatingIncomeLoss	56
647	3	4	2024	Q2	2024-04-01	2024-06-30	-43274000.0000	USD	us-gaap:OperatingIncomeLoss	57
648	3	4	2024	Q3	2024-07-01	2024-09-30	-51899000.0000	USD	us-gaap:OperatingIncomeLoss	58
649	3	4	2024	FY	2024-01-01	2024-12-31	-189801000.0000	USD	us-gaap:OperatingIncomeLoss	3
650	3	4	2025	Q1	2025-01-01	2025-03-31	-59188000.0000	USD	us-gaap:OperatingIncomeLoss	59
651	3	4	2025	Q2	2025-04-01	2025-06-30	-59639000.0000	USD	us-gaap:OperatingIncomeLoss	60
652	3	4	2025	Q3	2025-07-01	2025-09-30	-58969000.0000	USD	us-gaap:OperatingIncomeLoss	61
653	3	4	2025	FY	2025-01-01	2025-12-31	-228838000.0000	USD	us-gaap:OperatingIncomeLoss	3
654	3	4	2026	Q1	2026-01-01	2026-03-31	-55969000.0000	USD	us-gaap:OperatingIncomeLoss	59
655	3	4	2026	Q2	2026-04-01	2026-06-30	-57514000.0000	USD	us-gaap:OperatingIncomeLoss	60
656	3	4	2026	Q3	2026-07-01	2026-09-30	-79189000.0000	USD	us-gaap:OperatingIncomeLoss	61
657	3	5	2020	Q1	2020-01-01	2020-03-31	-14247000.0000	USD	us-gaap:NetIncomeLoss	43
658	3	5	2020	Q2	2020-04-01	2020-06-30	-9206000.0000	USD	us-gaap:NetIncomeLoss	43
659	3	5	2020	Q3	2020-07-01	2020-09-30	-12605000.0000	USD	us-gaap:NetIncomeLoss	43
660	3	5	2020	FY	2020-01-01	2020-12-31	-55005000.0000	USD	us-gaap:NetIncomeLoss	44
661	3	5	2021	Q1	2021-01-01	2021-03-31	-15882000.0000	USD	us-gaap:NetIncomeLoss	47
662	3	5	2021	Q2	2021-04-01	2021-06-30	-16665000.0000	USD	us-gaap:NetIncomeLoss	47
663	3	5	2021	Q3	2021-07-01	2021-09-30	-87969000.0000	USD	us-gaap:NetIncomeLoss	47
664	3	5	2021	FY	2021-01-01	2021-12-31	-117320000.0000	USD	us-gaap:NetIncomeLoss	62
665	3	5	2022	Q1	2022-01-01	2022-03-31	-26709000.0000	USD	us-gaap:NetIncomeLoss	51
666	3	5	2022	Q2	2022-04-01	2022-06-30	-37417000.0000	USD	us-gaap:NetIncomeLoss	51
667	3	5	2022	Q3	2022-07-01	2022-09-30	-34610000.0000	USD	us-gaap:NetIncomeLoss	51
668	3	5	2022	FY	2022-01-01	2022-12-31	-135944000.0000	USD	us-gaap:NetIncomeLoss	62
669	3	5	2023	Q1	2023-01-01	2023-03-31	-45617000.0000	USD	us-gaap:NetIncomeLoss	55
670	3	5	2023	Q2	2023-04-01	2023-06-30	-45889000.0000	USD	us-gaap:NetIncomeLoss	55
671	3	5	2023	Q3	2023-07-01	2023-09-30	-40568000.0000	USD	us-gaap:NetIncomeLoss	55
672	3	5	2023	FY	2023-01-01	2023-12-31	-182571000.0000	USD	us-gaap:NetIncomeLoss	62
673	3	5	2024	Q1	2024-01-01	2024-03-31	-44260000.0000	USD	us-gaap:NetIncomeLoss	58
674	3	5	2024	Q2	2024-04-01	2024-06-30	-41631000.0000	USD	us-gaap:NetIncomeLoss	58
675	3	5	2024	Q3	2024-07-01	2024-09-30	-51939000.0000	USD	us-gaap:NetIncomeLoss	58
676	3	5	2024	FY	2024-01-01	2024-12-31	-190175000.0000	USD	us-gaap:NetIncomeLoss	62
677	3	5	2025	Q1	2025-01-01	2025-03-31	-60616000.0000	USD	us-gaap:NetIncomeLoss	61
678	3	5	2025	Q2	2025-04-01	2025-06-30	-66414000.0000	USD	us-gaap:NetIncomeLoss	61
679	3	5	2025	Q3	2025-07-01	2025-09-30	-18257000.0000	USD	us-gaap:NetIncomeLoss	61
680	3	5	2025	FY	2025-01-01	2025-12-31	-198209000.0000	USD	us-gaap:NetIncomeLoss	62
681	3	5	2026	Q1	2026-01-01	2026-03-31	-45022000.0000	USD	us-gaap:NetIncomeLoss	61
682	3	5	2026	Q2	2026-04-01	2026-06-30	-49258000.0000	USD	us-gaap:NetIncomeLoss	61
683	3	5	2026	Q3	2026-07-01	2026-09-30	-79677000.0000	USD	us-gaap:NetIncomeLoss	61
684	3	6	2020	Q3	2020-07-28	2020-09-30	-448248.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	63
685	3	6	2020	FY	2020-01-01	2020-12-31	-27757000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	44
686	3	6	2021	Q1	2021-01-01	2021-03-31	-15479000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	45
687	3	6	2021	FY	2021-01-01	2021-12-31	-71791000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	48
688	3	6	2022	Q1	2022-01-01	2022-03-31	-26339000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	49
689	3	6	2022	FY	2022-01-01	2022-12-31	-106538000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	52
690	3	6	2023	Q1	2023-01-01	2023-03-31	-25385000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	53
691	3	6	2023	FY	2023-01-01	2023-12-31	-98867000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	3
692	3	6	2024	Q1	2024-01-01	2024-03-31	-2588000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	56
693	3	6	2024	FY	2024-01-01	2024-12-31	-48890000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	3
694	3	6	2025	Q1	2025-01-01	2025-03-31	-54225000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	59
695	3	6	2025	FY	2025-01-01	2025-12-31	-165521000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	3
696	3	6	2026	Q1	2026-01-01	2026-03-31	-50332000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	59
697	3	7	2020	FY	2020-01-01	2020-12-31	25121000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	44
698	3	7	2021	Q1	2021-01-01	2021-03-31	4046000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	45
699	3	7	2021	FY	2021-01-01	2021-12-31	25699000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	48
700	3	7	2022	Q1	2022-01-01	2022-03-31	6242000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	49
701	3	7	2022	FY	2022-01-01	2022-12-31	42412000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	52
702	3	7	2023	Q1	2023-01-01	2023-03-31	12674000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	53
703	3	7	2023	FY	2023-01-01	2023-12-31	54707000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	3
704	3	7	2024	Q1	2024-01-01	2024-03-31	19177000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	56
705	3	7	2024	FY	2024-01-01	2024-12-31	67093000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	3
706	3	7	2025	Q1	2025-01-01	2025-03-31	28677000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	59
707	3	7	2025	FY	2025-01-01	2025-12-31	156285000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	3
708	3	7	2026	Q1	2026-01-01	2026-03-31	27065000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	59
709	3	8	2020	Q3	\N	2020-09-30	301352520.0000	USD	us-gaap:Assets	63
710	3	8	2020	FY	\N	2020-12-31	187869000.0000	USD	us-gaap:Assets	64
711	3	8	2021	Q1	\N	2021-03-31	320787359.0000	USD	us-gaap:Assets	65
712	3	8	2021	Q2	\N	2021-06-30	320343990.0000	USD	us-gaap:Assets	66
713	3	8	2021	Q3	\N	2021-09-30	955377000.0000	USD	us-gaap:Assets	43
714	3	8	2021	FY	\N	2021-12-31	980847000.0000	USD	us-gaap:Assets	44
715	3	8	2022	Q1	\N	2022-03-31	1057484000.0000	USD	us-gaap:Assets	45
716	3	8	2022	Q2	\N	2022-06-30	1004752000.0000	USD	us-gaap:Assets	46
717	3	8	2022	Q3	\N	2022-09-30	1001362000.0000	USD	us-gaap:Assets	47
718	3	8	2022	FY	\N	2022-12-31	989123000.0000	USD	us-gaap:Assets	48
719	3	8	2023	Q1	\N	2023-03-31	990908000.0000	USD	us-gaap:Assets	49
720	3	8	2023	Q2	\N	2023-06-30	981496000.0000	USD	us-gaap:Assets	50
721	3	8	2023	Q3	\N	2023-09-30	950493000.0000	USD	us-gaap:Assets	51
722	3	8	2023	FY	\N	2023-12-31	941211000.0000	USD	us-gaap:Assets	52
723	3	8	2024	Q1	\N	2024-03-31	1181924000.0000	USD	us-gaap:Assets	53
724	3	8	2024	Q2	\N	2024-06-30	1188598000.0000	USD	us-gaap:Assets	54
725	3	8	2024	Q3	\N	2024-09-30	1153029000.0000	USD	us-gaap:Assets	55
726	3	8	2024	FY	\N	2024-12-31	1184342000.0000	USD	us-gaap:Assets	3
727	3	8	2025	Q1	\N	2025-03-31	1254973000.0000	USD	us-gaap:Assets	56
728	3	8	2025	Q2	\N	2025-06-30	1553233000.0000	USD	us-gaap:Assets	57
729	3	8	2025	Q3	\N	2025-09-30	2221395000.0000	USD	us-gaap:Assets	58
730	3	8	2025	FY	\N	2025-12-31	2324478000.0000	USD	us-gaap:Assets	61
731	3	8	2026	Q1	\N	2026-03-31	2819941000.0000	USD	us-gaap:Assets	59
732	3	8	2026	Q2	\N	2026-06-30	4187374000.0000	USD	us-gaap:Assets	60
733	3	8	2026	Q3	\N	2026-09-30	6568707000.0000	USD	us-gaap:Assets	61
734	3	9	2020	Q3	\N	2020-09-30	10500600.0000	USD	us-gaap:Liabilities	63
735	3	9	2020	FY	\N	2020-12-31	79617000.0000	USD	us-gaap:Liabilities	64
736	3	9	2021	Q1	\N	2021-03-31	59090288.0000	USD	us-gaap:Liabilities	65
737	3	9	2021	Q2	\N	2021-06-30	59706013.0000	USD	us-gaap:Liabilities	66
738	3	9	2021	Q3	\N	2021-09-30	281259000.0000	USD	us-gaap:Liabilities	43
739	3	9	2021	FY	\N	2021-12-31	282399000.0000	USD	us-gaap:Liabilities	44
740	3	9	2022	Q1	\N	2022-03-31	324889000.0000	USD	us-gaap:Liabilities	45
741	3	9	2022	Q2	\N	2022-06-30	291298000.0000	USD	us-gaap:Liabilities	46
742	3	9	2022	Q3	\N	2022-09-30	310526000.0000	USD	us-gaap:Liabilities	47
743	3	9	2022	FY	\N	2022-12-31	315917000.0000	USD	us-gaap:Liabilities	48
744	3	9	2023	Q1	\N	2023-03-31	350890000.0000	USD	us-gaap:Liabilities	49
745	3	9	2023	Q2	\N	2023-06-30	370448000.0000	USD	us-gaap:Liabilities	50
746	3	9	2023	Q3	\N	2023-09-30	364691000.0000	USD	us-gaap:Liabilities	51
747	3	9	2023	FY	\N	2023-12-31	386667000.0000	USD	us-gaap:Liabilities	52
748	3	9	2024	Q1	\N	2024-03-31	702978000.0000	USD	us-gaap:Liabilities	53
749	3	9	2024	Q2	\N	2024-06-30	733418000.0000	USD	us-gaap:Liabilities	54
750	3	9	2024	Q3	\N	2024-09-30	733194000.0000	USD	us-gaap:Liabilities	55
751	3	9	2024	FY	\N	2024-12-31	801889000.0000	USD	us-gaap:Liabilities	3
752	3	9	2025	Q1	\N	2025-03-31	823679000.0000	USD	us-gaap:Liabilities	56
753	3	9	2025	Q2	\N	2025-06-30	864748000.0000	USD	us-gaap:Liabilities	57
754	3	9	2025	Q3	\N	2025-09-30	940409000.0000	USD	us-gaap:Liabilities	58
755	3	9	2025	FY	\N	2025-12-31	602624000.0000	USD	us-gaap:Liabilities	61
756	3	9	2026	Q1	\N	2026-03-31	555574000.0000	USD	us-gaap:Liabilities	59
757	3	9	2026	Q2	\N	2026-06-30	695221000.0000	USD	us-gaap:Liabilities	60
758	3	9	2026	Q3	\N	2026-09-30	766137000.0000	USD	us-gaap:Liabilities	61
759	3	10	2019	FY	\N	2019-12-31	-118529000.0000	USD	us-gaap:StockholdersEquity	44
760	3	10	2020	Q1	\N	2020-03-31	-132484000.0000	USD	us-gaap:StockholdersEquity	43
761	3	10	2020	Q2	\N	2020-06-30	-140404000.0000	USD	us-gaap:StockholdersEquity	43
762	3	10	2020	Q3	\N	2020-09-30	-151753000.0000	USD	us-gaap:StockholdersEquity	43
763	3	10	2020	FY	\N	2020-12-31	-166708000.0000	USD	us-gaap:StockholdersEquity	48
764	3	10	2021	Q1	\N	2021-03-31	-180205000.0000	USD	us-gaap:StockholdersEquity	47
765	3	10	2021	Q2	\N	2021-06-30	-195029000.0000	USD	us-gaap:StockholdersEquity	47
766	3	10	2021	Q3	\N	2021-09-30	674126000.0000	USD	us-gaap:StockholdersEquity	47
767	3	10	2021	FY	\N	2021-12-31	698448000.0000	USD	us-gaap:StockholdersEquity	52
768	3	10	2022	Q1	\N	2022-03-31	732595000.0000	USD	us-gaap:StockholdersEquity	51
769	3	10	2022	Q2	\N	2022-06-30	713454000.0000	USD	us-gaap:StockholdersEquity	51
770	3	10	2022	Q3	\N	2022-09-30	690836000.0000	USD	us-gaap:StockholdersEquity	51
771	3	10	2022	FY	\N	2022-12-31	673206000.0000	USD	us-gaap:StockholdersEquity	3
772	3	10	2023	Q1	\N	2023-03-31	640018000.0000	USD	us-gaap:StockholdersEquity	55
773	3	10	2023	Q2	\N	2023-06-30	611048000.0000	USD	us-gaap:StockholdersEquity	55
774	3	10	2023	Q3	\N	2023-09-30	585802000.0000	USD	us-gaap:StockholdersEquity	55
775	3	10	2023	FY	\N	2023-12-31	554544000.0000	USD	us-gaap:StockholdersEquity	3
776	3	10	2024	Q1	\N	2024-03-31	478946000.0000	USD	us-gaap:StockholdersEquity	58
777	3	10	2024	Q2	\N	2024-06-30	455180000.0000	USD	us-gaap:StockholdersEquity	58
778	3	10	2024	Q3	\N	2024-09-30	419835000.0000	USD	us-gaap:StockholdersEquity	58
779	3	10	2024	FY	\N	2024-12-31	382453000.0000	USD	us-gaap:StockholdersEquity	61
780	3	10	2025	Q1	\N	2025-03-31	431294000.0000	USD	us-gaap:StockholdersEquity	61
781	3	10	2025	Q2	\N	2025-06-30	688485000.0000	USD	us-gaap:StockholdersEquity	61
782	3	10	2025	Q3	\N	2025-09-30	1280986000.0000	USD	us-gaap:StockholdersEquity	61
783	3	10	2025	FY	\N	2025-12-31	1721854000.0000	USD	us-gaap:StockholdersEquity	61
784	3	10	2026	Q1	\N	2026-03-31	2264367000.0000	USD	us-gaap:StockholdersEquity	61
785	3	10	2026	Q2	\N	2026-06-30	3492153000.0000	USD	us-gaap:StockholdersEquity	61
786	3	10	2026	Q3	\N	2026-09-30	5802570000.0000	USD	us-gaap:StockholdersEquity	61
787	3	11	2020	Q3	\N	2020-09-30	924370.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	63
788	3	11	2020	FY	\N	2020-12-31	52792000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	64
789	3	11	2021	Q1	\N	2021-03-31	425453.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	65
790	3	11	2021	Q2	\N	2021-06-30	44846.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	66
791	3	11	2021	Q3	\N	2021-09-30	792660000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	43
792	3	11	2021	FY	\N	2021-12-31	690959000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	44
793	3	11	2022	Q1	\N	2022-03-31	603144000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	45
794	3	11	2022	Q2	\N	2022-06-30	542511000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	46
795	3	11	2022	Q3	\N	2022-09-30	333279000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	47
796	3	11	2022	FY	\N	2022-12-31	242515000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	48
797	3	11	2023	Q1	\N	2023-03-31	208365000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	49
798	3	11	2023	Q2	\N	2023-06-30	197160000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	50
799	3	11	2023	Q3	\N	2023-09-30	140904000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	51
800	3	11	2023	FY	\N	2023-12-31	162518000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	52
801	3	11	2024	Q1	\N	2024-03-31	365929000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	53
802	3	11	2024	Q2	\N	2024-06-30	340911000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	54
803	3	11	2024	Q3	\N	2024-09-30	292470000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	55
804	3	11	2024	FY	\N	2024-12-31	271042000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	3
805	3	11	2025	Q1	\N	2025-03-31	303149000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	56
806	3	11	2025	Q2	\N	2025-06-30	564081000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	57
807	3	11	2025	Q3	\N	2025-09-30	807875000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	58
808	3	11	2025	FY	\N	2025-12-31	828660000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	61
809	3	11	2026	Q1	\N	2026-03-31	1205499000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	59
810	3	11	2026	Q2	\N	2026-06-30	2129485000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	60
811	3	11	2026	Q3	\N	2026-09-30	4447665000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	61
812	3	12	2020	FY	\N	2020-12-31	0.0000	USD	us-gaap:LongTermDebtNoncurrent	64
813	3	12	2021	Q3	\N	2021-09-30	96616000.0000	USD	us-gaap:LongTermDebtNoncurrent	43
814	3	12	2021	FY	\N	2021-12-31	97297000.0000	USD	us-gaap:LongTermDebtNoncurrent	44
815	3	12	2022	Q1	\N	2022-03-31	97967000.0000	USD	us-gaap:LongTermDebtNoncurrent	45
816	3	12	2022	Q2	\N	2022-06-30	98649000.0000	USD	us-gaap:LongTermDebtNoncurrent	46
817	3	12	2022	Q3	\N	2022-09-30	99344000.0000	USD	us-gaap:LongTermDebtNoncurrent	47
818	3	12	2022	FY	\N	2022-12-31	100043000.0000	USD	us-gaap:LongTermDebtNoncurrent	48
819	3	12	2023	Q1	\N	2023-03-31	100724000.0000	USD	us-gaap:LongTermDebtNoncurrent	49
820	3	12	2023	Q2	\N	2023-06-30	0.0000	USD	us-gaap:LongTermDebtNoncurrent	50
821	3	12	2023	Q3	\N	2023-09-30	0.0000	USD	us-gaap:LongTermDebtNoncurrent	51
822	3	12	2023	FY	\N	2023-12-31	87587000.0000	USD	us-gaap:LongTermDebtNoncurrent	52
823	3	12	2024	Q1	\N	2024-03-31	52717000.0000	USD	us-gaap:LongTermDebtNoncurrent	53
824	3	12	2024	Q2	\N	2024-06-30	50061000.0000	USD	us-gaap:LongTermDebtNoncurrent	54
825	3	12	2024	Q3	\N	2024-09-30	46915000.0000	USD	us-gaap:LongTermDebtNoncurrent	55
826	3	12	2024	FY	\N	2024-12-31	44049000.0000	USD	us-gaap:LongTermDebtNoncurrent	3
827	3	12	2025	Q1	\N	2025-03-31	57728000.0000	USD	us-gaap:LongTermDebtNoncurrent	56
828	3	12	2025	Q2	\N	2025-06-30	53720000.0000	USD	us-gaap:LongTermDebtNoncurrent	57
829	3	12	2025	Q3	\N	2025-09-30	51267000.0000	USD	us-gaap:LongTermDebtNoncurrent	58
830	3	12	2025	FY	\N	2025-12-31	1716000.0000	USD	us-gaap:LongTermDebtNoncurrent	61
831	3	12	2026	Q1	\N	2026-03-31	1716000.0000	USD	us-gaap:LongTermDebtNoncurrent	59
832	3	12	2026	Q2	\N	2026-06-30	1716000.0000	USD	us-gaap:LongTermDebtNoncurrent	60
833	3	12	2026	Q3	\N	2026-09-30	1716000.0000	USD	us-gaap:LongTermDebtNoncurrent	61
834	3	13	2020	FY	\N	2020-12-31	26135000.0000	USD	us-gaap:InventoryNet	64
835	3	13	2021	Q3	\N	2021-09-30	38365000.0000	USD	us-gaap:InventoryNet	43
836	3	13	2021	FY	\N	2021-12-31	47904000.0000	USD	us-gaap:InventoryNet	44
837	3	13	2022	Q1	\N	2022-03-31	77888000.0000	USD	us-gaap:InventoryNet	45
838	3	13	2022	Q2	\N	2022-06-30	85683000.0000	USD	us-gaap:InventoryNet	46
839	3	13	2022	Q3	\N	2022-09-30	86138000.0000	USD	us-gaap:InventoryNet	47
840	3	13	2022	FY	\N	2022-12-31	92279000.0000	USD	us-gaap:InventoryNet	48
841	3	13	2023	Q1	\N	2023-03-31	98453000.0000	USD	us-gaap:InventoryNet	49
842	3	13	2023	Q2	\N	2023-06-30	102234000.0000	USD	us-gaap:InventoryNet	50
843	3	13	2023	Q3	\N	2023-09-30	102394000.0000	USD	us-gaap:InventoryNet	51
844	3	13	2023	FY	\N	2023-12-31	107857000.0000	USD	us-gaap:InventoryNet	52
845	3	13	2024	Q1	\N	2024-03-31	99901000.0000	USD	us-gaap:InventoryNet	53
846	3	13	2024	Q2	\N	2024-06-30	104539000.0000	USD	us-gaap:InventoryNet	54
847	3	13	2024	Q3	\N	2024-09-30	114435000.0000	USD	us-gaap:InventoryNet	55
848	3	13	2024	FY	\N	2024-12-31	119074000.0000	USD	us-gaap:InventoryNet	3
849	3	13	2025	Q1	\N	2025-03-31	125588000.0000	USD	us-gaap:InventoryNet	56
850	3	13	2025	Q2	\N	2025-06-30	130232000.0000	USD	us-gaap:InventoryNet	57
851	3	13	2025	Q3	\N	2025-09-30	144999000.0000	USD	us-gaap:InventoryNet	58
852	3	13	2025	FY	\N	2025-12-31	158407000.0000	USD	us-gaap:InventoryNet	61
853	3	13	2026	Q1	\N	2026-03-31	183146000.0000	USD	us-gaap:InventoryNet	59
854	3	13	2026	Q2	\N	2026-06-30	266931000.0000	USD	us-gaap:InventoryNet	60
855	3	13	2026	Q3	\N	2026-09-30	280885000.0000	USD	us-gaap:InventoryNet	61
856	3	14	2020	Q3	2020-07-01	2020-09-30	4903000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	43
857	3	14	2020	FY	2020-01-01	2020-12-31	19142000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	44
858	3	14	2021	Q1	2021-01-01	2021-03-31	7078000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	45
859	3	14	2021	Q2	2021-04-01	2021-06-30	8529000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	46
860	3	14	2021	Q3	2021-07-01	2021-09-30	14189000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	47
861	3	14	2021	FY	2021-01-01	2021-12-31	41765000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	48
862	3	14	2022	Q1	2022-01-01	2022-03-31	13477000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	49
863	3	14	2022	Q2	2022-04-01	2022-06-30	19165000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	50
864	3	14	2022	Q3	2022-07-01	2022-09-30	17508000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	51
865	3	14	2022	FY	2022-01-01	2022-12-31	65168000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	52
866	3	14	2023	Q1	2023-01-01	2023-03-31	23905000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	53
867	3	14	2023	Q2	2023-04-01	2023-06-30	31035000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	54
868	3	14	2023	Q3	2023-07-01	2023-09-30	26626000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	55
869	3	14	2023	FY	2023-01-01	2023-12-31	119054000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	3
870	3	14	2024	Q1	2024-01-01	2024-03-31	38504000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	56
871	3	14	2024	Q2	2024-04-01	2024-06-30	39912000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	57
872	3	14	2024	Q3	2024-07-01	2024-09-30	47723000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	58
873	3	14	2024	FY	2024-01-01	2024-12-31	174394000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	3
874	3	14	2025	Q1	2025-01-01	2025-03-31	55109000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	59
875	3	14	2025	Q2	2025-04-01	2025-06-30	66134000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	60
876	3	14	2025	Q3	2025-07-01	2025-09-30	70694000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	61
877	3	14	2025	FY	2025-01-01	2025-12-31	270716000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	3
878	3	14	2026	Q1	2026-01-01	2026-03-31	80513000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	59
879	3	14	2026	Q2	2026-04-01	2026-06-30	82429000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	60
880	3	14	2026	Q3	2026-07-01	2026-09-30	98388000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	61
881	3	15	2020	FY	2020-01-01	2020-12-31	4218000.0000	USD	us-gaap:ShareBasedCompensation	44
882	3	15	2021	Q1	2021-01-01	2021-03-31	1090000.0000	USD	us-gaap:ShareBasedCompensation	45
883	3	15	2021	FY	2021-01-01	2021-12-31	32557000.0000	USD	us-gaap:ShareBasedCompensation	48
884	3	15	2022	Q1	2022-01-01	2022-03-31	11958000.0000	USD	us-gaap:ShareBasedCompensation	49
885	3	15	2022	FY	2022-01-01	2022-12-31	55649000.0000	USD	us-gaap:ShareBasedCompensation	52
886	3	15	2023	Q1	2023-01-01	2023-03-31	14036000.0000	USD	us-gaap:ShareBasedCompensation	53
887	3	15	2023	FY	2023-01-01	2023-12-31	53461000.0000	USD	us-gaap:ShareBasedCompensation	3
888	3	15	2024	Q1	2024-01-01	2024-03-31	13093000.0000	USD	us-gaap:ShareBasedCompensation	56
889	3	15	2024	FY	2024-01-01	2024-12-31	56816000.0000	USD	us-gaap:ShareBasedCompensation	3
890	3	15	2025	Q1	2025-01-01	2025-03-31	19234000.0000	USD	us-gaap:ShareBasedCompensation	59
891	3	15	2025	FY	2025-01-01	2025-12-31	71099000.0000	USD	us-gaap:ShareBasedCompensation	3
892	3	15	2026	Q1	2026-01-01	2026-03-31	28116000.0000	USD	us-gaap:ShareBasedCompensation	59
893	3	15	2020	Q3	2020-07-01	2020-09-30	1190000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	43
894	3	15	2021	Q2	2021-04-01	2021-06-30	1289000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	46
895	3	15	2021	Q3	\N	2021-08-25	9642000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	48
896	3	15	2022	Q2	2022-04-01	2022-06-30	16869000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	50
897	3	15	2022	Q3	2022-07-01	2022-09-30	14485000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	51
898	3	15	2023	Q2	2023-04-01	2023-06-30	15264000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	54
899	3	15	2023	Q3	2023-07-01	2023-09-30	14098000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	55
900	3	15	2024	Q2	2024-04-01	2024-06-30	13955000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	57
901	3	15	2024	Q3	2024-07-01	2024-09-30	12896000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	58
902	3	15	2025	Q2	2025-04-01	2025-06-30	17933000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	60
903	3	15	2025	Q3	2025-07-01	2025-09-30	15727000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	61
904	3	15	2026	Q2	2026-04-01	2026-06-30	19561000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	60
905	3	15	2026	Q3	2026-07-01	2026-09-30	18324000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	61
906	3	17	2020	Q3	2020-07-01	2020-09-30	-1000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	43
907	3	17	2020	FY	2020-01-01	2020-12-31	467000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	44
908	3	17	2021	Q1	2021-01-01	2021-03-31	264000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	45
909	3	17	2021	Q2	2021-04-01	2021-06-30	440000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	46
910	3	17	2021	Q3	2021-07-01	2021-09-30	-1684000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	47
911	3	17	2021	FY	2021-01-01	2021-12-31	-7520000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	48
912	3	17	2022	Q1	2022-01-01	2022-03-31	4388000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	49
913	3	17	2022	Q2	2022-04-01	2022-06-30	2073000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	50
914	3	17	2022	Q3	2022-07-01	2022-09-30	1693000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	51
996	4	2	2023	Q3	2023-06-26	2023-09-24	14830000000.0000	USD	us-gaap:CostOfRevenue	83
915	3	17	2022	FY	2022-01-01	2022-12-31	2998000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	52
916	3	17	2023	Q1	2023-01-01	2023-03-31	526000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	53
917	3	17	2023	Q2	2023-04-01	2023-06-30	761000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	54
918	3	17	2023	Q3	2023-07-01	2023-09-30	1352000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	55
919	3	17	2023	FY	2023-01-01	2023-12-31	3650000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	3
920	3	17	2024	Q1	2024-01-01	2024-03-31	5000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	56
921	3	17	2024	Q2	2024-04-01	2024-06-30	-860000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	57
922	3	17	2024	Q3	2024-07-01	2024-09-30	944000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	58
923	3	17	2024	FY	2024-01-01	2024-12-31	764000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	3
924	3	17	2025	Q1	2025-01-01	2025-03-31	-813000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	59
925	3	17	2025	Q2	2025-04-01	2025-06-30	2938000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	60
926	3	17	2025	Q3	2025-07-01	2025-09-30	-41091000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	61
927	3	17	2025	FY	2025-01-01	2025-12-31	-27688000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	3
928	3	17	2026	Q1	2026-01-01	2026-03-31	-1792000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	59
929	3	17	2026	Q2	2026-04-01	2026-06-30	5327000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	60
930	3	17	2026	Q3	2026-07-01	2026-09-30	3503000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	61
931	3	18	2020	FY	2020-01-01	2020-12-31	-0.7300	USD/shares	us-gaap:EarningsPerShareDiluted	44
932	3	18	2021	Q2	2021-04-01	2021-06-30	-0.2100	USD/shares	us-gaap:EarningsPerShareDiluted	46
933	3	18	2021	Q3	2021-07-01	2021-09-30	-0.3900	USD/shares	us-gaap:EarningsPerShareDiluted	47
934	3	18	2021	FY	2021-01-01	2021-12-31	-0.5600	USD/shares	us-gaap:EarningsPerShareDiluted	48
935	3	18	2022	Q1	2022-01-01	2022-03-31	-0.0600	USD/shares	us-gaap:EarningsPerShareDiluted	49
936	3	18	2022	Q2	2022-04-01	2022-06-30	-0.0800	USD/shares	us-gaap:EarningsPerShareDiluted	50
937	3	18	2022	Q3	2022-07-01	2022-09-30	-0.0700	USD/shares	us-gaap:EarningsPerShareDiluted	51
938	3	18	2022	FY	2022-01-01	2022-12-31	-0.2900	USD/shares	us-gaap:EarningsPerShareDiluted	52
939	3	18	2023	Q1	2023-01-01	2023-03-31	-0.1000	USD/shares	us-gaap:EarningsPerShareDiluted	53
940	3	18	2023	Q2	2023-04-01	2023-06-30	-0.1000	USD/shares	us-gaap:EarningsPerShareDiluted	54
941	3	18	2023	Q3	2023-07-01	2023-09-30	-0.0800	USD/shares	us-gaap:EarningsPerShareDiluted	55
942	3	18	2023	FY	2023-01-01	2023-12-31	-0.3800	USD/shares	us-gaap:EarningsPerShareDiluted	3
943	3	18	2024	Q1	2024-01-01	2024-03-31	-0.0900	USD/shares	us-gaap:EarningsPerShareDiluted	56
944	3	18	2024	Q2	2024-04-01	2024-06-30	-0.0800	USD/shares	us-gaap:EarningsPerShareDiluted	57
945	3	18	2024	Q3	2024-07-01	2024-09-30	-0.1000	USD/shares	us-gaap:EarningsPerShareDiluted	58
946	3	18	2024	FY	2024-01-01	2024-12-31	-0.3800	USD/shares	us-gaap:EarningsPerShareDiluted	3
947	3	18	2025	Q1	2025-01-01	2025-03-31	-0.1200	USD/shares	us-gaap:EarningsPerShareDiluted	59
948	3	18	2025	Q2	2025-04-01	2025-06-30	-0.1300	USD/shares	us-gaap:EarningsPerShareDiluted	60
949	3	18	2025	Q3	2025-07-01	2025-09-30	-0.0300	USD/shares	us-gaap:EarningsPerShareDiluted	61
950	3	18	2025	FY	2025-01-01	2025-12-31	-0.3700	USD/shares	us-gaap:EarningsPerShareDiluted	3
951	3	18	2026	Q1	2026-01-01	2026-03-31	-0.0700	USD/shares	us-gaap:EarningsPerShareDiluted	59
952	3	18	2026	Q2	2026-04-01	2026-06-30	-0.0800	USD/shares	us-gaap:EarningsPerShareDiluted	60
953	3	18	2026	Q3	2026-07-01	2026-09-30	-0.1200	USD/shares	us-gaap:EarningsPerShareDiluted	61
954	4	1	2019	Q1	2019-01-01	2019-03-31	14336000000.0000	USD	us-gaap:Revenues	67
955	4	1	2019	Q2	2019-04-01	2019-06-30	14427000000.0000	USD	us-gaap:Revenues	67
956	4	1	2019	Q3	2019-07-01	2019-09-29	15171000000.0000	USD	us-gaap:Revenues	67
957	4	1	2019	FY	2019-01-01	2019-12-31	59812000000.0000	USD	us-gaap:Revenues	68
958	4	1	2019	Q4	2019-09-30	2019-12-31	15878000000.0000	USD	us-gaap:Revenues	67
959	4	1	2020	Q1	2020-01-01	2020-03-29	15651000000.0000	USD	us-gaap:Revenues	69
960	4	1	2020	Q2	2020-03-30	2020-06-28	16220000000.0000	USD	us-gaap:Revenues	70
961	4	1	2020	Q3	2020-06-29	2020-09-27	16495000000.0000	USD	us-gaap:Revenues	71
962	4	1	2020	FY	2020-01-01	2020-12-31	65398000000.0000	USD	us-gaap:Revenues	72
963	4	1	2020	Q4	2020-09-28	2020-12-31	17032000000.0000	USD	us-gaap:Revenues	67
964	4	1	2021	Q1	2021-01-01	2021-03-28	16258000000.0000	USD	us-gaap:Revenues	73
965	4	1	2021	Q2	2021-03-29	2021-06-27	17029000000.0000	USD	us-gaap:Revenues	74
966	4	1	2021	Q3	2021-06-28	2021-09-26	16028000000.0000	USD	us-gaap:Revenues	75
967	4	1	2021	FY	2021-01-01	2021-12-31	67044000000.0000	USD	us-gaap:Revenues	76
968	4	1	2022	Q1	2022-01-01	2022-03-27	14964000000.0000	USD	us-gaap:Revenues	77
969	4	1	2022	Q2	2022-03-28	2022-06-26	15446000000.0000	USD	us-gaap:Revenues	78
970	4	1	2022	Q3	2022-06-27	2022-09-25	16583000000.0000	USD	us-gaap:Revenues	79
971	4	1	2022	FY	2022-01-01	2022-12-31	65984000000.0000	USD	us-gaap:Revenues	80
972	4	1	2023	Q1	2023-01-01	2023-03-26	15126000000.0000	USD	us-gaap:Revenues	81
973	4	1	2023	Q2	2023-03-27	2023-06-25	16693000000.0000	USD	us-gaap:Revenues	82
974	4	1	2023	Q3	2023-06-26	2023-09-24	16878000000.0000	USD	us-gaap:Revenues	83
975	4	1	2023	FY	2023-01-01	2023-12-31	67571000000.0000	USD	us-gaap:Revenues	4
976	4	1	2024	Q1	2024-01-01	2024-03-31	17195000000.0000	USD	us-gaap:Revenues	84
977	4	1	2024	Q2	2024-04-01	2024-06-30	18122000000.0000	USD	us-gaap:Revenues	85
978	4	1	2024	Q3	2024-07-01	2024-09-29	17104000000.0000	USD	us-gaap:Revenues	86
979	4	1	2024	FY	2024-01-01	2024-12-31	71043000000.0000	USD	us-gaap:Revenues	4
980	4	1	2025	Q1	2025-01-01	2025-03-30	17963000000.0000	USD	us-gaap:Revenues	87
981	4	1	2025	Q2	2025-03-31	2025-06-29	18155000000.0000	USD	us-gaap:Revenues	88
982	4	1	2025	Q3	2025-06-30	2025-09-28	18609000000.0000	USD	us-gaap:Revenues	89
983	4	1	2025	FY	2025-01-01	2025-12-31	75048000000.0000	USD	us-gaap:Revenues	4
984	4	1	2026	Q1	2026-01-01	2026-03-29	18021000000.0000	USD	us-gaap:Revenues	87
985	4	1	2026	Q2	2026-03-30	2026-06-28	20063000000.0000	USD	us-gaap:Revenues	88
986	4	1	2026	Q3	2026-06-29	2026-09-27	20711000000.0000	USD	us-gaap:Revenues	89
987	4	2	2020	FY	2020-01-01	2020-12-31	56744000000.0000	USD	us-gaap:CostOfRevenue	72
988	4	2	2021	Q3	2021-06-28	2021-09-26	13726000000.0000	USD	us-gaap:CostOfRevenue	75
989	4	2	2021	FY	2021-01-01	2021-12-31	57983000000.0000	USD	us-gaap:CostOfRevenue	76
990	4	2	2022	Q1	2022-01-01	2022-03-27	13055000000.0000	USD	us-gaap:CostOfRevenue	77
991	4	2	2022	Q2	2022-03-28	2022-06-26	13490000000.0000	USD	us-gaap:CostOfRevenue	78
992	4	2	2022	Q3	2022-06-27	2022-09-25	14463000000.0000	USD	us-gaap:CostOfRevenue	79
993	4	2	2022	FY	2022-01-01	2022-12-31	57697000000.0000	USD	us-gaap:CostOfRevenue	80
994	4	2	2023	Q1	2023-01-01	2023-03-26	13080000000.0000	USD	us-gaap:CostOfRevenue	81
995	4	2	2023	Q2	2023-03-27	2023-06-25	14603000000.0000	USD	us-gaap:CostOfRevenue	82
997	4	2	2023	FY	2023-01-01	2023-12-31	59092000000.0000	USD	us-gaap:CostOfRevenue	4
998	4	2	2024	Q1	2024-01-01	2024-03-31	15202000000.0000	USD	us-gaap:CostOfRevenue	84
999	4	2	2024	Q2	2024-04-01	2024-06-30	15992000000.0000	USD	us-gaap:CostOfRevenue	85
1000	4	2	2024	Q3	2024-07-01	2024-09-29	14987000000.0000	USD	us-gaap:CostOfRevenue	86
1001	4	2	2024	FY	2024-01-01	2024-12-31	64113000000.0000	USD	us-gaap:CostOfRevenue	4
1002	4	2	2025	Q1	2025-01-01	2025-03-30	15640000000.0000	USD	us-gaap:CostOfRevenue	87
1003	4	2	2025	Q2	2025-03-31	2025-06-29	17421000000.0000	USD	us-gaap:CostOfRevenue	88
1004	4	2	2025	Q3	2025-06-30	2025-09-28	16369000000.0000	USD	us-gaap:CostOfRevenue	89
1005	4	2	2025	FY	2025-01-01	2025-12-31	67429000000.0000	USD	us-gaap:CostOfRevenue	4
1006	4	2	2026	Q1	2026-01-01	2026-03-29	15943000000.0000	USD	us-gaap:CostOfRevenue	87
1007	4	2	2026	Q2	2026-03-30	2026-06-28	17617000000.0000	USD	us-gaap:CostOfRevenue	88
1008	4	2	2026	Q3	2026-06-29	2026-09-27	18275000000.0000	USD	us-gaap:CostOfRevenue	89
1009	4	2	2019	Q1	2019-01-01	2019-03-31	12148000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	90
1010	4	2	2019	Q2	2019-04-01	2019-06-30	12434000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	91
1011	4	2	2019	Q3	2019-07-01	2019-09-29	13108000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	92
1012	4	2	2019	FY	2019-01-01	2019-12-31	51445000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	68
1013	4	2	2020	Q1	2020-01-01	2020-03-29	13560000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	69
1014	4	2	2020	Q2	2020-03-30	2020-06-28	14007000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	70
1015	4	2	2020	Q3	2020-06-29	2020-09-27	14359000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	71
1016	4	2	2021	Q1	2021-01-01	2021-03-28	14072000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	73
1017	4	2	2021	Q2	2021-03-29	2021-06-27	14878000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	74
1018	4	3	2019	Q1	2019-01-01	2019-03-31	2188000000.0000	USD	us-gaap:GrossProfit	90
1019	4	3	2019	Q2	2019-04-01	2019-06-30	1993000000.0000	USD	us-gaap:GrossProfit	91
1020	4	3	2019	Q3	2019-07-01	2019-09-29	2063000000.0000	USD	us-gaap:GrossProfit	92
1021	4	3	2019	FY	2019-01-01	2019-12-31	8367000000.0000	USD	us-gaap:GrossProfit	68
1022	4	3	2020	Q1	2020-01-01	2020-03-29	2091000000.0000	USD	us-gaap:GrossProfit	69
1023	4	3	2020	Q2	2020-03-30	2020-06-28	2213000000.0000	USD	us-gaap:GrossProfit	70
1024	4	3	2020	Q3	2020-06-29	2020-09-27	2136000000.0000	USD	us-gaap:GrossProfit	71
1025	4	3	2020	FY	2020-01-01	2020-12-31	8654000000.0000	USD	us-gaap:GrossProfit	72
1026	4	3	2021	Q1	2021-01-01	2021-03-28	2186000000.0000	USD	us-gaap:GrossProfit	73
1027	4	3	2021	Q2	2021-03-29	2021-06-27	2151000000.0000	USD	us-gaap:GrossProfit	74
1028	4	3	2021	Q3	2021-06-28	2021-09-26	2302000000.0000	USD	us-gaap:GrossProfit	75
1029	4	3	2021	FY	2021-01-01	2021-12-31	9061000000.0000	USD	us-gaap:GrossProfit	76
1030	4	3	2022	Q1	2022-01-01	2022-03-27	1909000000.0000	USD	us-gaap:GrossProfit	77
1031	4	3	2022	Q2	2022-03-28	2022-06-26	1956000000.0000	USD	us-gaap:GrossProfit	78
1032	4	3	2022	Q3	2022-06-27	2022-09-25	2120000000.0000	USD	us-gaap:GrossProfit	79
1033	4	3	2022	FY	2022-01-01	2022-12-31	8287000000.0000	USD	us-gaap:GrossProfit	80
1034	4	3	2023	Q1	2023-01-01	2023-03-26	2046000000.0000	USD	us-gaap:GrossProfit	81
1035	4	3	2023	Q2	2023-03-27	2023-06-25	2090000000.0000	USD	us-gaap:GrossProfit	82
1036	4	3	2023	Q3	2023-06-26	2023-09-24	2048000000.0000	USD	us-gaap:GrossProfit	83
1037	4	3	2023	FY	2023-01-01	2023-12-31	8479000000.0000	USD	us-gaap:GrossProfit	4
1038	4	3	2024	Q1	2024-01-01	2024-03-31	1993000000.0000	USD	us-gaap:GrossProfit	84
1039	4	3	2024	Q2	2024-04-01	2024-06-30	2130000000.0000	USD	us-gaap:GrossProfit	85
1040	4	3	2024	Q3	2024-07-01	2024-09-29	2117000000.0000	USD	us-gaap:GrossProfit	86
1041	4	3	2024	FY	2024-01-01	2024-12-31	6930000000.0000	USD	us-gaap:GrossProfit	4
1042	4	3	2025	Q1	2025-01-01	2025-03-30	2323000000.0000	USD	us-gaap:GrossProfit	87
1043	4	3	2025	Q2	2025-03-31	2025-06-29	734000000.0000	USD	us-gaap:GrossProfit	88
1044	4	3	2025	Q3	2025-06-30	2025-09-28	2240000000.0000	USD	us-gaap:GrossProfit	89
1045	4	3	2025	FY	2025-01-01	2025-12-31	7619000000.0000	USD	us-gaap:GrossProfit	4
1046	4	3	2026	Q1	2026-01-01	2026-03-29	2078000000.0000	USD	us-gaap:GrossProfit	87
1047	4	3	2026	Q2	2026-03-30	2026-06-28	2446000000.0000	USD	us-gaap:GrossProfit	88
1048	4	3	2026	Q3	2026-06-29	2026-09-27	2436000000.0000	USD	us-gaap:GrossProfit	89
1049	4	4	2019	Q1	2019-01-01	2019-03-31	2283000000.0000	USD	us-gaap:OperatingIncomeLoss	67
1050	4	4	2019	Q2	2019-04-01	2019-06-30	2008000000.0000	USD	us-gaap:OperatingIncomeLoss	67
1051	4	4	2019	Q3	2019-07-01	2019-09-29	2105000000.0000	USD	us-gaap:OperatingIncomeLoss	67
1052	4	4	2019	FY	2019-01-01	2019-12-31	8545000000.0000	USD	us-gaap:OperatingIncomeLoss	68
1053	4	4	2019	Q4	2019-09-30	2019-12-31	2149000000.0000	USD	us-gaap:OperatingIncomeLoss	67
1054	4	4	2020	Q1	2020-01-01	2020-03-29	2122000000.0000	USD	us-gaap:OperatingIncomeLoss	69
1055	4	4	2020	Q2	2020-03-30	2020-06-28	2086000000.0000	USD	us-gaap:OperatingIncomeLoss	70
1056	4	4	2020	Q3	2020-06-29	2020-09-27	2147000000.0000	USD	us-gaap:OperatingIncomeLoss	71
1057	4	4	2020	FY	2020-01-01	2020-12-31	8644000000.0000	USD	us-gaap:OperatingIncomeLoss	72
1058	4	4	2020	Q4	2020-09-28	2020-12-31	2289000000.0000	USD	us-gaap:OperatingIncomeLoss	67
1059	4	4	2021	Q1	2021-01-01	2021-03-28	2182000000.0000	USD	us-gaap:OperatingIncomeLoss	73
1060	4	4	2021	Q2	2021-03-29	2021-06-27	2192000000.0000	USD	us-gaap:OperatingIncomeLoss	74
1061	4	4	2021	Q3	2021-06-28	2021-09-26	2294000000.0000	USD	us-gaap:OperatingIncomeLoss	75
1062	4	4	2021	FY	2021-01-01	2021-12-31	9123000000.0000	USD	us-gaap:OperatingIncomeLoss	76
1063	4	4	2022	Q1	2022-01-01	2022-03-27	1933000000.0000	USD	us-gaap:OperatingIncomeLoss	77
1064	4	4	2022	Q2	2022-03-28	2022-06-26	1963000000.0000	USD	us-gaap:OperatingIncomeLoss	78
1065	4	4	2022	Q3	2022-06-27	2022-09-25	2159000000.0000	USD	us-gaap:OperatingIncomeLoss	79
1066	4	4	2022	FY	2022-01-01	2022-12-31	8348000000.0000	USD	us-gaap:OperatingIncomeLoss	80
1067	4	4	2023	Q1	2023-01-01	2023-03-26	2037000000.0000	USD	us-gaap:OperatingIncomeLoss	81
1068	4	4	2023	Q2	2023-03-27	2023-06-25	2135000000.0000	USD	us-gaap:OperatingIncomeLoss	82
1069	4	4	2023	Q3	2023-06-26	2023-09-24	2042000000.0000	USD	us-gaap:OperatingIncomeLoss	83
1070	4	4	2023	FY	2023-01-01	2023-12-31	8507000000.0000	USD	us-gaap:OperatingIncomeLoss	4
1071	4	4	2024	Q1	2024-01-01	2024-03-31	2029000000.0000	USD	us-gaap:OperatingIncomeLoss	84
1072	4	4	2024	Q2	2024-04-01	2024-06-30	2148000000.0000	USD	us-gaap:OperatingIncomeLoss	85
1073	4	4	2024	Q3	2024-07-01	2024-09-29	2140000000.0000	USD	us-gaap:OperatingIncomeLoss	86
1074	4	4	2024	FY	2024-01-01	2024-12-31	7013000000.0000	USD	us-gaap:OperatingIncomeLoss	4
1075	4	4	2025	Q1	2025-01-01	2025-03-30	2372000000.0000	USD	us-gaap:OperatingIncomeLoss	87
1076	4	4	2025	Q2	2025-03-31	2025-06-29	748000000.0000	USD	us-gaap:OperatingIncomeLoss	88
1077	4	4	2025	Q3	2025-06-30	2025-09-28	2280000000.0000	USD	us-gaap:OperatingIncomeLoss	89
1078	4	4	2025	FY	2025-01-01	2025-12-31	7731000000.0000	USD	us-gaap:OperatingIncomeLoss	4
1079	4	4	2026	Q1	2026-01-01	2026-03-29	2063000000.0000	USD	us-gaap:OperatingIncomeLoss	87
1080	4	4	2026	Q2	2026-03-30	2026-06-28	2479000000.0000	USD	us-gaap:OperatingIncomeLoss	88
1081	4	4	2026	Q3	2026-06-29	2026-09-27	2443000000.0000	USD	us-gaap:OperatingIncomeLoss	89
1082	4	5	2019	Q1	2019-01-01	2019-03-31	1704000000.0000	USD	us-gaap:NetIncomeLoss	67
1083	4	5	2019	Q2	2019-04-01	2019-06-30	1420000000.0000	USD	us-gaap:NetIncomeLoss	67
1084	4	5	2019	Q3	2019-07-01	2019-09-29	1608000000.0000	USD	us-gaap:NetIncomeLoss	67
1085	4	5	2019	FY	2019-01-01	2019-12-31	6230000000.0000	USD	us-gaap:NetIncomeLoss	68
1086	4	5	2019	Q4	2019-09-30	2019-12-31	1498000000.0000	USD	us-gaap:NetIncomeLoss	67
1087	4	5	2020	Q1	2020-01-01	2020-03-29	1717000000.0000	USD	us-gaap:NetIncomeLoss	69
1088	4	5	2020	Q2	2020-03-30	2020-06-28	1626000000.0000	USD	us-gaap:NetIncomeLoss	70
1089	4	5	2020	Q3	2020-06-29	2020-09-27	1698000000.0000	USD	us-gaap:NetIncomeLoss	71
1090	4	5	2020	FY	2020-01-01	2020-12-31	6833000000.0000	USD	us-gaap:NetIncomeLoss	72
1091	4	5	2020	Q4	2020-09-28	2020-12-31	1792000000.0000	USD	us-gaap:NetIncomeLoss	67
1092	4	5	2021	Q1	2021-01-01	2021-03-28	1837000000.0000	USD	us-gaap:NetIncomeLoss	73
1093	4	5	2021	Q2	2021-03-29	2021-06-27	1815000000.0000	USD	us-gaap:NetIncomeLoss	74
1094	4	5	2021	Q3	2021-06-28	2021-09-26	614000000.0000	USD	us-gaap:NetIncomeLoss	75
1095	4	5	2021	FY	2021-01-01	2021-12-31	6315000000.0000	USD	us-gaap:NetIncomeLoss	76
1096	4	5	2022	Q1	2022-01-01	2022-03-27	1733000000.0000	USD	us-gaap:NetIncomeLoss	77
1097	4	5	2022	Q2	2022-03-28	2022-06-26	309000000.0000	USD	us-gaap:NetIncomeLoss	78
1098	4	5	2022	Q3	2022-06-27	2022-09-25	1778000000.0000	USD	us-gaap:NetIncomeLoss	79
1099	4	5	2022	FY	2022-01-01	2022-12-31	5732000000.0000	USD	us-gaap:NetIncomeLoss	80
1100	4	5	2023	Q1	2023-01-01	2023-03-26	1689000000.0000	USD	us-gaap:NetIncomeLoss	81
1101	4	5	2023	Q2	2023-03-27	2023-06-25	1681000000.0000	USD	us-gaap:NetIncomeLoss	82
1102	4	5	2023	Q3	2023-06-26	2023-09-24	1684000000.0000	USD	us-gaap:NetIncomeLoss	83
1103	4	5	2023	FY	2023-01-01	2023-12-31	6920000000.0000	USD	us-gaap:NetIncomeLoss	4
1104	4	5	2024	Q1	2024-01-01	2024-03-31	1545000000.0000	USD	us-gaap:NetIncomeLoss	84
1105	4	5	2024	Q2	2024-04-01	2024-06-30	1641000000.0000	USD	us-gaap:NetIncomeLoss	85
1106	4	5	2024	Q3	2024-07-01	2024-09-29	1623000000.0000	USD	us-gaap:NetIncomeLoss	86
1107	4	5	2024	FY	2024-01-01	2024-12-31	5336000000.0000	USD	us-gaap:NetIncomeLoss	4
1108	4	5	2025	Q1	2025-01-01	2025-03-30	1712000000.0000	USD	us-gaap:NetIncomeLoss	87
1109	4	5	2025	Q2	2025-03-31	2025-06-29	342000000.0000	USD	us-gaap:NetIncomeLoss	88
1110	4	5	2025	Q3	2025-06-30	2025-09-28	1619000000.0000	USD	us-gaap:NetIncomeLoss	89
1111	4	5	2025	FY	2025-01-01	2025-12-31	5017000000.0000	USD	us-gaap:NetIncomeLoss	4
1112	4	5	2026	Q1	2026-01-01	2026-03-29	1488000000.0000	USD	us-gaap:NetIncomeLoss	87
1113	4	5	2026	Q2	2026-03-30	2026-06-28	1836000000.0000	USD	us-gaap:NetIncomeLoss	88
1114	4	5	2026	Q3	2026-06-29	2026-09-27	1845000000.0000	USD	us-gaap:NetIncomeLoss	89
1115	4	6	2019	Q1	2019-01-01	2019-03-31	1663000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	90
1116	4	6	2019	FY	2019-01-01	2019-12-31	7311000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	68
1117	4	6	2020	Q1	2020-01-01	2020-03-29	2314000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	69
1118	4	6	2020	FY	2020-01-01	2020-12-31	8183000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	72
1119	4	6	2021	Q1	2021-01-01	2021-03-28	1748000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	73
1120	4	6	2021	FY	2021-01-01	2021-12-31	9221000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	76
1121	4	6	2022	Q1	2022-01-01	2022-03-27	1410000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	77
1122	4	6	2022	FY	2022-01-01	2022-12-31	7802000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	80
1123	4	6	2023	Q1	2023-01-01	2023-03-26	1564000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	81
1124	4	6	2023	FY	2023-01-01	2023-12-31	7920000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	4
1125	4	6	2024	Q1	2024-01-01	2024-03-31	1635000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	84
1126	4	6	2024	FY	2024-01-01	2024-12-31	6972000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	4
1127	4	6	2025	Q1	2025-01-01	2025-03-30	1409000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	87
1128	4	6	2025	FY	2025-01-01	2025-12-31	8557000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	4
1129	4	6	2026	Q1	2026-01-01	2026-03-29	220000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	87
1130	4	8	2019	Q1	\N	2019-03-31	47684000000.0000	USD	us-gaap:Assets	93
1131	4	8	2019	Q2	\N	2019-06-30	47840000000.0000	USD	us-gaap:Assets	94
1132	4	8	2019	Q3	\N	2019-09-29	49275000000.0000	USD	us-gaap:Assets	95
1133	4	8	2019	FY	\N	2019-12-31	47528000000.0000	USD	us-gaap:Assets	67
1134	4	8	2020	Q1	\N	2020-03-29	49248000000.0000	USD	us-gaap:Assets	90
1135	4	8	2020	Q2	\N	2020-06-28	49603000000.0000	USD	us-gaap:Assets	91
1136	4	8	2020	Q3	\N	2020-09-27	50773000000.0000	USD	us-gaap:Assets	92
1137	4	8	2020	FY	\N	2020-12-31	50710000000.0000	USD	us-gaap:Assets	68
1138	4	8	2021	Q1	\N	2021-03-28	51437000000.0000	USD	us-gaap:Assets	69
1139	4	8	2021	Q2	\N	2021-06-27	52099000000.0000	USD	us-gaap:Assets	70
1140	4	8	2021	Q3	\N	2021-09-26	51843000000.0000	USD	us-gaap:Assets	71
1141	4	8	2021	FY	\N	2021-12-31	50873000000.0000	USD	us-gaap:Assets	72
1142	4	8	2022	Q1	\N	2022-03-27	51510000000.0000	USD	us-gaap:Assets	73
1143	4	8	2022	Q2	\N	2022-06-26	51758000000.0000	USD	us-gaap:Assets	74
1144	4	8	2022	Q3	\N	2022-09-25	52030000000.0000	USD	us-gaap:Assets	75
1145	4	8	2022	FY	\N	2022-12-31	52880000000.0000	USD	us-gaap:Assets	76
1146	4	8	2023	Q1	\N	2023-03-26	54622000000.0000	USD	us-gaap:Assets	77
1147	4	8	2023	Q2	\N	2023-06-25	56978000000.0000	USD	us-gaap:Assets	78
1148	4	8	2023	Q3	\N	2023-09-24	56666000000.0000	USD	us-gaap:Assets	79
1149	4	8	2023	FY	\N	2023-12-31	52456000000.0000	USD	us-gaap:Assets	80
1150	4	8	2024	Q1	\N	2024-03-31	54963000000.0000	USD	us-gaap:Assets	81
1151	4	8	2024	Q2	\N	2024-06-30	55076000000.0000	USD	us-gaap:Assets	82
1152	4	8	2024	Q3	\N	2024-09-29	55520000000.0000	USD	us-gaap:Assets	83
1153	4	8	2024	FY	\N	2024-12-31	55617000000.0000	USD	us-gaap:Assets	4
1154	4	8	2025	Q1	\N	2025-03-30	56669000000.0000	USD	us-gaap:Assets	84
1155	4	8	2025	Q2	\N	2025-06-29	58870000000.0000	USD	us-gaap:Assets	85
1156	4	8	2025	Q3	\N	2025-09-28	60276000000.0000	USD	us-gaap:Assets	86
1157	4	8	2025	FY	\N	2025-12-31	59840000000.0000	USD	us-gaap:Assets	89
1158	4	8	2026	Q1	\N	2026-03-29	59238000000.0000	USD	us-gaap:Assets	87
1159	4	8	2026	Q2	\N	2026-06-28	62450000000.0000	USD	us-gaap:Assets	88
1160	4	8	2026	Q3	\N	2026-09-27	64510000000.0000	USD	us-gaap:Assets	89
1161	4	9	2019	Q1	\N	2019-03-31	45162000000.0000	USD	us-gaap:Liabilities	93
1162	4	9	2019	Q2	\N	2019-06-30	44944000000.0000	USD	us-gaap:Liabilities	94
1163	4	9	2019	Q3	\N	2019-09-29	45338000000.0000	USD	us-gaap:Liabilities	95
1164	4	9	2019	FY	\N	2019-12-31	44357000000.0000	USD	us-gaap:Liabilities	67
1165	4	9	2020	Q1	\N	2020-03-29	45761000000.0000	USD	us-gaap:Liabilities	90
1166	4	9	2020	Q2	\N	2020-06-28	45817000000.0000	USD	us-gaap:Liabilities	91
1167	4	9	2020	Q3	\N	2020-09-27	45787000000.0000	USD	us-gaap:Liabilities	92
1168	4	9	2020	FY	\N	2020-12-31	44672000000.0000	USD	us-gaap:Liabilities	68
1169	4	9	2021	Q1	\N	2021-03-28	45104000000.0000	USD	us-gaap:Liabilities	69
1170	4	9	2021	Q2	\N	2021-06-27	45569000000.0000	USD	us-gaap:Liabilities	70
1171	4	9	2021	Q3	\N	2021-09-26	42212000000.0000	USD	us-gaap:Liabilities	71
1172	4	9	2021	FY	\N	2021-12-31	39914000000.0000	USD	us-gaap:Liabilities	72
1173	4	9	2022	Q1	\N	2022-03-27	41508000000.0000	USD	us-gaap:Liabilities	73
1174	4	9	2022	Q2	\N	2022-06-26	40326000000.0000	USD	us-gaap:Liabilities	74
1175	4	9	2022	Q3	\N	2022-09-25	40064000000.0000	USD	us-gaap:Liabilities	75
1176	4	9	2022	FY	\N	2022-12-31	43614000000.0000	USD	us-gaap:Liabilities	76
1177	4	9	2023	Q1	\N	2023-03-26	44976000000.0000	USD	us-gaap:Liabilities	77
1178	4	9	2023	Q2	\N	2023-06-25	47738000000.0000	USD	us-gaap:Liabilities	78
1179	4	9	2023	Q3	\N	2023-09-24	47392000000.0000	USD	us-gaap:Liabilities	79
1180	4	9	2023	FY	\N	2023-12-31	45621000000.0000	USD	us-gaap:Liabilities	80
1181	4	9	2024	Q1	\N	2024-03-31	48313000000.0000	USD	us-gaap:Liabilities	81
1182	4	9	2024	Q2	\N	2024-06-30	48901000000.0000	USD	us-gaap:Liabilities	82
1183	4	9	2024	Q3	\N	2024-09-29	48320000000.0000	USD	us-gaap:Liabilities	83
1184	4	9	2024	FY	\N	2024-12-31	49284000000.0000	USD	us-gaap:Liabilities	4
1185	4	9	2025	Q1	\N	2025-03-30	49986000000.0000	USD	us-gaap:Liabilities	84
1186	4	9	2025	Q2	\N	2025-06-29	53536000000.0000	USD	us-gaap:Liabilities	85
1187	4	9	2025	Q3	\N	2025-09-28	54095000000.0000	USD	us-gaap:Liabilities	86
1188	4	9	2025	FY	\N	2025-12-31	53119000000.0000	USD	us-gaap:Liabilities	89
1189	4	9	2026	Q1	\N	2026-03-29	51749000000.0000	USD	us-gaap:Liabilities	87
1190	4	9	2026	Q2	\N	2026-06-28	53682000000.0000	USD	us-gaap:Liabilities	88
1191	4	9	2026	Q3	\N	2026-09-27	54447000000.0000	USD	us-gaap:Liabilities	89
1192	4	10	2019	Q1	\N	2019-03-31	2465000000.0000	USD	us-gaap:StockholdersEquity	93
1193	4	10	2019	Q2	\N	2019-06-30	2850000000.0000	USD	us-gaap:StockholdersEquity	94
1194	4	10	2019	Q3	\N	2019-09-29	3893000000.0000	USD	us-gaap:StockholdersEquity	95
1195	4	10	2019	FY	\N	2019-12-31	3127000000.0000	USD	us-gaap:StockholdersEquity	67
1196	4	10	2020	Q1	\N	2020-03-29	3446000000.0000	USD	us-gaap:StockholdersEquity	90
1197	4	10	2020	Q2	\N	2020-06-28	3751000000.0000	USD	us-gaap:StockholdersEquity	91
1198	4	10	2020	Q3	\N	2020-09-27	4953000000.0000	USD	us-gaap:StockholdersEquity	92
1199	4	10	2020	FY	\N	2020-12-31	6015000000.0000	USD	us-gaap:StockholdersEquity	68
1200	4	10	2021	Q1	\N	2021-03-28	6312000000.0000	USD	us-gaap:StockholdersEquity	69
1201	4	10	2021	Q2	\N	2021-06-27	6522000000.0000	USD	us-gaap:StockholdersEquity	70
1202	4	10	2021	Q3	\N	2021-09-26	9631000000.0000	USD	us-gaap:StockholdersEquity	71
1203	4	10	2021	FY	\N	2021-12-31	10959000000.0000	USD	us-gaap:StockholdersEquity	80
1204	4	10	2022	Q1	\N	2022-03-27	10002000000.0000	USD	us-gaap:StockholdersEquity	73
1205	4	10	2022	Q2	\N	2022-06-26	11432000000.0000	USD	us-gaap:StockholdersEquity	74
1206	4	10	2022	Q3	\N	2022-09-25	11966000000.0000	USD	us-gaap:StockholdersEquity	75
1207	4	10	2022	FY	\N	2022-12-31	9266000000.0000	USD	us-gaap:StockholdersEquity	4
1208	4	10	2023	Q1	\N	2023-03-26	9646000000.0000	USD	us-gaap:StockholdersEquity	82
1209	4	10	2023	Q2	\N	2023-06-25	9240000000.0000	USD	us-gaap:StockholdersEquity	83
1210	4	10	2023	Q3	\N	2023-09-24	9274000000.0000	USD	us-gaap:StockholdersEquity	83
1211	4	10	2023	FY	\N	2023-12-31	6835000000.0000	USD	us-gaap:StockholdersEquity	4
1212	4	10	2024	Q1	\N	2024-03-31	6650000000.0000	USD	us-gaap:StockholdersEquity	85
1213	4	10	2024	Q2	\N	2024-06-30	6175000000.0000	USD	us-gaap:StockholdersEquity	86
1214	4	10	2024	Q3	\N	2024-09-29	7200000000.0000	USD	us-gaap:StockholdersEquity	86
1215	4	10	2024	FY	\N	2024-12-31	6333000000.0000	USD	us-gaap:StockholdersEquity	89
1216	4	10	2025	Q1	\N	2025-03-30	6683000000.0000	USD	us-gaap:StockholdersEquity	88
1217	4	10	2025	Q2	\N	2025-06-29	5334000000.0000	USD	us-gaap:StockholdersEquity	89
1218	4	10	2025	Q3	\N	2025-09-28	6181000000.0000	USD	us-gaap:StockholdersEquity	89
1219	4	10	2025	FY	\N	2025-12-31	6721000000.0000	USD	us-gaap:StockholdersEquity	89
1220	4	10	2026	Q1	\N	2026-03-29	7489000000.0000	USD	us-gaap:StockholdersEquity	88
1221	4	10	2026	Q2	\N	2026-06-28	8768000000.0000	USD	us-gaap:StockholdersEquity	89
1222	4	10	2026	Q3	\N	2026-09-27	10063000000.0000	USD	us-gaap:StockholdersEquity	89
1223	4	11	2019	Q1	\N	2019-03-31	991000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	93
1224	4	11	2019	Q2	\N	2019-06-30	1167000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	94
1225	4	11	2019	Q3	\N	2019-09-29	2539000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	95
1226	4	11	2019	FY	\N	2019-12-31	1514000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	67
1227	4	11	2020	Q1	\N	2020-03-29	1988000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	90
1228	4	11	2020	Q2	\N	2020-06-28	2855000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	91
1229	4	11	2020	Q3	\N	2020-09-27	3585000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	92
1230	4	11	2020	FY	\N	2020-12-31	3160000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	68
1231	4	11	2021	Q1	\N	2021-03-28	2933000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	69
1232	4	11	2021	Q2	\N	2021-06-27	2745000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	70
1233	4	11	2021	Q3	\N	2021-09-26	2727000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	71
1234	4	11	2021	FY	\N	2021-12-31	3604000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	72
1235	4	11	2022	Q1	\N	2022-03-27	1883000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	73
1236	4	11	2022	Q2	\N	2022-06-26	1775000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	74
1237	4	11	2022	Q3	\N	2022-09-25	2430000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	75
1238	4	11	2022	FY	\N	2022-12-31	2547000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	76
1239	4	11	2023	Q1	\N	2023-03-26	2440000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	77
1240	4	11	2023	Q2	\N	2023-06-25	3673000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	78
1241	4	11	2023	Q3	\N	2023-09-24	3551000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	79
1242	4	11	2023	FY	\N	2023-12-31	1442000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	80
1243	4	11	2024	Q1	\N	2024-03-31	2790000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	81
1244	4	11	2024	Q2	\N	2024-06-30	2523000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	82
1245	4	11	2024	Q3	\N	2024-09-29	3151000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	83
1246	4	11	2024	FY	\N	2024-12-31	2483000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	4
1247	4	11	2025	Q1	\N	2025-03-30	1803000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	84
1248	4	11	2025	Q2	\N	2025-06-29	1293000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	85
1249	4	11	2025	Q3	\N	2025-09-28	3470000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	86
1250	4	11	2025	FY	\N	2025-12-31	4121000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	89
1251	4	11	2026	Q1	\N	2026-03-29	1894000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	87
1252	4	11	2026	Q2	\N	2026-06-28	3791000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	88
1253	4	11	2026	Q3	\N	2026-09-27	5960000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	89
1254	4	12	2019	Q1	\N	2019-03-31	12621000000.0000	USD	us-gaap:LongTermDebtNoncurrent	93
1255	4	12	2019	Q2	\N	2019-06-30	12637000000.0000	USD	us-gaap:LongTermDebtNoncurrent	94
1256	4	12	2019	Q3	\N	2019-09-29	12652000000.0000	USD	us-gaap:LongTermDebtNoncurrent	95
1257	4	12	2019	FY	\N	2019-12-31	11404000000.0000	USD	us-gaap:LongTermDebtNoncurrent	67
1258	4	12	2020	Q1	\N	2020-03-29	11439000000.0000	USD	us-gaap:LongTermDebtNoncurrent	90
1259	4	12	2020	Q2	\N	2020-06-28	12174000000.0000	USD	us-gaap:LongTermDebtNoncurrent	91
1260	4	12	2020	Q3	\N	2020-09-27	11675000000.0000	USD	us-gaap:LongTermDebtNoncurrent	92
1261	4	12	2020	FY	\N	2020-12-31	11669000000.0000	USD	us-gaap:LongTermDebtNoncurrent	68
1262	4	12	2021	Q1	\N	2021-03-28	11657000000.0000	USD	us-gaap:LongTermDebtNoncurrent	69
1263	4	12	2021	Q2	\N	2021-06-27	11665000000.0000	USD	us-gaap:LongTermDebtNoncurrent	70
1264	4	12	2021	Q3	\N	2021-09-26	11668000000.0000	USD	us-gaap:LongTermDebtNoncurrent	71
1265	4	12	2021	FY	\N	2021-12-31	11670000000.0000	USD	us-gaap:LongTermDebtNoncurrent	72
1266	4	12	2022	Q1	\N	2022-03-27	11145000000.0000	USD	us-gaap:LongTermDebtNoncurrent	73
1267	4	12	2022	Q2	\N	2022-06-26	11644000000.0000	USD	us-gaap:LongTermDebtNoncurrent	74
1268	4	12	2022	Q3	\N	2022-09-25	11480000000.0000	USD	us-gaap:LongTermDebtNoncurrent	75
1269	4	12	2022	FY	\N	2022-12-31	15429000000.0000	USD	us-gaap:LongTermDebtNoncurrent	76
1270	4	12	2023	Q1	\N	2023-03-26	15485000000.0000	USD	us-gaap:LongTermDebtNoncurrent	77
1271	4	12	2023	Q2	\N	2023-06-25	17262000000.0000	USD	us-gaap:LongTermDebtNoncurrent	78
1272	4	12	2023	Q3	\N	2023-09-24	17221000000.0000	USD	us-gaap:LongTermDebtNoncurrent	79
1273	4	12	2023	FY	\N	2023-12-31	17291000000.0000	USD	us-gaap:LongTermDebtNoncurrent	80
1274	4	12	2024	Q1	\N	2024-03-31	19250000000.0000	USD	us-gaap:LongTermDebtNoncurrent	81
1275	4	12	2024	Q2	\N	2024-06-30	19115000000.0000	USD	us-gaap:LongTermDebtNoncurrent	82
1276	4	12	2024	Q3	\N	2024-09-29	19179000000.0000	USD	us-gaap:LongTermDebtNoncurrent	83
1277	4	12	2024	FY	\N	2024-12-31	19627000000.0000	USD	us-gaap:LongTermDebtNoncurrent	4
1278	4	12	2025	Q1	\N	2025-03-30	18661000000.0000	USD	us-gaap:LongTermDebtNoncurrent	84
1279	4	12	2025	Q2	\N	2025-06-29	18520000000.0000	USD	us-gaap:LongTermDebtNoncurrent	85
1280	4	12	2025	Q3	\N	2025-09-28	20520000000.0000	USD	us-gaap:LongTermDebtNoncurrent	86
1281	4	12	2025	FY	\N	2025-12-31	20532000000.0000	USD	us-gaap:LongTermDebtNoncurrent	89
1282	4	12	2026	Q1	\N	2026-03-29	20529000000.0000	USD	us-gaap:LongTermDebtNoncurrent	87
1283	4	12	2026	Q2	\N	2026-06-28	20538000000.0000	USD	us-gaap:LongTermDebtNoncurrent	88
1284	4	12	2026	Q3	\N	2026-09-27	20498000000.0000	USD	us-gaap:LongTermDebtNoncurrent	89
1285	4	13	2019	FY	\N	2019-12-31	3619000000.0000	USD	us-gaap:InventoryNet	67
1286	4	13	2020	FY	\N	2020-12-31	3545000000.0000	USD	us-gaap:InventoryNet	68
1287	4	13	2021	FY	\N	2021-12-31	2981000000.0000	USD	us-gaap:InventoryNet	72
1288	4	13	2022	FY	\N	2022-12-31	3088000000.0000	USD	us-gaap:InventoryNet	76
1289	4	13	2023	FY	\N	2023-12-31	3132000000.0000	USD	us-gaap:InventoryNet	80
1290	4	13	2024	Q1	\N	2024-03-31	3278000000.0000	USD	us-gaap:InventoryNet	81
1291	4	13	2024	Q2	\N	2024-06-30	3097000000.0000	USD	us-gaap:InventoryNet	82
1292	4	13	2024	Q3	\N	2024-09-29	3234000000.0000	USD	us-gaap:InventoryNet	83
1293	4	13	2024	FY	\N	2024-12-31	3474000000.0000	USD	us-gaap:InventoryNet	4
1294	4	13	2025	Q1	\N	2025-03-30	3599000000.0000	USD	us-gaap:InventoryNet	84
1295	4	13	2025	Q2	\N	2025-06-29	3699000000.0000	USD	us-gaap:InventoryNet	85
1296	4	13	2025	Q3	\N	2025-09-28	3749000000.0000	USD	us-gaap:InventoryNet	86
1297	4	13	2025	FY	\N	2025-12-31	3524000000.0000	USD	us-gaap:InventoryNet	89
1298	4	13	2026	Q1	\N	2026-03-29	4251000000.0000	USD	us-gaap:InventoryNet	87
1299	4	13	2026	Q2	\N	2026-06-28	4411000000.0000	USD	us-gaap:InventoryNet	88
1300	4	13	2026	Q3	\N	2026-09-27	3987000000.0000	USD	us-gaap:InventoryNet	89
1301	4	14	2019	FY	2019-01-01	2019-12-31	1300000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	68
1302	4	14	2020	FY	2020-01-01	2020-12-31	1300000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	72
1303	4	14	2021	FY	2021-01-01	2021-12-31	1500000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	76
1304	4	14	2022	FY	2022-01-01	2022-12-31	1700000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	80
1305	4	14	2023	FY	2023-01-01	2023-12-31	1500000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	4
1306	4	14	2024	FY	2024-01-01	2024-12-31	1600000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	4
1307	4	14	2025	FY	2025-01-01	2025-12-31	2000000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	4
1308	4	15	2019	Q1	2019-01-01	2019-03-31	37000000.0000	USD	us-gaap:ShareBasedCompensation	90
1309	4	15	2019	FY	2019-01-01	2019-12-31	189000000.0000	USD	us-gaap:ShareBasedCompensation	68
1310	4	15	2020	Q1	2020-01-01	2020-03-29	42000000.0000	USD	us-gaap:ShareBasedCompensation	69
1311	4	15	2020	FY	2020-01-01	2020-12-31	221000000.0000	USD	us-gaap:ShareBasedCompensation	72
1312	4	15	2021	Q1	2021-01-01	2021-03-28	47000000.0000	USD	us-gaap:ShareBasedCompensation	73
1313	4	15	2021	FY	2021-01-01	2021-12-31	227000000.0000	USD	us-gaap:ShareBasedCompensation	76
1314	4	15	2022	Q1	2022-01-01	2022-03-27	54000000.0000	USD	us-gaap:ShareBasedCompensation	77
1315	4	15	2022	FY	2022-01-01	2022-12-31	238000000.0000	USD	us-gaap:ShareBasedCompensation	80
1316	4	15	2023	Q1	2023-01-01	2023-03-26	57000000.0000	USD	us-gaap:ShareBasedCompensation	81
1317	4	15	2023	FY	2023-01-01	2023-12-31	265000000.0000	USD	us-gaap:ShareBasedCompensation	4
1318	4	15	2024	Q1	2024-01-01	2024-03-31	61000000.0000	USD	us-gaap:ShareBasedCompensation	84
1319	4	15	2024	FY	2024-01-01	2024-12-31	277000000.0000	USD	us-gaap:ShareBasedCompensation	4
1320	4	15	2025	Q1	2025-01-01	2025-03-30	60000000.0000	USD	us-gaap:ShareBasedCompensation	87
1321	4	15	2025	FY	2025-01-01	2025-12-31	304000000.0000	USD	us-gaap:ShareBasedCompensation	4
1322	4	15	2026	Q1	2026-01-01	2026-03-29	83000000.0000	USD	us-gaap:ShareBasedCompensation	87
1323	4	16	2023	FY	2023-01-01	2023-12-31	1430000000.0000	USD	us-gaap:DepreciationAmortizationAndAccretionNet	4
1324	4	16	2024	FY	2024-01-01	2024-12-31	1559000000.0000	USD	us-gaap:DepreciationAmortizationAndAccretionNet	4
1325	4	16	2025	Q1	2025-01-01	2025-03-30	397000000.0000	USD	us-gaap:DepreciationAmortizationAndAccretionNet	87
1326	4	16	2025	FY	2025-01-01	2025-12-31	1687000000.0000	USD	us-gaap:DepreciationAmortizationAndAccretionNet	4
1327	4	16	2026	Q1	2026-01-01	2026-03-29	398000000.0000	USD	us-gaap:DepreciationAmortizationAndAccretionNet	87
1328	4	17	2019	Q1	2019-01-01	2019-03-31	241000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	90
1329	4	17	2019	Q2	2019-04-01	2019-06-30	263000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	91
1330	4	17	2019	Q3	2019-07-01	2019-09-29	173000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	92
1331	4	17	2019	FY	2019-01-01	2019-12-31	1011000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	68
1332	4	17	2020	Q1	2020-01-01	2020-03-29	313000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	69
1333	4	17	2020	Q2	2020-03-30	2020-06-28	336000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	70
1334	4	17	2020	Q3	2020-06-29	2020-09-27	303000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	71
1335	4	17	2020	FY	2020-01-01	2020-12-31	1347000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	72
1336	4	17	2021	Q1	2021-01-01	2021-03-28	374000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	73
1337	4	17	2021	Q2	2021-03-29	2021-06-27	355000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	74
1338	4	17	2021	Q3	2021-06-28	2021-09-26	65000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	75
1339	4	17	2021	FY	2021-01-01	2021-12-31	1235000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	76
1340	4	17	2022	Q1	2022-01-01	2022-03-27	328000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	77
1341	4	17	2022	Q2	2022-03-28	2022-06-26	21000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	78
1342	4	17	2022	Q3	2022-06-27	2022-09-25	321000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	79
1343	4	17	2022	FY	2022-01-01	2022-12-31	948000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	80
1344	4	17	2023	Q1	2023-01-01	2023-03-26	305000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	81
1345	4	17	2023	Q2	2023-03-27	2023-06-25	325000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	82
1346	4	17	2023	Q3	2023-06-26	2023-09-24	269000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	83
1347	4	17	2023	FY	2023-01-01	2023-12-31	1178000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	4
1348	4	17	2024	Q1	2024-01-01	2024-03-31	290000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	84
1349	4	17	2024	Q2	2024-04-01	2024-06-30	307000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	85
1350	4	17	2024	Q3	2024-07-01	2024-09-29	295000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	86
1351	4	17	2024	FY	2024-01-01	2024-12-31	884000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	4
1352	4	17	2025	Q1	2025-01-01	2025-03-30	324000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	87
1353	4	17	2025	Q2	2025-03-31	2025-06-29	75000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	88
1354	4	17	2025	Q3	2025-06-30	2025-09-28	319000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	89
1355	4	17	2025	FY	2025-01-01	2025-12-31	905000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	4
1356	4	17	2026	Q1	2026-01-01	2026-03-29	286000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	87
1357	4	17	2026	Q2	2026-03-30	2026-06-28	342000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	88
1358	4	17	2026	Q3	2026-06-29	2026-09-27	327000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	89
1359	4	18	2019	Q1	2019-01-01	2019-03-31	5.9900	USD/shares	us-gaap:EarningsPerShareDiluted	67
1360	4	18	2019	Q2	2019-04-01	2019-06-30	5.0000	USD/shares	us-gaap:EarningsPerShareDiluted	67
1361	4	18	2019	Q3	2019-07-01	2019-09-29	5.6600	USD/shares	us-gaap:EarningsPerShareDiluted	67
1362	4	18	2019	FY	2019-01-01	2019-12-31	21.9500	USD/shares	us-gaap:EarningsPerShareDiluted	68
1363	4	18	2019	Q4	2019-09-30	2019-12-31	5.2900	USD/shares	us-gaap:EarningsPerShareDiluted	67
1364	4	18	2020	Q1	2020-01-01	2020-03-29	6.0800	USD/shares	us-gaap:EarningsPerShareDiluted	69
1365	4	18	2020	Q2	2020-03-30	2020-06-28	5.7900	USD/shares	us-gaap:EarningsPerShareDiluted	70
1366	4	18	2020	Q3	2020-06-29	2020-09-27	6.0500	USD/shares	us-gaap:EarningsPerShareDiluted	71
1367	4	18	2020	FY	2020-01-01	2020-12-31	24.3000	USD/shares	us-gaap:EarningsPerShareDiluted	72
1368	4	18	2020	Q4	2020-09-28	2020-12-31	6.3800	USD/shares	us-gaap:EarningsPerShareDiluted	67
1369	4	18	2021	Q1	2021-01-01	2021-03-28	6.5600	USD/shares	us-gaap:EarningsPerShareDiluted	73
1370	4	18	2021	Q2	2021-03-29	2021-06-27	6.5200	USD/shares	us-gaap:EarningsPerShareDiluted	74
1371	4	18	2021	Q3	2021-06-28	2021-09-26	2.2100	USD/shares	us-gaap:EarningsPerShareDiluted	75
1372	4	18	2021	FY	2021-01-01	2021-12-31	22.7600	USD/shares	us-gaap:EarningsPerShareDiluted	76
1373	4	18	2022	Q1	2022-01-01	2022-03-27	6.4400	USD/shares	us-gaap:EarningsPerShareDiluted	77
1374	4	18	2022	Q2	2022-03-28	2022-06-26	1.1600	USD/shares	us-gaap:EarningsPerShareDiluted	78
1375	4	18	2022	Q3	2022-06-27	2022-09-25	6.7100	USD/shares	us-gaap:EarningsPerShareDiluted	79
1376	4	18	2022	FY	2022-01-01	2022-12-31	21.6600	USD/shares	us-gaap:EarningsPerShareDiluted	80
1377	4	18	2023	Q1	2023-01-01	2023-03-26	6.6100	USD/shares	us-gaap:EarningsPerShareDiluted	81
1378	4	18	2023	Q2	2023-03-27	2023-06-25	6.6300	USD/shares	us-gaap:EarningsPerShareDiluted	82
1379	4	18	2023	Q3	2023-06-26	2023-09-24	6.7300	USD/shares	us-gaap:EarningsPerShareDiluted	83
1380	4	18	2023	FY	2023-01-01	2023-12-31	27.5500	USD/shares	us-gaap:EarningsPerShareDiluted	4
1381	4	18	2024	Q1	2024-01-01	2024-03-31	6.3900	USD/shares	us-gaap:EarningsPerShareDiluted	84
1382	4	18	2024	Q2	2024-04-01	2024-06-30	6.8500	USD/shares	us-gaap:EarningsPerShareDiluted	85
1383	4	18	2024	Q3	2024-07-01	2024-09-29	6.8000	USD/shares	us-gaap:EarningsPerShareDiluted	86
1384	4	18	2024	FY	2024-01-01	2024-12-31	22.3100	USD/shares	us-gaap:EarningsPerShareDiluted	4
1385	4	18	2025	Q1	2025-01-01	2025-03-30	7.2800	USD/shares	us-gaap:EarningsPerShareDiluted	87
1386	4	18	2025	Q2	2025-03-31	2025-06-29	1.4600	USD/shares	us-gaap:EarningsPerShareDiluted	88
1387	4	18	2025	Q3	2025-06-30	2025-09-28	6.9500	USD/shares	us-gaap:EarningsPerShareDiluted	89
1388	4	18	2025	FY	2025-01-01	2025-12-31	21.4900	USD/shares	us-gaap:EarningsPerShareDiluted	4
1389	4	18	2026	Q1	2026-01-01	2026-03-29	6.4400	USD/shares	us-gaap:EarningsPerShareDiluted	87
1390	4	18	2026	Q2	2026-03-30	2026-06-28	7.9400	USD/shares	us-gaap:EarningsPerShareDiluted	88
1391	4	18	2026	Q3	2026-06-29	2026-09-27	7.9700	USD/shares	us-gaap:EarningsPerShareDiluted	89
1392	4	19	2019	Q1	2019-01-01	2019-03-31	638000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	90
1393	4	19	2019	FY	2019-01-01	2019-12-31	2556000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	68
1394	4	19	2020	Q1	2020-01-01	2020-03-29	693000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	69
1395	4	19	2020	FY	2020-01-01	2020-12-31	2764000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	72
1396	4	19	2021	Q1	2021-01-01	2021-03-28	739000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	73
1397	4	19	2021	FY	2021-01-01	2021-12-31	2940000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	76
1398	4	19	2022	Q1	2022-01-01	2022-03-27	767000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	77
1399	4	19	2022	FY	2022-01-01	2022-12-31	3016000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	80
1400	4	19	2023	Q1	2023-01-01	2023-03-26	784000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	81
1401	4	19	2023	FY	2023-01-01	2023-12-31	3056000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	4
1402	4	19	2024	Q1	2024-01-01	2024-03-31	780000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	84
1403	4	19	2024	FY	2024-01-01	2024-12-31	3059000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	4
1404	4	19	2025	Q1	2025-01-01	2025-03-30	796000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	87
1405	4	19	2025	FY	2025-01-01	2025-12-31	3131000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	4
1406	4	19	2026	Q1	2026-01-01	2026-03-29	816000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	87
1407	4	20	2019	Q1	2019-01-01	2019-03-31	281000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	90
1408	4	20	2019	Q3	\N	2019-10-30	350000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	96
1409	4	20	2019	FY	2019-01-01	2019-12-31	1200000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	68
1410	4	20	2020	Q1	2020-01-01	2020-03-29	756000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	69
1411	4	20	2020	FY	2020-01-01	2020-12-31	1100000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	72
1412	4	20	2021	Q1	2021-01-01	2021-03-28	1000000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	73
1413	4	20	2021	FY	2021-01-01	2021-12-31	4087000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	76
1414	4	20	2022	Q1	2022-01-01	2022-03-27	2000000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	77
1415	4	20	2022	FY	2022-01-01	2022-12-31	7900000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	80
1416	4	20	2023	Q1	2023-01-01	2023-03-26	500000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	81
1417	4	20	2023	FY	2023-01-01	2023-12-31	6000000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	4
1418	4	20	2024	Q1	2024-01-01	2024-03-31	1000000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	84
1419	4	20	2024	FY	2024-01-01	2024-12-31	3700000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	4
1420	4	20	2025	Q1	2025-01-01	2025-03-30	750000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	87
1421	4	20	2025	FY	2025-01-01	2025-12-31	3000000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	4
1422	4	20	2026	Q1	2026-01-01	2026-03-29	0.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	87
1423	4	21	2019	Q1	2019-01-01	2019-03-31	2.2000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	90
1424	4	21	2019	Q2	2019-04-01	2019-06-30	4.4000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	91
1425	4	21	2019	Q3	2019-07-01	2019-09-29	2.4000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	92
1426	4	21	2019	FY	2019-01-01	2019-12-31	9.0000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	68
1427	4	21	2020	Q1	2020-01-01	2020-03-29	2.4000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	69
1428	4	21	2020	Q2	2020-03-30	2020-06-28	4.8000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	70
1429	4	21	2020	Q3	2020-06-29	2020-09-27	2.6000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	71
1430	4	21	2020	FY	2020-01-01	2020-12-31	9.8000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	68
1431	4	21	2021	Q1	2021-01-01	2021-03-28	2.6000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	69
1432	4	21	2021	Q2	2021-03-29	2021-06-27	2.6000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	71
1433	4	21	2021	Q3	2021-06-28	2021-09-26	2.8000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	71
1434	4	21	2021	FY	2021-01-01	2021-12-31	10.6000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	76
1435	4	21	2022	Q1	2022-01-01	2022-03-27	2.8000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	73
1436	4	21	2022	FY	2022-01-01	2022-12-31	11.4000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	80
1437	4	21	2023	Q1	2023-01-01	2023-03-26	3.0000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	77
1438	4	21	2023	Q2	2023-03-27	2023-06-25	3.0000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	79
1439	4	21	2023	FY	2023-01-01	2023-12-31	12.1500	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	4
1440	4	21	2024	Q1	2024-01-01	2024-03-31	3.1500	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	81
1441	4	21	2024	Q3	2024-07-01	2024-09-29	3.1500	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	83
1442	4	21	2024	FY	2024-01-01	2024-12-31	12.7500	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	4
1443	4	21	2025	Q1	2025-01-01	2025-03-30	3.3000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	87
1444	4	21	2025	Q2	2025-03-31	2025-06-29	3.3000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	88
1445	4	21	2025	Q3	2025-06-30	2025-09-28	3.3000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	86
1446	4	21	2025	FY	2025-01-01	2025-12-31	13.3500	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	4
1447	4	21	2026	Q1	2026-01-01	2026-03-29	3.4500	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	87
1448	4	21	2026	Q2	2026-03-30	2026-06-28	3.4500	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	88
1449	4	21	2026	Q3	2026-06-29	2026-09-27	3.4500	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	89
1450	5	1	2019	Q1	2019-01-01	2019-03-31	22917000000.0000	USD	us-gaap:Revenues	97
1451	5	1	2019	Q2	2019-04-01	2019-06-30	15751000000.0000	USD	us-gaap:Revenues	97
1452	5	1	2019	Q3	2019-07-01	2019-09-30	19980000000.0000	USD	us-gaap:Revenues	97
1453	5	1	2019	FY	2019-01-01	2019-12-31	76559000000.0000	USD	us-gaap:Revenues	98
1454	5	1	2019	Q4	2019-10-01	2019-12-31	17911000000.0000	USD	us-gaap:Revenues	97
1455	5	1	2020	Q1	2020-01-01	2020-03-31	16908000000.0000	USD	us-gaap:Revenues	99
1456	5	1	2020	Q2	2020-04-01	2020-06-30	11807000000.0000	USD	us-gaap:Revenues	100
1457	5	1	2020	Q3	2020-07-01	2020-09-30	14139000000.0000	USD	us-gaap:Revenues	101
1458	5	1	2020	FY	2020-01-01	2020-12-31	58158000000.0000	USD	us-gaap:Revenues	102
1459	5	1	2020	Q4	2020-10-01	2020-12-31	15304000000.0000	USD	us-gaap:Revenues	97
1460	5	1	2021	Q1	2021-01-01	2021-03-31	15217000000.0000	USD	us-gaap:Revenues	103
1461	5	1	2021	Q2	2021-04-01	2021-06-30	16998000000.0000	USD	us-gaap:Revenues	104
1462	5	1	2021	Q3	2021-07-01	2021-09-30	15278000000.0000	USD	us-gaap:Revenues	105
1463	5	1	2021	FY	2021-01-01	2021-12-31	62286000000.0000	USD	us-gaap:Revenues	106
1464	5	1	2022	Q1	2022-01-01	2022-03-31	13991000000.0000	USD	us-gaap:Revenues	107
1465	5	1	2022	Q2	2022-04-01	2022-06-30	16681000000.0000	USD	us-gaap:Revenues	108
1466	5	1	2022	Q3	2022-07-01	2022-09-30	15956000000.0000	USD	us-gaap:Revenues	109
1467	5	1	2022	FY	2022-01-01	2022-12-31	66608000000.0000	USD	us-gaap:Revenues	110
1468	5	1	2023	Q1	2023-01-01	2023-03-31	17921000000.0000	USD	us-gaap:Revenues	111
1469	5	1	2023	Q2	2023-04-01	2023-06-30	19751000000.0000	USD	us-gaap:Revenues	112
1470	5	1	2023	Q3	2023-07-01	2023-09-30	18104000000.0000	USD	us-gaap:Revenues	113
1471	5	1	2023	FY	2023-01-01	2023-12-31	77794000000.0000	USD	us-gaap:Revenues	5
1472	5	1	2024	Q1	2024-01-01	2024-03-31	16569000000.0000	USD	us-gaap:Revenues	114
1473	5	1	2024	Q2	2024-04-01	2024-06-30	16866000000.0000	USD	us-gaap:Revenues	115
1474	5	1	2024	Q3	2024-07-01	2024-09-30	17840000000.0000	USD	us-gaap:Revenues	116
1475	5	1	2024	FY	2024-01-01	2024-12-31	66517000000.0000	USD	us-gaap:Revenues	5
1476	5	1	2025	Q1	2025-01-01	2025-03-31	19496000000.0000	USD	us-gaap:Revenues	117
1477	5	1	2025	Q2	2025-04-01	2025-06-30	22749000000.0000	USD	us-gaap:Revenues	118
1478	5	1	2025	Q3	2025-07-01	2025-09-30	23270000000.0000	USD	us-gaap:Revenues	119
1479	5	1	2025	FY	2025-01-01	2025-12-31	89463000000.0000	USD	us-gaap:Revenues	5
1480	5	1	2026	Q1	2026-01-01	2026-03-31	22217000000.0000	USD	us-gaap:Revenues	117
1481	5	1	2026	Q2	2026-04-01	2026-06-30	24560000000.0000	USD	us-gaap:Revenues	118
1482	5	1	2026	Q3	2026-07-01	2026-09-30	24188000000.0000	USD	us-gaap:Revenues	119
1483	5	2	2019	Q1	2019-01-01	2019-03-31	18645000000.0000	USD	us-gaap:CostOfRevenue	97
1484	5	2	2019	Q2	2019-04-01	2019-06-30	17810000000.0000	USD	us-gaap:CostOfRevenue	97
1485	5	2	2019	Q3	2019-07-01	2019-09-30	16930000000.0000	USD	us-gaap:CostOfRevenue	97
1486	5	2	2019	FY	2019-01-01	2019-12-31	72093000000.0000	USD	us-gaap:CostOfRevenue	98
1487	5	2	2019	Q4	2019-10-01	2019-12-31	18708000000.0000	USD	us-gaap:CostOfRevenue	97
1488	5	2	2020	Q1	2020-01-01	2020-03-31	16768000000.0000	USD	us-gaap:CostOfRevenue	99
1489	5	2	2020	Q2	2020-04-01	2020-06-30	12978000000.0000	USD	us-gaap:CostOfRevenue	100
1490	5	2	2020	Q3	2020-07-01	2020-09-30	13105000000.0000	USD	us-gaap:CostOfRevenue	101
1491	5	2	2020	FY	2020-01-01	2020-12-31	63843000000.0000	USD	us-gaap:CostOfRevenue	102
1492	5	2	2020	Q4	2020-10-01	2020-12-31	20992000000.0000	USD	us-gaap:CostOfRevenue	97
1493	5	2	2021	Q1	2021-01-01	2021-03-31	13808000000.0000	USD	us-gaap:CostOfRevenue	103
1494	5	2	2021	Q2	2021-04-01	2021-06-30	14588000000.0000	USD	us-gaap:CostOfRevenue	104
1495	5	2	2021	Q3	2021-07-01	2021-09-30	13566000000.0000	USD	us-gaap:CostOfRevenue	105
1496	5	2	2021	FY	2021-01-01	2021-12-31	59237000000.0000	USD	us-gaap:CostOfRevenue	106
1497	5	2	2022	Q1	2022-01-01	2022-03-31	13638000000.0000	USD	us-gaap:CostOfRevenue	107
1498	5	2	2022	Q2	2022-04-01	2022-06-30	14553000000.0000	USD	us-gaap:CostOfRevenue	108
1499	5	2	2022	Q3	2022-07-01	2022-09-30	16771000000.0000	USD	us-gaap:CostOfRevenue	109
1500	5	2	2022	FY	2022-01-01	2022-12-31	63078000000.0000	USD	us-gaap:CostOfRevenue	110
1501	5	2	2023	Q1	2023-01-01	2023-03-31	15998000000.0000	USD	us-gaap:CostOfRevenue	111
1502	5	2	2023	Q2	2023-04-01	2023-06-30	17812000000.0000	USD	us-gaap:CostOfRevenue	112
1503	5	2	2023	Q3	2023-07-01	2023-09-30	16939000000.0000	USD	us-gaap:CostOfRevenue	113
1504	5	2	2023	FY	2023-01-01	2023-12-31	70070000000.0000	USD	us-gaap:CostOfRevenue	5
1505	5	2	2024	Q1	2024-01-01	2024-03-31	14693000000.0000	USD	us-gaap:CostOfRevenue	114
1506	5	2	2024	Q2	2024-04-01	2024-06-30	15637000000.0000	USD	us-gaap:CostOfRevenue	115
1507	5	2	2024	Q3	2024-07-01	2024-09-30	21347000000.0000	USD	us-gaap:CostOfRevenue	116
1508	5	2	2024	FY	2024-01-01	2024-12-31	68508000000.0000	USD	us-gaap:CostOfRevenue	5
1509	5	2	2025	Q1	2025-01-01	2025-03-31	17079000000.0000	USD	us-gaap:CostOfRevenue	117
1510	5	2	2025	Q2	2025-04-01	2025-06-30	20314000000.0000	USD	us-gaap:CostOfRevenue	118
1511	5	2	2025	Q3	2025-07-01	2025-09-30	25645000000.0000	USD	us-gaap:CostOfRevenue	119
1512	5	2	2025	FY	2025-01-01	2025-12-31	85174000000.0000	USD	us-gaap:CostOfRevenue	5
1513	5	2	2026	Q1	2026-01-01	2026-03-31	19671000000.0000	USD	us-gaap:CostOfRevenue	117
1514	5	2	2026	Q2	2026-04-01	2026-06-30	22146000000.0000	USD	us-gaap:CostOfRevenue	118
1515	5	2	2026	Q3	2026-07-01	2026-09-30	22021000000.0000	USD	us-gaap:CostOfRevenue	119
1516	5	3	2019	Q1	2019-01-01	2019-03-31	4272000000.0000	USD	us-gaap:GrossProfit	120
1517	5	3	2019	Q2	2019-04-01	2019-06-30	-2059000000.0000	USD	us-gaap:GrossProfit	121
1518	5	3	2019	Q3	2019-07-01	2019-09-30	3050000000.0000	USD	us-gaap:GrossProfit	122
1519	5	3	2019	FY	2019-01-01	2019-12-31	4466000000.0000	USD	us-gaap:GrossProfit	98
1520	5	3	2020	Q1	2020-01-01	2020-03-31	140000000.0000	USD	us-gaap:GrossProfit	99
1521	5	3	2020	Q2	2020-04-01	2020-06-30	-1171000000.0000	USD	us-gaap:GrossProfit	100
1522	5	3	2020	Q3	2020-07-01	2020-09-30	1034000000.0000	USD	us-gaap:GrossProfit	101
1523	5	3	2020	FY	2020-01-01	2020-12-31	-5685000000.0000	USD	us-gaap:GrossProfit	102
1524	5	3	2021	Q1	2021-01-01	2021-03-31	1409000000.0000	USD	us-gaap:GrossProfit	103
1525	5	3	2021	Q2	2021-04-01	2021-06-30	2410000000.0000	USD	us-gaap:GrossProfit	104
1526	5	3	2021	Q3	2021-07-01	2021-09-30	1712000000.0000	USD	us-gaap:GrossProfit	105
1527	5	3	2021	FY	2021-01-01	2021-12-31	3049000000.0000	USD	us-gaap:GrossProfit	106
1528	5	3	2022	Q1	2022-01-01	2022-03-31	353000000.0000	USD	us-gaap:GrossProfit	107
1529	5	3	2022	Q2	2022-04-01	2022-06-30	2128000000.0000	USD	us-gaap:GrossProfit	108
1530	5	3	2022	Q3	2022-07-01	2022-09-30	-815000000.0000	USD	us-gaap:GrossProfit	109
1531	5	3	2022	FY	2022-01-01	2022-12-31	3530000000.0000	USD	us-gaap:GrossProfit	110
1532	5	3	2023	Q1	2023-01-01	2023-03-31	1923000000.0000	USD	us-gaap:GrossProfit	111
1533	5	3	2023	Q2	2023-04-01	2023-06-30	1939000000.0000	USD	us-gaap:GrossProfit	112
1534	5	3	2023	Q3	2023-07-01	2023-09-30	1165000000.0000	USD	us-gaap:GrossProfit	113
1535	5	3	2023	FY	2023-01-01	2023-12-31	7724000000.0000	USD	us-gaap:GrossProfit	5
1536	5	3	2024	Q1	2024-01-01	2024-03-31	1876000000.0000	USD	us-gaap:GrossProfit	114
1537	5	3	2024	Q2	2024-04-01	2024-06-30	1229000000.0000	USD	us-gaap:GrossProfit	115
1538	5	3	2024	Q3	2024-07-01	2024-09-30	-3507000000.0000	USD	us-gaap:GrossProfit	116
1539	5	3	2024	FY	2024-01-01	2024-12-31	-1991000000.0000	USD	us-gaap:GrossProfit	5
1540	5	3	2025	Q1	2025-01-01	2025-03-31	2417000000.0000	USD	us-gaap:GrossProfit	117
1541	5	3	2025	Q2	2025-04-01	2025-06-30	2435000000.0000	USD	us-gaap:GrossProfit	118
1542	5	3	2025	Q3	2025-07-01	2025-09-30	-2375000000.0000	USD	us-gaap:GrossProfit	119
1543	5	3	2025	FY	2025-01-01	2025-12-31	4289000000.0000	USD	us-gaap:GrossProfit	5
1544	5	3	2026	Q1	2026-01-01	2026-03-31	2546000000.0000	USD	us-gaap:GrossProfit	117
1545	5	3	2026	Q2	2026-04-01	2026-06-30	2414000000.0000	USD	us-gaap:GrossProfit	118
1546	5	3	2026	Q3	2026-07-01	2026-09-30	2167000000.0000	USD	us-gaap:GrossProfit	119
1547	5	4	2019	Q1	2019-01-01	2019-03-31	2350000000.0000	USD	us-gaap:OperatingIncomeLoss	97
1548	5	4	2019	Q2	2019-04-01	2019-06-30	-3380000000.0000	USD	us-gaap:OperatingIncomeLoss	97
1549	5	4	2019	Q3	2019-07-01	2019-09-30	1259000000.0000	USD	us-gaap:OperatingIncomeLoss	97
1550	5	4	2019	FY	2019-01-01	2019-12-31	-1975000000.0000	USD	us-gaap:OperatingIncomeLoss	98
1551	5	4	2019	Q4	2019-10-01	2019-12-31	-2204000000.0000	USD	us-gaap:OperatingIncomeLoss	97
1552	5	4	2020	Q1	2020-01-01	2020-03-31	-1353000000.0000	USD	us-gaap:OperatingIncomeLoss	99
1553	5	4	2020	Q2	2020-04-01	2020-06-30	-2964000000.0000	USD	us-gaap:OperatingIncomeLoss	100
1554	5	4	2020	Q3	2020-07-01	2020-09-30	-401000000.0000	USD	us-gaap:OperatingIncomeLoss	101
1555	5	4	2020	FY	2020-01-01	2020-12-31	-12767000000.0000	USD	us-gaap:OperatingIncomeLoss	102
1556	5	4	2020	Q4	2020-10-01	2020-12-31	-8049000000.0000	USD	us-gaap:OperatingIncomeLoss	97
1557	5	4	2021	Q1	2021-01-01	2021-03-31	-83000000.0000	USD	us-gaap:OperatingIncomeLoss	103
1558	5	4	2021	Q2	2021-04-01	2021-06-30	1023000000.0000	USD	us-gaap:OperatingIncomeLoss	104
1559	5	4	2021	Q3	2021-07-01	2021-09-30	329000000.0000	USD	us-gaap:OperatingIncomeLoss	105
1560	5	4	2021	FY	2021-01-01	2021-12-31	-2870000000.0000	USD	us-gaap:OperatingIncomeLoss	106
1561	5	4	2022	Q1	2022-01-01	2022-03-31	-1162000000.0000	USD	us-gaap:OperatingIncomeLoss	107
1562	5	4	2022	Q2	2022-04-01	2022-06-30	780000000.0000	USD	us-gaap:OperatingIncomeLoss	108
1563	5	4	2022	Q3	2022-07-01	2022-09-30	-2792000000.0000	USD	us-gaap:OperatingIncomeLoss	109
1564	5	4	2022	FY	2022-01-01	2022-12-31	-3519000000.0000	USD	us-gaap:OperatingIncomeLoss	110
1565	5	4	2023	Q1	2023-01-01	2023-03-31	-149000000.0000	USD	us-gaap:OperatingIncomeLoss	111
1566	5	4	2023	Q2	2023-04-01	2023-06-30	-99000000.0000	USD	us-gaap:OperatingIncomeLoss	112
1567	5	4	2023	Q3	2023-07-01	2023-09-30	-808000000.0000	USD	us-gaap:OperatingIncomeLoss	113
1568	5	4	2023	FY	2023-01-01	2023-12-31	-773000000.0000	USD	us-gaap:OperatingIncomeLoss	5
1569	5	4	2024	Q1	2024-01-01	2024-03-31	-86000000.0000	USD	us-gaap:OperatingIncomeLoss	114
1570	5	4	2024	Q2	2024-04-01	2024-06-30	-1090000000.0000	USD	us-gaap:OperatingIncomeLoss	115
1571	5	4	2024	Q3	2024-07-01	2024-09-30	-5761000000.0000	USD	us-gaap:OperatingIncomeLoss	116
1572	5	4	2024	FY	2024-01-01	2024-12-31	-10707000000.0000	USD	us-gaap:OperatingIncomeLoss	5
1573	5	4	2025	Q1	2025-01-01	2025-03-31	461000000.0000	USD	us-gaap:OperatingIncomeLoss	117
1574	5	4	2025	Q2	2025-04-01	2025-06-30	-176000000.0000	USD	us-gaap:OperatingIncomeLoss	118
1575	5	4	2025	Q3	2025-07-01	2025-09-30	-4781000000.0000	USD	us-gaap:OperatingIncomeLoss	119
1576	5	4	2025	FY	2025-01-01	2025-12-31	4281000000.0000	USD	us-gaap:OperatingIncomeLoss	5
1577	5	4	2026	Q1	2026-01-01	2026-03-31	448000000.0000	USD	us-gaap:OperatingIncomeLoss	117
1578	5	4	2026	Q2	2026-04-01	2026-06-30	156000000.0000	USD	us-gaap:OperatingIncomeLoss	118
1579	5	4	2026	Q3	2026-07-01	2026-09-30	354000000.0000	USD	us-gaap:OperatingIncomeLoss	119
1580	5	5	2019	Q1	2019-01-01	2019-03-31	2149000000.0000	USD	us-gaap:NetIncomeLoss	97
1581	5	5	2019	Q2	2019-04-01	2019-06-30	-2942000000.0000	USD	us-gaap:NetIncomeLoss	97
1582	5	5	2019	Q3	2019-07-01	2019-09-30	1167000000.0000	USD	us-gaap:NetIncomeLoss	97
1583	5	5	2019	FY	2019-01-01	2019-12-31	-636000000.0000	USD	us-gaap:NetIncomeLoss	98
1584	5	5	2019	Q4	2019-10-01	2019-12-31	-1010000000.0000	USD	us-gaap:NetIncomeLoss	97
1585	5	5	2020	Q1	2020-01-01	2020-03-31	-628000000.0000	USD	us-gaap:NetIncomeLoss	99
1586	5	5	2020	Q2	2020-04-01	2020-06-30	-2376000000.0000	USD	us-gaap:NetIncomeLoss	100
1587	5	5	2020	Q3	2020-07-01	2020-09-30	-449000000.0000	USD	us-gaap:NetIncomeLoss	101
1588	5	5	2020	FY	2020-01-01	2020-12-31	-11873000000.0000	USD	us-gaap:NetIncomeLoss	102
1589	5	5	2020	Q4	2020-10-01	2020-12-31	-8420000000.0000	USD	us-gaap:NetIncomeLoss	97
1590	5	5	2021	Q1	2021-01-01	2021-03-31	-537000000.0000	USD	us-gaap:NetIncomeLoss	103
1591	5	5	2021	Q2	2021-04-01	2021-06-30	587000000.0000	USD	us-gaap:NetIncomeLoss	104
1592	5	5	2021	Q3	2021-07-01	2021-09-30	-109000000.0000	USD	us-gaap:NetIncomeLoss	105
1593	5	5	2021	FY	2021-01-01	2021-12-31	-4202000000.0000	USD	us-gaap:NetIncomeLoss	106
1594	5	5	2022	Q1	2022-01-01	2022-03-31	-1219000000.0000	USD	us-gaap:NetIncomeLoss	107
1595	5	5	2022	Q2	2022-04-01	2022-06-30	193000000.0000	USD	us-gaap:NetIncomeLoss	108
1596	5	5	2022	Q3	2022-07-01	2022-09-30	-3275000000.0000	USD	us-gaap:NetIncomeLoss	109
1597	5	5	2022	FY	2022-01-01	2022-12-31	-4935000000.0000	USD	us-gaap:NetIncomeLoss	110
1598	5	5	2023	Q1	2023-01-01	2023-03-31	-414000000.0000	USD	us-gaap:NetIncomeLoss	111
1599	5	5	2023	Q2	2023-04-01	2023-06-30	-149000000.0000	USD	us-gaap:NetIncomeLoss	112
1600	5	5	2023	Q3	2023-07-01	2023-09-30	-1636000000.0000	USD	us-gaap:NetIncomeLoss	113
1601	5	5	2023	FY	2023-01-01	2023-12-31	-2222000000.0000	USD	us-gaap:NetIncomeLoss	5
1602	5	5	2024	Q1	2024-01-01	2024-03-31	-343000000.0000	USD	us-gaap:NetIncomeLoss	114
1603	5	5	2024	Q2	2024-04-01	2024-06-30	-1439000000.0000	USD	us-gaap:NetIncomeLoss	115
1604	5	5	2024	Q3	2024-07-01	2024-09-30	-6170000000.0000	USD	us-gaap:NetIncomeLoss	116
1605	5	5	2024	FY	2024-01-01	2024-12-31	-11817000000.0000	USD	us-gaap:NetIncomeLoss	5
1606	5	5	2025	Q1	2025-01-01	2025-03-31	-37000000.0000	USD	us-gaap:NetIncomeLoss	117
1607	5	5	2025	Q2	2025-04-01	2025-06-30	-611000000.0000	USD	us-gaap:NetIncomeLoss	118
1608	5	5	2025	Q3	2025-07-01	2025-09-30	-5337000000.0000	USD	us-gaap:NetIncomeLoss	119
1609	5	5	2025	FY	2025-01-01	2025-12-31	2235000000.0000	USD	us-gaap:NetIncomeLoss	5
1610	5	5	2026	Q1	2026-01-01	2026-03-31	-4000000.0000	USD	us-gaap:NetIncomeLoss	117
1611	5	5	2026	Q2	2026-04-01	2026-06-30	-444000000.0000	USD	us-gaap:NetIncomeLoss	118
1612	5	5	2026	Q3	2026-07-01	2026-09-30	-116000000.0000	USD	us-gaap:NetIncomeLoss	119
1613	5	6	2019	Q1	2019-01-01	2019-03-31	2788000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	120
1614	5	6	2019	FY	2019-01-01	2019-12-31	-2446000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	98
1615	5	6	2020	Q1	2020-01-01	2020-03-31	-4302000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	99
1616	5	6	2020	FY	2020-01-01	2020-12-31	-18410000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	102
1617	5	6	2021	Q1	2021-01-01	2021-03-31	-3387000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	103
1618	5	6	2021	FY	2021-01-01	2021-12-31	-3416000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	106
1619	5	6	2022	Q1	2022-01-01	2022-03-31	-3216000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	107
1620	5	6	2022	FY	2022-01-01	2022-12-31	3512000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	110
1621	5	6	2023	Q1	2023-01-01	2023-03-31	-318000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	111
1622	5	6	2023	FY	2023-01-01	2023-12-31	5960000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	5
1623	5	6	2024	Q1	2024-01-01	2024-03-31	-3362000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	114
1624	5	6	2024	FY	2024-01-01	2024-12-31	-12080000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	5
1625	5	6	2025	Q1	2025-01-01	2025-03-31	-1616000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	117
1626	5	6	2025	FY	2025-01-01	2025-12-31	1065000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	5
1627	5	6	2026	Q1	2026-01-01	2026-03-31	-179000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	117
1628	5	7	2019	Q1	2019-01-01	2019-03-31	501000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	120
1629	5	7	2019	FY	2019-01-01	2019-12-31	1834000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	98
1630	5	7	2020	Q1	2020-01-01	2020-03-31	428000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	99
1631	5	7	2020	FY	2020-01-01	2020-12-31	1303000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	102
1632	5	7	2021	Q1	2021-01-01	2021-03-31	291000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	103
1633	5	7	2021	FY	2021-01-01	2021-12-31	980000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	106
1634	5	7	2022	Q1	2022-01-01	2022-03-31	349000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	107
1635	5	7	2022	FY	2022-01-01	2022-12-31	1222000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	110
1636	5	7	2023	Q1	2023-01-01	2023-03-31	468000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	111
1637	5	7	2023	FY	2023-01-01	2023-12-31	1527000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	5
1638	5	7	2024	Q1	2024-01-01	2024-03-31	567000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	114
1639	5	7	2024	FY	2024-01-01	2024-12-31	2230000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	5
1640	5	7	2025	Q1	2025-01-01	2025-03-31	674000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	117
1641	5	7	2025	FY	2025-01-01	2025-12-31	2942000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	5
1642	5	7	2026	Q1	2026-01-01	2026-03-31	1275000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	117
1643	5	8	2019	Q1	\N	2019-03-31	120209000000.0000	USD	us-gaap:Assets	123
1644	5	8	2019	Q2	\N	2019-06-30	126261000000.0000	USD	us-gaap:Assets	124
1645	5	8	2019	Q3	\N	2019-09-30	132598000000.0000	USD	us-gaap:Assets	125
1646	5	8	2019	FY	\N	2019-12-31	133625000000.0000	USD	us-gaap:Assets	97
1647	5	8	2020	Q1	\N	2020-03-31	143075000000.0000	USD	us-gaap:Assets	120
1648	5	8	2020	Q2	\N	2020-06-30	162872000000.0000	USD	us-gaap:Assets	121
1649	5	8	2020	Q3	\N	2020-09-30	161261000000.0000	USD	us-gaap:Assets	122
1650	5	8	2020	FY	\N	2020-12-31	152136000000.0000	USD	us-gaap:Assets	98
1651	5	8	2021	Q1	\N	2021-03-31	150035000000.0000	USD	us-gaap:Assets	99
1652	5	8	2021	Q2	\N	2021-06-30	148935000000.0000	USD	us-gaap:Assets	100
1653	5	8	2021	Q3	\N	2021-09-30	146846000000.0000	USD	us-gaap:Assets	101
1654	5	8	2021	FY	\N	2021-12-31	138552000000.0000	USD	us-gaap:Assets	102
1655	5	8	2022	Q1	\N	2022-03-31	135801000000.0000	USD	us-gaap:Assets	103
1656	5	8	2022	Q2	\N	2022-06-30	135479000000.0000	USD	us-gaap:Assets	104
1657	5	8	2022	Q3	\N	2022-09-30	137558000000.0000	USD	us-gaap:Assets	105
1658	5	8	2022	FY	\N	2022-12-31	137100000000.0000	USD	us-gaap:Assets	106
1659	5	8	2023	Q1	\N	2023-03-31	136347000000.0000	USD	us-gaap:Assets	107
1660	5	8	2023	Q2	\N	2023-06-30	134774000000.0000	USD	us-gaap:Assets	108
1661	5	8	2023	Q3	\N	2023-09-30	134281000000.0000	USD	us-gaap:Assets	109
1662	5	8	2023	FY	\N	2023-12-31	137012000000.0000	USD	us-gaap:Assets	110
1663	5	8	2024	Q1	\N	2024-03-31	134484000000.0000	USD	us-gaap:Assets	111
1664	5	8	2024	Q2	\N	2024-06-30	142720000000.0000	USD	us-gaap:Assets	112
1665	5	8	2024	Q3	\N	2024-09-30	137695000000.0000	USD	us-gaap:Assets	113
1666	5	8	2024	FY	\N	2024-12-31	156363000000.0000	USD	us-gaap:Assets	5
1667	5	8	2025	Q1	\N	2025-03-31	156494000000.0000	USD	us-gaap:Assets	114
1668	5	8	2025	Q2	\N	2025-06-30	155120000000.0000	USD	us-gaap:Assets	115
1669	5	8	2025	Q3	\N	2025-09-30	150023000000.0000	USD	us-gaap:Assets	116
1670	5	8	2025	FY	\N	2025-12-31	168235000000.0000	USD	us-gaap:Assets	119
1671	5	8	2026	Q1	\N	2026-03-31	164787000000.0000	USD	us-gaap:Assets	117
1672	5	8	2026	Q2	\N	2026-06-30	165870000000.0000	USD	us-gaap:Assets	118
1673	5	8	2026	Q3	\N	2026-09-30	170739000000.0000	USD	us-gaap:Assets	119
1674	5	9	2019	FY	\N	2019-12-31	141925000000.0000	USD	us-gaap:Liabilities	97
1675	5	9	2020	Q1	\N	2020-03-31	152435000000.0000	USD	us-gaap:Liabilities	120
1676	5	9	2020	Q2	\N	2020-06-30	174254000000.0000	USD	us-gaap:Liabilities	121
1677	5	9	2020	Q3	\N	2020-09-30	172814000000.0000	USD	us-gaap:Liabilities	122
1678	5	9	2020	FY	\N	2020-12-31	170211000000.0000	USD	us-gaap:Liabilities	98
1679	5	9	2021	Q1	\N	2021-03-31	167876000000.0000	USD	us-gaap:Liabilities	99
1680	5	9	2021	Q2	\N	2021-06-30	165420000000.0000	USD	us-gaap:Liabilities	100
1681	5	9	2021	Q3	\N	2021-09-30	161112000000.0000	USD	us-gaap:Liabilities	101
1682	5	9	2021	FY	\N	2021-12-31	153398000000.0000	USD	us-gaap:Liabilities	102
1683	5	9	2022	Q1	\N	2022-03-31	151069000000.0000	USD	us-gaap:Liabilities	103
1684	5	9	2022	Q2	\N	2022-06-30	150270000000.0000	USD	us-gaap:Liabilities	104
1685	5	9	2022	Q3	\N	2022-09-30	155193000000.0000	USD	us-gaap:Liabilities	105
1686	5	9	2022	FY	\N	2022-12-31	152948000000.0000	USD	us-gaap:Liabilities	106
1687	5	9	2023	Q1	\N	2023-03-31	151831000000.0000	USD	us-gaap:Liabilities	107
1688	5	9	2023	Q2	\N	2023-06-30	150267000000.0000	USD	us-gaap:Liabilities	108
1689	5	9	2023	Q3	\N	2023-09-30	150998000000.0000	USD	us-gaap:Liabilities	109
1690	5	9	2023	FY	\N	2023-12-31	154240000000.0000	USD	us-gaap:Liabilities	110
1691	5	9	2024	Q1	\N	2024-03-31	151500000000.0000	USD	us-gaap:Liabilities	111
1692	5	9	2024	Q2	\N	2024-06-30	160702000000.0000	USD	us-gaap:Liabilities	112
1693	5	9	2024	Q3	\N	2024-09-30	161257000000.0000	USD	us-gaap:Liabilities	113
1694	5	9	2024	FY	\N	2024-12-31	160277000000.0000	USD	us-gaap:Liabilities	5
1695	5	9	2025	Q1	\N	2025-03-31	159819000000.0000	USD	us-gaap:Liabilities	114
1696	5	9	2025	Q2	\N	2025-06-30	158416000000.0000	USD	us-gaap:Liabilities	115
1697	5	9	2025	Q3	\N	2025-09-30	158276000000.0000	USD	us-gaap:Liabilities	116
1698	5	9	2025	FY	\N	2025-12-31	162778000000.0000	USD	us-gaap:Liabilities	119
1699	5	9	2026	Q1	\N	2026-03-31	158800000000.0000	USD	us-gaap:Liabilities	117
1700	5	9	2026	Q2	\N	2026-06-30	159755000000.0000	USD	us-gaap:Liabilities	118
1701	5	9	2026	Q3	\N	2026-09-30	164177000000.0000	USD	us-gaap:Liabilities	119
1702	5	10	2019	Q1	\N	2019-03-31	125000000.0000	USD	us-gaap:StockholdersEquity	123
1703	5	10	2019	Q2	\N	2019-06-30	-5322000000.0000	USD	us-gaap:StockholdersEquity	124
1704	5	10	2019	Q3	\N	2019-09-30	-4116000000.0000	USD	us-gaap:StockholdersEquity	125
1705	5	10	2019	FY	\N	2019-12-31	-8617000000.0000	USD	us-gaap:StockholdersEquity	97
1706	5	10	2020	Q1	\N	2020-03-31	-9665000000.0000	USD	us-gaap:StockholdersEquity	120
1707	5	10	2020	Q2	\N	2020-06-30	-11667000000.0000	USD	us-gaap:StockholdersEquity	121
1708	5	10	2020	Q3	\N	2020-09-30	-11821000000.0000	USD	us-gaap:StockholdersEquity	122
1709	5	10	2020	FY	\N	2020-12-31	-18316000000.0000	USD	us-gaap:StockholdersEquity	98
1710	5	10	2021	Q1	\N	2021-03-31	-18058000000.0000	USD	us-gaap:StockholdersEquity	99
1711	5	10	2021	Q2	\N	2021-06-30	-16682000000.0000	USD	us-gaap:StockholdersEquity	100
1712	5	10	2021	Q3	\N	2021-09-30	-14440000000.0000	USD	us-gaap:StockholdersEquity	101
1713	5	10	2021	FY	\N	2021-12-31	-14999000000.0000	USD	us-gaap:StockholdersEquity	102
1714	5	10	2022	Q1	\N	2022-03-31	-15398000000.0000	USD	us-gaap:StockholdersEquity	103
1715	5	10	2022	Q2	\N	2022-06-30	-14888000000.0000	USD	us-gaap:StockholdersEquity	104
1716	5	10	2022	Q3	\N	2022-09-30	-17699000000.0000	USD	us-gaap:StockholdersEquity	105
1717	5	10	2022	FY	\N	2022-12-31	-15883000000.0000	USD	us-gaap:StockholdersEquity	106
1718	5	10	2023	Q1	\N	2023-03-31	-15508000000.0000	USD	us-gaap:StockholdersEquity	107
1719	5	10	2023	Q2	\N	2023-06-30	-15517000000.0000	USD	us-gaap:StockholdersEquity	108
1720	5	10	2023	Q3	\N	2023-09-30	-16729000000.0000	USD	us-gaap:StockholdersEquity	109
1721	5	10	2023	FY	\N	2023-12-31	-17233000000.0000	USD	us-gaap:StockholdersEquity	110
1722	5	10	2024	Q1	\N	2024-03-31	-17009000000.0000	USD	us-gaap:StockholdersEquity	111
1723	5	10	2024	Q2	\N	2024-06-30	-17976000000.0000	USD	us-gaap:StockholdersEquity	112
1724	5	10	2024	Q3	\N	2024-09-30	-23552000000.0000	USD	us-gaap:StockholdersEquity	113
1725	5	10	2024	FY	\N	2024-12-31	-3908000000.0000	USD	us-gaap:StockholdersEquity	5
1726	5	10	2025	Q1	\N	2025-03-31	-3325000000.0000	USD	us-gaap:StockholdersEquity	114
1727	5	10	2025	Q2	\N	2025-06-30	-3295000000.0000	USD	us-gaap:StockholdersEquity	115
1728	5	10	2025	Q3	\N	2025-09-30	-8250000000.0000	USD	us-gaap:StockholdersEquity	116
1729	5	10	2025	FY	\N	2025-12-31	5454000000.0000	USD	us-gaap:StockholdersEquity	119
1730	5	10	2026	Q1	\N	2026-03-31	5987000000.0000	USD	us-gaap:StockholdersEquity	117
1731	5	10	2026	Q2	\N	2026-06-30	6100000000.0000	USD	us-gaap:StockholdersEquity	118
1732	5	10	2026	Q3	\N	2026-09-30	6547000000.0000	USD	us-gaap:StockholdersEquity	119
1733	5	11	2019	Q1	\N	2019-03-31	6836000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	120
1734	5	11	2019	Q2	\N	2019-06-30	9167000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	121
1735	5	11	2019	Q3	\N	2019-09-30	9763000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	122
1736	5	11	2019	FY	\N	2019-12-31	9485000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	98
1737	5	11	2020	Q1	\N	2020-03-31	15039000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	99
1738	5	11	2020	Q2	\N	2020-06-30	19992000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	100
1739	5	11	2020	Q3	\N	2020-09-30	10564000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	101
1740	5	11	2020	FY	\N	2020-12-31	7752000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	102
1741	5	11	2021	Q1	\N	2021-03-31	7059000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	103
1742	5	11	2021	Q2	\N	2021-06-30	8271000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	104
1743	5	11	2021	Q3	\N	2021-09-30	9764000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	105
1744	5	11	2021	FY	\N	2021-12-31	8052000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	106
1745	5	11	2022	Q1	\N	2022-03-31	7409000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	107
1746	5	11	2022	Q2	\N	2022-06-30	10090000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	108
1747	5	11	2022	Q3	\N	2022-09-30	13494000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	109
1748	5	11	2022	FY	\N	2022-12-31	14614000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	110
1749	5	11	2023	Q1	\N	2023-03-31	10812000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	111
1750	5	11	2023	Q2	\N	2023-06-30	7254000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	112
1751	5	11	2023	Q3	\N	2023-09-30	6811000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	113
1752	5	11	2023	FY	\N	2023-12-31	12691000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	5
1753	5	11	2024	Q1	\N	2024-03-31	6914000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	114
1754	5	11	2024	Q2	\N	2024-06-30	10894000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	115
1755	5	11	2024	Q3	\N	2024-09-30	9961000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	116
1756	5	11	2024	FY	\N	2024-12-31	13801000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	5
1757	5	11	2025	Q1	\N	2025-03-31	10142000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	117
1758	5	11	2025	Q2	\N	2025-06-30	7087000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	118
1759	5	11	2025	Q3	\N	2025-09-30	6173000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	119
1760	5	11	2025	FY	\N	2025-12-31	10921000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	119
1761	5	11	2026	Q1	\N	2026-03-31	9441000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	117
1762	5	11	2026	Q2	\N	2026-06-30	7239000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	118
1763	5	11	2026	Q3	\N	2026-09-30	9498000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	119
1764	5	12	2019	FY	\N	2019-12-31	20964000000.0000	USD	us-gaap:LongTermDebt	97
1765	5	12	2020	Q2	\N	2020-06-30	58788000000.0000	USD	us-gaap:LongTermDebt	121
1766	5	12	2020	Q3	\N	2020-09-30	58840000000.0000	USD	us-gaap:LongTermDebt	122
1767	5	12	2020	FY	\N	2020-12-31	63380000000.0000	USD	us-gaap:LongTermDebt	98
1768	5	12	2021	Q1	\N	2021-03-31	63384000000.0000	USD	us-gaap:LongTermDebt	99
1769	5	12	2021	Q2	\N	2021-06-30	63377000000.0000	USD	us-gaap:LongTermDebt	100
1770	5	12	2021	Q3	\N	2021-09-30	62238000000.0000	USD	us-gaap:LongTermDebt	101
1771	5	12	2021	FY	\N	2021-12-31	57921000000.0000	USD	us-gaap:LongTermDebt	102
1772	5	12	2022	Q1	\N	2022-03-31	57559000000.0000	USD	us-gaap:LongTermDebt	103
1773	5	12	2022	Q2	\N	2022-06-30	57009000000.0000	USD	us-gaap:LongTermDebt	104
1774	5	12	2022	Q3	\N	2022-09-30	57021000000.0000	USD	us-gaap:LongTermDebt	105
1775	5	12	2022	FY	\N	2022-12-31	56794000000.0000	USD	us-gaap:LongTermDebt	106
1776	5	12	2023	Q1	\N	2023-03-31	55175000000.0000	USD	us-gaap:LongTermDebt	107
1777	5	12	2023	Q2	\N	2023-06-30	52037000000.0000	USD	us-gaap:LongTermDebt	108
1778	5	12	2023	Q3	\N	2023-09-30	52031000000.0000	USD	us-gaap:LongTermDebt	109
1779	5	12	2023	FY	\N	2023-12-31	52055000000.0000	USD	us-gaap:LongTermDebt	110
1780	5	12	2024	Q1	\N	2024-03-31	47689000000.0000	USD	us-gaap:LongTermDebt	111
1781	5	12	2024	Q2	\N	2024-06-30	57669000000.0000	USD	us-gaap:LongTermDebt	112
1782	5	12	2024	Q3	\N	2024-09-30	57397000000.0000	USD	us-gaap:LongTermDebt	113
1783	5	12	2024	FY	\N	2024-12-31	53625000000.0000	USD	us-gaap:LongTermDebt	5
1784	5	12	2025	Q1	\N	2025-03-31	53394000000.0000	USD	us-gaap:LongTermDebt	114
1785	5	12	2025	Q2	\N	2025-06-30	53143000000.0000	USD	us-gaap:LongTermDebt	115
1786	5	12	2025	Q3	\N	2025-09-30	53177000000.0000	USD	us-gaap:LongTermDebt	116
1787	5	12	2025	FY	\N	2025-12-31	53848000000.0000	USD	us-gaap:LongTermDebt	119
1788	5	12	2026	Q1	\N	2026-03-31	46962000000.0000	USD	us-gaap:LongTermDebt	117
1789	5	12	2026	Q2	\N	2026-06-30	45596000000.0000	USD	us-gaap:LongTermDebt	118
1790	5	12	2026	Q3	\N	2026-09-30	45606000000.0000	USD	us-gaap:LongTermDebt	119
1791	5	14	2019	Q1	2019-01-01	2019-03-31	866000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	120
1792	5	14	2019	Q2	2019-04-01	2019-06-30	826000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	121
1793	5	14	2019	Q3	2019-07-01	2019-09-30	778000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	122
1794	5	14	2019	FY	2019-01-01	2019-12-31	3219000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	98
1795	5	14	2020	Q1	2020-01-01	2020-03-31	672000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	99
1796	5	14	2020	Q2	2020-04-01	2020-06-30	625000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	100
1797	5	14	2020	Q3	2020-07-01	2020-09-30	574000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	101
1798	5	14	2020	FY	2020-01-01	2020-12-31	2476000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	102
1799	5	14	2021	Q1	2021-01-01	2021-03-31	499000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	103
1800	5	14	2021	Q2	2021-04-01	2021-06-30	497000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	104
1801	5	14	2021	Q3	2021-07-01	2021-09-30	575000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	105
1802	5	14	2021	FY	2021-01-01	2021-12-31	2249000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	106
1803	5	14	2022	Q1	2022-01-01	2022-03-31	633000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	107
1804	5	14	2022	Q2	2022-04-01	2022-06-30	698000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	108
1805	5	14	2022	Q3	2022-07-01	2022-09-30	727000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	109
1806	5	14	2022	FY	2022-01-01	2022-12-31	2852000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	110
1807	5	14	2023	Q1	2023-01-01	2023-03-31	741000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	111
1808	5	14	2023	Q2	2023-04-01	2023-06-30	797000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	112
1809	5	14	2023	Q3	2023-07-01	2023-09-30	958000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	113
1810	5	14	2023	FY	2023-01-01	2023-12-31	3377000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	5
1811	5	14	2024	Q1	2024-01-01	2024-03-31	868000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	114
1812	5	14	2024	Q2	2024-04-01	2024-06-30	954000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	115
1813	5	14	2024	Q3	2024-07-01	2024-09-30	1154000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	116
1814	5	14	2024	FY	2024-01-01	2024-12-31	3812000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	5
1815	5	14	2025	Q1	2025-01-01	2025-03-31	844000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	117
1816	5	14	2025	Q2	2025-04-01	2025-06-30	910000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	118
1817	5	14	2025	Q3	2025-07-01	2025-09-30	897000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	119
1818	5	14	2025	FY	2025-01-01	2025-12-31	3615000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	5
1819	5	14	2026	Q1	2026-01-01	2026-03-31	903000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	117
1820	5	14	2026	Q2	2026-04-01	2026-06-30	921000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	118
1821	5	14	2026	Q3	2026-07-01	2026-09-30	830000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	119
1822	5	15	2019	Q1	2019-01-01	2019-03-31	47000000.0000	USD	us-gaap:ShareBasedCompensation	120
1823	5	15	2019	FY	2019-01-01	2019-12-31	212000000.0000	USD	us-gaap:ShareBasedCompensation	98
1824	5	15	2020	Q1	2020-01-01	2020-03-31	55000000.0000	USD	us-gaap:ShareBasedCompensation	99
1825	5	15	2020	FY	2020-01-01	2020-12-31	250000000.0000	USD	us-gaap:ShareBasedCompensation	102
1826	5	15	2021	Q1	2021-01-01	2021-03-31	321000000.0000	USD	us-gaap:ShareBasedCompensation	103
1827	5	15	2021	FY	2021-01-01	2021-12-31	833000000.0000	USD	us-gaap:ShareBasedCompensation	106
1828	5	15	2022	Q1	2022-01-01	2022-03-31	203000000.0000	USD	us-gaap:ShareBasedCompensation	107
1829	5	15	2022	FY	2022-01-01	2022-12-31	725000000.0000	USD	us-gaap:ShareBasedCompensation	110
1830	5	15	2023	Q1	2023-01-01	2023-03-31	222000000.0000	USD	us-gaap:ShareBasedCompensation	111
1831	5	15	2023	FY	2023-01-01	2023-12-31	690000000.0000	USD	us-gaap:ShareBasedCompensation	5
1832	5	15	2024	Q1	2024-01-01	2024-03-31	119000000.0000	USD	us-gaap:ShareBasedCompensation	114
1833	5	15	2024	FY	2024-01-01	2024-12-31	407000000.0000	USD	us-gaap:ShareBasedCompensation	5
1834	5	15	2025	Q1	2025-01-01	2025-03-31	135000000.0000	USD	us-gaap:ShareBasedCompensation	117
1835	5	15	2025	FY	2025-01-01	2025-12-31	426000000.0000	USD	us-gaap:ShareBasedCompensation	5
1836	5	15	2026	Q1	2026-01-01	2026-03-31	161000000.0000	USD	us-gaap:ShareBasedCompensation	117
1837	5	16	2019	Q1	2019-01-01	2019-03-31	521000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	120
1838	5	16	2019	FY	2019-01-01	2019-12-31	2271000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	98
1839	5	16	2020	Q1	2020-01-01	2020-03-31	556000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	99
1840	5	16	2020	FY	2020-01-01	2020-12-31	2246000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	102
1841	5	16	2021	Q1	2021-01-01	2021-03-31	536000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	103
1842	5	16	2021	FY	2021-01-01	2021-12-31	2144000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	106
1843	5	16	2022	Q1	2022-01-01	2022-03-31	486000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	107
1844	5	16	2022	FY	2022-01-01	2022-12-31	1979000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	110
1845	5	16	2023	Q1	2023-01-01	2023-03-31	457000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	111
1846	5	16	2023	FY	2023-01-01	2023-12-31	1861000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	5
1847	5	16	2024	Q1	2024-01-01	2024-03-31	442000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	114
1848	5	16	2024	Q2	2024-04-01	2024-06-30	441000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	115
1849	5	16	2024	Q3	2024-07-01	2024-09-30	444000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	116
1850	5	16	2024	FY	2024-01-01	2024-12-31	1836000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	5
1851	5	16	2025	Q1	2025-01-01	2025-03-31	466000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	117
1852	5	16	2025	Q2	2025-04-01	2025-06-30	460000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	118
1853	5	16	2025	Q3	2025-07-01	2025-09-30	491000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	119
1854	5	16	2025	FY	2025-01-01	2025-12-31	1953000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	5
1855	5	16	2026	Q1	2026-01-01	2026-03-31	573000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	117
1856	5	16	2026	Q2	2026-04-01	2026-06-30	596000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	118
1857	5	16	2026	Q3	2026-07-01	2026-09-30	584000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	119
1858	5	17	2019	Q1	2019-01-01	2019-03-31	184000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	120
1859	5	17	2019	Q2	2019-04-01	2019-06-30	-485000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	121
1860	5	17	2019	Q3	2019-07-01	2019-09-30	10000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	122
1861	5	17	2019	FY	2019-01-01	2019-12-31	-1623000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	98
1862	5	17	2020	Q1	2020-01-01	2020-03-31	-862000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	99
1863	5	17	2020	Q2	2020-04-01	2020-06-30	-1028000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	100
1864	5	17	2020	Q3	2020-07-01	2020-09-30	-459000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	101
1865	5	17	2020	FY	2020-01-01	2020-12-31	-2535000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	102
1866	5	17	2021	Q1	2021-01-01	2021-03-31	-11000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	103
1867	5	17	2021	Q2	2021-04-01	2021-06-30	-18000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	104
1868	5	17	2021	Q3	2021-07-01	2021-09-30	-178000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	105
1869	5	17	2021	FY	2021-01-01	2021-12-31	-743000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	106
1870	5	17	2022	Q1	2022-01-01	2022-03-31	-376000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	107
1871	5	17	2022	Q2	2022-04-01	2022-06-30	217000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	108
1872	5	17	2022	Q3	2022-07-01	2022-09-30	176000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	109
1873	5	17	2022	FY	2022-01-01	2022-12-31	31000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	110
1874	5	17	2023	Q1	2023-01-01	2023-03-31	-71000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	111
1875	5	17	2023	Q2	2023-04-01	2023-06-30	-251000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	112
1876	5	17	2023	Q3	2023-07-01	2023-09-30	538000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	113
1877	5	17	2023	FY	2023-01-01	2023-12-31	237000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	5
1878	5	17	2024	Q1	2024-01-01	2024-03-31	-23000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	114
1879	5	17	2024	Q2	2024-04-01	2024-06-30	-76000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	115
1880	5	17	2024	Q3	2024-07-01	2024-09-30	-50000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	116
1881	5	17	2024	FY	2024-01-01	2024-12-31	-381000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	5
1882	5	17	2025	Q1	2025-01-01	2025-03-31	107000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	117
1883	5	17	2025	Q2	2025-04-01	2025-06-30	51000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	118
1884	5	17	2025	Q3	2025-07-01	2025-09-30	140000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	119
1885	5	17	2025	FY	2025-01-01	2025-12-31	397000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	5
1886	5	17	2026	Q1	2026-01-01	2026-03-31	33000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	117
1887	5	17	2026	Q2	2026-04-01	2026-06-30	63000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	118
1888	5	17	2026	Q3	2026-07-01	2026-09-30	-7000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	119
1889	5	18	2019	Q1	2019-01-01	2019-03-31	3.7500	USD/shares	us-gaap:EarningsPerShareDiluted	97
1890	5	18	2019	Q2	2019-04-01	2019-06-30	-5.2100	USD/shares	us-gaap:EarningsPerShareDiluted	97
1891	5	18	2019	Q3	2019-07-01	2019-09-30	2.0500	USD/shares	us-gaap:EarningsPerShareDiluted	97
1892	5	18	2019	FY	2019-01-01	2019-12-31	-1.1200	USD/shares	us-gaap:EarningsPerShareDiluted	98
1893	5	18	2019	Q4	2019-10-01	2019-12-31	-1.7900	USD/shares	us-gaap:EarningsPerShareDiluted	97
1894	5	18	2020	Q1	2020-01-01	2020-03-31	-1.1100	USD/shares	us-gaap:EarningsPerShareDiluted	99
1895	5	18	2020	Q2	2020-04-01	2020-06-30	-4.2000	USD/shares	us-gaap:EarningsPerShareDiluted	100
1896	5	18	2020	Q3	2020-07-01	2020-09-30	-0.7900	USD/shares	us-gaap:EarningsPerShareDiluted	101
1897	5	18	2020	FY	2020-01-01	2020-12-31	-20.8800	USD/shares	us-gaap:EarningsPerShareDiluted	102
1898	5	18	2020	Q4	2020-10-01	2020-12-31	-14.6500	USD/shares	us-gaap:EarningsPerShareDiluted	97
1899	5	18	2021	Q1	2021-01-01	2021-03-31	-0.9200	USD/shares	us-gaap:EarningsPerShareDiluted	103
1900	5	18	2021	Q2	2021-04-01	2021-06-30	1.0000	USD/shares	us-gaap:EarningsPerShareDiluted	104
1901	5	18	2021	Q3	2021-07-01	2021-09-30	-0.1900	USD/shares	us-gaap:EarningsPerShareDiluted	105
1902	5	18	2021	FY	2021-01-01	2021-12-31	-7.1500	USD/shares	us-gaap:EarningsPerShareDiluted	106
1903	5	18	2022	Q1	2022-01-01	2022-03-31	-2.0600	USD/shares	us-gaap:EarningsPerShareDiluted	107
1904	5	18	2022	Q2	2022-04-01	2022-06-30	0.3200	USD/shares	us-gaap:EarningsPerShareDiluted	108
1905	5	18	2022	Q3	2022-07-01	2022-09-30	-5.4900	USD/shares	us-gaap:EarningsPerShareDiluted	109
1906	5	18	2022	FY	2022-01-01	2022-12-31	-8.3000	USD/shares	us-gaap:EarningsPerShareDiluted	110
1907	5	18	2023	Q1	2023-01-01	2023-03-31	-0.6900	USD/shares	us-gaap:EarningsPerShareDiluted	111
1908	5	18	2023	Q2	2023-04-01	2023-06-30	-0.2500	USD/shares	us-gaap:EarningsPerShareDiluted	112
1909	5	18	2023	Q3	2023-07-01	2023-09-30	-2.7000	USD/shares	us-gaap:EarningsPerShareDiluted	113
1910	5	18	2023	FY	2023-01-01	2023-12-31	-3.6700	USD/shares	us-gaap:EarningsPerShareDiluted	5
1911	5	18	2024	Q1	2024-01-01	2024-03-31	-0.5600	USD/shares	us-gaap:EarningsPerShareDiluted	114
1912	5	18	2024	Q2	2024-04-01	2024-06-30	-2.3300	USD/shares	us-gaap:EarningsPerShareDiluted	115
1913	5	18	2024	Q3	2024-07-01	2024-09-30	-9.9700	USD/shares	us-gaap:EarningsPerShareDiluted	116
1914	5	18	2024	FY	2024-01-01	2024-12-31	-18.3600	USD/shares	us-gaap:EarningsPerShareDiluted	5
1915	5	18	2025	Q1	2025-01-01	2025-03-31	-0.1600	USD/shares	us-gaap:EarningsPerShareDiluted	117
1916	5	18	2025	Q2	2025-04-01	2025-06-30	-0.9200	USD/shares	us-gaap:EarningsPerShareDiluted	118
1917	5	18	2025	Q3	2025-07-01	2025-09-30	-7.1400	USD/shares	us-gaap:EarningsPerShareDiluted	119
1918	5	18	2025	FY	2025-01-01	2025-12-31	2.4800	USD/shares	us-gaap:EarningsPerShareDiluted	5
1919	5	18	2026	Q1	2026-01-01	2026-03-31	-0.1100	USD/shares	us-gaap:EarningsPerShareDiluted	117
1920	5	18	2026	Q2	2026-04-01	2026-06-30	-0.6700	USD/shares	us-gaap:EarningsPerShareDiluted	118
1921	5	18	2026	Q3	2026-07-01	2026-09-30	-0.2600	USD/shares	us-gaap:EarningsPerShareDiluted	119
1922	5	19	2019	Q1	2019-01-01	2019-03-31	1161000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	120
1923	5	19	2019	FY	2019-01-01	2019-12-31	4630000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	98
1924	5	19	2020	Q1	2020-01-01	2020-03-31	1158000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	99
1925	5	19	2020	FY	2020-01-01	2020-12-31	1158000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	102
1926	5	19	2025	Q1	2025-01-01	2025-03-31	72000000.0000	USD	us-gaap:PaymentsOfDividends	117
1927	5	19	2025	Q2	2025-04-01	2025-06-30	86000000.0000	USD	us-gaap:PaymentsOfDividends	118
1928	5	19	2025	Q3	2025-07-01	2025-09-30	86000000.0000	USD	us-gaap:PaymentsOfDividends	119
1929	5	19	2025	FY	2025-01-01	2025-12-31	331000000.0000	USD	us-gaap:PaymentsOfDividends	5
1930	5	19	2026	Q1	2026-01-01	2026-03-31	86000000.0000	USD	us-gaap:PaymentsOfDividends	117
1931	5	19	2026	Q2	2026-04-01	2026-06-30	86000000.0000	USD	us-gaap:PaymentsOfDividends	118
1932	5	19	2026	Q3	2026-07-01	2026-09-30	86000000.0000	USD	us-gaap:PaymentsOfDividends	119
1933	5	20	2019	Q1	2019-01-01	2019-03-31	2341000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	120
1934	5	20	2019	FY	2019-01-01	2019-12-31	2651000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	98
1935	5	21	2019	Q2	2019-04-01	2019-06-30	4.1100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	121
1936	5	21	2019	FY	2019-01-01	2019-12-31	8.2200	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	98
1937	6	1	2019	Q1	2019-01-28	2019-04-28	2220000000.0000	USD	us-gaap:Revenues	126
1938	6	1	2019	Q2	2019-04-29	2019-07-28	2579000000.0000	USD	us-gaap:Revenues	127
1939	6	1	2019	Q3	2019-07-29	2019-10-27	3014000000.0000	USD	us-gaap:Revenues	128
1940	6	1	2019	FY	2019-01-28	2020-01-26	10918000000.0000	USD	us-gaap:Revenues	129
1941	6	1	2020	Q1	2020-01-27	2020-04-26	3080000000.0000	USD	us-gaap:Revenues	130
1942	6	1	2020	Q2	2020-04-27	2020-07-26	3866000000.0000	USD	us-gaap:Revenues	131
1943	6	1	2020	Q3	2020-07-27	2020-10-25	4726000000.0000	USD	us-gaap:Revenues	132
1944	6	1	2020	FY	2020-01-27	2021-01-31	16675000000.0000	USD	us-gaap:Revenues	133
1945	6	1	2021	Q1	2021-02-01	2021-05-02	5661000000.0000	USD	us-gaap:Revenues	134
1946	6	1	2021	Q2	2021-05-03	2021-08-01	6507000000.0000	USD	us-gaap:Revenues	135
1947	6	1	2021	Q3	2021-08-02	2021-10-31	7103000000.0000	USD	us-gaap:Revenues	136
1948	6	1	2021	FY	2021-02-01	2022-01-30	26914000000.0000	USD	us-gaap:Revenues	137
1949	6	1	2022	Q1	2022-01-31	2022-05-01	8288000000.0000	USD	us-gaap:Revenues	138
1950	6	1	2022	Q2	2022-05-02	2022-07-31	6704000000.0000	USD	us-gaap:Revenues	139
1951	6	1	2022	Q3	2022-08-01	2022-10-30	5931000000.0000	USD	us-gaap:Revenues	140
1952	6	1	2022	FY	2022-01-31	2023-01-29	26974000000.0000	USD	us-gaap:Revenues	141
1953	6	1	2023	Q1	2023-01-30	2023-04-30	7192000000.0000	USD	us-gaap:Revenues	142
1954	6	1	2023	Q2	2023-05-01	2023-07-30	13507000000.0000	USD	us-gaap:Revenues	143
1955	6	1	2023	Q3	2023-07-31	2023-10-29	18120000000.0000	USD	us-gaap:Revenues	144
1956	6	1	2023	FY	2023-01-30	2024-01-28	60922000000.0000	USD	us-gaap:Revenues	6
1957	6	1	2024	Q1	2024-01-29	2024-04-28	26044000000.0000	USD	us-gaap:Revenues	145
1958	6	1	2024	Q2	2024-04-29	2024-07-28	30040000000.0000	USD	us-gaap:Revenues	146
1959	6	1	2024	Q3	2024-07-29	2024-10-27	35082000000.0000	USD	us-gaap:Revenues	147
1960	6	1	2024	FY	2024-01-29	2025-01-26	130497000000.0000	USD	us-gaap:Revenues	6
1961	6	1	2025	Q1	2025-01-27	2025-04-27	44062000000.0000	USD	us-gaap:Revenues	148
1962	6	1	2025	Q2	2025-04-28	2025-07-27	46743000000.0000	USD	us-gaap:Revenues	149
1963	6	1	2025	Q3	2025-07-28	2025-10-26	57006000000.0000	USD	us-gaap:Revenues	147
1964	6	1	2025	FY	2025-01-27	2026-01-25	215938000000.0000	USD	us-gaap:Revenues	6
1965	6	1	2026	Q1	2026-01-26	2026-04-26	81615000000.0000	USD	us-gaap:Revenues	148
1966	6	1	2026	Q2	2026-04-27	2026-07-26	96221000000.0000	USD	us-gaap:Revenues	149
1967	6	1	2019	Q4	2019-10-28	2020-01-26	3105000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	150
1968	6	2	2019	Q1	2019-01-28	2019-04-28	924000000.0000	USD	us-gaap:CostOfRevenue	126
1969	6	2	2019	Q2	2019-04-29	2019-07-28	1038000000.0000	USD	us-gaap:CostOfRevenue	127
1970	6	2	2019	Q3	2019-07-29	2019-10-27	1098000000.0000	USD	us-gaap:CostOfRevenue	128
1971	6	2	2019	FY	2019-01-28	2020-01-26	4150000000.0000	USD	us-gaap:CostOfRevenue	129
1972	6	2	2020	Q1	2020-01-27	2020-04-26	1076000000.0000	USD	us-gaap:CostOfRevenue	130
1973	6	2	2020	Q2	2020-04-27	2020-07-26	1591000000.0000	USD	us-gaap:CostOfRevenue	131
1974	6	2	2020	Q3	2020-07-27	2020-10-25	1766000000.0000	USD	us-gaap:CostOfRevenue	132
1975	6	2	2020	FY	2020-01-27	2021-01-31	6279000000.0000	USD	us-gaap:CostOfRevenue	133
1976	6	2	2021	Q1	2021-02-01	2021-05-02	2032000000.0000	USD	us-gaap:CostOfRevenue	134
1977	6	2	2021	Q2	2021-05-03	2021-08-01	2292000000.0000	USD	us-gaap:CostOfRevenue	135
1978	6	2	2021	Q3	2021-08-02	2021-10-31	2472000000.0000	USD	us-gaap:CostOfRevenue	136
1979	6	2	2021	FY	2021-02-01	2022-01-30	9439000000.0000	USD	us-gaap:CostOfRevenue	137
1980	6	2	2022	Q1	2022-01-31	2022-05-01	2857000000.0000	USD	us-gaap:CostOfRevenue	138
1981	6	2	2022	Q2	2022-05-02	2022-07-31	3789000000.0000	USD	us-gaap:CostOfRevenue	139
1982	6	2	2022	Q3	2022-08-01	2022-10-30	2754000000.0000	USD	us-gaap:CostOfRevenue	140
1983	6	2	2022	FY	2022-01-31	2023-01-29	11618000000.0000	USD	us-gaap:CostOfRevenue	141
1984	6	2	2023	Q1	2023-01-30	2023-04-30	2544000000.0000	USD	us-gaap:CostOfRevenue	142
1985	6	2	2023	Q2	2023-05-01	2023-07-30	4045000000.0000	USD	us-gaap:CostOfRevenue	143
1986	6	2	2023	Q3	2023-07-31	2023-10-29	4720000000.0000	USD	us-gaap:CostOfRevenue	144
1987	6	2	2023	FY	2023-01-30	2024-01-28	16621000000.0000	USD	us-gaap:CostOfRevenue	6
1988	6	2	2024	Q1	2024-01-29	2024-04-28	5638000000.0000	USD	us-gaap:CostOfRevenue	145
1989	6	2	2024	Q2	2024-04-29	2024-07-28	7466000000.0000	USD	us-gaap:CostOfRevenue	146
1990	6	2	2024	Q3	2024-07-29	2024-10-27	8926000000.0000	USD	us-gaap:CostOfRevenue	147
1991	6	2	2024	FY	2024-01-29	2025-01-26	32639000000.0000	USD	us-gaap:CostOfRevenue	6
1992	6	2	2025	Q1	2025-01-27	2025-04-27	17394000000.0000	USD	us-gaap:CostOfRevenue	148
1993	6	2	2025	Q2	2025-04-28	2025-07-27	12890000000.0000	USD	us-gaap:CostOfRevenue	149
1994	6	2	2025	Q3	2025-07-28	2025-10-26	15157000000.0000	USD	us-gaap:CostOfRevenue	147
1995	6	2	2025	FY	2025-01-27	2026-01-25	62475000000.0000	USD	us-gaap:CostOfRevenue	6
1996	6	2	2026	Q1	2026-01-26	2026-04-26	20458000000.0000	USD	us-gaap:CostOfRevenue	148
1997	6	2	2026	Q2	2026-04-27	2026-07-26	24079000000.0000	USD	us-gaap:CostOfRevenue	149
1998	6	2	2019	Q4	2019-10-28	2020-01-26	1090000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	150
1999	6	3	2019	Q1	2019-01-28	2019-04-28	1296000000.0000	USD	us-gaap:GrossProfit	126
2000	6	3	2019	Q2	2019-04-29	2019-07-28	1541000000.0000	USD	us-gaap:GrossProfit	127
2001	6	3	2019	Q3	2019-07-29	2019-10-27	1916000000.0000	USD	us-gaap:GrossProfit	128
2002	6	3	2019	FY	2019-01-28	2020-01-26	6768000000.0000	USD	us-gaap:GrossProfit	129
2003	6	3	2019	Q4	2019-10-28	2020-01-26	2015000000.0000	USD	us-gaap:GrossProfit	150
2004	6	3	2020	Q1	2020-01-27	2020-04-26	2004000000.0000	USD	us-gaap:GrossProfit	130
2005	6	3	2020	Q2	2020-04-27	2020-07-26	2275000000.0000	USD	us-gaap:GrossProfit	131
2006	6	3	2020	Q3	2020-07-27	2020-10-25	2960000000.0000	USD	us-gaap:GrossProfit	132
2007	6	3	2020	FY	2020-01-27	2021-01-31	10396000000.0000	USD	us-gaap:GrossProfit	133
2008	6	3	2021	Q1	2021-02-01	2021-05-02	3629000000.0000	USD	us-gaap:GrossProfit	134
2009	6	3	2021	Q2	2021-05-03	2021-08-01	4215000000.0000	USD	us-gaap:GrossProfit	135
2010	6	3	2021	Q3	2021-08-02	2021-10-31	4631000000.0000	USD	us-gaap:GrossProfit	136
2011	6	3	2021	FY	2021-02-01	2022-01-30	17475000000.0000	USD	us-gaap:GrossProfit	137
2012	6	3	2022	Q1	2022-01-31	2022-05-01	5431000000.0000	USD	us-gaap:GrossProfit	138
2013	6	3	2022	Q2	2022-05-02	2022-07-31	2915000000.0000	USD	us-gaap:GrossProfit	139
2014	6	3	2022	Q3	2022-08-01	2022-10-30	3177000000.0000	USD	us-gaap:GrossProfit	140
2015	6	3	2022	FY	2022-01-31	2023-01-29	15356000000.0000	USD	us-gaap:GrossProfit	141
2016	6	3	2023	Q1	2023-01-30	2023-04-30	4648000000.0000	USD	us-gaap:GrossProfit	142
2017	6	3	2023	Q2	2023-05-01	2023-07-30	9462000000.0000	USD	us-gaap:GrossProfit	143
2018	6	3	2023	Q3	2023-07-31	2023-10-29	13400000000.0000	USD	us-gaap:GrossProfit	144
2019	6	3	2023	FY	2023-01-30	2024-01-28	44301000000.0000	USD	us-gaap:GrossProfit	6
2020	6	3	2024	Q1	2024-01-29	2024-04-28	20406000000.0000	USD	us-gaap:GrossProfit	145
2021	6	3	2024	Q2	2024-04-29	2024-07-28	22574000000.0000	USD	us-gaap:GrossProfit	146
2022	6	3	2024	Q3	2024-07-29	2024-10-27	26156000000.0000	USD	us-gaap:GrossProfit	147
2023	6	3	2024	FY	2024-01-29	2025-01-26	97858000000.0000	USD	us-gaap:GrossProfit	6
2024	6	3	2025	Q1	2025-01-27	2025-04-27	26668000000.0000	USD	us-gaap:GrossProfit	148
2025	6	3	2025	Q2	2025-04-28	2025-07-27	33853000000.0000	USD	us-gaap:GrossProfit	149
2026	6	3	2025	Q3	2025-07-28	2025-10-26	41849000000.0000	USD	us-gaap:GrossProfit	147
2027	6	3	2025	FY	2025-01-27	2026-01-25	153463000000.0000	USD	us-gaap:GrossProfit	6
2028	6	3	2026	Q1	2026-01-26	2026-04-26	61157000000.0000	USD	us-gaap:GrossProfit	148
2029	6	3	2026	Q2	2026-04-27	2026-07-26	72142000000.0000	USD	us-gaap:GrossProfit	149
2030	6	4	2019	Q1	2019-01-28	2019-04-28	358000000.0000	USD	us-gaap:OperatingIncomeLoss	126
2031	6	4	2019	Q2	2019-04-29	2019-07-28	571000000.0000	USD	us-gaap:OperatingIncomeLoss	127
2032	6	4	2019	Q3	2019-07-29	2019-10-27	927000000.0000	USD	us-gaap:OperatingIncomeLoss	128
2033	6	4	2019	FY	2019-01-28	2020-01-26	2846000000.0000	USD	us-gaap:OperatingIncomeLoss	129
2034	6	4	2020	Q1	2020-01-27	2020-04-26	976000000.0000	USD	us-gaap:OperatingIncomeLoss	130
2035	6	4	2020	Q2	2020-04-27	2020-07-26	651000000.0000	USD	us-gaap:OperatingIncomeLoss	131
2036	6	4	2020	Q3	2020-07-27	2020-10-25	1398000000.0000	USD	us-gaap:OperatingIncomeLoss	132
2037	6	4	2020	FY	2020-01-27	2021-01-31	4532000000.0000	USD	us-gaap:OperatingIncomeLoss	133
2038	6	4	2021	Q1	2021-02-01	2021-05-02	1956000000.0000	USD	us-gaap:OperatingIncomeLoss	134
2039	6	4	2021	Q2	2021-05-03	2021-08-01	2444000000.0000	USD	us-gaap:OperatingIncomeLoss	135
2040	6	4	2021	Q3	2021-08-02	2021-10-31	2671000000.0000	USD	us-gaap:OperatingIncomeLoss	136
2041	6	4	2021	FY	2021-02-01	2022-01-30	10041000000.0000	USD	us-gaap:OperatingIncomeLoss	137
2042	6	4	2022	Q1	2022-01-31	2022-05-01	1868000000.0000	USD	us-gaap:OperatingIncomeLoss	138
2043	6	4	2022	Q2	2022-05-02	2022-07-31	499000000.0000	USD	us-gaap:OperatingIncomeLoss	139
2044	6	4	2022	Q3	2022-08-01	2022-10-30	601000000.0000	USD	us-gaap:OperatingIncomeLoss	140
2045	6	4	2022	FY	2022-01-31	2023-01-29	4224000000.0000	USD	us-gaap:OperatingIncomeLoss	141
2046	6	4	2023	Q1	2023-01-30	2023-04-30	2140000000.0000	USD	us-gaap:OperatingIncomeLoss	142
2047	6	4	2023	Q2	2023-05-01	2023-07-30	6800000000.0000	USD	us-gaap:OperatingIncomeLoss	143
2048	6	4	2023	Q3	2023-07-31	2023-10-29	10417000000.0000	USD	us-gaap:OperatingIncomeLoss	144
2049	6	4	2023	FY	2023-01-30	2024-01-28	32972000000.0000	USD	us-gaap:OperatingIncomeLoss	6
2050	6	4	2024	Q1	2024-01-29	2024-04-28	16909000000.0000	USD	us-gaap:OperatingIncomeLoss	145
2051	6	4	2024	Q2	2024-04-29	2024-07-28	18642000000.0000	USD	us-gaap:OperatingIncomeLoss	146
2052	6	4	2024	Q3	2024-07-29	2024-10-27	21869000000.0000	USD	us-gaap:OperatingIncomeLoss	147
2053	6	4	2024	FY	2024-01-29	2025-01-26	81453000000.0000	USD	us-gaap:OperatingIncomeLoss	6
2054	6	4	2025	Q1	2025-01-27	2025-04-27	21638000000.0000	USD	us-gaap:OperatingIncomeLoss	148
2055	6	4	2025	Q2	2025-04-28	2025-07-27	28440000000.0000	USD	us-gaap:OperatingIncomeLoss	149
2056	6	4	2025	Q3	2025-07-28	2025-10-26	36010000000.0000	USD	us-gaap:OperatingIncomeLoss	147
2057	6	4	2025	FY	2025-01-27	2026-01-25	130387000000.0000	USD	us-gaap:OperatingIncomeLoss	6
2058	6	4	2026	Q1	2026-01-26	2026-04-26	53536000000.0000	USD	us-gaap:OperatingIncomeLoss	148
2059	6	4	2026	Q2	2026-04-27	2026-07-26	63734000000.0000	USD	us-gaap:OperatingIncomeLoss	149
2060	6	5	2019	Q1	2019-01-28	2019-04-28	394000000.0000	USD	us-gaap:NetIncomeLoss	126
2061	6	5	2019	Q2	2019-04-29	2019-07-28	552000000.0000	USD	us-gaap:NetIncomeLoss	127
2062	6	5	2019	Q3	2019-07-29	2019-10-27	899000000.0000	USD	us-gaap:NetIncomeLoss	128
2063	6	5	2019	FY	2019-01-28	2020-01-26	2796000000.0000	USD	us-gaap:NetIncomeLoss	129
2064	6	5	2019	Q4	2019-10-28	2020-01-26	950000000.0000	USD	us-gaap:NetIncomeLoss	150
2065	6	5	2020	Q1	2020-01-27	2020-04-26	917000000.0000	USD	us-gaap:NetIncomeLoss	130
2066	6	5	2020	Q2	2020-04-27	2020-07-26	622000000.0000	USD	us-gaap:NetIncomeLoss	131
2067	6	5	2020	Q3	2020-07-27	2020-10-25	1336000000.0000	USD	us-gaap:NetIncomeLoss	132
2068	6	5	2020	FY	2020-01-27	2021-01-31	4332000000.0000	USD	us-gaap:NetIncomeLoss	133
2069	6	5	2021	Q1	2021-02-01	2021-05-02	1912000000.0000	USD	us-gaap:NetIncomeLoss	134
2070	6	5	2021	Q2	2021-05-03	2021-08-01	2374000000.0000	USD	us-gaap:NetIncomeLoss	135
2071	6	5	2021	Q3	2021-08-02	2021-10-31	2464000000.0000	USD	us-gaap:NetIncomeLoss	136
2072	6	5	2021	FY	2021-02-01	2022-01-30	9752000000.0000	USD	us-gaap:NetIncomeLoss	151
2073	6	5	2022	Q1	2022-01-31	2022-05-01	1618000000.0000	USD	us-gaap:NetIncomeLoss	138
2074	6	5	2022	Q2	2022-05-02	2022-07-31	656000000.0000	USD	us-gaap:NetIncomeLoss	139
2075	6	5	2022	Q3	2022-08-01	2022-10-30	680000000.0000	USD	us-gaap:NetIncomeLoss	140
2076	6	5	2022	FY	2022-01-31	2023-01-29	4368000000.0000	USD	us-gaap:NetIncomeLoss	151
2077	6	5	2023	Q1	2023-01-30	2023-04-30	2043000000.0000	USD	us-gaap:NetIncomeLoss	142
2078	6	5	2023	Q2	2023-05-01	2023-07-30	6188000000.0000	USD	us-gaap:NetIncomeLoss	143
2079	6	5	2023	Q3	2023-07-31	2023-10-29	9243000000.0000	USD	us-gaap:NetIncomeLoss	144
2080	6	5	2023	FY	2023-01-30	2024-01-28	29760000000.0000	USD	us-gaap:NetIncomeLoss	151
2081	6	5	2024	Q1	2024-01-29	2024-04-28	14881000000.0000	USD	us-gaap:NetIncomeLoss	145
2082	6	5	2024	Q2	2024-04-29	2024-07-28	16599000000.0000	USD	us-gaap:NetIncomeLoss	146
2083	6	5	2024	Q3	2024-07-29	2024-10-27	19309000000.0000	USD	us-gaap:NetIncomeLoss	147
2084	6	5	2024	FY	2024-01-29	2025-01-26	72880000000.0000	USD	us-gaap:NetIncomeLoss	151
2085	6	5	2025	Q1	2025-01-27	2025-04-27	18775000000.0000	USD	us-gaap:NetIncomeLoss	148
2086	6	5	2025	Q2	2025-04-28	2025-07-27	26422000000.0000	USD	us-gaap:NetIncomeLoss	149
2087	6	5	2025	Q3	2025-07-28	2025-10-26	31910000000.0000	USD	us-gaap:NetIncomeLoss	147
2088	6	5	2025	FY	2025-01-27	2026-01-25	120067000000.0000	USD	us-gaap:NetIncomeLoss	151
2089	6	5	2026	Q1	2026-01-26	2026-04-26	58321000000.0000	USD	us-gaap:NetIncomeLoss	148
2090	6	5	2026	Q2	2026-04-27	2026-07-26	59688000000.0000	USD	us-gaap:NetIncomeLoss	149
2091	6	6	2019	Q1	2019-01-28	2019-04-28	720000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	126
2092	6	6	2019	FY	2019-01-28	2020-01-26	4761000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	129
2093	6	6	2020	Q1	2020-01-27	2020-04-26	909000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	130
2094	6	6	2020	FY	2020-01-27	2021-01-31	5822000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	133
2095	6	6	2021	Q1	2021-02-01	2021-05-02	1874000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	134
2096	6	6	2021	FY	2021-02-01	2022-01-30	9108000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	137
2097	6	6	2022	Q1	2022-01-31	2022-05-01	1731000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	138
2098	6	6	2022	FY	2022-01-31	2023-01-29	5641000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	141
2099	6	6	2023	Q1	2023-01-30	2023-04-30	2911000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	142
2100	6	6	2023	FY	2023-01-30	2024-01-28	28090000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	6
2101	6	6	2024	Q1	2024-01-29	2024-04-28	15345000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	145
2102	6	6	2024	FY	2024-01-29	2025-01-26	64089000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	6
2103	6	6	2025	Q1	2025-01-27	2025-04-27	27414000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	148
2104	6	6	2025	FY	2025-01-27	2026-01-25	102718000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	6
2105	6	6	2026	Q1	2026-01-26	2026-04-26	50344000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	148
2106	6	7	2019	Q1	2019-01-28	2019-04-28	128000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	126
2107	6	7	2020	Q1	2020-01-27	2020-04-26	155000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	126
2108	6	8	2019	Q1	\N	2019-04-28	14021000000.0000	USD	us-gaap:Assets	152
2109	6	8	2019	Q2	\N	2019-07-28	14775000000.0000	USD	us-gaap:Assets	153
2110	6	8	2019	Q3	\N	2019-10-27	15810000000.0000	USD	us-gaap:Assets	154
2111	6	8	2019	FY	\N	2020-01-26	17315000000.0000	USD	us-gaap:Assets	155
2112	6	8	2020	Q1	\N	2020-04-26	23254000000.0000	USD	us-gaap:Assets	126
2113	6	8	2020	Q2	\N	2020-07-26	25180000000.0000	USD	us-gaap:Assets	127
2114	6	8	2020	Q3	\N	2020-10-25	26881000000.0000	USD	us-gaap:Assets	128
2115	6	8	2020	FY	\N	2021-01-31	28791000000.0000	USD	us-gaap:Assets	129
2116	6	8	2021	Q1	\N	2021-05-02	30796000000.0000	USD	us-gaap:Assets	130
2117	6	8	2021	Q2	\N	2021-08-01	38650000000.0000	USD	us-gaap:Assets	131
2118	6	8	2021	Q3	\N	2021-10-31	40632000000.0000	USD	us-gaap:Assets	132
2119	6	8	2021	FY	\N	2022-01-30	44187000000.0000	USD	us-gaap:Assets	133
2120	6	8	2022	Q1	\N	2022-05-01	45212000000.0000	USD	us-gaap:Assets	134
2121	6	8	2022	Q2	\N	2022-07-31	43476000000.0000	USD	us-gaap:Assets	135
2122	6	8	2022	Q3	\N	2022-10-30	40488000000.0000	USD	us-gaap:Assets	136
2123	6	8	2022	FY	\N	2023-01-29	41182000000.0000	USD	us-gaap:Assets	137
2124	6	8	2023	Q1	\N	2023-04-30	44460000000.0000	USD	us-gaap:Assets	138
2125	6	8	2023	Q2	\N	2023-07-30	49555000000.0000	USD	us-gaap:Assets	139
2126	6	8	2023	Q3	\N	2023-10-29	54148000000.0000	USD	us-gaap:Assets	140
2127	6	8	2023	FY	\N	2024-01-28	65728000000.0000	USD	us-gaap:Assets	141
2128	6	8	2024	Q1	\N	2024-04-28	77072000000.0000	USD	us-gaap:Assets	142
2129	6	8	2024	Q2	\N	2024-07-28	85227000000.0000	USD	us-gaap:Assets	143
2130	6	8	2024	Q3	\N	2024-10-27	96013000000.0000	USD	us-gaap:Assets	144
2131	6	8	2024	FY	\N	2025-01-26	111601000000.0000	USD	us-gaap:Assets	6
2132	6	8	2025	Q1	\N	2025-04-27	125254000000.0000	USD	us-gaap:Assets	145
2133	6	8	2025	Q2	\N	2025-07-27	140740000000.0000	USD	us-gaap:Assets	146
2134	6	8	2025	Q3	\N	2025-10-26	161148000000.0000	USD	us-gaap:Assets	147
2135	6	8	2025	FY	\N	2026-01-25	206803000000.0000	USD	us-gaap:Assets	149
2136	6	8	2026	Q1	\N	2026-04-26	259474000000.0000	USD	us-gaap:Assets	148
2137	6	8	2026	Q2	\N	2026-07-26	320272000000.0000	USD	us-gaap:Assets	149
2138	6	9	2019	Q1	\N	2019-04-28	4317000000.0000	USD	us-gaap:Liabilities	152
2139	6	9	2019	Q2	\N	2019-07-28	4439000000.0000	USD	us-gaap:Liabilities	153
2140	6	9	2019	Q3	\N	2019-10-27	4596000000.0000	USD	us-gaap:Liabilities	154
2141	6	9	2019	FY	\N	2020-01-26	5111000000.0000	USD	us-gaap:Liabilities	155
2142	6	9	2020	Q1	\N	2020-04-26	10155000000.0000	USD	us-gaap:Liabilities	126
2143	6	9	2020	Q2	\N	2020-07-26	11266000000.0000	USD	us-gaap:Liabilities	127
2144	6	9	2020	Q3	\N	2020-10-25	11547000000.0000	USD	us-gaap:Liabilities	128
2145	6	9	2020	FY	\N	2021-01-31	11898000000.0000	USD	us-gaap:Liabilities	129
2146	6	9	2021	Q1	\N	2021-05-02	12022000000.0000	USD	us-gaap:Liabilities	130
2147	6	9	2021	Q2	\N	2021-08-01	17503000000.0000	USD	us-gaap:Liabilities	131
2148	6	9	2021	Q3	\N	2021-10-31	16834000000.0000	USD	us-gaap:Liabilities	132
2149	6	9	2021	FY	\N	2022-01-30	17575000000.0000	USD	us-gaap:Liabilities	133
2150	6	9	2022	Q1	\N	2022-05-01	18892000000.0000	USD	us-gaap:Liabilities	134
2151	6	9	2022	Q2	\N	2022-07-31	19625000000.0000	USD	us-gaap:Liabilities	135
2152	6	9	2022	Q3	\N	2022-10-30	19139000000.0000	USD	us-gaap:Liabilities	136
2153	6	9	2022	FY	\N	2023-01-29	19081000000.0000	USD	us-gaap:Liabilities	137
2154	6	9	2023	Q1	\N	2023-04-30	19940000000.0000	USD	us-gaap:Liabilities	138
2155	6	9	2023	Q2	\N	2023-07-30	22054000000.0000	USD	us-gaap:Liabilities	139
2156	6	9	2023	Q3	\N	2023-10-29	20883000000.0000	USD	us-gaap:Liabilities	140
2157	6	9	2023	FY	\N	2024-01-28	22750000000.0000	USD	us-gaap:Liabilities	141
2158	6	9	2024	Q1	\N	2024-04-28	27930000000.0000	USD	us-gaap:Liabilities	142
2159	6	9	2024	Q2	\N	2024-07-28	27070000000.0000	USD	us-gaap:Liabilities	143
2160	6	9	2024	Q3	\N	2024-10-27	30114000000.0000	USD	us-gaap:Liabilities	144
2161	6	9	2024	FY	\N	2025-01-26	32274000000.0000	USD	us-gaap:Liabilities	6
2162	6	9	2025	Q1	\N	2025-04-27	41411000000.0000	USD	us-gaap:Liabilities	145
2163	6	9	2025	Q2	\N	2025-07-27	40609000000.0000	USD	us-gaap:Liabilities	146
2164	6	9	2025	Q3	\N	2025-10-26	42251000000.0000	USD	us-gaap:Liabilities	147
2165	6	9	2025	FY	\N	2026-01-25	49510000000.0000	USD	us-gaap:Liabilities	149
2166	6	9	2026	Q1	\N	2026-04-26	64000000000.0000	USD	us-gaap:Liabilities	148
2167	6	9	2026	Q2	\N	2026-07-26	91288000000.0000	USD	us-gaap:Liabilities	149
2168	6	10	2019	Q1	\N	2019-04-28	9704000000.0000	USD	us-gaap:StockholdersEquity	127
2169	6	10	2019	Q2	\N	2019-07-28	10336000000.0000	USD	us-gaap:StockholdersEquity	128
2170	6	10	2019	Q3	\N	2019-10-27	11214000000.0000	USD	us-gaap:StockholdersEquity	128
2171	6	10	2019	FY	\N	2020-01-26	12204000000.0000	USD	us-gaap:StockholdersEquity	133
2172	6	10	2020	Q1	\N	2020-04-26	13099000000.0000	USD	us-gaap:StockholdersEquity	131
2173	6	10	2020	Q2	\N	2020-07-26	13914000000.0000	USD	us-gaap:StockholdersEquity	132
2174	6	10	2020	Q3	\N	2020-10-25	15334000000.0000	USD	us-gaap:StockholdersEquity	132
2175	6	10	2020	FY	\N	2021-01-31	16893000000.0000	USD	us-gaap:StockholdersEquity	137
2176	6	10	2021	Q1	\N	2021-05-02	18774000000.0000	USD	us-gaap:StockholdersEquity	135
2177	6	10	2021	Q2	\N	2021-08-01	21147000000.0000	USD	us-gaap:StockholdersEquity	136
2178	6	10	2021	Q3	\N	2021-10-31	23798000000.0000	USD	us-gaap:StockholdersEquity	136
2179	6	10	2021	FY	\N	2022-01-30	26612000000.0000	USD	us-gaap:StockholdersEquity	141
2180	6	10	2022	Q1	\N	2022-05-01	26320000000.0000	USD	us-gaap:StockholdersEquity	139
2181	6	10	2022	Q2	\N	2022-07-31	23851000000.0000	USD	us-gaap:StockholdersEquity	140
2182	6	10	2022	Q3	\N	2022-10-30	21349000000.0000	USD	us-gaap:StockholdersEquity	140
2183	6	10	2022	FY	\N	2023-01-29	22101000000.0000	USD	us-gaap:StockholdersEquity	6
2184	6	10	2023	Q1	\N	2023-04-30	24520000000.0000	USD	us-gaap:StockholdersEquity	143
2185	6	10	2023	Q2	\N	2023-07-30	27501000000.0000	USD	us-gaap:StockholdersEquity	144
2186	6	10	2023	Q3	\N	2023-10-29	33265000000.0000	USD	us-gaap:StockholdersEquity	144
2187	6	10	2023	FY	\N	2024-01-28	42978000000.0000	USD	us-gaap:StockholdersEquity	6
2188	6	10	2024	Q1	\N	2024-04-28	49142000000.0000	USD	us-gaap:StockholdersEquity	146
2189	6	10	2024	Q2	\N	2024-07-28	58157000000.0000	USD	us-gaap:StockholdersEquity	147
2190	6	10	2024	Q3	\N	2024-10-27	65899000000.0000	USD	us-gaap:StockholdersEquity	147
2191	6	10	2024	FY	\N	2025-01-26	79327000000.0000	USD	us-gaap:StockholdersEquity	149
2192	6	10	2025	Q1	\N	2025-04-27	83843000000.0000	USD	us-gaap:StockholdersEquity	149
2193	6	10	2025	Q2	\N	2025-07-27	100131000000.0000	USD	us-gaap:StockholdersEquity	149
2194	6	10	2025	Q3	\N	2025-10-26	118897000000.0000	USD	us-gaap:StockholdersEquity	147
2195	6	10	2025	FY	\N	2026-01-25	157293000000.0000	USD	us-gaap:StockholdersEquity	149
2196	6	10	2026	Q1	\N	2026-04-26	195474000000.0000	USD	us-gaap:StockholdersEquity	149
2197	6	10	2026	Q2	\N	2026-07-26	228984000000.0000	USD	us-gaap:StockholdersEquity	149
2198	6	11	2019	Q1	\N	2019-04-28	2772000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	152
2199	6	11	2019	Q2	\N	2019-07-28	7105000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	153
2200	6	11	2019	Q3	\N	2019-10-27	9765000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	154
2201	6	11	2019	FY	\N	2020-01-26	10896000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	155
2202	6	11	2020	Q1	\N	2020-04-26	15494000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	126
2203	6	11	2020	Q2	\N	2020-07-26	3274000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	127
2204	6	11	2020	Q3	\N	2020-10-25	2251000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	128
2205	6	11	2020	FY	\N	2021-01-31	847000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	129
2206	6	11	2021	Q1	\N	2021-05-02	978000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	130
2207	6	11	2021	Q2	\N	2021-08-01	5628000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	131
2208	6	11	2021	Q3	\N	2021-10-31	1288000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	132
2209	6	11	2021	FY	\N	2022-01-30	1990000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	133
2210	6	11	2022	Q1	\N	2022-05-01	3887000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	134
2211	6	11	2022	Q2	\N	2022-07-31	3013000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	139
2212	6	11	2022	Q3	\N	2022-10-30	2800000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	136
2213	6	11	2022	FY	\N	2023-01-29	3389000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	137
2214	6	11	2023	Q1	\N	2023-04-30	5079000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	138
2215	6	11	2023	Q2	\N	2023-07-30	5783000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	143
2216	6	11	2023	Q3	\N	2023-10-29	5519000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	140
2217	6	11	2023	FY	\N	2024-01-28	7280000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	141
2218	6	11	2024	Q1	\N	2024-04-28	7587000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	142
2219	6	11	2024	Q2	\N	2024-07-28	8563000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	143
2220	6	11	2024	Q3	\N	2024-10-27	9107000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	144
2221	6	11	2024	FY	\N	2025-01-26	8589000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	6
2222	6	11	2025	Q1	\N	2025-04-27	15234000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	145
2223	6	11	2025	Q2	\N	2025-07-27	11639000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	146
2224	6	11	2025	Q3	\N	2025-10-26	11486000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	147
2225	6	11	2025	FY	\N	2026-01-25	10605000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	149
2226	6	11	2026	Q1	\N	2026-04-26	13237000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	148
2227	6	11	2026	Q2	\N	2026-07-26	22443000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	149
2228	6	12	2019	FY	\N	2020-01-26	1991000000.0000	USD	us-gaap:LongTermDebtNoncurrent	155
2528	7	2	2019	FY	2019-01-01	2019-12-31	2331649000.0000	USD	us-gaap:CostOfRevenue	159
2229	6	12	2020	Q3	\N	2020-10-25	5963000000.0000	USD	us-gaap:LongTermDebtNoncurrent	128
2230	6	12	2020	FY	\N	2021-01-31	5964000000.0000	USD	us-gaap:LongTermDebtNoncurrent	129
2231	6	12	2021	Q1	\N	2021-05-02	5964000000.0000	USD	us-gaap:LongTermDebtNoncurrent	130
2232	6	12	2021	Q2	\N	2021-08-01	10943000000.0000	USD	us-gaap:LongTermDebtNoncurrent	131
2233	6	12	2021	Q3	\N	2021-10-31	10944000000.0000	USD	us-gaap:LongTermDebtNoncurrent	132
2234	6	12	2021	FY	\N	2022-01-30	10946000000.0000	USD	us-gaap:LongTermDebtNoncurrent	133
2235	6	12	2022	Q1	\N	2022-05-01	10947000000.0000	USD	us-gaap:LongTermDebtNoncurrent	134
2236	6	12	2022	Q2	\N	2022-07-31	9700000000.0000	USD	us-gaap:LongTermDebtNoncurrent	135
2237	6	12	2022	Q3	\N	2022-10-30	9701000000.0000	USD	us-gaap:LongTermDebtNoncurrent	136
2238	6	12	2022	FY	\N	2023-01-29	9703000000.0000	USD	us-gaap:LongTermDebtNoncurrent	137
2239	6	12	2023	Q1	\N	2023-04-30	9704000000.0000	USD	us-gaap:LongTermDebtNoncurrent	138
2240	6	12	2023	Q2	\N	2023-07-30	8456000000.0000	USD	us-gaap:LongTermDebtNoncurrent	139
2241	6	12	2023	Q3	\N	2023-10-29	8457000000.0000	USD	us-gaap:LongTermDebtNoncurrent	140
2242	6	12	2023	FY	\N	2024-01-28	8459000000.0000	USD	us-gaap:LongTermDebtNoncurrent	141
2243	6	12	2024	Q1	\N	2024-04-28	8460000000.0000	USD	us-gaap:LongTermDebtNoncurrent	142
2244	6	12	2024	Q2	\N	2024-07-28	8461000000.0000	USD	us-gaap:LongTermDebtNoncurrent	143
2245	6	12	2024	Q3	\N	2024-10-27	8462000000.0000	USD	us-gaap:LongTermDebtNoncurrent	144
2246	6	12	2024	FY	\N	2025-01-26	8463000000.0000	USD	us-gaap:LongTermDebtNoncurrent	6
2247	6	12	2025	Q1	\N	2025-04-27	8464000000.0000	USD	us-gaap:LongTermDebtNoncurrent	145
2248	6	12	2025	Q2	\N	2025-07-27	8466000000.0000	USD	us-gaap:LongTermDebtNoncurrent	146
2249	6	12	2025	Q3	\N	2025-10-26	7468000000.0000	USD	us-gaap:LongTermDebtNoncurrent	147
2250	6	12	2025	FY	\N	2026-01-25	7469000000.0000	USD	us-gaap:LongTermDebtNoncurrent	149
2251	6	12	2026	Q1	\N	2026-04-26	7470000000.0000	USD	us-gaap:LongTermDebtNoncurrent	148
2252	6	12	2026	Q2	\N	2026-07-26	32366000000.0000	USD	us-gaap:LongTermDebtNoncurrent	149
2253	6	12	2019	Q1	\N	2019-04-28	1988000000.0000	USD	us-gaap:LongTermDebt	152
2254	6	12	2019	Q2	\N	2019-07-28	1989000000.0000	USD	us-gaap:LongTermDebt	153
2255	6	12	2019	Q3	\N	2019-10-27	1990000000.0000	USD	us-gaap:LongTermDebt	154
2256	6	12	2020	Q1	\N	2020-04-26	6959000000.0000	USD	us-gaap:LongTermDebt	126
2257	6	12	2020	Q2	\N	2020-07-26	6960000000.0000	USD	us-gaap:LongTermDebt	127
2258	6	13	2019	Q1	\N	2019-04-28	1426000000.0000	USD	us-gaap:InventoryNet	152
2259	6	13	2019	Q2	\N	2019-07-28	1204000000.0000	USD	us-gaap:InventoryNet	153
2260	6	13	2019	Q3	\N	2019-10-27	1047000000.0000	USD	us-gaap:InventoryNet	154
2261	6	13	2019	FY	\N	2020-01-26	979000000.0000	USD	us-gaap:InventoryNet	155
2262	6	13	2020	Q1	\N	2020-04-26	1128000000.0000	USD	us-gaap:InventoryNet	126
2263	6	13	2020	Q2	\N	2020-07-26	1401000000.0000	USD	us-gaap:InventoryNet	127
2264	6	13	2020	Q3	\N	2020-10-25	1495000000.0000	USD	us-gaap:InventoryNet	128
2265	6	13	2020	FY	\N	2021-01-31	1826000000.0000	USD	us-gaap:InventoryNet	129
2266	6	13	2021	Q1	\N	2021-05-02	1992000000.0000	USD	us-gaap:InventoryNet	130
2267	6	13	2021	Q2	\N	2021-08-01	2114000000.0000	USD	us-gaap:InventoryNet	131
2268	6	13	2021	Q3	\N	2021-10-31	2233000000.0000	USD	us-gaap:InventoryNet	132
2269	6	13	2021	FY	\N	2022-01-30	2605000000.0000	USD	us-gaap:InventoryNet	133
2270	6	13	2022	Q1	\N	2022-05-01	3163000000.0000	USD	us-gaap:InventoryNet	134
2271	6	13	2022	Q2	\N	2022-07-31	3889000000.0000	USD	us-gaap:InventoryNet	135
2272	6	13	2022	Q3	\N	2022-10-30	4454000000.0000	USD	us-gaap:InventoryNet	136
2273	6	13	2022	FY	\N	2023-01-29	5159000000.0000	USD	us-gaap:InventoryNet	137
2274	6	13	2023	Q1	\N	2023-04-30	4611000000.0000	USD	us-gaap:InventoryNet	138
2275	6	13	2023	Q2	\N	2023-07-30	4319000000.0000	USD	us-gaap:InventoryNet	139
2276	6	13	2023	Q3	\N	2023-10-29	4779000000.0000	USD	us-gaap:InventoryNet	140
2277	6	13	2023	FY	\N	2024-01-28	5282000000.0000	USD	us-gaap:InventoryNet	141
2278	6	13	2024	Q1	\N	2024-04-28	5864000000.0000	USD	us-gaap:InventoryNet	142
2279	6	13	2024	Q2	\N	2024-07-28	6675000000.0000	USD	us-gaap:InventoryNet	143
2280	6	13	2024	Q3	\N	2024-10-27	7654000000.0000	USD	us-gaap:InventoryNet	144
2281	6	13	2024	FY	\N	2025-01-26	10080000000.0000	USD	us-gaap:InventoryNet	6
2282	6	13	2025	Q1	\N	2025-04-27	11333000000.0000	USD	us-gaap:InventoryNet	145
2283	6	13	2025	Q2	\N	2025-07-27	14962000000.0000	USD	us-gaap:InventoryNet	146
2284	6	13	2025	Q3	\N	2025-10-26	19784000000.0000	USD	us-gaap:InventoryNet	147
2285	6	13	2025	FY	\N	2026-01-25	21403000000.0000	USD	us-gaap:InventoryNet	149
2286	6	13	2026	Q1	\N	2026-04-26	25797000000.0000	USD	us-gaap:InventoryNet	148
2287	6	13	2026	Q2	\N	2026-07-26	31575000000.0000	USD	us-gaap:InventoryNet	149
2288	6	14	2019	Q1	2019-01-28	2019-04-28	674000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	126
2289	6	14	2019	Q2	2019-04-29	2019-07-28	704000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	127
2290	6	14	2019	Q3	2019-07-29	2019-10-27	712000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	128
2291	6	14	2019	FY	2019-01-28	2020-01-26	2829000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	129
2292	6	14	2020	Q1	2020-01-27	2020-04-26	735000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	130
2293	6	14	2020	Q2	2020-04-27	2020-07-26	997000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	131
2294	6	14	2020	Q3	2020-07-27	2020-10-25	1047000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	132
2295	6	14	2020	FY	2020-01-27	2021-01-31	3924000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	133
2296	6	14	2021	Q1	2021-02-01	2021-05-02	1153000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	134
2297	6	14	2021	Q2	2021-05-03	2021-08-01	1245000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	135
2298	6	14	2021	Q3	2021-08-02	2021-10-31	1403000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	136
2299	6	14	2021	FY	2021-02-01	2022-01-30	5268000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	137
2300	6	14	2022	Q1	2022-01-31	2022-05-01	1618000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	138
2301	6	14	2022	Q2	2022-05-02	2022-07-31	1824000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	139
2302	6	14	2022	Q3	2022-08-01	2022-10-30	1945000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	140
2303	6	14	2022	FY	2022-01-31	2023-01-29	7339000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	141
2304	6	14	2023	Q1	2023-01-30	2023-04-30	1875000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	142
2529	7	2	2020	Q1	2020-01-01	2020-03-31	496827000.0000	USD	us-gaap:CostOfRevenue	161
2305	6	14	2023	Q2	2023-05-01	2023-07-30	2040000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	143
2306	6	14	2023	Q3	2023-07-31	2023-10-29	2294000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	144
2307	6	14	2023	FY	2023-01-30	2024-01-28	8675000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	6
2308	6	14	2024	Q1	2024-01-29	2024-04-28	2720000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	145
2309	6	14	2024	Q2	2024-04-29	2024-07-28	3090000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	146
2310	6	14	2024	Q3	2024-07-29	2024-10-27	3390000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	147
2311	6	14	2024	FY	2024-01-29	2025-01-26	12914000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	6
2312	6	14	2025	Q1	2025-01-27	2025-04-27	3989000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	148
2313	6	14	2025	Q2	2025-04-28	2025-07-27	4291000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	149
2314	6	14	2025	Q3	2025-07-28	2025-10-26	4705000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	147
2315	6	14	2025	FY	2025-01-27	2026-01-25	18497000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	6
2316	6	14	2026	Q1	2026-01-26	2026-04-26	6321000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	148
2317	6	14	2026	Q2	2026-04-27	2026-07-26	7054000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	149
2318	6	15	2019	Q1	2019-01-28	2019-04-28	178000000.0000	USD	us-gaap:ShareBasedCompensation	126
2319	6	15	2019	Q2	2019-04-29	2019-07-28	224000000.0000	USD	us-gaap:ShareBasedCompensation	127
2320	6	15	2019	Q3	2019-07-29	2019-10-27	223000000.0000	USD	us-gaap:ShareBasedCompensation	128
2321	6	15	2019	FY	2019-01-28	2020-01-26	844000000.0000	USD	us-gaap:ShareBasedCompensation	129
2322	6	15	2020	Q1	2020-01-27	2020-04-26	224000000.0000	USD	us-gaap:ShareBasedCompensation	130
2323	6	15	2020	Q2	2020-04-27	2020-07-26	374000000.0000	USD	us-gaap:ShareBasedCompensation	131
2324	6	15	2020	Q3	2020-07-27	2020-10-25	383000000.0000	USD	us-gaap:ShareBasedCompensation	132
2325	6	15	2020	FY	2020-01-27	2021-01-31	1397000000.0000	USD	us-gaap:ShareBasedCompensation	133
2326	6	15	2021	Q1	2021-02-01	2021-05-02	429000000.0000	USD	us-gaap:ShareBasedCompensation	134
2327	6	15	2021	Q2	2021-05-03	2021-08-01	465000000.0000	USD	us-gaap:ShareBasedCompensation	131
2328	6	15	2021	Q3	2021-08-02	2021-10-31	559000000.0000	USD	us-gaap:ShareBasedCompensation	132
2329	6	15	2021	FY	2021-02-01	2022-01-30	2004000000.0000	USD	us-gaap:ShareBasedCompensation	137
2330	6	15	2022	Q1	2022-01-31	2022-05-01	578000000.0000	USD	us-gaap:ShareBasedCompensation	134
2331	6	15	2022	FY	2022-01-31	2023-01-29	2709000000.0000	USD	us-gaap:ShareBasedCompensation	141
2332	6	15	2023	Q1	2023-01-30	2023-04-30	735000000.0000	USD	us-gaap:ShareBasedCompensation	142
2333	6	15	2023	FY	2023-01-30	2024-01-28	3549000000.0000	USD	us-gaap:ShareBasedCompensation	6
2334	6	15	2024	Q1	2024-01-29	2024-04-28	1011000000.0000	USD	us-gaap:ShareBasedCompensation	145
2335	6	15	2024	FY	2024-01-29	2025-01-26	4737000000.0000	USD	us-gaap:ShareBasedCompensation	6
2336	6	15	2025	Q1	2025-01-27	2025-04-27	1474000000.0000	USD	us-gaap:ShareBasedCompensation	148
2337	6	15	2025	FY	2025-01-27	2026-01-25	6386000000.0000	USD	us-gaap:ShareBasedCompensation	6
2338	6	15	2026	Q1	2026-01-26	2026-04-26	1928000000.0000	USD	us-gaap:ShareBasedCompensation	148
2339	6	15	2022	Q2	2022-05-02	2022-07-31	649000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	139
2340	6	15	2022	Q3	2022-08-01	2022-10-30	745000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	140
2341	6	15	2023	Q2	2023-05-01	2023-07-30	842000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	143
2342	6	15	2023	Q3	2023-07-31	2023-10-29	979000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	144
2343	6	15	2024	Q2	2024-04-29	2024-07-28	1154000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	146
2344	6	15	2024	Q3	2024-07-29	2024-10-27	1252000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	147
2345	6	15	2025	Q2	2025-04-28	2025-07-27	1624000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	149
2346	6	15	2025	Q3	2025-07-28	2025-10-26	1655000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	147
2347	6	15	2026	Q2	2026-04-27	2026-07-26	2027000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	149
2348	6	16	2019	FY	2019-01-28	2020-01-26	381000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	129
2349	6	16	2020	FY	2020-01-27	2021-01-31	1098000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	133
2350	6	16	2021	Q1	2021-02-01	2021-05-02	281000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	134
2351	6	16	2021	FY	2021-02-01	2022-01-30	1174000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	137
2352	6	16	2022	Q1	2022-01-31	2022-05-01	334000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	138
2353	6	16	2022	FY	2022-01-31	2023-01-29	1544000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	141
2354	6	16	2023	Q1	2023-01-30	2023-04-30	384000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	142
2355	6	16	2023	FY	2023-01-30	2024-01-28	1508000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	6
2356	6	16	2024	Q1	2024-01-29	2024-04-28	410000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	145
2357	6	16	2024	FY	2024-01-29	2025-01-26	1864000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	6
2358	6	16	2025	Q1	2025-01-27	2025-04-27	611000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	148
2359	6	16	2025	FY	2025-01-27	2026-01-25	2843000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	6
2360	6	16	2026	Q1	2026-01-26	2026-04-26	997000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	148
2361	6	17	2019	Q1	2019-01-28	2019-04-28	-5000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	126
2362	6	17	2019	Q2	2019-04-29	2019-07-28	54000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	127
2363	6	17	2019	Q3	2019-07-29	2019-10-27	60000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	128
2364	6	17	2019	FY	2019-01-28	2020-01-26	174000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	129
2365	6	17	2020	Q1	2020-01-27	2020-04-26	64000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	130
2366	6	17	2020	Q2	2020-04-27	2020-07-26	-13000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	131
2367	6	17	2020	Q3	2020-07-27	2020-10-25	12000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	132
2368	6	17	2020	FY	2020-01-27	2021-01-31	77000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	133
2369	6	17	2021	Q1	2021-02-01	2021-05-02	132000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	134
2370	6	17	2021	Q2	2021-05-03	2021-08-01	20000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	135
2371	6	17	2021	Q3	2021-08-02	2021-10-31	174000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	136
2372	6	17	2021	FY	2021-02-01	2022-01-30	189000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	137
2373	6	17	2022	Q1	2022-01-31	2022-05-01	187000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	138
2374	6	17	2022	Q2	2022-05-02	2022-07-31	-181000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	139
2375	6	17	2022	Q3	2022-08-01	2022-10-30	-67000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	140
2376	6	17	2022	FY	2022-01-31	2023-01-29	-187000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	141
2377	6	17	2023	Q1	2023-01-30	2023-04-30	166000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	142
2378	6	17	2023	Q2	2023-05-01	2023-07-30	793000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	143
2379	6	17	2023	Q3	2023-07-31	2023-10-29	1279000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	144
2380	6	17	2023	FY	2023-01-30	2024-01-28	4058000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	6
2381	6	17	2024	Q1	2024-01-29	2024-04-28	2398000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	145
2382	6	17	2024	Q2	2024-04-29	2024-07-28	2615000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	146
2383	6	17	2024	Q3	2024-07-29	2024-10-27	3007000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	147
2384	6	17	2024	FY	2024-01-29	2025-01-26	11146000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	6
2385	6	17	2025	Q1	2025-01-27	2025-04-27	3135000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	148
2386	6	17	2025	Q2	2025-04-28	2025-07-27	4784000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	149
2387	6	17	2025	Q3	2025-07-28	2025-10-26	6026000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	147
2388	6	17	2025	FY	2025-01-27	2026-01-25	21383000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	6
2389	6	17	2026	Q1	2026-01-26	2026-04-26	11582000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	148
2390	6	17	2026	Q2	2026-04-27	2026-07-26	11819000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	149
2391	6	18	2019	Q1	2019-01-28	2019-04-28	0.6400	USD/shares	us-gaap:EarningsPerShareDiluted	126
2392	6	18	2019	Q2	2019-04-29	2019-07-28	0.9000	USD/shares	us-gaap:EarningsPerShareDiluted	127
2393	6	18	2019	Q3	2019-07-29	2019-10-27	1.4500	USD/shares	us-gaap:EarningsPerShareDiluted	128
2394	6	18	2019	FY	2019-01-28	2020-01-26	1.1300	USD/shares	us-gaap:EarningsPerShareDiluted	129
2395	6	18	2019	Q4	2019-10-28	2020-01-26	1.5300	USD/shares	us-gaap:EarningsPerShareDiluted	150
2396	6	18	2020	Q1	2020-01-27	2020-04-26	1.4700	USD/shares	us-gaap:EarningsPerShareDiluted	130
2397	6	18	2020	Q2	2020-04-27	2020-07-26	0.2500	USD/shares	us-gaap:EarningsPerShareDiluted	131
2398	6	18	2020	Q3	2020-07-27	2020-10-25	0.5300	USD/shares	us-gaap:EarningsPerShareDiluted	132
2399	6	18	2020	FY	2020-01-27	2021-01-31	1.7300	USD/shares	us-gaap:EarningsPerShareDiluted	133
2400	6	18	2021	Q1	2021-02-01	2021-05-02	0.7600	USD/shares	us-gaap:EarningsPerShareDiluted	134
2401	6	18	2021	Q2	2021-05-03	2021-08-01	0.9400	USD/shares	us-gaap:EarningsPerShareDiluted	135
2402	6	18	2021	Q3	2021-08-02	2021-10-31	0.9700	USD/shares	us-gaap:EarningsPerShareDiluted	136
2403	6	18	2021	FY	2021-02-01	2022-01-30	3.8500	USD/shares	us-gaap:EarningsPerShareDiluted	137
2404	6	18	2022	Q1	2022-01-31	2022-05-01	0.6400	USD/shares	us-gaap:EarningsPerShareDiluted	138
2405	6	18	2022	Q2	2022-05-02	2022-07-31	0.2600	USD/shares	us-gaap:EarningsPerShareDiluted	139
2406	6	18	2022	Q3	2022-08-01	2022-10-30	0.2700	USD/shares	us-gaap:EarningsPerShareDiluted	140
2407	6	18	2022	FY	2022-01-31	2023-01-29	0.1700	USD/shares	us-gaap:EarningsPerShareDiluted	141
2408	6	18	2023	Q1	2023-01-30	2023-04-30	0.8200	USD/shares	us-gaap:EarningsPerShareDiluted	142
2409	6	18	2023	Q2	2023-05-01	2023-07-30	0.2500	USD/shares	us-gaap:EarningsPerShareDiluted	143
2410	6	18	2023	Q3	2023-07-31	2023-10-29	0.3700	USD/shares	us-gaap:EarningsPerShareDiluted	144
2411	6	18	2023	FY	2023-01-30	2024-01-28	1.1900	USD/shares	us-gaap:EarningsPerShareDiluted	6
2412	6	18	2024	Q1	2024-01-29	2024-04-28	0.6000	USD/shares	us-gaap:EarningsPerShareDiluted	145
2413	6	18	2024	Q2	2024-04-29	2024-07-28	0.6700	USD/shares	us-gaap:EarningsPerShareDiluted	146
2414	6	18	2024	Q3	2024-07-29	2024-10-27	0.7800	USD/shares	us-gaap:EarningsPerShareDiluted	147
2415	6	18	2024	FY	2024-01-29	2025-01-26	2.9400	USD/shares	us-gaap:EarningsPerShareDiluted	6
2416	6	18	2025	Q1	2025-01-27	2025-04-27	0.7600	USD/shares	us-gaap:EarningsPerShareDiluted	148
2417	6	18	2025	Q2	2025-04-28	2025-07-27	1.0800	USD/shares	us-gaap:EarningsPerShareDiluted	149
2418	6	18	2025	Q3	2025-07-28	2025-10-26	1.3000	USD/shares	us-gaap:EarningsPerShareDiluted	147
2419	6	18	2025	FY	2025-01-27	2026-01-25	4.9000	USD/shares	us-gaap:EarningsPerShareDiluted	6
2420	6	18	2026	Q1	2026-01-26	2026-04-26	2.3900	USD/shares	us-gaap:EarningsPerShareDiluted	148
2421	6	18	2026	Q2	2026-04-27	2026-07-26	2.4600	USD/shares	us-gaap:EarningsPerShareDiluted	149
2422	6	19	2019	Q1	2019-01-28	2019-04-28	97000000.0000	USD	us-gaap:PaymentsOfDividends	126
2423	6	19	2019	Q2	2019-04-29	2019-07-28	97000000.0000	USD	us-gaap:PaymentsOfDividends	153
2424	6	19	2019	Q3	2019-07-29	2019-10-27	98000000.0000	USD	us-gaap:PaymentsOfDividends	154
2425	6	19	2019	FY	2019-01-28	2020-01-26	390000000.0000	USD	us-gaap:PaymentsOfDividends	129
2426	6	19	2020	Q1	2020-01-27	2020-04-26	98000000.0000	USD	us-gaap:PaymentsOfDividends	130
2427	6	19	2020	Q2	2020-04-27	2020-07-26	99000000.0000	USD	us-gaap:PaymentsOfDividends	127
2428	6	19	2020	Q3	2020-07-27	2020-10-25	99000000.0000	USD	us-gaap:PaymentsOfDividends	132
2429	6	19	2020	FY	2020-01-27	2021-01-31	395000000.0000	USD	us-gaap:PaymentsOfDividends	133
2430	6	19	2021	Q1	2021-02-01	2021-05-02	99000000.0000	USD	us-gaap:PaymentsOfDividends	134
2431	6	19	2021	Q2	2021-05-03	2021-08-01	100000000.0000	USD	us-gaap:PaymentsOfDividends	135
2432	6	19	2021	Q3	2021-08-02	2021-10-31	100000000.0000	USD	us-gaap:PaymentsOfDividends	136
2433	6	19	2021	FY	2021-02-01	2022-01-30	399000000.0000	USD	us-gaap:PaymentsOfDividends	137
2434	6	19	2022	Q1	2022-01-31	2022-05-01	100000000.0000	USD	us-gaap:PaymentsOfDividends	138
2435	6	19	2022	Q2	2022-05-02	2022-07-31	100000000.0000	USD	us-gaap:PaymentsOfDividends	139
2436	6	19	2022	Q3	2022-08-01	2022-10-30	100000000.0000	USD	us-gaap:PaymentsOfDividends	140
2437	6	19	2022	FY	2022-01-31	2023-01-29	398000000.0000	USD	us-gaap:PaymentsOfDividends	141
2438	6	19	2023	Q1	2023-01-30	2023-04-30	99000000.0000	USD	us-gaap:PaymentsOfDividends	142
2439	6	19	2023	Q2	2023-05-01	2023-07-30	99000000.0000	USD	us-gaap:PaymentsOfDividends	143
2440	6	19	2023	Q3	2023-07-31	2023-10-29	99000000.0000	USD	us-gaap:PaymentsOfDividends	144
2441	6	19	2023	FY	2023-01-30	2024-01-28	395000000.0000	USD	us-gaap:PaymentsOfDividends	6
2442	6	19	2024	Q1	2024-01-29	2024-04-28	98000000.0000	USD	us-gaap:PaymentsOfDividends	145
2443	6	19	2024	Q2	2024-04-29	2024-07-28	246000000.0000	USD	us-gaap:PaymentsOfDividends	146
2444	6	19	2024	Q3	2024-07-29	2024-10-27	245000000.0000	USD	us-gaap:PaymentsOfDividends	144
2445	6	19	2024	FY	2024-01-29	2025-01-26	834000000.0000	USD	us-gaap:PaymentsOfDividends	6
2446	6	19	2025	Q1	2025-01-27	2025-04-27	244000000.0000	USD	us-gaap:PaymentsOfDividends	148
2447	6	19	2025	Q2	2025-04-28	2025-07-27	244000000.0000	USD	us-gaap:PaymentsOfDividends	149
2448	6	19	2025	FY	2025-01-27	2026-01-25	974000000.0000	USD	us-gaap:PaymentsOfDividends	6
2449	6	19	2026	Q1	2026-01-26	2026-04-26	243000000.0000	USD	us-gaap:PaymentsOfDividends	148
2450	6	19	2026	Q2	2026-04-27	2026-07-26	6000000000.0000	USD	us-gaap:PaymentsOfDividends	149
2451	6	20	2019	Q1	2019-01-28	2019-04-28	0.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	152
2452	6	20	2019	FY	2019-01-28	2020-01-26	0.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	155
2453	6	20	2020	FY	2020-01-27	2021-01-31	0.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	133
2454	6	20	2021	Q1	2021-02-01	2021-05-02	0.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	134
2455	6	20	2021	FY	2021-02-01	2022-01-30	0.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	137
2456	6	20	2022	Q1	2022-01-31	2022-05-01	1996000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	138
2457	6	20	2022	FY	2022-01-31	2023-01-29	10039000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	141
2458	6	20	2023	Q1	2023-01-30	2023-04-30	0.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	142
2459	6	20	2023	FY	2023-01-30	2024-01-28	9533000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	6
2460	6	20	2024	Q1	2024-01-29	2024-04-28	7740000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	145
2461	6	20	2024	FY	2024-01-29	2025-01-26	33706000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	6
2462	6	20	2025	Q1	2025-01-27	2025-04-27	14095000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	148
2463	6	20	2025	FY	2025-01-27	2026-01-25	40086000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	6
2464	6	20	2026	Q1	2026-01-26	2026-04-26	19312000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	148
2465	6	21	2019	Q1	2019-01-28	2019-04-28	0.1600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	126
2466	6	21	2019	Q2	2019-04-29	2019-07-28	0.1600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	127
2467	6	21	2019	Q3	2019-07-29	2019-10-27	0.1600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	128
2468	6	21	2020	Q1	2020-01-27	2020-04-26	0.1600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	130
2469	6	21	2020	Q2	2020-04-27	2020-07-26	0.0400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	131
2470	6	21	2020	Q3	2020-07-27	2020-10-25	0.0400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	132
2471	6	21	2021	Q1	2021-02-01	2021-05-02	0.0400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	134
2472	6	21	2021	Q2	2021-05-03	2021-08-01	0.0400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	135
2473	6	21	2021	Q3	2021-08-02	2021-10-31	0.0400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	136
2474	6	21	2021	FY	2021-02-01	2022-01-30	0.1600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	137
2475	6	21	2022	Q1	2022-01-31	2022-05-01	0.0400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	138
2476	6	21	2022	Q2	2022-05-02	2022-07-31	0.0400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	139
2477	6	21	2022	Q3	2022-08-01	2022-10-30	0.0400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	140
2478	6	21	2022	FY	2022-01-31	2023-01-29	0.0160	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	141
2479	6	21	2023	Q1	2023-01-30	2023-04-30	0.0400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	142
2480	6	21	2023	Q2	2023-05-01	2023-07-30	0.0040	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	143
2481	6	21	2023	Q3	2023-07-31	2023-10-29	0.0040	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	144
2482	6	21	2023	FY	2023-01-30	2024-01-28	0.0160	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	6
2483	6	21	2024	Q1	2024-01-29	2024-04-28	0.0040	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	145
2484	6	21	2024	Q2	2024-04-29	2024-07-28	0.0100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	146
2485	6	21	2024	Q3	2024-07-29	2024-10-27	0.0100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	147
2486	6	21	2024	FY	2024-01-29	2025-01-26	0.0340	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	6
2487	6	21	2025	Q1	2025-01-27	2025-04-27	0.0100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	148
2488	6	21	2025	Q2	2025-04-28	2025-07-27	0.0100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	149
2489	6	21	2025	Q3	2025-07-28	2025-10-26	0.0100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	147
2490	6	21	2025	FY	2025-01-27	2026-01-25	0.0400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	6
2491	6	21	2026	Q1	2026-01-26	2026-04-26	0.0100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	149
2492	6	21	2026	Q2	2026-04-27	2026-07-26	0.2500	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	149
2493	7	1	2019	Q1	2019-01-01	2019-03-31	832064000.0000	USD	us-gaap:Revenues	156
2494	7	1	2019	Q2	2019-04-01	2019-06-30	885052000.0000	USD	us-gaap:Revenues	157
2495	7	1	2019	Q3	2019-07-01	2019-09-30	879747000.0000	USD	us-gaap:Revenues	158
2496	7	1	2019	FY	2019-01-01	2019-12-31	3589427000.0000	USD	us-gaap:Revenues	159
2497	7	1	2019	Q4	2019-10-01	2019-12-31	992564000.0000	USD	us-gaap:Revenues	160
2498	7	1	2020	Q1	2020-01-01	2020-03-31	738845000.0000	USD	us-gaap:Revenues	161
2499	7	1	2020	Q2	2020-04-01	2020-06-30	764049000.0000	USD	us-gaap:Revenues	162
2500	7	1	2020	Q3	2020-07-01	2020-09-30	746868000.0000	USD	us-gaap:Revenues	163
2501	7	1	2020	FY	2020-01-01	2020-12-31	3128909000.0000	USD	us-gaap:Revenues	164
2502	7	1	2021	Q1	2021-01-01	2021-03-31	829291000.0000	USD	us-gaap:Revenues	165
2503	7	1	2021	Q2	2021-04-01	2021-06-30	773896000.0000	USD	us-gaap:Revenues	166
2504	7	1	2021	Q3	2021-07-01	2021-09-30	830566000.0000	USD	us-gaap:Revenues	167
2505	7	1	2021	FY	2021-01-01	2021-12-31	3327957000.0000	USD	us-gaap:Revenues	168
2506	7	1	2022	Q1	2022-01-01	2022-03-31	1127728000.0000	USD	us-gaap:Revenues	169
2507	7	1	2022	Q2	2022-04-01	2022-06-30	1479593000.0000	USD	us-gaap:Revenues	170
2508	7	1	2022	Q3	2022-07-01	2022-09-30	2091805000.0000	USD	us-gaap:Revenues	171
2509	7	1	2022	FY	2022-01-01	2022-12-31	7320104000.0000	USD	us-gaap:Revenues	172
2510	7	1	2023	Q1	2023-01-01	2023-03-31	2580252000.0000	USD	us-gaap:Revenues	173
2511	7	1	2023	Q2	2023-04-01	2023-06-30	2370190000.0000	USD	us-gaap:Revenues	174
2512	7	1	2023	Q3	2023-07-01	2023-09-30	2310596000.0000	USD	us-gaap:Revenues	175
2513	7	1	2023	FY	2023-01-01	2023-12-31	9617203000.0000	USD	us-gaap:Revenues	7
2514	7	1	2024	Q1	2024-01-01	2024-03-31	1360736000.0000	USD	us-gaap:Revenues	176
2515	7	1	2024	Q2	2024-04-01	2024-06-30	1430385000.0000	USD	us-gaap:Revenues	177
2516	7	1	2024	Q3	2024-07-01	2024-09-30	1354692000.0000	USD	us-gaap:Revenues	178
2517	7	1	2024	FY	2024-01-01	2024-12-31	5377526000.0000	USD	us-gaap:Revenues	7
2518	7	1	2025	Q1	2025-01-01	2025-03-31	1076881000.0000	USD	us-gaap:Revenues	179
2519	7	1	2025	Q2	2025-04-01	2025-06-30	1329992000.0000	USD	us-gaap:Revenues	180
2520	7	1	2025	Q3	2025-07-01	2025-09-30	1307829000.0000	USD	us-gaap:Revenues	181
2521	7	1	2025	FY	2025-01-01	2025-12-31	5142733000.0000	USD	us-gaap:Revenues	7
2522	7	1	2026	Q1	2026-01-01	2026-03-31	1428731000.0000	USD	us-gaap:Revenues	179
2523	7	1	2026	Q2	2026-04-01	2026-06-30	1743313000.0000	USD	us-gaap:Revenues	180
2524	7	1	2026	Q3	2026-07-01	2026-09-30	1553097000.0000	USD	us-gaap:Revenues	181
2525	7	2	2019	Q1	2019-01-01	2019-03-31	548578000.0000	USD	us-gaap:CostOfRevenue	156
2526	7	2	2019	Q2	2019-04-01	2019-06-30	559138000.0000	USD	us-gaap:CostOfRevenue	157
2527	7	2	2019	Q3	2019-07-01	2019-09-30	569880000.0000	USD	us-gaap:CostOfRevenue	158
2530	7	2	2020	Q2	2020-04-01	2020-06-30	530690000.0000	USD	us-gaap:CostOfRevenue	162
2531	7	2	2020	Q3	2020-07-01	2020-09-30	492812000.0000	USD	us-gaap:CostOfRevenue	163
2532	7	2	2020	FY	2020-01-01	2020-12-31	2134056000.0000	USD	us-gaap:CostOfRevenue	164
2533	7	2	2021	Q1	2021-01-01	2021-03-31	565604000.0000	USD	us-gaap:CostOfRevenue	165
2534	7	2	2021	Q2	2021-04-01	2021-06-30	525479000.0000	USD	us-gaap:CostOfRevenue	166
2535	7	2	2021	Q3	2021-07-01	2021-09-30	581293000.0000	USD	us-gaap:CostOfRevenue	167
2536	7	2	2021	FY	2021-01-01	2021-12-31	2329986000.0000	USD	us-gaap:CostOfRevenue	168
2537	7	2	2022	Q1	2022-01-01	2022-03-31	678698000.0000	USD	us-gaap:CostOfRevenue	169
2538	7	2	2022	Q2	2022-04-01	2022-06-30	899169000.0000	USD	us-gaap:CostOfRevenue	170
2539	7	2	2022	Q3	2022-07-01	2022-09-30	1047991000.0000	USD	us-gaap:CostOfRevenue	171
2540	7	2	2022	FY	2022-01-01	2022-12-31	4245517000.0000	USD	us-gaap:CostOfRevenue	172
2541	7	2	2023	Q1	2023-01-01	2023-03-31	1303712000.0000	USD	us-gaap:CostOfRevenue	173
2542	7	2	2023	Q2	2023-04-01	2023-06-30	1811703000.0000	USD	us-gaap:CostOfRevenue	174
2543	7	2	2023	Q3	2023-07-01	2023-09-30	2255662000.0000	USD	us-gaap:CostOfRevenue	175
2544	7	2	2023	FY	2023-01-01	2023-12-31	8431294000.0000	USD	us-gaap:CostOfRevenue	7
2545	7	2	2024	Q1	2024-01-01	2024-03-31	1321798000.0000	USD	us-gaap:CostOfRevenue	176
2546	7	2	2024	Q2	2024-04-01	2024-06-30	1440963000.0000	USD	us-gaap:CostOfRevenue	177
2547	7	2	2024	Q3	2024-07-01	2024-09-30	1458726000.0000	USD	us-gaap:CostOfRevenue	178
2548	7	2	2024	FY	2024-01-01	2024-12-31	5314987000.0000	USD	us-gaap:CostOfRevenue	7
2549	7	2	2025	Q1	2025-01-01	2025-03-31	920582000.0000	USD	us-gaap:CostOfRevenue	179
2550	7	2	2025	Q2	2025-04-01	2025-06-30	1133116000.0000	USD	us-gaap:CostOfRevenue	180
2551	7	2	2025	Q3	2025-07-01	2025-09-30	1190219000.0000	USD	us-gaap:CostOfRevenue	181
2552	7	2	2025	FY	2025-01-01	2025-12-31	4474014000.0000	USD	us-gaap:CostOfRevenue	7
2553	7	2	2026	Q1	2026-01-01	2026-03-31	927765000.0000	USD	us-gaap:CostOfRevenue	179
2554	7	2	2026	Q2	2026-04-01	2026-06-30	1153012000.0000	USD	us-gaap:CostOfRevenue	180
2555	7	2	2026	Q3	2026-07-01	2026-09-30	1252373000.0000	USD	us-gaap:CostOfRevenue	181
2556	7	3	2019	Q1	2019-01-01	2019-03-31	283486000.0000	USD	us-gaap:GrossProfit	156
2557	7	3	2019	Q2	2019-04-01	2019-06-30	325914000.0000	USD	us-gaap:GrossProfit	157
2558	7	3	2019	Q3	2019-07-01	2019-09-30	309867000.0000	USD	us-gaap:GrossProfit	158
2559	7	3	2019	FY	2019-01-01	2019-12-31	1257778000.0000	USD	us-gaap:GrossProfit	159
2560	7	3	2019	Q4	2019-10-01	2019-12-31	338511000.0000	USD	us-gaap:GrossProfit	160
2561	7	3	2020	Q1	2020-01-01	2020-03-31	242018000.0000	USD	us-gaap:GrossProfit	161
2562	7	3	2020	Q2	2020-04-01	2020-06-30	233359000.0000	USD	us-gaap:GrossProfit	162
2563	7	3	2020	Q3	2020-07-01	2020-09-30	254056000.0000	USD	us-gaap:GrossProfit	163
2564	7	3	2020	FY	2020-01-01	2020-12-31	994853000.0000	USD	us-gaap:GrossProfit	164
2565	7	3	2021	Q1	2021-01-01	2021-03-31	263687000.0000	USD	us-gaap:GrossProfit	165
2566	7	3	2021	Q2	2021-04-01	2021-06-30	248417000.0000	USD	us-gaap:GrossProfit	166
2567	7	3	2021	Q3	2021-07-01	2021-09-30	249273000.0000	USD	us-gaap:GrossProfit	167
2568	7	3	2021	FY	2021-01-01	2021-12-31	997971000.0000	USD	us-gaap:GrossProfit	168
2569	7	3	2022	Q1	2022-01-01	2022-03-31	449030000.0000	USD	us-gaap:GrossProfit	169
2570	7	3	2022	Q2	2022-04-01	2022-06-30	580424000.0000	USD	us-gaap:GrossProfit	170
2571	7	3	2022	Q3	2022-07-01	2022-09-30	1043814000.0000	USD	us-gaap:GrossProfit	171
2572	7	3	2022	FY	2022-01-01	2022-12-31	3074587000.0000	USD	us-gaap:GrossProfit	172
2573	7	3	2023	Q1	2023-01-01	2023-03-31	1276540000.0000	USD	us-gaap:GrossProfit	173
2574	7	3	2023	Q2	2023-04-01	2023-06-30	558487000.0000	USD	us-gaap:GrossProfit	174
2575	7	3	2023	Q3	2023-07-01	2023-09-30	54934000.0000	USD	us-gaap:GrossProfit	175
2576	7	3	2023	FY	2023-01-01	2023-12-31	1185909000.0000	USD	us-gaap:GrossProfit	7
2577	7	3	2024	Q1	2024-01-01	2024-03-31	38938000.0000	USD	us-gaap:GrossProfit	176
2578	7	3	2024	Q2	2024-04-01	2024-06-30	-10578000.0000	USD	us-gaap:GrossProfit	177
2579	7	3	2024	Q3	2024-07-01	2024-09-30	-104034000.0000	USD	us-gaap:GrossProfit	178
2580	7	3	2024	FY	2024-01-01	2024-12-31	62539000.0000	USD	us-gaap:GrossProfit	7
2581	7	3	2025	Q1	2025-01-01	2025-03-31	156299000.0000	USD	us-gaap:GrossProfit	179
2582	7	3	2025	Q2	2025-04-01	2025-06-30	196876000.0000	USD	us-gaap:GrossProfit	180
2583	7	3	2025	Q3	2025-07-01	2025-09-30	117610000.0000	USD	us-gaap:GrossProfit	181
2584	7	3	2025	FY	2025-01-01	2025-12-31	668719000.0000	USD	us-gaap:GrossProfit	7
2585	7	3	2026	Q1	2026-01-01	2026-03-31	500966000.0000	USD	us-gaap:GrossProfit	179
2586	7	3	2026	Q2	2026-04-01	2026-06-30	590301000.0000	USD	us-gaap:GrossProfit	180
2587	7	3	2026	Q3	2026-07-01	2026-09-30	300724000.0000	USD	us-gaap:GrossProfit	181
2588	7	4	2019	Q1	2019-01-01	2019-03-31	155154000.0000	USD	us-gaap:OperatingIncomeLoss	156
2589	7	4	2019	Q2	2019-04-01	2019-06-30	185737000.0000	USD	us-gaap:OperatingIncomeLoss	157
2590	7	4	2019	Q3	2019-07-01	2019-09-30	186147000.0000	USD	us-gaap:OperatingIncomeLoss	158
2591	7	4	2019	FY	2019-01-01	2019-12-31	666123000.0000	USD	us-gaap:OperatingIncomeLoss	159
2592	7	4	2020	Q1	2020-01-01	2020-03-31	124044000.0000	USD	us-gaap:OperatingIncomeLoss	161
2593	7	4	2020	Q2	2020-04-01	2020-06-30	112200000.0000	USD	us-gaap:OperatingIncomeLoss	162
2594	7	4	2020	Q3	2020-07-01	2020-09-30	144432000.0000	USD	us-gaap:OperatingIncomeLoss	163
2595	7	4	2020	FY	2020-01-01	2020-12-31	505812000.0000	USD	us-gaap:OperatingIncomeLoss	164
2596	7	4	2021	Q1	2021-01-01	2021-03-31	155864000.0000	USD	us-gaap:OperatingIncomeLoss	165
2597	7	4	2021	Q2	2021-04-01	2021-06-30	542333000.0000	USD	us-gaap:OperatingIncomeLoss	166
2598	7	4	2021	Q3	2021-07-01	2021-09-30	131523000.0000	USD	us-gaap:OperatingIncomeLoss	167
2599	7	4	2021	FY	2021-01-01	2021-12-31	798434000.0000	USD	us-gaap:OperatingIncomeLoss	168
2600	7	4	2022	Q1	2022-01-01	2022-03-31	311979000.0000	USD	us-gaap:OperatingIncomeLoss	169
2601	7	4	2022	Q2	2022-04-01	2022-06-30	434096000.0000	USD	us-gaap:OperatingIncomeLoss	170
2602	7	4	2022	Q3	2022-07-01	2022-09-30	890977000.0000	USD	us-gaap:OperatingIncomeLoss	171
2603	7	4	2022	FY	2022-01-01	2022-12-31	2470061000.0000	USD	us-gaap:OperatingIncomeLoss	172
2604	7	4	2023	Q1	2023-01-01	2023-03-31	1101763000.0000	USD	us-gaap:OperatingIncomeLoss	173
2605	7	4	2023	Q2	2023-04-01	2023-06-30	139998000.0000	USD	us-gaap:OperatingIncomeLoss	174
2606	7	4	2023	Q3	2023-07-01	2023-09-30	-140014000.0000	USD	us-gaap:OperatingIncomeLoss	175
2607	7	4	2023	FY	2023-01-01	2023-12-31	251881000.0000	USD	us-gaap:OperatingIncomeLoss	7
2608	7	4	2024	Q1	2024-01-01	2024-03-31	-179506000.0000	USD	us-gaap:OperatingIncomeLoss	176
2609	7	4	2024	Q2	2024-04-01	2024-06-30	-492611000.0000	USD	us-gaap:OperatingIncomeLoss	177
2610	7	4	2024	Q3	2024-07-01	2024-09-30	-1108830000.0000	USD	us-gaap:OperatingIncomeLoss	178
2611	7	4	2024	FY	2024-01-01	2024-12-31	-1776545000.0000	USD	us-gaap:OperatingIncomeLoss	7
2612	7	4	2025	Q1	2025-01-01	2025-03-31	19761000.0000	USD	us-gaap:OperatingIncomeLoss	179
2613	7	4	2025	Q2	2025-04-01	2025-06-30	47527000.0000	USD	us-gaap:OperatingIncomeLoss	180
2614	7	4	2025	Q3	2025-07-01	2025-09-30	-216986000.0000	USD	us-gaap:OperatingIncomeLoss	181
2615	7	4	2025	FY	2025-01-01	2025-12-31	-367084000.0000	USD	us-gaap:OperatingIncomeLoss	7
2616	7	4	2026	Q1	2026-01-01	2026-03-31	233506000.0000	USD	us-gaap:OperatingIncomeLoss	179
2617	7	4	2026	Q2	2026-04-01	2026-06-30	452944000.0000	USD	us-gaap:OperatingIncomeLoss	180
2618	7	4	2026	Q3	2026-07-01	2026-09-30	148160000.0000	USD	us-gaap:OperatingIncomeLoss	181
2619	7	5	2019	Q1	2019-01-01	2019-03-31	133569000.0000	USD	us-gaap:NetIncomeLoss	156
2620	7	5	2019	Q2	2019-04-01	2019-06-30	154198000.0000	USD	us-gaap:NetIncomeLoss	157
2621	7	5	2019	Q3	2019-07-01	2019-09-30	155070000.0000	USD	us-gaap:NetIncomeLoss	158
2622	7	5	2019	FY	2019-01-01	2019-12-31	533228000.0000	USD	us-gaap:NetIncomeLoss	159
2623	7	5	2019	Q4	2019-10-01	2019-12-31	90391000.0000	USD	us-gaap:NetIncomeLoss	160
2624	7	5	2020	Q1	2020-01-01	2020-03-31	107204000.0000	USD	us-gaap:NetIncomeLoss	161
2625	7	5	2020	Q2	2020-04-01	2020-06-30	85624000.0000	USD	us-gaap:NetIncomeLoss	162
2626	7	5	2020	Q3	2020-07-01	2020-09-30	98301000.0000	USD	us-gaap:NetIncomeLoss	163
2627	7	5	2020	FY	2020-01-01	2020-12-31	375764000.0000	USD	us-gaap:NetIncomeLoss	164
2628	7	5	2021	Q1	2021-01-01	2021-03-31	95677000.0000	USD	us-gaap:NetIncomeLoss	165
2629	7	5	2021	Q2	2021-04-01	2021-06-30	424600000.0000	USD	us-gaap:NetIncomeLoss	166
2630	7	5	2021	Q3	2021-07-01	2021-09-30	-392781000.0000	USD	us-gaap:NetIncomeLoss	167
2631	7	5	2021	FY	2021-01-01	2021-12-31	123672000.0000	USD	us-gaap:NetIncomeLoss	168
2632	7	5	2022	Q1	2022-01-01	2022-03-31	253383000.0000	USD	us-gaap:NetIncomeLoss	169
2633	7	5	2022	Q2	2022-04-01	2022-06-30	406773000.0000	USD	us-gaap:NetIncomeLoss	170
2634	7	5	2022	Q3	2022-07-01	2022-09-30	897215000.0000	USD	us-gaap:NetIncomeLoss	171
2635	7	5	2022	FY	2022-01-01	2022-12-31	2689816000.0000	USD	us-gaap:NetIncomeLoss	172
2636	7	5	2023	Q1	2023-01-01	2023-03-31	1238580000.0000	USD	us-gaap:NetIncomeLoss	173
2637	7	5	2023	Q2	2023-04-01	2023-06-30	650043000.0000	USD	us-gaap:NetIncomeLoss	174
2638	7	5	2023	Q3	2023-07-01	2023-09-30	302533000.0000	USD	us-gaap:NetIncomeLoss	175
2639	7	5	2023	FY	2023-01-01	2023-12-31	1573476000.0000	USD	us-gaap:NetIncomeLoss	7
2640	7	5	2024	Q1	2024-01-01	2024-03-31	2448000.0000	USD	us-gaap:NetIncomeLoss	176
2641	7	5	2024	Q2	2024-04-01	2024-06-30	-188198000.0000	USD	us-gaap:NetIncomeLoss	177
2642	7	5	2024	Q3	2024-07-01	2024-09-30	-1068992000.0000	USD	us-gaap:NetIncomeLoss	178
2643	7	5	2024	FY	2024-01-01	2024-12-31	-1179449000.0000	USD	us-gaap:NetIncomeLoss	7
2644	7	5	2025	Q1	2025-01-01	2025-03-31	41348000.0000	USD	us-gaap:NetIncomeLoss	179
2645	7	5	2025	Q2	2025-04-01	2025-06-30	22897000.0000	USD	us-gaap:NetIncomeLoss	180
2646	7	5	2025	Q3	2025-07-01	2025-09-30	-160694000.0000	USD	us-gaap:NetIncomeLoss	181
2647	7	5	2025	FY	2025-01-01	2025-12-31	-510628000.0000	USD	us-gaap:NetIncomeLoss	7
2648	7	5	2026	Q1	2026-01-01	2026-03-31	319091000.0000	USD	us-gaap:NetIncomeLoss	179
2649	7	5	2026	Q2	2026-04-01	2026-06-30	479959000.0000	USD	us-gaap:NetIncomeLoss	180
2650	7	5	2026	Q3	2026-07-01	2026-09-30	296755000.0000	USD	us-gaap:NetIncomeLoss	181
2651	7	6	2019	Q1	2019-01-01	2019-03-31	54916000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	156
2652	7	6	2019	FY	2019-01-01	2019-12-31	719374000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	159
2653	7	6	2020	Q1	2020-01-01	2020-03-31	155054000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	161
2654	7	6	2020	FY	2020-01-01	2020-12-31	798914000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	164
2655	7	6	2021	Q1	2021-01-01	2021-03-31	157949000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	165
2656	7	6	2021	FY	2021-01-01	2021-12-31	344257000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	168
2657	7	6	2022	Q1	2022-01-01	2022-03-31	206176000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	169
2658	7	6	2022	FY	2022-01-01	2022-12-31	1912416000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	177
2659	7	6	2023	Q1	2023-01-01	2023-03-31	720980000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	173
2660	7	6	2023	FY	2023-01-01	2023-12-31	1326583000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	7
2661	7	6	2024	Q1	2024-01-01	2024-03-31	97485000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	177
2662	7	6	2024	FY	2024-01-01	2024-12-31	687876000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	7
2663	7	6	2025	Q1	2025-01-01	2025-03-31	547207000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	179
2664	7	6	2025	FY	2025-01-01	2025-12-31	1282267000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	7
2665	7	6	2026	Q1	2026-01-01	2026-03-31	346244000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	179
2666	7	7	2019	Q1	2019-01-01	2019-03-31	216132000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	156
2667	7	7	2019	FY	2019-01-01	2019-12-31	851796000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	159
2668	7	7	2020	Q1	2020-01-01	2020-03-31	214529000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	161
2669	7	7	2020	FY	2020-01-01	2020-12-31	850477000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	164
2670	7	7	2021	Q1	2021-01-01	2021-03-31	179683000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	165
2671	7	7	2021	FY	2021-01-01	2021-12-31	953667000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	168
2672	7	7	2022	Q1	2022-01-01	2022-03-31	231698000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	169
2673	7	7	2022	FY	2022-01-01	2022-12-31	1261646000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	172
2674	7	7	2023	Q1	2023-01-01	2023-03-31	415608000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	173
2675	7	7	2023	FY	2023-01-01	2023-12-31	2154542000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	7
2676	7	7	2024	Q1	2024-01-01	2024-03-31	583042000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	177
2677	7	7	2024	FY	2024-01-01	2024-12-31	1680529000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	7
2678	7	7	2025	Q1	2025-01-01	2025-03-31	182624000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	179
2679	7	7	2025	FY	2025-01-01	2025-12-31	589801000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	7
2680	7	7	2026	Q1	2026-01-01	2026-03-31	98676000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	179
2681	7	8	2019	Q1	\N	2019-03-31	7871062000.0000	USD	us-gaap:Assets	182
2682	7	8	2019	Q2	\N	2019-06-30	8094414000.0000	USD	us-gaap:Assets	183
2683	7	8	2019	Q3	\N	2019-09-30	8141603000.0000	USD	us-gaap:Assets	184
2684	7	8	2019	FY	\N	2019-12-31	9860863000.0000	USD	us-gaap:Assets	159
2685	7	8	2020	Q1	\N	2020-03-31	9847638000.0000	USD	us-gaap:Assets	156
2686	7	8	2020	Q2	\N	2020-06-30	10170253000.0000	USD	us-gaap:Assets	157
2687	7	8	2020	Q3	\N	2020-09-30	10231983000.0000	USD	us-gaap:Assets	158
2688	7	8	2020	FY	\N	2020-12-31	10450946000.0000	USD	us-gaap:Assets	164
2689	7	8	2021	Q1	\N	2021-03-31	10290302000.0000	USD	us-gaap:Assets	161
2690	7	8	2021	Q2	\N	2021-06-30	10796926000.0000	USD	us-gaap:Assets	162
2691	7	8	2021	Q3	\N	2021-09-30	10832325000.0000	USD	us-gaap:Assets	163
2692	7	8	2021	FY	\N	2021-12-31	10974118000.0000	USD	us-gaap:Assets	168
2693	7	8	2022	Q1	\N	2022-03-31	11416058000.0000	USD	us-gaap:Assets	165
2694	7	8	2022	Q2	\N	2022-06-30	12520405000.0000	USD	us-gaap:Assets	166
2695	7	8	2022	Q3	\N	2022-09-30	13828502000.0000	USD	us-gaap:Assets	167
2696	7	8	2022	FY	\N	2022-12-31	15456522000.0000	USD	us-gaap:Assets	172
2697	7	8	2023	Q1	\N	2023-03-31	17564358000.0000	USD	us-gaap:Assets	169
2698	7	8	2023	Q2	\N	2023-06-30	19109668000.0000	USD	us-gaap:Assets	170
2699	7	8	2023	Q3	\N	2023-09-30	18883354000.0000	USD	us-gaap:Assets	171
2700	7	8	2023	FY	\N	2023-12-31	18270652000.0000	USD	us-gaap:Assets	7
2701	7	8	2024	Q1	\N	2024-03-31	19032333000.0000	USD	us-gaap:Assets	173
2702	7	8	2024	Q2	\N	2024-06-30	18388282000.0000	USD	us-gaap:Assets	174
2703	7	8	2024	Q3	\N	2024-09-30	17455186000.0000	USD	us-gaap:Assets	175
2704	7	8	2024	FY	\N	2024-12-31	16609649000.0000	USD	us-gaap:Assets	7
2705	7	8	2025	Q1	\N	2025-03-31	16999258000.0000	USD	us-gaap:Assets	176
2706	7	8	2025	Q2	\N	2025-06-30	17291927000.0000	USD	us-gaap:Assets	177
2707	7	8	2025	Q3	\N	2025-09-30	17148285000.0000	USD	us-gaap:Assets	178
2708	7	8	2025	FY	\N	2025-12-31	16374211000.0000	USD	us-gaap:Assets	181
2709	7	8	2026	Q1	\N	2026-03-31	15139578000.0000	USD	us-gaap:Assets	179
2710	7	8	2026	Q2	\N	2026-06-30	15905095000.0000	USD	us-gaap:Assets	180
2711	7	8	2026	Q3	\N	2026-09-30	16083315000.0000	USD	us-gaap:Assets	181
2712	7	10	2019	Q1	\N	2019-03-31	3672274000.0000	USD	us-gaap:StockholdersEquity	182
2713	7	10	2019	Q2	\N	2019-06-30	3800801000.0000	USD	us-gaap:StockholdersEquity	183
2714	7	10	2019	Q3	\N	2019-09-30	3836559000.0000	USD	us-gaap:StockholdersEquity	184
2715	7	10	2019	FY	\N	2019-12-31	3932250000.0000	USD	us-gaap:StockholdersEquity	185
2716	7	10	2020	Q1	\N	2020-03-31	3878004000.0000	USD	us-gaap:StockholdersEquity	156
2717	7	10	2020	Q2	\N	2020-06-30	4024472000.0000	USD	us-gaap:StockholdersEquity	157
2718	7	10	2020	Q3	\N	2020-09-30	4124881000.0000	USD	us-gaap:StockholdersEquity	158
2719	7	10	2020	FY	\N	2020-12-31	4268227000.0000	USD	us-gaap:StockholdersEquity	159
2720	7	10	2021	Q1	\N	2021-03-31	5746384000.0000	USD	us-gaap:StockholdersEquity	161
2721	7	10	2021	Q2	\N	2021-06-30	6165549000.0000	USD	us-gaap:StockholdersEquity	162
2722	7	10	2021	Q3	\N	2021-09-30	5694116000.0000	USD	us-gaap:StockholdersEquity	163
2723	7	10	2021	FY	\N	2021-12-31	5625266000.0000	USD	us-gaap:StockholdersEquity	164
2724	7	10	2022	Q1	\N	2022-03-31	5826600000.0000	USD	us-gaap:StockholdersEquity	165
2725	7	10	2022	Q2	\N	2022-06-30	6085291000.0000	USD	us-gaap:StockholdersEquity	166
2726	7	10	2022	Q3	\N	2022-09-30	6732636000.0000	USD	us-gaap:StockholdersEquity	167
2727	7	10	2022	FY	\N	2022-12-31	7982627000.0000	USD	us-gaap:StockholdersEquity	168
2728	7	10	2023	Q1	\N	2023-03-31	9212735000.0000	USD	us-gaap:StockholdersEquity	169
2729	7	10	2023	Q2	\N	2023-06-30	9815309000.0000	USD	us-gaap:StockholdersEquity	170
2730	7	10	2023	Q3	\N	2023-09-30	9897815000.0000	USD	us-gaap:StockholdersEquity	171
2731	7	10	2023	FY	\N	2023-12-31	9412180000.0000	USD	us-gaap:StockholdersEquity	172
2732	7	10	2024	Q1	\N	2024-03-31	11532802000.0000	USD	us-gaap:StockholdersEquity	173
2733	7	10	2024	Q2	\N	2024-06-30	11222559000.0000	USD	us-gaap:StockholdersEquity	174
2734	7	10	2024	Q3	\N	2024-09-30	10240595000.0000	USD	us-gaap:StockholdersEquity	175
2735	7	10	2024	FY	\N	2024-12-31	9961517000.0000	USD	us-gaap:StockholdersEquity	7
2736	7	10	2025	Q1	\N	2025-03-31	10028239000.0000	USD	us-gaap:StockholdersEquity	176
2737	7	10	2025	Q2	\N	2025-06-30	10240526000.0000	USD	us-gaap:StockholdersEquity	177
2738	7	10	2025	Q3	\N	2025-09-30	9996113000.0000	USD	us-gaap:StockholdersEquity	178
2739	7	10	2025	FY	\N	2025-12-31	9533365000.0000	USD	us-gaap:StockholdersEquity	181
2740	7	10	2026	Q1	\N	2026-03-31	9850174000.0000	USD	us-gaap:StockholdersEquity	179
2741	7	10	2026	Q2	\N	2026-06-30	10275169000.0000	USD	us-gaap:StockholdersEquity	180
2742	7	10	2026	Q3	\N	2026-09-30	10541570000.0000	USD	us-gaap:StockholdersEquity	181
2743	7	11	2019	Q1	\N	2019-03-31	465274000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	156
2744	7	11	2019	Q2	\N	2019-06-30	398183000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	183
2745	7	11	2019	Q3	\N	2019-09-30	317823000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	184
2746	7	11	2019	FY	\N	2019-12-31	613110000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	158
2747	7	11	2020	Q1	\N	2020-03-31	553228000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	156
2748	7	11	2020	Q2	\N	2020-06-30	736696000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	157
2749	7	11	2020	Q3	\N	2020-09-30	702073000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	158
2750	7	11	2020	FY	\N	2020-12-31	746724000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	163
2751	7	11	2021	Q1	\N	2021-03-31	569859000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	161
2752	7	11	2021	Q2	\N	2021-06-30	823572000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	162
2753	7	11	2021	Q3	\N	2021-09-30	595049000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	163
2754	7	11	2021	FY	\N	2021-12-31	439272000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	167
2755	7	11	2022	Q1	\N	2022-03-31	463325000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	165
2756	7	11	2022	Q2	\N	2022-06-30	930596000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	166
2757	7	11	2022	Q3	\N	2022-09-30	1382803000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	167
2758	7	11	2022	FY	\N	2022-12-31	1499142000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	171
2759	7	11	2023	Q1	\N	2023-03-31	1586734000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	169
2760	7	11	2023	Q2	\N	2023-06-30	1599738000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	170
2761	7	11	2023	Q3	\N	2023-09-30	1601668000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	171
2762	7	11	2023	FY	\N	2023-12-31	889900000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	175
2763	7	11	2024	Q1	\N	2024-03-31	2055813000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	173
2764	7	11	2024	Q2	\N	2024-06-30	1830227000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	174
2765	7	11	2024	Q3	\N	2024-09-30	1664519000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	175
2766	7	11	2024	FY	\N	2024-12-31	1192230000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	178
2767	7	11	2025	Q1	\N	2025-03-31	1518511000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	176
2768	7	11	2025	Q2	\N	2025-06-30	1806829000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	177
2769	7	11	2025	Q3	\N	2025-09-30	1931758000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	178
2770	7	11	2025	FY	\N	2025-12-31	1618001000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	181
2771	7	11	2026	Q1	\N	2026-03-31	1089809000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	179
2772	7	11	2026	Q2	\N	2026-06-30	1631688000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	180
2773	7	11	2026	Q3	\N	2026-09-30	1845999000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	181
2774	7	12	2019	Q1	\N	2019-03-31	1393904000.0000	USD	us-gaap:LongTermDebtNoncurrent	182
2775	7	12	2019	Q2	\N	2019-06-30	1398419000.0000	USD	us-gaap:LongTermDebtNoncurrent	183
2776	7	12	2019	Q3	\N	2019-09-30	1381984000.0000	USD	us-gaap:LongTermDebtNoncurrent	184
2777	7	12	2019	FY	\N	2019-12-31	2862921000.0000	USD	us-gaap:LongTermDebtNoncurrent	185
2778	7	12	2020	Q1	\N	2020-03-31	3105225000.0000	USD	us-gaap:LongTermDebtNoncurrent	156
2779	7	12	2020	Q2	\N	2020-06-30	3132191000.0000	USD	us-gaap:LongTermDebtNoncurrent	157
2780	7	12	2020	Q3	\N	2020-09-30	2940533000.0000	USD	us-gaap:LongTermDebtNoncurrent	158
2781	7	12	2020	FY	\N	2020-12-31	2767381000.0000	USD	us-gaap:LongTermDebtNoncurrent	159
2782	7	12	2021	Q1	\N	2021-03-31	2030032000.0000	USD	us-gaap:LongTermDebtNoncurrent	161
2783	7	12	2021	Q2	\N	2021-06-30	2043794000.0000	USD	us-gaap:LongTermDebtNoncurrent	162
2784	7	12	2021	Q3	\N	2021-09-30	2021487000.0000	USD	us-gaap:LongTermDebtNoncurrent	163
2785	7	12	2021	FY	\N	2021-12-31	2004319000.0000	USD	us-gaap:LongTermDebtNoncurrent	164
2786	7	12	2022	Q1	\N	2022-03-31	1985696000.0000	USD	us-gaap:LongTermDebtNoncurrent	165
2787	7	12	2022	Q2	\N	2022-06-30	3205730000.0000	USD	us-gaap:LongTermDebtNoncurrent	166
2788	7	12	2022	Q3	\N	2022-09-30	3118753000.0000	USD	us-gaap:LongTermDebtNoncurrent	167
2789	7	12	2022	FY	\N	2022-12-31	3214972000.0000	USD	us-gaap:LongTermDebtNoncurrent	168
2790	7	12	2023	Q1	\N	2023-03-31	3233393000.0000	USD	us-gaap:LongTermDebtNoncurrent	169
2791	7	12	2023	Q2	\N	2023-06-30	3509289000.0000	USD	us-gaap:LongTermDebtNoncurrent	170
2792	7	12	2023	Q3	\N	2023-09-30	3495971000.0000	USD	us-gaap:LongTermDebtNoncurrent	171
2793	7	12	2023	FY	\N	2023-12-31	3541002000.0000	USD	us-gaap:LongTermDebtNoncurrent	172
2794	7	12	2024	Q1	\N	2024-03-31	3519453000.0000	USD	us-gaap:LongTermDebtNoncurrent	173
2795	7	12	2024	Q2	\N	2024-06-30	3519504000.0000	USD	us-gaap:LongTermDebtNoncurrent	174
2796	7	12	2024	Q3	\N	2024-09-30	3565990000.0000	USD	us-gaap:LongTermDebtNoncurrent	175
2797	7	12	2024	FY	\N	2024-12-31	3118142000.0000	USD	us-gaap:LongTermDebtNoncurrent	7
2798	7	12	2025	Q1	\N	2025-03-31	3128655000.0000	USD	us-gaap:LongTermDebtNoncurrent	176
2799	7	12	2025	Q2	\N	2025-06-30	3178111000.0000	USD	us-gaap:LongTermDebtNoncurrent	177
2800	7	12	2025	Q3	\N	2025-09-30	3181009000.0000	USD	us-gaap:LongTermDebtNoncurrent	178
2801	7	12	2025	FY	\N	2025-12-31	3119464000.0000	USD	us-gaap:LongTermDebtNoncurrent	181
2802	7	12	2026	Q1	\N	2026-03-31	1807203000.0000	USD	us-gaap:LongTermDebtNoncurrent	179
2803	7	12	2026	Q2	\N	2026-06-30	1802107000.0000	USD	us-gaap:LongTermDebtNoncurrent	180
2804	7	12	2026	Q3	\N	2026-09-30	1806750000.0000	USD	us-gaap:LongTermDebtNoncurrent	181
2805	7	13	2019	Q1	\N	2019-03-31	756193000.0000	USD	us-gaap:InventoryNet	182
2806	7	13	2019	Q2	\N	2019-06-30	814022000.0000	USD	us-gaap:InventoryNet	183
2807	7	13	2019	Q3	\N	2019-09-30	802434000.0000	USD	us-gaap:InventoryNet	184
2808	7	13	2019	FY	\N	2019-12-31	768984000.0000	USD	us-gaap:InventoryNet	185
2809	7	13	2020	Q1	\N	2020-03-31	853500000.0000	USD	us-gaap:InventoryNet	156
2810	7	13	2020	Q2	\N	2020-06-30	851256000.0000	USD	us-gaap:InventoryNet	157
2811	7	13	2020	Q3	\N	2020-09-30	828080000.0000	USD	us-gaap:InventoryNet	158
2812	7	13	2020	FY	\N	2020-12-31	750237000.0000	USD	us-gaap:InventoryNet	159
2813	7	13	2021	Q1	\N	2021-03-31	685779000.0000	USD	us-gaap:InventoryNet	161
2814	7	13	2021	Q2	\N	2021-06-30	732563000.0000	USD	us-gaap:InventoryNet	162
2815	7	13	2021	Q3	\N	2021-09-30	745598000.0000	USD	us-gaap:InventoryNet	163
2816	7	13	2021	FY	\N	2021-12-31	798620000.0000	USD	us-gaap:InventoryNet	164
2817	7	13	2022	Q1	\N	2022-03-31	1013793000.0000	USD	us-gaap:InventoryNet	165
2818	7	13	2022	Q2	\N	2022-06-30	1216213000.0000	USD	us-gaap:InventoryNet	166
2819	7	13	2022	Q3	\N	2022-09-30	1614299000.0000	USD	us-gaap:InventoryNet	167
2820	7	13	2022	FY	\N	2022-12-31	2076031000.0000	USD	us-gaap:InventoryNet	168
2821	7	13	2023	Q1	\N	2023-03-31	3180825000.0000	USD	us-gaap:InventoryNet	169
2822	7	13	2023	Q2	\N	2023-06-30	3658623000.0000	USD	us-gaap:InventoryNet	170
2823	7	13	2023	Q3	\N	2023-09-30	3404212000.0000	USD	us-gaap:InventoryNet	171
2824	7	13	2023	FY	\N	2023-12-31	2161287000.0000	USD	us-gaap:InventoryNet	172
2825	7	13	2024	Q1	\N	2024-03-31	1904827000.0000	USD	us-gaap:InventoryNet	173
2826	7	13	2024	Q2	\N	2024-06-30	1800114000.0000	USD	us-gaap:InventoryNet	174
2827	7	13	2024	Q3	\N	2024-09-30	1657688000.0000	USD	us-gaap:InventoryNet	175
2828	7	13	2024	FY	\N	2024-12-31	1502531000.0000	USD	us-gaap:InventoryNet	7
2829	7	13	2025	Q1	\N	2025-03-31	1656365000.0000	USD	us-gaap:InventoryNet	176
2830	7	13	2025	Q2	\N	2025-06-30	1640925000.0000	USD	us-gaap:InventoryNet	177
2831	7	13	2025	Q3	\N	2025-09-30	1532622000.0000	USD	us-gaap:InventoryNet	178
2832	7	13	2025	FY	\N	2025-12-31	1179271000.0000	USD	us-gaap:InventoryNet	181
2833	7	13	2026	Q1	\N	2026-03-31	1346960000.0000	USD	us-gaap:InventoryNet	179
2834	7	13	2026	Q2	\N	2026-06-30	1384563000.0000	USD	us-gaap:InventoryNet	180
2835	7	13	2026	Q3	\N	2026-09-30	1392595000.0000	USD	us-gaap:InventoryNet	181
3053	8	1	2025	FY	2025-01-01	2025-12-31	67589000000.0000	USD	us-gaap:Revenues	203
2836	7	14	2019	Q1	2019-01-01	2019-03-31	14977000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	156
2837	7	14	2019	Q2	2019-04-01	2019-06-30	13462000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	157
2838	7	14	2019	Q3	2019-07-01	2019-09-30	15585000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	158
2839	7	14	2019	FY	2019-01-01	2019-12-31	58287000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	159
2840	7	14	2020	Q1	2020-01-01	2020-03-31	16097000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	161
2841	7	14	2020	Q2	2020-04-01	2020-06-30	14210000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	162
2842	7	14	2020	Q3	2020-07-01	2020-09-30	13532000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	163
2843	7	14	2020	FY	2020-01-01	2020-12-31	59214000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	164
2844	7	14	2021	Q1	2021-01-01	2021-03-31	14636000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	165
2845	7	14	2021	Q2	2021-04-01	2021-06-30	13976000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	166
2846	7	14	2021	Q3	2021-07-01	2021-09-30	13289000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	167
2847	7	14	2021	FY	2021-01-01	2021-12-31	54026000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	168
2848	7	14	2022	Q1	2022-01-01	2022-03-31	16083000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	169
2849	7	14	2022	Q2	2022-04-01	2022-06-30	17386000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	170
2850	7	14	2022	Q3	2022-07-01	2022-09-30	18358000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	171
2851	7	14	2022	FY	2022-01-01	2022-12-31	71981000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	172
2852	7	14	2023	Q1	2023-01-01	2023-03-31	20471000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	173
2853	7	14	2023	Q2	2023-04-01	2023-06-30	21419000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	174
2854	7	14	2023	Q3	2023-07-01	2023-09-30	21082000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	175
2855	7	14	2023	FY	2023-01-01	2023-12-31	85725000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	7
2856	7	14	2024	Q1	2024-01-01	2024-03-31	23532000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	176
2857	7	14	2024	Q2	2024-04-01	2024-06-30	20770000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	177
2858	7	14	2024	Q3	2024-07-01	2024-09-30	22397000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	178
2859	7	14	2024	FY	2024-01-01	2024-12-31	86720000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	7
2860	7	14	2025	Q1	2025-01-01	2025-03-31	14099000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	179
2861	7	14	2025	Q2	2025-04-01	2025-06-30	12444000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	180
2862	7	14	2025	Q3	2025-07-01	2025-09-30	12674000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	181
2863	7	14	2025	FY	2025-01-01	2025-12-31	51398000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	7
2864	7	14	2026	Q1	2026-01-01	2026-03-31	9170000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	179
2865	7	14	2026	Q2	2026-04-01	2026-06-30	3667000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	180
2866	7	14	2026	Q3	2026-07-01	2026-09-30	8173000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	181
2867	7	15	2019	Q1	2019-01-01	2019-03-31	5556000.0000	USD	us-gaap:ShareBasedCompensation	156
2868	7	15	2019	FY	2019-01-01	2019-12-31	19680000.0000	USD	us-gaap:ShareBasedCompensation	159
2869	7	15	2020	Q1	2020-01-01	2020-03-31	2501000.0000	USD	us-gaap:ShareBasedCompensation	161
2870	7	15	2020	FY	2020-01-01	2020-12-31	22837000.0000	USD	us-gaap:ShareBasedCompensation	164
2871	7	15	2021	Q1	2021-01-01	2021-03-31	2560000.0000	USD	us-gaap:ShareBasedCompensation	165
2872	7	15	2021	FY	2021-01-01	2021-12-31	20120000.0000	USD	us-gaap:ShareBasedCompensation	168
2873	7	15	2022	Q1	2022-01-01	2022-03-31	4245000.0000	USD	us-gaap:ShareBasedCompensation	169
2874	7	15	2022	FY	2022-01-01	2022-12-31	30474000.0000	USD	us-gaap:ShareBasedCompensation	172
2875	7	15	2023	Q1	2023-01-01	2023-03-31	10540000.0000	USD	us-gaap:ShareBasedCompensation	173
2876	7	15	2023	FY	2023-01-01	2023-12-31	36545000.0000	USD	us-gaap:ShareBasedCompensation	7
2877	7	15	2024	Q1	2024-01-01	2024-03-31	9317000.0000	USD	us-gaap:ShareBasedCompensation	176
2878	7	15	2024	FY	2024-01-01	2024-12-31	32141000.0000	USD	us-gaap:ShareBasedCompensation	7
2879	7	15	2025	Q1	2025-01-01	2025-03-31	6966000.0000	USD	us-gaap:ShareBasedCompensation	179
2880	7	15	2025	FY	2025-01-01	2025-12-31	40271000.0000	USD	us-gaap:ShareBasedCompensation	7
2881	7	15	2026	Q1	2026-01-01	2026-03-31	7883000.0000	USD	us-gaap:ShareBasedCompensation	179
2882	7	16	2019	Q1	2019-01-01	2019-03-31	49283000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	156
2883	7	16	2019	Q2	2019-04-01	2019-06-30	52948000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	157
2884	7	16	2019	Q3	2019-07-01	2019-09-30	54487000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	158
2885	7	16	2019	FY	2019-01-01	2019-12-31	213484000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	159
2886	7	16	2020	Q1	2020-01-01	2020-03-31	53694000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	161
2887	7	16	2020	Q2	2020-04-01	2020-06-30	57841000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	162
2888	7	16	2020	Q3	2020-07-01	2020-09-30	58679000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	163
2889	7	16	2020	FY	2020-01-01	2020-12-31	231984000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	164
2890	7	16	2021	Q1	2021-01-01	2021-03-31	62260000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	165
2891	7	16	2021	Q2	2021-04-01	2021-06-30	61423000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	166
2892	7	16	2021	Q3	2021-07-01	2021-09-30	62082000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	167
2893	7	16	2021	FY	2021-01-01	2021-12-31	254000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	168
2894	7	16	2022	Q1	2022-01-01	2022-03-31	66574000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	169
2895	7	16	2022	Q2	2022-04-01	2022-06-30	70993000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	170
2896	7	16	2022	Q3	2022-07-01	2022-09-30	77713000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	171
2897	7	16	2022	FY	2022-01-01	2022-12-31	300841000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	172
2898	7	16	2023	Q1	2023-01-01	2023-03-31	87271000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	173
2899	7	16	2023	Q2	2023-04-01	2023-06-30	93085000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	174
2900	7	16	2023	Q3	2023-07-01	2023-09-30	105445000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	175
2901	7	16	2023	FY	2023-01-01	2023-12-31	429944000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	7
2902	7	16	2024	Q1	2024-01-01	2024-03-31	123751000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	176
2903	7	16	2024	Q2	2024-04-01	2024-06-30	138279000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	177
2904	7	16	2024	Q3	2024-07-01	2024-09-30	163502000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	178
2905	7	16	2024	FY	2024-01-01	2024-12-31	588638000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	7
2906	7	16	2025	Q1	2025-01-01	2025-03-31	161754000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	179
2907	7	16	2025	Q2	2025-04-01	2025-06-30	168731000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	180
2908	7	16	2025	Q3	2025-07-01	2025-09-30	164483000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	181
2909	7	16	2025	FY	2025-01-01	2025-12-31	658678000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	7
2910	7	16	2026	Q1	2026-01-01	2026-03-31	157805000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	179
2911	7	16	2026	Q2	2026-04-01	2026-06-30	155801000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	180
2912	7	16	2026	Q3	2026-07-01	2026-09-30	168404000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	181
2913	7	17	2019	Q1	2019-01-01	2019-03-31	37514000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	156
2914	7	17	2019	Q2	2019-04-01	2019-06-30	30411000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	157
2915	7	17	2019	Q3	2019-07-01	2019-09-30	25341000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	158
2916	7	17	2019	FY	2019-01-01	2019-12-31	88161000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	159
2917	7	17	2020	Q1	2020-01-01	2020-03-31	18442000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	161
2918	7	17	2020	Q2	2020-04-01	2020-06-30	15431000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	162
2919	7	17	2020	Q3	2020-07-01	2020-09-30	30653000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	163
2920	7	17	2020	FY	2020-01-01	2020-12-31	54425000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	164
2921	7	17	2021	Q1	2021-01-01	2021-03-31	22107000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	165
2922	7	17	2021	Q2	2021-04-01	2021-06-30	106985000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	166
2923	7	17	2021	Q3	2021-07-01	2021-09-30	-114670000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	167
2924	7	17	2021	FY	2021-01-01	2021-12-31	29446000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	168
2925	7	17	2022	Q1	2022-01-01	2022-03-31	80530000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	169
2926	7	17	2022	Q2	2022-04-01	2022-06-30	89018000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	170
2927	7	17	2022	Q3	2022-07-01	2022-09-30	196938000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	171
2928	7	17	2022	FY	2022-01-01	2022-12-31	390588000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	172
2929	7	17	2023	Q1	2023-01-01	2023-03-31	276963000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	173
2930	7	17	2023	Q2	2023-04-01	2023-06-30	42987000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	174
2931	7	17	2023	Q3	2023-07-01	2023-09-30	-8551000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	175
2932	7	17	2023	FY	2023-01-01	2023-12-31	430277000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	7
2933	7	17	2024	Q1	2024-01-01	2024-03-31	-3721000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	176
2934	7	17	2024	Q2	2024-04-01	2024-06-30	-30660000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	177
2935	7	17	2024	Q3	2024-07-01	2024-09-30	110853000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	178
2936	7	17	2024	FY	2024-01-01	2024-12-31	87085000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	7
2937	7	17	2025	Q1	2025-01-01	2025-03-31	-3978000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	179
2938	7	17	2025	Q2	2025-04-01	2025-06-30	34094000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	180
2939	7	17	2025	Q3	2025-07-01	2025-09-30	-30565000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	181
2940	7	17	2025	FY	2025-01-01	2025-12-31	156881000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	7
2941	7	17	2026	Q1	2026-01-01	2026-03-31	21511000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	179
2942	7	17	2026	Q2	2026-04-01	2026-06-30	94002000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	180
2943	7	17	2026	Q3	2026-07-01	2026-09-30	21900000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	181
2944	7	18	2019	Q1	2019-01-01	2019-03-31	1.2600	USD/shares	us-gaap:EarningsPerShareDiluted	156
2945	7	18	2019	Q2	2019-04-01	2019-06-30	1.4500	USD/shares	us-gaap:EarningsPerShareDiluted	157
2946	7	18	2019	Q3	2019-07-01	2019-09-30	1.4600	USD/shares	us-gaap:EarningsPerShareDiluted	158
2947	7	18	2019	FY	2019-01-01	2019-12-31	5.0200	USD/shares	us-gaap:EarningsPerShareDiluted	159
2948	7	18	2020	Q1	2020-01-01	2020-03-31	1.0100	USD/shares	us-gaap:EarningsPerShareDiluted	161
2949	7	18	2020	Q2	2020-04-01	2020-06-30	0.8000	USD/shares	us-gaap:EarningsPerShareDiluted	162
2950	7	18	2020	Q3	2020-07-01	2020-09-30	0.9200	USD/shares	us-gaap:EarningsPerShareDiluted	163
2951	7	18	2020	FY	2020-01-01	2020-12-31	3.5200	USD/shares	us-gaap:EarningsPerShareDiluted	164
2952	7	18	2021	Q1	2021-01-01	2021-03-31	0.8400	USD/shares	us-gaap:EarningsPerShareDiluted	165
2953	7	18	2021	Q2	2021-04-01	2021-06-30	3.6200	USD/shares	us-gaap:EarningsPerShareDiluted	166
2954	7	18	2021	Q3	2021-07-01	2021-09-30	-3.3600	USD/shares	us-gaap:EarningsPerShareDiluted	167
2955	7	18	2021	FY	2021-01-01	2021-12-31	1.0600	USD/shares	us-gaap:EarningsPerShareDiluted	168
2956	7	18	2022	Q1	2022-01-01	2022-03-31	2.1500	USD/shares	us-gaap:EarningsPerShareDiluted	169
2957	7	18	2022	Q2	2022-04-01	2022-06-30	3.4600	USD/shares	us-gaap:EarningsPerShareDiluted	170
2958	7	18	2022	Q3	2022-07-01	2022-09-30	7.6100	USD/shares	us-gaap:EarningsPerShareDiluted	171
2959	7	18	2022	FY	2022-01-01	2022-12-31	22.8400	USD/shares	us-gaap:EarningsPerShareDiluted	172
2960	7	18	2023	Q1	2023-01-01	2023-03-31	10.5100	USD/shares	us-gaap:EarningsPerShareDiluted	173
2961	7	18	2023	Q2	2023-04-01	2023-06-30	5.5200	USD/shares	us-gaap:EarningsPerShareDiluted	174
2962	7	18	2023	Q3	2023-07-01	2023-09-30	2.5700	USD/shares	us-gaap:EarningsPerShareDiluted	175
2963	7	18	2023	FY	2023-01-01	2023-12-31	13.3600	USD/shares	us-gaap:EarningsPerShareDiluted	7
2964	7	18	2024	Q1	2024-01-01	2024-03-31	-0.0800	USD/shares	us-gaap:EarningsPerShareDiluted	176
2965	7	18	2024	Q2	2024-04-01	2024-06-30	-1.9600	USD/shares	us-gaap:EarningsPerShareDiluted	177
2966	7	18	2024	Q3	2024-07-01	2024-09-30	-9.4500	USD/shares	us-gaap:EarningsPerShareDiluted	178
2967	7	18	2024	FY	2024-01-01	2024-12-31	-11.2000	USD/shares	us-gaap:EarningsPerShareDiluted	7
2968	7	18	2025	Q1	2025-01-01	2025-03-31	0.0000	USD/shares	us-gaap:EarningsPerShareDiluted	179
2969	7	18	2025	Q2	2025-04-01	2025-06-30	-0.1600	USD/shares	us-gaap:EarningsPerShareDiluted	180
2970	7	18	2025	Q3	2025-07-01	2025-09-30	-1.7200	USD/shares	us-gaap:EarningsPerShareDiluted	181
2971	7	18	2025	FY	2025-01-01	2025-12-31	-5.7600	USD/shares	us-gaap:EarningsPerShareDiluted	7
2972	7	18	2026	Q1	2026-01-01	2026-03-31	2.3400	USD/shares	us-gaap:EarningsPerShareDiluted	179
2973	7	18	2026	Q2	2026-04-01	2026-06-30	3.5200	USD/shares	us-gaap:EarningsPerShareDiluted	180
2974	7	18	2026	Q3	2026-07-01	2026-09-30	2.1500	USD/shares	us-gaap:EarningsPerShareDiluted	181
2975	7	19	2019	Q1	2019-01-01	2019-03-31	35387000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	156
2976	7	19	2019	FY	2019-01-01	2019-12-31	152204000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	159
2977	7	19	2020	Q1	2020-01-01	2020-03-31	38982000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	161
2978	7	19	2020	FY	2020-01-01	2020-12-31	161818000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	164
2979	7	19	2021	Q1	2021-01-01	2021-03-31	41130000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	165
2980	7	19	2021	FY	2021-01-01	2021-12-31	177853000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	168
2981	7	19	2022	Q1	2022-01-01	2022-03-31	45637000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	169
2982	7	19	2022	FY	2022-01-01	2022-12-31	184429000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	172
2983	7	19	2023	Q1	2023-01-01	2023-03-31	46282000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	173
2984	7	19	2023	FY	2023-01-01	2023-12-31	187188000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	7
2985	7	19	2024	Q1	2024-01-01	2024-03-31	46908000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	176
2986	7	19	2024	FY	2024-01-01	2024-12-31	188530000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	7
2987	7	19	2025	Q1	2025-01-01	2025-03-31	47607000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	179
2988	7	19	2025	FY	2025-01-01	2025-12-31	190530000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	7
2989	7	19	2026	Q1	2026-01-01	2026-03-31	47667000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	179
2990	7	20	2019	FY	2019-01-01	2019-12-31	0.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	185
2991	7	20	2020	FY	2020-01-01	2020-12-31	0.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	185
2992	7	21	2019	Q1	2019-01-01	2019-03-31	0.3675	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	156
2993	7	21	2019	Q2	2019-04-01	2019-06-30	0.3675	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	157
2994	7	21	2019	Q3	2019-07-01	2019-09-30	0.3675	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	158
2995	7	21	2019	FY	2019-01-01	2019-12-31	1.4700	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	159
2996	7	21	2020	Q1	2020-01-01	2020-03-31	0.3850	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	161
2997	7	21	2020	Q2	2020-04-01	2020-06-30	0.3850	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	162
2998	7	21	2020	Q3	2020-07-01	2020-09-30	0.3850	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	163
2999	7	21	2020	FY	2020-01-01	2020-12-31	1.5400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	164
3000	7	21	2021	Q1	2021-01-01	2021-03-31	0.3900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	165
3001	7	21	2021	Q2	2021-04-01	2021-06-30	0.3900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	166
3002	7	21	2021	Q3	2021-07-01	2021-09-30	0.3900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	167
3003	7	21	2021	FY	2021-01-01	2021-12-31	1.5600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	168
3004	7	21	2022	Q1	2022-01-01	2022-03-31	0.3950	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	169
3005	7	21	2022	Q2	2022-04-01	2022-06-30	0.3950	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	170
3006	7	21	2022	Q3	2022-07-01	2022-09-30	0.3950	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	171
3007	7	21	2022	FY	2022-01-01	2022-12-31	1.5800	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	172
3008	7	21	2023	Q1	2023-01-01	2023-03-31	0.4000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	173
3009	7	21	2023	Q2	2023-04-01	2023-06-30	0.4000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	174
3010	7	21	2023	Q3	2023-07-01	2023-09-30	0.4000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	175
3011	7	21	2023	FY	2023-01-01	2023-12-31	1.6000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	7
3012	7	21	2024	Q1	2024-01-01	2024-03-31	0.4000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	176
3013	7	21	2024	Q2	2024-04-01	2024-06-30	0.4000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	177
3014	7	21	2024	Q3	2024-07-01	2024-09-30	0.4050	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	178
3015	7	21	2024	FY	2024-01-01	2024-12-31	1.6100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	7
3016	7	21	2025	Q1	2025-01-01	2025-03-31	0.4050	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	179
3017	7	21	2025	Q2	2025-04-01	2025-06-30	0.4050	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	180
3018	7	21	2025	Q3	2025-07-01	2025-09-30	0.4050	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	181
3019	7	21	2025	FY	2025-01-01	2025-12-31	1.6200	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	7
3020	7	21	2026	Q1	2026-01-01	2026-03-31	0.4050	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	179
3021	7	21	2026	Q2	2026-04-01	2026-06-30	0.4050	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	180
3022	7	21	2026	Q3	2026-07-01	2026-09-30	0.4100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	181
3023	8	1	2019	Q1	2019-01-01	2019-03-31	13466000000.0000	USD	us-gaap:Revenues	186
3024	8	1	2019	Q2	2019-04-01	2019-06-30	14432000000.0000	USD	us-gaap:Revenues	186
3025	8	1	2019	Q3	2019-07-01	2019-09-30	12758000000.0000	USD	us-gaap:Revenues	186
3026	8	1	2019	FY	2019-01-01	2019-12-31	53800000000.0000	USD	us-gaap:Revenues	187
3027	8	1	2019	Q4	2019-10-01	2019-12-31	13144000000.0000	USD	us-gaap:Revenues	186
3028	8	1	2020	Q1	2020-01-01	2020-03-31	10635000000.0000	USD	us-gaap:Revenues	188
3029	8	1	2020	Q2	2020-04-01	2020-06-30	9997000000.0000	USD	us-gaap:Revenues	189
3030	8	1	2020	Q3	2020-07-01	2020-09-30	9881000000.0000	USD	us-gaap:Revenues	190
3031	8	1	2020	FY	2020-01-01	2020-12-31	41748000000.0000	USD	us-gaap:Revenues	191
3032	8	1	2020	Q4	2020-10-01	2020-12-31	11235000000.0000	USD	us-gaap:Revenues	186
3033	8	1	2021	Q1	2021-01-01	2021-03-31	11887000000.0000	USD	us-gaap:Revenues	192
3034	8	1	2021	Q2	2021-04-01	2021-06-30	12889000000.0000	USD	us-gaap:Revenues	193
3035	8	1	2021	Q3	2021-07-01	2021-09-30	12397000000.0000	USD	us-gaap:Revenues	194
3036	8	1	2021	FY	2021-01-01	2021-12-31	50971000000.0000	USD	us-gaap:Revenues	195
3037	8	1	2022	Q1	2022-01-01	2022-03-31	13589000000.0000	USD	us-gaap:Revenues	196
3038	8	1	2022	Q2	2022-04-01	2022-06-30	14247000000.0000	USD	us-gaap:Revenues	197
3039	8	1	2022	Q3	2022-07-01	2022-09-30	14994000000.0000	USD	us-gaap:Revenues	198
3040	8	1	2022	FY	2022-01-01	2022-12-31	59427000000.0000	USD	us-gaap:Revenues	199
3041	8	1	2023	Q1	2023-01-01	2023-03-31	15862000000.0000	USD	us-gaap:Revenues	200
3042	8	1	2023	Q2	2023-04-01	2023-06-30	17318000000.0000	USD	us-gaap:Revenues	201
3043	8	1	2023	Q3	2023-07-01	2023-09-30	16810000000.0000	USD	us-gaap:Revenues	202
3044	8	1	2023	FY	2023-01-01	2023-12-31	67060000000.0000	USD	us-gaap:Revenues	8
3045	8	1	2024	Q1	2024-01-01	2024-03-31	15799000000.0000	USD	us-gaap:Revenues	203
3046	8	1	2024	Q2	2024-04-01	2024-06-30	16689000000.0000	USD	us-gaap:Revenues	203
3047	8	1	2024	Q3	2024-07-01	2024-09-30	16106000000.0000	USD	us-gaap:Revenues	203
3048	8	1	2024	FY	2024-01-01	2024-12-31	64809000000.0000	USD	us-gaap:Revenues	203
3049	8	1	2024	Q4	2024-10-01	2024-12-31	16215000000.0000	USD	us-gaap:Revenues	203
3050	8	1	2025	Q1	2025-01-01	2025-03-31	14249000000.0000	USD	us-gaap:Revenues	204
3051	8	1	2025	Q2	2025-04-01	2025-06-30	16569000000.0000	USD	us-gaap:Revenues	205
3052	8	1	2025	Q3	2025-07-01	2025-09-30	17638000000.0000	USD	us-gaap:Revenues	206
3054	8	1	2025	Q4	2025-10-01	2025-12-31	19133000000.0000	USD	us-gaap:Revenues	203
3055	8	1	2026	Q1	2026-01-01	2026-03-31	17415000000.0000	USD	us-gaap:Revenues	204
3056	8	1	2026	Q2	2026-04-01	2026-06-30	20543000000.0000	USD	us-gaap:Revenues	205
3057	8	1	2026	Q3	2026-07-01	2026-09-30	20682000000.0000	USD	us-gaap:Revenues	206
3058	8	2	2019	Q1	2019-01-01	2019-03-31	9003000000.0000	USD	us-gaap:CostOfRevenue	186
3059	8	2	2019	Q2	2019-04-01	2019-06-30	9941000000.0000	USD	us-gaap:CostOfRevenue	186
3060	8	2	2019	Q3	2019-07-01	2019-09-30	8569000000.0000	USD	us-gaap:CostOfRevenue	186
3061	8	2	2019	FY	2019-01-01	2019-12-31	36630000000.0000	USD	us-gaap:CostOfRevenue	187
3062	8	2	2019	Q4	2019-10-01	2019-12-31	9117000000.0000	USD	us-gaap:CostOfRevenue	186
3063	8	2	2020	Q1	2020-01-01	2020-03-31	7266000000.0000	USD	us-gaap:CostOfRevenue	188
3064	8	2	2020	Q2	2020-04-01	2020-06-30	7113000000.0000	USD	us-gaap:CostOfRevenue	189
3065	8	2	2020	Q3	2020-07-01	2020-09-30	6919000000.0000	USD	us-gaap:CostOfRevenue	190
3066	8	2	2020	FY	2020-01-01	2020-12-31	29082000000.0000	USD	us-gaap:CostOfRevenue	191
3067	8	2	2020	Q4	2020-10-01	2020-12-31	7784000000.0000	USD	us-gaap:CostOfRevenue	186
3068	8	2	2021	Q1	2021-01-01	2021-03-31	8012000000.0000	USD	us-gaap:CostOfRevenue	192
3069	8	2	2021	Q2	2021-04-01	2021-06-30	8881000000.0000	USD	us-gaap:CostOfRevenue	193
3070	8	2	2021	Q3	2021-07-01	2021-09-30	8617000000.0000	USD	us-gaap:CostOfRevenue	194
3071	8	2	2021	FY	2021-01-01	2021-12-31	35513000000.0000	USD	us-gaap:CostOfRevenue	195
3072	8	2	2022	Q1	2022-01-01	2022-03-31	9559000000.0000	USD	us-gaap:CostOfRevenue	196
3073	8	2	2022	Q2	2022-04-01	2022-06-30	9975000000.0000	USD	us-gaap:CostOfRevenue	197
3074	8	2	2022	Q3	2022-07-01	2022-09-30	10202000000.0000	USD	us-gaap:CostOfRevenue	198
3075	8	2	2022	FY	2022-01-01	2022-12-31	41350000000.0000	USD	us-gaap:CostOfRevenue	199
3076	8	2	2023	Q1	2023-01-01	2023-03-31	10103000000.0000	USD	us-gaap:CostOfRevenue	200
3077	8	2	2023	Q2	2023-04-01	2023-06-30	11065000000.0000	USD	us-gaap:CostOfRevenue	201
3078	8	2	2023	Q3	2023-07-01	2023-09-30	10583000000.0000	USD	us-gaap:CostOfRevenue	202
3079	8	2	2023	FY	2023-01-01	2023-12-31	42767000000.0000	USD	us-gaap:CostOfRevenue	8
3080	8	2	2024	Q1	2024-01-01	2024-03-31	9662000000.0000	USD	us-gaap:CostOfRevenue	207
3081	8	2	2024	Q2	2024-04-01	2024-06-30	10150000000.0000	USD	us-gaap:CostOfRevenue	208
3082	8	2	2024	Q3	2024-07-01	2024-09-30	10066000000.0000	USD	us-gaap:CostOfRevenue	209
3083	8	2	2024	FY	2024-01-01	2024-12-31	40199000000.0000	USD	us-gaap:CostOfRevenue	8
3084	8	2	2025	Q1	2025-01-01	2025-03-31	8965000000.0000	USD	us-gaap:CostOfRevenue	204
3085	8	2	2025	Q2	2025-04-01	2025-06-30	10807000000.0000	USD	us-gaap:CostOfRevenue	205
3086	8	2	2025	Q3	2025-07-01	2025-09-30	11673000000.0000	USD	us-gaap:CostOfRevenue	206
3087	8	2	2025	FY	2025-01-01	2025-12-31	44752000000.0000	USD	us-gaap:CostOfRevenue	8
3088	8	2	2026	Q1	2026-01-01	2026-03-31	11306000000.0000	USD	us-gaap:CostOfRevenue	204
3089	8	2	2026	Q2	2026-04-01	2026-06-30	12781000000.0000	USD	us-gaap:CostOfRevenue	205
3090	8	2	2026	Q3	2026-07-01	2026-09-30	13332000000.0000	USD	us-gaap:CostOfRevenue	206
3091	8	3	2019	Q1	2019-01-01	2019-03-31	3721000000.0000	USD	us-gaap:GrossProfit	186
3092	8	3	2019	Q2	2019-04-01	2019-06-30	3730000000.0000	USD	us-gaap:GrossProfit	186
3093	8	3	2019	Q3	2019-07-01	2019-09-30	3405000000.0000	USD	us-gaap:GrossProfit	186
3094	8	3	2019	Q4	2019-10-01	2019-12-31	3269000000.0000	USD	us-gaap:GrossProfit	186
3095	8	3	2020	Q1	2020-01-01	2020-03-31	2648000000.0000	USD	us-gaap:GrossProfit	186
3096	8	3	2020	Q2	2020-04-01	2020-06-30	2197000000.0000	USD	us-gaap:GrossProfit	186
3097	8	3	2020	Q3	2020-07-01	2020-09-30	2309000000.0000	USD	us-gaap:GrossProfit	186
3098	8	3	2020	Q4	2020-10-01	2020-12-31	2786000000.0000	USD	us-gaap:GrossProfit	186
3099	8	4	2019	Q1	2019-01-01	2019-03-31	2207000000.0000	USD	us-gaap:OperatingIncomeLoss	210
3100	8	4	2019	Q2	2019-04-01	2019-06-30	2213000000.0000	USD	us-gaap:OperatingIncomeLoss	211
3101	8	4	2019	Q3	2019-07-01	2019-09-30	2020000000.0000	USD	us-gaap:OperatingIncomeLoss	212
3102	8	4	2019	FY	2019-01-01	2019-12-31	8290000000.0000	USD	us-gaap:OperatingIncomeLoss	187
3103	8	4	2020	Q1	2020-01-01	2020-03-31	1404000000.0000	USD	us-gaap:OperatingIncomeLoss	188
3104	8	4	2020	Q2	2020-04-01	2020-06-30	784000000.0000	USD	us-gaap:OperatingIncomeLoss	189
3105	8	4	2020	Q3	2020-07-01	2020-09-30	985000000.0000	USD	us-gaap:OperatingIncomeLoss	190
3106	8	4	2020	FY	2020-01-01	2020-12-31	4553000000.0000	USD	us-gaap:OperatingIncomeLoss	191
3107	8	4	2021	Q1	2021-01-01	2021-03-31	1814000000.0000	USD	us-gaap:OperatingIncomeLoss	192
3108	8	4	2021	Q2	2021-04-01	2021-06-30	1789000000.0000	USD	us-gaap:OperatingIncomeLoss	193
3109	8	4	2021	Q3	2021-07-01	2021-09-30	1664000000.0000	USD	us-gaap:OperatingIncomeLoss	194
3110	8	4	2021	FY	2021-01-01	2021-12-31	6878000000.0000	USD	us-gaap:OperatingIncomeLoss	195
3111	8	4	2022	Q1	2022-01-01	2022-03-31	1855000000.0000	USD	us-gaap:OperatingIncomeLoss	196
3112	8	4	2022	Q2	2022-04-01	2022-06-30	1944000000.0000	USD	us-gaap:OperatingIncomeLoss	197
3113	8	4	2022	Q3	2022-07-01	2022-09-30	2425000000.0000	USD	us-gaap:OperatingIncomeLoss	198
3114	8	4	2022	FY	2022-01-01	2022-12-31	7904000000.0000	USD	us-gaap:OperatingIncomeLoss	199
3115	8	4	2023	Q1	2023-01-01	2023-03-31	2731000000.0000	USD	us-gaap:OperatingIncomeLoss	200
3116	8	4	2023	Q2	2023-04-01	2023-06-30	3652000000.0000	USD	us-gaap:OperatingIncomeLoss	201
3117	8	4	2023	Q3	2023-07-01	2023-09-30	3449000000.0000	USD	us-gaap:OperatingIncomeLoss	202
3118	8	4	2023	FY	2023-01-01	2023-12-31	12966000000.0000	USD	us-gaap:OperatingIncomeLoss	8
3119	8	4	2024	Q1	2024-01-01	2024-03-31	3519000000.0000	USD	us-gaap:OperatingIncomeLoss	207
3120	8	4	2024	Q2	2024-04-01	2024-06-30	3482000000.0000	USD	us-gaap:OperatingIncomeLoss	208
3121	8	4	2024	Q3	2024-07-01	2024-09-30	3147000000.0000	USD	us-gaap:OperatingIncomeLoss	209
3122	8	4	2024	FY	2024-01-01	2024-12-31	13072000000.0000	USD	us-gaap:OperatingIncomeLoss	8
3123	8	4	2025	Q1	2025-01-01	2025-03-31	2579000000.0000	USD	us-gaap:OperatingIncomeLoss	204
3124	8	4	2025	Q2	2025-04-01	2025-06-30	2860000000.0000	USD	us-gaap:OperatingIncomeLoss	205
3125	8	4	2025	Q3	2025-07-01	2025-09-30	3052000000.0000	USD	us-gaap:OperatingIncomeLoss	206
3126	8	4	2025	FY	2025-01-01	2025-12-31	11151000000.0000	USD	us-gaap:OperatingIncomeLoss	8
3127	8	4	2026	Q1	2026-01-01	2026-03-31	3085000000.0000	USD	us-gaap:OperatingIncomeLoss	204
3128	8	4	2026	Q2	2026-04-01	2026-06-30	4295000000.0000	USD	us-gaap:OperatingIncomeLoss	205
3129	8	4	2026	Q3	2026-07-01	2026-09-30	4214000000.0000	USD	us-gaap:OperatingIncomeLoss	206
3130	8	5	2021	FY	2021-01-01	2021-12-31	6489000000.0000	USD	us-gaap:NetIncomeLoss	213
3131	8	5	2022	FY	2022-01-01	2022-12-31	6705000000.0000	USD	us-gaap:NetIncomeLoss	213
3132	8	5	2023	FY	2023-01-01	2023-12-31	10335000000.0000	USD	us-gaap:NetIncomeLoss	213
3133	8	5	2024	FY	2024-01-01	2024-12-31	10792000000.0000	USD	us-gaap:NetIncomeLoss	213
3134	8	5	2025	FY	2025-01-01	2025-12-31	8884000000.0000	USD	us-gaap:NetIncomeLoss	213
3135	8	6	2019	Q1	2019-01-01	2019-03-31	1121000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	210
3136	8	6	2019	FY	2019-01-01	2019-12-31	6912000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	187
3137	8	6	2020	Q1	2020-01-01	2020-03-31	1130000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	188
3138	8	6	2020	FY	2020-01-01	2020-12-31	6327000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	191
3139	8	6	2021	Q1	2021-01-01	2021-03-31	1928000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	192
3140	8	6	2021	FY	2021-01-01	2021-12-31	7198000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	195
3141	8	6	2022	Q1	2022-01-01	2022-03-31	313000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	196
3142	8	6	2022	FY	2022-01-01	2022-12-31	7766000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	199
3143	8	6	2023	Q1	2023-01-01	2023-03-31	1573000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	200
3144	8	6	2023	FY	2023-01-01	2023-12-31	12885000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	8
3145	8	6	2024	Q1	2024-01-01	2024-03-31	2052000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	207
3146	8	6	2024	FY	2024-01-01	2024-12-31	12035000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	8
3147	8	6	2025	Q1	2025-01-01	2025-03-31	1289000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	204
3148	8	6	2025	FY	2025-01-01	2025-12-31	11739000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	8
3149	8	6	2026	Q1	2026-01-01	2026-03-31	1870000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	204
3150	8	7	2019	Q1	2019-01-01	2019-03-31	278000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	210
3151	8	7	2019	FY	2019-01-01	2019-12-31	1056000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	187
3152	8	7	2020	Q1	2020-01-01	2020-03-31	305000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	188
3153	8	7	2020	FY	2020-01-01	2020-12-31	978000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	191
3154	8	7	2021	Q1	2021-01-01	2021-03-31	252000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	192
3155	8	7	2021	FY	2021-01-01	2021-12-31	1093000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	195
3156	8	7	2022	Q1	2022-01-01	2022-03-31	346000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	196
3157	8	7	2022	FY	2022-01-01	2022-12-31	1296000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	199
3158	8	7	2023	Q1	2023-01-01	2023-03-31	422000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	200
3159	8	7	2023	FY	2023-01-01	2023-12-31	1597000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	8
3160	8	7	2024	Q1	2024-01-01	2024-03-31	500000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	207
3161	8	7	2024	FY	2024-01-01	2024-12-31	1988000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	8
3162	8	7	2025	Q1	2025-01-01	2025-03-31	710000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	204
3163	8	7	2025	FY	2025-01-01	2025-12-31	2821000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	8
3164	8	7	2026	Q1	2026-01-01	2026-03-31	728000000.0000	USD	us-gaap:PaymentsToAcquirePropertyPlantAndEquipment	204
3165	8	8	2019	Q1	\N	2019-03-31	78726000000.0000	USD	us-gaap:Assets	214
3166	8	8	2019	Q2	\N	2019-06-30	79187000000.0000	USD	us-gaap:Assets	215
3167	8	8	2019	Q3	\N	2019-09-30	77993000000.0000	USD	us-gaap:Assets	216
3168	8	8	2019	FY	\N	2019-12-31	78453000000.0000	USD	us-gaap:Assets	186
3169	8	8	2020	Q1	\N	2020-03-31	75894000000.0000	USD	us-gaap:Assets	210
3170	8	8	2020	Q2	\N	2020-06-30	76566000000.0000	USD	us-gaap:Assets	211
3171	8	8	2020	Q3	\N	2020-09-30	76741000000.0000	USD	us-gaap:Assets	212
3172	8	8	2020	FY	\N	2020-12-31	78324000000.0000	USD	us-gaap:Assets	187
3173	8	8	2021	Q1	\N	2021-03-31	80729000000.0000	USD	us-gaap:Assets	188
3174	8	8	2021	Q2	\N	2021-06-30	81697000000.0000	USD	us-gaap:Assets	189
3175	8	8	2021	Q3	\N	2021-09-30	80784000000.0000	USD	us-gaap:Assets	190
3176	8	8	2021	FY	\N	2021-12-31	82793000000.0000	USD	us-gaap:Assets	191
3177	8	8	2022	Q1	\N	2022-03-31	82276000000.0000	USD	us-gaap:Assets	192
3178	8	8	2022	Q2	\N	2022-06-30	81107000000.0000	USD	us-gaap:Assets	193
3179	8	8	2022	Q3	\N	2022-09-30	80907000000.0000	USD	us-gaap:Assets	194
3180	8	8	2022	FY	\N	2022-12-31	81943000000.0000	USD	us-gaap:Assets	195
3181	8	8	2023	Q1	\N	2023-03-31	83649000000.0000	USD	us-gaap:Assets	196
3182	8	8	2023	Q2	\N	2023-06-30	85427000000.0000	USD	us-gaap:Assets	197
3183	8	8	2023	Q3	\N	2023-09-30	86791000000.0000	USD	us-gaap:Assets	198
3184	8	8	2023	FY	\N	2023-12-31	87476000000.0000	USD	us-gaap:Assets	199
3185	8	8	2024	Q1	\N	2024-03-31	83741000000.0000	USD	us-gaap:Assets	200
3186	8	8	2024	Q2	\N	2024-06-30	83336000000.0000	USD	us-gaap:Assets	201
3187	8	8	2024	Q3	\N	2024-09-30	86273000000.0000	USD	us-gaap:Assets	202
3188	8	8	2024	FY	\N	2024-12-31	87764000000.0000	USD	us-gaap:Assets	203
3189	8	8	2025	Q1	\N	2025-03-31	84974000000.0000	USD	us-gaap:Assets	207
3190	8	8	2025	Q2	\N	2025-06-30	90325000000.0000	USD	us-gaap:Assets	208
3191	8	8	2025	Q3	\N	2025-09-30	93722000000.0000	USD	us-gaap:Assets	209
3192	8	8	2025	FY	\N	2025-12-31	98585000000.0000	USD	us-gaap:Assets	206
3193	8	8	2026	Q1	\N	2026-03-31	95550000000.0000	USD	us-gaap:Assets	204
3194	8	8	2026	Q2	\N	2026-06-30	102609000000.0000	USD	us-gaap:Assets	205
3195	8	8	2026	Q3	\N	2026-09-30	106843000000.0000	USD	us-gaap:Assets	206
3196	8	9	2019	Q1	\N	2019-03-31	63248000000.0000	USD	us-gaap:Liabilities	214
3197	8	9	2019	Q2	\N	2019-06-30	64309000000.0000	USD	us-gaap:Liabilities	215
3198	8	9	2019	Q3	\N	2019-09-30	63000000000.0000	USD	us-gaap:Liabilities	216
3199	8	9	2019	FY	\N	2019-12-31	63824000000.0000	USD	us-gaap:Liabilities	186
3200	8	9	2020	Q1	\N	2020-03-31	61655000000.0000	USD	us-gaap:Liabilities	210
3201	8	9	2020	Q2	\N	2020-06-30	62789000000.0000	USD	us-gaap:Liabilities	211
3202	8	9	2020	Q3	\N	2020-09-30	61747000000.0000	USD	us-gaap:Liabilities	212
3203	8	9	2020	FY	\N	2020-12-31	62946000000.0000	USD	us-gaap:Liabilities	187
3204	8	9	2021	Q1	\N	2021-03-31	64112000000.0000	USD	us-gaap:Liabilities	188
3205	8	9	2021	Q2	\N	2021-06-30	64817000000.0000	USD	us-gaap:Liabilities	189
3206	8	9	2021	Q3	\N	2021-09-30	64089000000.0000	USD	us-gaap:Liabilities	190
3207	8	9	2021	FY	\N	2021-12-31	66277000000.0000	USD	us-gaap:Liabilities	191
3208	8	9	2022	Q1	\N	2022-03-31	65179000000.0000	USD	us-gaap:Liabilities	192
3209	8	9	2022	Q2	\N	2022-06-30	65348000000.0000	USD	us-gaap:Liabilities	193
3210	8	9	2022	Q3	\N	2022-09-30	65285000000.0000	USD	us-gaap:Liabilities	194
3211	8	9	2022	FY	\N	2022-12-31	66052000000.0000	USD	us-gaap:Liabilities	195
3212	8	9	2023	Q1	\N	2023-03-31	65479000000.0000	USD	us-gaap:Liabilities	196
3213	8	9	2023	Q2	\N	2023-06-30	67171000000.0000	USD	us-gaap:Liabilities	197
3214	8	9	2023	Q3	\N	2023-09-30	66284000000.0000	USD	us-gaap:Liabilities	198
3215	8	9	2023	FY	\N	2023-12-31	67973000000.0000	USD	us-gaap:Liabilities	199
3216	8	9	2024	Q1	\N	2024-03-31	66096000000.0000	USD	us-gaap:Liabilities	200
3217	8	9	2024	Q2	\N	2024-06-30	66200000000.0000	USD	us-gaap:Liabilities	201
3218	8	9	2024	Q3	\N	2024-09-30	66870000000.0000	USD	us-gaap:Liabilities	202
3219	8	9	2024	FY	\N	2024-12-31	68270000000.0000	USD	us-gaap:Liabilities	8
3220	8	9	2025	Q1	\N	2025-03-31	66904000000.0000	USD	us-gaap:Liabilities	207
3221	8	9	2025	Q2	\N	2025-06-30	71662000000.0000	USD	us-gaap:Liabilities	208
3222	8	9	2025	Q3	\N	2025-09-30	73063000000.0000	USD	us-gaap:Liabilities	209
3223	8	9	2025	FY	\N	2025-12-31	77267000000.0000	USD	us-gaap:Liabilities	206
3224	8	9	2026	Q1	\N	2026-03-31	76890000000.0000	USD	us-gaap:Liabilities	204
3225	8	9	2026	Q2	\N	2026-06-30	83215000000.0000	USD	us-gaap:Liabilities	205
3226	8	9	2026	Q3	\N	2026-09-30	85361000000.0000	USD	us-gaap:Liabilities	206
3227	8	11	2020	FY	\N	2020-12-31	9352000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	187
3228	8	11	2021	Q3	\N	2021-09-30	9446000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	190
3229	8	11	2021	FY	\N	2021-12-31	9254000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	191
3230	8	11	2022	Q1	\N	2022-03-31	6526000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	192
3231	8	11	2022	Q2	\N	2022-06-30	6014000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	193
3232	8	11	2022	Q3	\N	2022-09-30	6346000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	194
3233	8	11	2022	FY	\N	2022-12-31	7004000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	195
3234	8	11	2023	Q1	\N	2023-03-31	6789000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	196
3235	8	11	2023	Q2	\N	2023-06-30	7387000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	197
3236	8	11	2023	Q3	\N	2023-09-30	6545000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	198
3237	8	11	2023	FY	\N	2023-12-31	6978000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	199
3238	8	11	2024	Q1	\N	2024-03-31	4959000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	200
3239	8	11	2024	Q2	\N	2024-06-30	4341000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	201
3240	8	11	2024	Q3	\N	2024-09-30	5638000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	202
3241	8	11	2024	FY	\N	2024-12-31	6889000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	8
3242	8	11	2025	Q1	\N	2025-03-31	3562000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	207
3243	8	11	2025	Q2	\N	2025-06-30	5442000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	208
3244	8	11	2025	Q3	\N	2025-09-30	7538000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	209
3245	8	11	2025	FY	\N	2025-12-31	9980000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	206
3246	8	11	2026	Q1	\N	2026-03-31	4072000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	204
3247	8	11	2026	Q2	\N	2026-06-30	6713000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	205
3248	8	11	2026	Q3	\N	2026-09-30	7929000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	206
3249	8	12	2019	FY	\N	2019-12-31	26281000000.0000	USD	us-gaap:LongTermDebtNoncurrent	186
3250	8	12	2020	FY	\N	2020-12-31	25999000000.0000	USD	us-gaap:LongTermDebtNoncurrent	187
3251	8	12	2021	FY	\N	2021-12-31	26033000000.0000	USD	us-gaap:LongTermDebtNoncurrent	191
3252	8	12	2022	FY	\N	2022-12-31	25714000000.0000	USD	us-gaap:LongTermDebtNoncurrent	195
3253	8	12	2023	FY	\N	2023-12-31	24472000000.0000	USD	us-gaap:LongTermDebtNoncurrent	199
3254	8	12	2024	FY	\N	2024-12-31	27351000000.0000	USD	us-gaap:LongTermDebtNoncurrent	8
3255	8	12	2025	FY	\N	2025-12-31	30696000000.0000	USD	us-gaap:LongTermDebtNoncurrent	8
3256	8	13	2019	Q1	\N	2019-03-31	12340000000.0000	USD	us-gaap:InventoryNet	214
3257	8	13	2019	Q2	\N	2019-06-30	12007000000.0000	USD	us-gaap:InventoryNet	215
3258	8	13	2019	Q3	\N	2019-09-30	12180000000.0000	USD	us-gaap:InventoryNet	216
3259	8	13	2019	FY	\N	2019-12-31	11266000000.0000	USD	us-gaap:InventoryNet	186
3260	8	13	2020	Q1	\N	2020-03-31	11748000000.0000	USD	us-gaap:InventoryNet	210
3261	8	13	2020	Q2	\N	2020-06-30	11371000000.0000	USD	us-gaap:InventoryNet	211
3262	8	13	2020	Q3	\N	2020-09-30	11453000000.0000	USD	us-gaap:InventoryNet	212
3263	8	13	2020	FY	\N	2020-12-31	11402000000.0000	USD	us-gaap:InventoryNet	187
3264	8	13	2021	Q1	\N	2021-03-31	12149000000.0000	USD	us-gaap:InventoryNet	188
3265	8	13	2021	Q2	\N	2021-06-30	12672000000.0000	USD	us-gaap:InventoryNet	189
3266	8	13	2021	Q3	\N	2021-09-30	13666000000.0000	USD	us-gaap:InventoryNet	190
3267	8	13	2021	FY	\N	2021-12-31	14038000000.0000	USD	us-gaap:InventoryNet	191
3268	8	13	2022	Q1	\N	2022-03-31	15038000000.0000	USD	us-gaap:InventoryNet	192
3269	8	13	2022	Q2	\N	2022-06-30	15881000000.0000	USD	us-gaap:InventoryNet	193
3270	8	13	2022	Q3	\N	2022-09-30	16860000000.0000	USD	us-gaap:InventoryNet	194
3271	8	13	2022	FY	\N	2022-12-31	16270000000.0000	USD	us-gaap:InventoryNet	195
3272	8	13	2023	Q1	\N	2023-03-31	17633000000.0000	USD	us-gaap:InventoryNet	196
3273	8	13	2023	Q2	\N	2023-06-30	17746000000.0000	USD	us-gaap:InventoryNet	197
3274	8	13	2023	Q3	\N	2023-09-30	17580000000.0000	USD	us-gaap:InventoryNet	198
3275	8	13	2023	FY	\N	2023-12-31	16565000000.0000	USD	us-gaap:InventoryNet	199
3276	8	13	2024	Q1	\N	2024-03-31	16953000000.0000	USD	us-gaap:InventoryNet	200
3277	8	13	2024	Q2	\N	2024-06-30	17082000000.0000	USD	us-gaap:InventoryNet	201
3278	8	13	2024	Q3	\N	2024-09-30	17312000000.0000	USD	us-gaap:InventoryNet	202
3279	8	13	2024	FY	\N	2024-12-31	16827000000.0000	USD	us-gaap:InventoryNet	8
3280	8	13	2025	Q1	\N	2025-03-31	17862000000.0000	USD	us-gaap:InventoryNet	207
3281	8	13	2025	Q2	\N	2025-06-30	18595000000.0000	USD	us-gaap:InventoryNet	208
3282	8	13	2025	Q3	\N	2025-09-30	18958000000.0000	USD	us-gaap:InventoryNet	209
3283	8	13	2025	FY	\N	2025-12-31	18135000000.0000	USD	us-gaap:InventoryNet	206
3284	8	13	2026	Q1	\N	2026-03-31	19626000000.0000	USD	us-gaap:InventoryNet	204
3285	8	13	2026	Q2	\N	2026-06-30	20627000000.0000	USD	us-gaap:InventoryNet	205
3286	8	13	2026	Q3	\N	2026-09-30	22214000000.0000	USD	us-gaap:InventoryNet	206
3287	8	14	2019	Q1	2019-01-01	2019-03-31	435000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	210
3288	8	14	2019	Q2	2019-04-01	2019-06-30	441000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	211
3289	8	14	2019	Q3	2019-07-01	2019-09-30	431000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	212
3290	8	14	2019	FY	2019-01-01	2019-12-31	1693000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	187
3291	8	14	2020	Q1	2020-01-01	2020-03-31	356000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	188
3292	8	14	2020	Q2	2020-04-01	2020-06-30	341000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	189
3293	8	14	2020	Q3	2020-07-01	2020-09-30	344000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	190
3294	8	14	2020	FY	2020-01-01	2020-12-31	1415000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	191
3295	8	14	2021	Q1	2021-01-01	2021-03-31	374000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	192
3296	8	14	2021	Q2	2021-04-01	2021-06-30	446000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	193
3297	8	14	2021	Q3	2021-07-01	2021-09-30	427000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	194
3298	8	14	2021	FY	2021-01-01	2021-12-31	1686000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	195
3299	8	14	2022	Q1	2022-01-01	2022-03-31	457000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	196
3300	8	14	2022	Q2	2022-04-01	2022-06-30	480000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	197
3301	8	14	2022	Q3	2022-07-01	2022-09-30	476000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	198
3302	8	14	2022	FY	2022-01-01	2022-12-31	1814000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	199
3303	8	14	2023	Q1	2023-01-01	2023-03-31	472000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	200
3304	8	14	2023	Q2	2023-04-01	2023-06-30	528000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	201
3305	8	14	2023	Q3	2023-07-01	2023-09-30	554000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	202
3306	8	14	2023	FY	2023-01-01	2023-12-31	2108000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	8
3307	8	14	2024	Q1	2024-01-01	2024-03-31	520000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	207
3308	8	14	2024	Q2	2024-04-01	2024-06-30	535000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	208
3309	8	14	2024	Q3	2024-07-01	2024-09-30	533000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	209
3310	8	14	2024	FY	2024-01-01	2024-12-31	2107000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	8
3311	8	14	2025	Q1	2025-01-01	2025-03-31	480000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	204
3312	8	14	2025	Q2	2025-04-01	2025-06-30	551000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	205
3313	8	14	2025	Q3	2025-07-01	2025-09-30	555000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	206
3314	8	14	2025	FY	2025-01-01	2025-12-31	2148000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	8
3315	8	14	2026	Q1	2026-01-01	2026-03-31	537000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	204
3316	8	14	2026	Q2	2026-04-01	2026-06-30	616000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	205
3317	8	14	2026	Q3	2026-07-01	2026-09-30	596000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	206
3318	8	15	2024	Q1	2024-01-01	2024-03-31	44000000.0000	USD	us-gaap:ShareBasedCompensation	207
3319	8	15	2025	Q1	2025-01-01	2025-03-31	45000000.0000	USD	us-gaap:ShareBasedCompensation	207
3320	8	15	2019	Q1	2019-01-01	2019-03-31	45000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	210
3321	8	15	2019	Q2	2019-04-01	2019-06-30	68000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	211
3322	8	15	2019	Q3	2019-07-01	2019-09-30	57000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	212
3323	8	15	2019	FY	2019-01-01	2019-12-31	205000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	187
3324	8	15	2020	Q1	2020-01-01	2020-03-31	47000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	188
3325	8	15	2020	Q2	2020-04-01	2020-06-30	67000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	189
3326	8	15	2020	Q3	2020-07-01	2020-09-30	55000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	190
3327	8	15	2020	FY	2020-01-01	2020-12-31	202000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	191
3328	8	15	2021	Q1	2021-01-01	2021-03-31	42000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	192
3329	8	15	2021	Q2	2021-04-01	2021-06-30	69000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	193
3330	8	15	2021	Q3	2021-07-01	2021-09-30	58000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	194
3331	8	15	2021	FY	2021-01-01	2021-12-31	200000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	195
3332	8	15	2022	Q1	2022-01-01	2022-03-31	40000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	196
3333	8	15	2022	Q2	2022-04-01	2022-06-30	67000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	197
3334	8	15	2022	Q3	2022-07-01	2022-09-30	55000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	198
3335	8	15	2022	FY	2022-01-01	2022-12-31	193000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	199
3336	8	15	2023	Q1	2023-01-01	2023-03-31	44000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	200
3337	8	15	2023	Q2	2023-04-01	2023-06-30	74000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	201
3338	8	15	2023	Q3	2023-07-01	2023-09-30	60000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	202
3339	8	15	2023	FY	2023-01-01	2023-12-31	208000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	8
3340	8	15	2024	Q2	2024-04-01	2024-06-30	75000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	208
3341	8	15	2024	Q3	2024-07-01	2024-09-30	52000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	209
3342	8	15	2024	FY	2024-01-01	2024-12-31	223000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	8
3343	8	15	2025	Q2	2025-04-01	2025-06-30	86000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	205
3344	8	15	2025	Q3	2025-07-01	2025-09-30	71000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	206
3345	8	15	2025	FY	2025-01-01	2025-12-31	242000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	8
3346	8	15	2026	Q1	2026-01-01	2026-03-31	54000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	204
3347	8	15	2026	Q2	2026-04-01	2026-06-30	92000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	205
3348	8	15	2026	Q3	2026-07-01	2026-09-30	81000000.0000	USD	us-gaap:AllocatedShareBasedCompensationExpense	206
3349	8	16	2019	Q1	2019-01-01	2019-03-31	641000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	210
3350	8	16	2019	Q2	2019-04-01	2019-06-30	647000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	211
3351	8	16	2019	Q3	2019-07-01	2019-09-30	645000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	212
3352	8	16	2019	FY	2019-01-01	2019-12-31	2577000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	187
3353	8	16	2020	Q1	2020-01-01	2020-03-31	614000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	188
3354	8	16	2020	Q2	2020-04-01	2020-06-30	608000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	189
3355	8	16	2020	Q3	2020-07-01	2020-09-30	593000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	190
3356	8	16	2020	FY	2020-01-01	2020-12-31	2432000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	191
3357	8	16	2021	Q1	2021-01-01	2021-03-31	586000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	192
3358	8	16	2021	Q2	2021-04-01	2021-06-30	587000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	193
3359	8	16	2021	Q3	2021-07-01	2021-09-30	593000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	194
3360	8	16	2021	FY	2021-01-01	2021-12-31	2352000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	195
3361	8	16	2022	Q1	2022-01-01	2022-03-31	557000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	196
3362	8	16	2022	Q2	2022-04-01	2022-06-30	553000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	197
3363	8	16	2022	Q3	2022-07-01	2022-09-30	551000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	198
3364	8	16	2022	FY	2022-01-01	2022-12-31	2219000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	199
3365	8	16	2023	Q1	2023-01-01	2023-03-31	532000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	200
3366	8	16	2023	Q2	2023-04-01	2023-06-30	542000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	201
3367	8	16	2023	Q3	2023-07-01	2023-09-30	525000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	202
3368	8	16	2023	FY	2023-01-01	2023-12-31	2144000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	8
3369	8	16	2024	Q1	2024-01-01	2024-03-31	524000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	203
3370	8	16	2024	Q2	2024-04-01	2024-06-30	531000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	203
3371	8	16	2024	Q3	2024-07-01	2024-09-30	543000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	203
3372	8	16	2024	FY	2024-01-01	2024-12-31	2153000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	203
3373	8	16	2024	Q4	2024-10-01	2024-12-31	555000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	203
3374	8	16	2025	Q1	2025-01-01	2025-03-31	540000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	204
3375	8	16	2025	Q2	2025-04-01	2025-06-30	554000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	205
3376	8	16	2025	Q3	2025-07-01	2025-09-30	570000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	206
3377	8	16	2025	FY	2025-01-01	2025-12-31	2262000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	203
3378	8	16	2025	Q4	2025-10-01	2025-12-31	598000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	203
3379	8	16	2026	Q1	2026-01-01	2026-03-31	595000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	204
3380	8	16	2026	Q2	2026-04-01	2026-06-30	616000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	205
3381	8	16	2026	Q3	2026-07-01	2026-09-30	615000000.0000	USD	us-gaap:DepreciationDepletionAndAmortization	206
3382	8	17	2019	Q1	2019-01-01	2019-03-31	387000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	210
3383	8	17	2019	Q2	2019-04-01	2019-06-30	565000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	211
3384	8	17	2019	Q3	2019-07-01	2019-09-30	518000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	212
3385	8	17	2019	FY	2019-01-01	2019-12-31	1746000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	187
3386	8	17	2020	Q1	2020-01-01	2020-03-31	425000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	188
3387	8	17	2020	Q2	2020-04-01	2020-06-30	227000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	189
3388	8	17	2020	Q3	2020-07-01	2020-09-30	187000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	190
3389	8	17	2020	FY	2020-01-01	2020-12-31	1006000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	191
3390	8	17	2021	Q1	2021-01-01	2021-03-31	475000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	192
3391	8	17	2021	Q2	2021-04-01	2021-06-30	470000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	193
3392	8	17	2021	Q3	2021-07-01	2021-09-30	368000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	194
3393	8	17	2021	FY	2021-01-01	2021-12-31	1742000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	195
3394	8	17	2022	Q1	2022-01-01	2022-03-31	469000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	196
3395	8	17	2022	Q2	2022-04-01	2022-06-30	427000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	197
3396	8	17	2022	Q3	2022-07-01	2022-09-30	527000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	198
3397	8	17	2022	FY	2022-01-01	2022-12-31	2067000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	199
3398	8	17	2023	Q1	2023-01-01	2023-03-31	708000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	200
3399	8	17	2023	Q2	2023-04-01	2023-06-30	752000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	201
3400	8	17	2023	Q3	2023-07-01	2023-09-30	734000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	202
3401	8	17	2023	FY	2023-01-01	2023-12-31	2781000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	8
3402	8	17	2024	Q1	2024-01-01	2024-03-31	688000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	207
3403	8	17	2024	Q2	2024-04-01	2024-06-30	836000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	208
3404	8	17	2024	Q3	2024-07-01	2024-09-30	642000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	209
3405	8	17	2024	FY	2024-01-01	2024-12-31	2629000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	8
3406	8	17	2025	Q1	2025-01-01	2025-03-31	574000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	204
3407	8	17	2025	Q2	2025-04-01	2025-06-30	646000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	205
3408	8	17	2025	Q3	2025-07-01	2025-09-30	836000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	206
3409	8	17	2025	FY	2025-01-01	2025-12-31	2768000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	8
3410	8	17	2026	Q1	2026-01-01	2026-03-31	670000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	204
3411	8	17	2026	Q2	2026-04-01	2026-06-30	1055000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	205
3412	8	17	2026	Q3	2026-07-01	2026-09-30	968000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	206
3413	8	18	2019	Q1	2019-01-01	2019-03-31	3.2500	USD/shares	us-gaap:EarningsPerShareDiluted	186
3414	8	18	2019	Q2	2019-04-01	2019-06-30	2.8300	USD/shares	us-gaap:EarningsPerShareDiluted	186
3415	8	18	2019	Q3	2019-07-01	2019-09-30	2.6600	USD/shares	us-gaap:EarningsPerShareDiluted	186
3416	8	18	2019	FY	2019-01-01	2019-12-31	10.7400	USD/shares	us-gaap:EarningsPerShareDiluted	187
3417	8	18	2019	Q4	2019-10-01	2019-12-31	1.9700	USD/shares	us-gaap:EarningsPerShareDiluted	186
3418	8	18	2020	Q1	2020-01-01	2020-03-31	1.9800	USD/shares	us-gaap:EarningsPerShareDiluted	188
3419	8	18	2020	Q2	2020-04-01	2020-06-30	0.8400	USD/shares	us-gaap:EarningsPerShareDiluted	189
3420	8	18	2020	Q3	2020-07-01	2020-09-30	1.2200	USD/shares	us-gaap:EarningsPerShareDiluted	190
3421	8	18	2020	FY	2020-01-01	2020-12-31	5.4600	USD/shares	us-gaap:EarningsPerShareDiluted	191
3422	8	18	2020	Q4	2020-10-01	2020-12-31	1.4200	USD/shares	us-gaap:EarningsPerShareDiluted	186
3423	8	18	2021	Q1	2021-01-01	2021-03-31	2.7700	USD/shares	us-gaap:EarningsPerShareDiluted	192
3424	8	18	2021	Q2	2021-04-01	2021-06-30	2.5600	USD/shares	us-gaap:EarningsPerShareDiluted	193
3425	8	18	2021	Q3	2021-07-01	2021-09-30	2.6000	USD/shares	us-gaap:EarningsPerShareDiluted	194
3426	8	18	2021	FY	2021-01-01	2021-12-31	11.8300	USD/shares	us-gaap:EarningsPerShareDiluted	195
3427	8	18	2022	Q1	2022-01-01	2022-03-31	2.8600	USD/shares	us-gaap:EarningsPerShareDiluted	196
3428	8	18	2022	Q2	2022-04-01	2022-06-30	3.1300	USD/shares	us-gaap:EarningsPerShareDiluted	197
3429	8	18	2022	Q3	2022-07-01	2022-09-30	3.8700	USD/shares	us-gaap:EarningsPerShareDiluted	198
3430	8	18	2022	FY	2022-01-01	2022-12-31	12.6400	USD/shares	us-gaap:EarningsPerShareDiluted	199
3431	8	18	2023	Q1	2023-01-01	2023-03-31	3.7400	USD/shares	us-gaap:EarningsPerShareDiluted	200
3432	8	18	2023	Q2	2023-04-01	2023-06-30	5.6700	USD/shares	us-gaap:EarningsPerShareDiluted	201
3433	8	18	2023	Q3	2023-07-01	2023-09-30	5.4500	USD/shares	us-gaap:EarningsPerShareDiluted	202
3434	8	18	2023	FY	2023-01-01	2023-12-31	20.1200	USD/shares	us-gaap:EarningsPerShareDiluted	8
3435	8	18	2024	Q1	2024-01-01	2024-03-31	5.7500	USD/shares	us-gaap:EarningsPerShareDiluted	207
3436	8	18	2024	Q2	2024-04-01	2024-06-30	5.4800	USD/shares	us-gaap:EarningsPerShareDiluted	208
3437	8	18	2024	Q3	2024-07-01	2024-09-30	5.0600	USD/shares	us-gaap:EarningsPerShareDiluted	209
3438	8	18	2024	FY	2024-01-01	2024-12-31	22.0500	USD/shares	us-gaap:EarningsPerShareDiluted	8
3439	8	18	2025	Q1	2025-01-01	2025-03-31	4.2000	USD/shares	us-gaap:EarningsPerShareDiluted	204
3440	8	18	2025	Q2	2025-04-01	2025-06-30	4.6200	USD/shares	us-gaap:EarningsPerShareDiluted	205
3441	8	18	2025	Q3	2025-07-01	2025-09-30	4.8800	USD/shares	us-gaap:EarningsPerShareDiluted	206
3442	8	18	2025	FY	2025-01-01	2025-12-31	18.8100	USD/shares	us-gaap:EarningsPerShareDiluted	8
3443	8	18	2026	Q1	2026-01-01	2026-03-31	5.4700	USD/shares	us-gaap:EarningsPerShareDiluted	204
3444	8	18	2026	Q2	2026-04-01	2026-06-30	7.7700	USD/shares	us-gaap:EarningsPerShareDiluted	205
3445	8	18	2026	Q3	2026-07-01	2026-09-30	7.1300	USD/shares	us-gaap:EarningsPerShareDiluted	206
3446	8	19	2019	Q1	2019-01-01	2019-03-31	494000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	210
3447	8	19	2019	FY	2019-01-01	2019-12-31	2132000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	187
3448	8	19	2020	Q1	2020-01-01	2020-03-31	567000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	188
3449	8	19	2020	FY	2020-01-01	2020-12-31	2243000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	191
3450	8	19	2021	Q1	2021-01-01	2021-03-31	562000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	192
3451	8	19	2021	FY	2021-01-01	2021-12-31	2332000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	195
3452	8	19	2022	Q1	2022-01-01	2022-03-31	595000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	196
3453	8	19	2022	FY	2022-01-01	2022-12-31	2440000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	199
3454	8	19	2023	Q1	2023-01-01	2023-03-31	620000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	200
3455	8	19	2023	FY	2023-01-01	2023-12-31	2563000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	8
3456	8	19	2024	Q1	2024-01-01	2024-03-31	648000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	207
3457	8	19	2024	FY	2024-01-01	2024-12-31	2646000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	8
3458	8	19	2025	Q1	2025-01-01	2025-03-31	674000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	204
3459	8	19	2025	FY	2025-01-01	2025-12-31	2749000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	8
3460	8	19	2026	Q1	2026-01-01	2026-03-31	703000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	204
3461	8	20	2019	Q1	2019-01-01	2019-03-31	751000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	210
3462	8	20	2019	Q2	2019-04-01	2019-06-30	1300000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	215
3463	8	20	2019	Q3	2019-07-01	2019-09-30	1300000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	212
3464	8	20	2019	FY	2019-01-01	2019-12-31	4047000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	187
3465	8	20	2020	Q1	2020-01-01	2020-03-31	1043000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	188
3466	8	20	2020	FY	2020-01-01	2020-12-31	1130000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	191
3467	8	20	2021	Q1	2021-01-01	2021-03-31	0.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	192
3468	8	20	2021	FY	2021-01-01	2021-12-31	2668000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	195
3469	8	20	2022	Q1	2022-01-01	2022-03-31	820000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	196
3470	8	20	2022	FY	2022-01-01	2022-12-31	4230000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	199
3471	8	20	2023	Q1	2023-01-01	2023-03-31	400000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	200
3472	8	20	2023	FY	2023-01-01	2023-12-31	4975000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	8
3473	8	20	2024	Q1	2024-01-01	2024-03-31	4455000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	207
3474	8	20	2024	FY	2024-01-01	2024-12-31	7697000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	8
3475	8	20	2025	Q1	2025-01-01	2025-03-31	3660000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	204
3476	8	20	2025	FY	2025-01-01	2025-12-31	5190000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	8
3477	8	20	2026	Q1	2026-01-01	2026-03-31	5028000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	204
3478	8	21	2019	Q2	2019-04-01	2019-06-30	1.8900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	211
3479	8	21	2019	FY	2019-01-01	2019-12-31	3.9500	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	187
3480	8	21	2020	Q2	2020-04-01	2020-06-30	2.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	189
3481	8	21	2020	FY	2020-01-01	2020-12-31	4.1200	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	191
3482	8	21	2021	Q2	2021-04-01	2021-06-30	2.1400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	193
3483	8	21	2021	FY	2021-01-01	2021-12-31	4.3600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	195
3484	8	21	2022	Q2	2022-04-01	2022-06-30	2.3100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	197
3485	8	21	2022	FY	2022-01-01	2022-12-31	4.7100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	199
3486	8	21	2023	Q2	2023-04-01	2023-06-30	2.5000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	201
3487	8	21	2023	FY	2023-01-01	2023-12-31	5.1000	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	8
3488	8	21	2024	Q2	2024-04-01	2024-06-30	2.7100	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	208
3489	8	21	2024	FY	2024-01-01	2024-12-31	5.5300	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	8
3490	8	21	2025	Q2	2025-04-01	2025-06-30	2.9200	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	205
3491	8	21	2025	FY	2025-01-01	2025-12-31	5.9400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	8
3492	8	21	2026	Q2	2026-04-01	2026-06-30	3.1400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	205
3493	9	1	2019	FY	2019-01-01	2019-12-31	1069985400000.0000	TWD	ifrs-full:Revenue	217
3494	9	1	2020	FY	2020-01-01	2020-12-31	1339254800000.0000	TWD	ifrs-full:Revenue	218
3495	9	1	2021	FY	2021-01-01	2021-12-31	1587415000000.0000	TWD	ifrs-full:Revenue	219
3496	9	1	2022	FY	2022-01-01	2022-12-31	2263891300000.0000	TWD	ifrs-full:Revenue	220
3497	9	1	2023	FY	2023-01-01	2023-12-31	2161735800000.0000	TWD	ifrs-full:Revenue	220
3498	9	1	2024	FY	2024-01-01	2024-12-31	2894307700000.0000	TWD	ifrs-full:Revenue	220
3499	9	1	2019	FY	2019-01-01	2019-12-31	35773500000.0000	USD	ifrs-full:Revenue	221
3500	9	1	2020	FY	2020-01-01	2020-12-31	47694300000.0000	USD	ifrs-full:Revenue	222
3501	9	1	2021	FY	2021-01-01	2021-12-31	57224800000.0000	USD	ifrs-full:Revenue	217
3502	9	1	2022	FY	2022-01-01	2022-12-31	73670400000.0000	USD	ifrs-full:Revenue	218
3503	9	1	2023	FY	2023-01-01	2023-12-31	70598800000.0000	USD	ifrs-full:Revenue	219
3504	9	1	2024	FY	2024-01-01	2024-12-31	88268000000.0000	USD	ifrs-full:Revenue	220
3505	9	2	2019	FY	2019-01-01	2019-12-31	577283500000.0000	TWD	ifrs-full:CostOfSales	217
3506	9	2	2020	FY	2020-01-01	2020-12-31	628124700000.0000	TWD	ifrs-full:CostOfSales	218
3507	9	2	2021	FY	2021-01-01	2021-12-31	767877700000.0000	TWD	ifrs-full:CostOfSales	219
3508	9	2	2022	FY	2022-01-01	2022-12-31	915536500000.0000	TWD	ifrs-full:CostOfSales	220
3509	9	2	2023	FY	2023-01-01	2023-12-31	986625200000.0000	TWD	ifrs-full:CostOfSales	220
3510	9	2	2024	FY	2024-01-01	2024-12-31	1269954100000.0000	TWD	ifrs-full:CostOfSales	220
3511	9	2	2019	FY	2019-01-01	2019-12-31	19300800000.0000	USD	ifrs-full:CostOfSales	221
3512	9	2	2020	FY	2020-01-01	2020-12-31	22368600000.0000	USD	ifrs-full:CostOfSales	222
3513	9	2	2021	FY	2021-01-01	2021-12-31	27681300000.0000	USD	ifrs-full:CostOfSales	217
3514	9	2	2022	FY	2022-01-01	2022-12-31	29792900000.0000	USD	ifrs-full:CostOfSales	218
3515	9	2	2023	FY	2023-01-01	2023-12-31	32221600000.0000	USD	ifrs-full:CostOfSales	219
3516	9	2	2024	FY	2024-01-01	2024-12-31	38729900000.0000	USD	ifrs-full:CostOfSales	220
3517	9	3	2019	FY	2019-01-01	2019-12-31	492701900000.0000	TWD	ifrs-full:GrossProfit	217
3518	9	3	2020	FY	2020-01-01	2020-12-31	711130100000.0000	TWD	ifrs-full:GrossProfit	218
3519	9	3	2021	FY	2021-01-01	2021-12-31	819537300000.0000	TWD	ifrs-full:GrossProfit	219
3520	9	3	2022	FY	2022-01-01	2022-12-31	1348354800000.0000	TWD	ifrs-full:GrossProfit	220
3521	9	3	2023	FY	2023-01-01	2023-12-31	1175110600000.0000	TWD	ifrs-full:GrossProfit	220
3522	9	3	2024	FY	2024-01-01	2024-12-31	1624353600000.0000	TWD	ifrs-full:GrossProfit	220
3523	9	3	2019	FY	2019-01-01	2019-12-31	16472800000.0000	USD	ifrs-full:GrossProfit	221
3524	9	3	2020	FY	2020-01-01	2020-12-31	25325100000.0000	USD	ifrs-full:GrossProfit	222
3525	9	3	2021	FY	2021-01-01	2021-12-31	29543500000.0000	USD	ifrs-full:GrossProfit	217
3526	9	3	2022	FY	2022-01-01	2022-12-31	43877500000.0000	USD	ifrs-full:GrossProfit	218
3527	9	3	2023	FY	2023-01-01	2023-12-31	38377200000.0000	USD	ifrs-full:GrossProfit	219
3528	9	3	2024	FY	2024-01-01	2024-12-31	49538100000.0000	USD	ifrs-full:GrossProfit	220
3529	9	4	2019	FY	2019-01-01	2019-12-31	372701100000.0000	TWD	ifrs-full:ProfitLossFromOperatingActivities	217
3530	9	4	2020	FY	2020-01-01	2020-12-31	566783700000.0000	TWD	ifrs-full:ProfitLossFromOperatingActivities	218
3531	9	4	2021	FY	2021-01-01	2021-12-31	649980900000.0000	TWD	ifrs-full:ProfitLossFromOperatingActivities	219
3532	9	4	2022	FY	2022-01-01	2022-12-31	1121278900000.0000	TWD	ifrs-full:ProfitLossFromOperatingActivities	220
3533	9	4	2023	FY	2023-01-01	2023-12-31	921465600000.0000	TWD	ifrs-full:ProfitLossFromOperatingActivities	220
3534	9	4	2024	FY	2024-01-01	2024-12-31	1322053000000.0000	TWD	ifrs-full:ProfitLossFromOperatingActivities	220
3535	9	4	2019	FY	2019-01-01	2019-12-31	12460800000.0000	USD	ifrs-full:ProfitLossFromOperatingActivities	221
3536	9	4	2020	FY	2020-01-01	2020-12-31	20184600000.0000	USD	ifrs-full:ProfitLossFromOperatingActivities	222
3537	9	4	2021	FY	2021-01-01	2021-12-31	23431200000.0000	USD	ifrs-full:ProfitLossFromOperatingActivities	217
3538	9	4	2022	FY	2022-01-01	2022-12-31	36488100000.0000	USD	ifrs-full:ProfitLossFromOperatingActivities	218
3539	9	4	2023	FY	2023-01-01	2023-12-31	30093600000.0000	USD	ifrs-full:ProfitLossFromOperatingActivities	219
3540	9	4	2024	FY	2024-01-01	2024-12-31	40318800000.0000	USD	ifrs-full:ProfitLossFromOperatingActivities	220
3541	9	5	2019	FY	2019-01-01	2019-12-31	353948000000.0000	TWD	ifrs-full:ProfitLossAttributableToOwnersOfParent	217
3542	9	5	2020	FY	2020-01-01	2020-12-31	510744000000.0000	TWD	ifrs-full:ProfitLossAttributableToOwnersOfParent	218
3543	9	5	2021	FY	2021-01-01	2021-12-31	592359200000.0000	TWD	ifrs-full:ProfitLossAttributableToOwnersOfParent	219
3544	9	5	2022	FY	2022-01-01	2022-12-31	992923400000.0000	TWD	ifrs-full:ProfitLossAttributableToOwnersOfParent	220
3545	9	5	2023	FY	2023-01-01	2023-12-31	851740000000.0000	TWD	ifrs-full:ProfitLossAttributableToOwnersOfParent	220
3546	9	5	2024	FY	2024-01-01	2024-12-31	1158380200000.0000	TWD	ifrs-full:ProfitLossAttributableToOwnersOfParent	220
3547	9	5	2019	FY	2019-01-01	2019-12-31	11833800000.0000	USD	ifrs-full:ProfitLossAttributableToOwnersOfParent	221
3548	9	5	2020	FY	2020-01-01	2020-12-31	18188900000.0000	USD	ifrs-full:ProfitLossAttributableToOwnersOfParent	222
3549	9	5	2021	FY	2021-01-01	2021-12-31	21354000000.0000	USD	ifrs-full:ProfitLossAttributableToOwnersOfParent	217
3550	9	5	2022	FY	2022-01-01	2022-12-31	32311200000.0000	USD	ifrs-full:ProfitLossAttributableToOwnersOfParent	218
3551	9	5	2023	FY	2023-01-01	2023-12-31	27816500000.0000	USD	ifrs-full:ProfitLossAttributableToOwnersOfParent	219
3552	9	5	2024	FY	2024-01-01	2024-12-31	35327200000.0000	USD	ifrs-full:ProfitLossAttributableToOwnersOfParent	220
3553	9	6	2019	FY	2019-01-01	2019-12-31	615138700000.0000	TWD	ifrs-full:CashFlowsFromUsedInOperatingActivities	217
3554	9	6	2020	FY	2020-01-01	2020-12-31	822666200000.0000	TWD	ifrs-full:CashFlowsFromUsedInOperatingActivities	218
3555	9	6	2021	FY	2021-01-01	2021-12-31	1112160700000.0000	TWD	ifrs-full:CashFlowsFromUsedInOperatingActivities	219
3556	9	6	2022	FY	2022-01-01	2022-12-31	1610599200000.0000	TWD	ifrs-full:CashFlowsFromUsedInOperatingActivities	220
3557	9	6	2023	FY	2023-01-01	2023-12-31	1241967300000.0000	TWD	ifrs-full:CashFlowsFromUsedInOperatingActivities	220
3558	9	6	2024	FY	2024-01-01	2024-12-31	1826177100000.0000	TWD	ifrs-full:CashFlowsFromUsedInOperatingActivities	220
3559	9	6	2019	FY	2019-01-01	2019-12-31	20566400000.0000	USD	ifrs-full:CashFlowsFromUsedInOperatingActivities	221
3560	9	6	2020	FY	2020-01-01	2020-12-31	29297200000.0000	USD	ifrs-full:CashFlowsFromUsedInOperatingActivities	222
3561	9	6	2021	FY	2021-01-01	2021-12-31	40092300000.0000	USD	ifrs-full:CashFlowsFromUsedInOperatingActivities	217
3562	9	6	2022	FY	2022-01-01	2022-12-31	52411300000.0000	USD	ifrs-full:CashFlowsFromUsedInOperatingActivities	218
3563	9	6	2023	FY	2023-01-01	2023-12-31	40560700000.0000	USD	ifrs-full:CashFlowsFromUsedInOperatingActivities	219
3564	9	6	2024	FY	2024-01-01	2024-12-31	55693100000.0000	USD	ifrs-full:CashFlowsFromUsedInOperatingActivities	220
3565	9	7	2019	FY	2019-01-01	2019-12-31	460422200000.0000	TWD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	217
3566	9	7	2020	FY	2020-01-01	2020-12-31	507238700000.0000	TWD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	218
3567	9	7	2021	FY	2021-01-01	2021-12-31	839195700000.0000	TWD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	219
3568	9	7	2022	FY	2022-01-01	2022-12-31	1082672100000.0000	TWD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	220
3569	9	7	2023	FY	2023-01-01	2023-12-31	949816800000.0000	TWD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	220
3570	9	7	2024	FY	2024-01-01	2024-12-31	956006500000.0000	TWD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	220
3571	9	7	2019	FY	2019-01-01	2019-12-31	15393600000.0000	USD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	221
3572	9	7	2020	FY	2020-01-01	2020-12-31	18064100000.0000	USD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	222
3573	9	7	2021	FY	2021-01-01	2021-12-31	30252200000.0000	USD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	217
3574	9	7	2022	FY	2022-01-01	2022-12-31	35231800000.0000	USD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	218
3575	9	7	2023	FY	2023-01-01	2023-12-31	31019500000.0000	USD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	219
3576	9	7	2024	FY	2024-01-01	2024-12-31	29155400000.0000	USD	ifrs-full:PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities	220
3577	9	8	2019	FY	\N	2019-12-31	2264725000000.0000	TWD	ifrs-full:Assets	222
3578	9	8	2020	FY	\N	2020-12-31	2760600500000.0000	TWD	ifrs-full:Assets	217
3579	9	8	2021	Q2	\N	2021-06-30	3092688800000.0000	TWD	ifrs-full:Assets	223
3580	9	8	2021	FY	\N	2021-12-31	3725302200000.0000	TWD	ifrs-full:Assets	218
3581	9	8	2022	FY	\N	2022-12-31	4964459100000.0000	TWD	ifrs-full:Assets	219
3582	9	8	2023	FY	\N	2023-12-31	5532196600000.0000	TWD	ifrs-full:Assets	220
3583	9	8	2024	FY	\N	2024-12-31	6691764700000.0000	TWD	ifrs-full:Assets	220
3584	9	8	2019	FY	\N	2019-12-31	75718000000.0000	USD	ifrs-full:Assets	221
3585	9	8	2020	FY	\N	2020-12-31	98312000000.0000	USD	ifrs-full:Assets	222
3586	9	8	2021	Q2	\N	2021-06-30	110809300000.0000	USD	ifrs-full:Assets	223
3587	9	8	2021	FY	\N	2021-12-31	134293500000.0000	USD	ifrs-full:Assets	217
3588	9	8	2022	FY	\N	2022-12-31	161550900000.0000	USD	ifrs-full:Assets	218
3589	9	8	2023	FY	\N	2023-12-31	180672700000.0000	USD	ifrs-full:Assets	219
3590	9	8	2024	FY	\N	2024-12-31	204079400000.0000	USD	ifrs-full:Assets	220
3591	9	9	2019	FY	\N	2019-12-31	650337700000.0000	TWD	ifrs-full:Liabilities	222
3592	9	9	2020	FY	\N	2020-12-31	924836700000.0000	TWD	ifrs-full:Liabilities	217
3593	9	9	2021	Q2	\N	2021-06-30	1110653900000.0000	TWD	ifrs-full:Liabilities	223
3594	9	9	2021	FY	\N	2021-12-31	1573619700000.0000	TWD	ifrs-full:Liabilities	218
3595	9	9	2022	FY	\N	2022-12-31	2046626700000.0000	TWD	ifrs-full:Liabilities	219
3596	9	9	2023	FY	\N	2023-12-31	2078330100000.0000	TWD	ifrs-full:Liabilities	220
3597	9	9	2024	FY	\N	2024-12-31	2412493100000.0000	TWD	ifrs-full:Liabilities	220
3598	9	9	2019	FY	\N	2019-12-31	21743200000.0000	USD	ifrs-full:Liabilities	221
3599	9	9	2020	FY	\N	2020-12-31	32935800000.0000	USD	ifrs-full:Liabilities	222
3600	9	9	2021	Q2	\N	2021-06-30	39794100000.0000	USD	ifrs-full:Liabilities	223
3601	9	9	2021	FY	\N	2021-12-31	56727500000.0000	USD	ifrs-full:Liabilities	217
3602	9	9	2022	FY	\N	2022-12-31	66600300000.0000	USD	ifrs-full:Liabilities	218
3603	9	9	2023	FY	\N	2023-12-31	67874900000.0000	USD	ifrs-full:Liabilities	219
3604	9	9	2024	FY	\N	2024-12-31	73574000000.0000	USD	ifrs-full:Liabilities	220
3605	9	10	2019	FY	\N	2019-12-31	1613705600000.0000	TWD	ifrs-full:EquityAttributableToOwnersOfParent	222
3606	9	10	2020	FY	\N	2020-12-31	1834811300000.0000	TWD	ifrs-full:EquityAttributableToOwnersOfParent	217
3607	9	10	2021	Q2	\N	2021-06-30	1979870900000.0000	TWD	ifrs-full:EquityAttributableToOwnersOfParent	223
3608	9	10	2021	FY	\N	2021-12-31	2149259800000.0000	TWD	ifrs-full:EquityAttributableToOwnersOfParent	218
3609	9	10	2022	FY	\N	2022-12-31	2903019700000.0000	TWD	ifrs-full:EquityAttributableToOwnersOfParent	219
3610	9	10	2023	FY	\N	2023-12-31	3429522400000.0000	TWD	ifrs-full:EquityAttributableToOwnersOfParent	220
3611	9	10	2024	FY	\N	2024-12-31	4244266500000.0000	TWD	ifrs-full:EquityAttributableToOwnersOfParent	220
3612	9	10	2019	FY	\N	2019-12-31	53952000000.0000	USD	ifrs-full:EquityAttributableToOwnersOfParent	221
3613	9	10	2020	FY	\N	2020-12-31	65342300000.0000	USD	ifrs-full:EquityAttributableToOwnersOfParent	222
3614	9	10	2021	Q2	\N	2021-06-30	70937700000.0000	USD	ifrs-full:EquityAttributableToOwnersOfParent	223
3615	9	10	2021	FY	\N	2021-12-31	77478700000.0000	USD	ifrs-full:EquityAttributableToOwnersOfParent	217
3616	9	10	2022	FY	\N	2022-12-31	94468600000.0000	USD	ifrs-full:EquityAttributableToOwnersOfParent	218
3617	9	10	2023	FY	\N	2023-12-31	112002700000.0000	USD	ifrs-full:EquityAttributableToOwnersOfParent	219
3618	9	10	2024	FY	\N	2024-12-31	129437800000.0000	USD	ifrs-full:EquityAttributableToOwnersOfParent	220
3619	9	11	2019	FY	\N	2019-12-31	455399300000.0000	TWD	ifrs-full:CashAndCashEquivalents	218
3620	9	11	2020	Q2	\N	2020-06-30	467613400000.0000	TWD	ifrs-full:CashAndCashEquivalents	223
3621	9	11	2020	FY	\N	2020-12-31	660170600000.0000	TWD	ifrs-full:CashAndCashEquivalents	219
3622	9	11	2021	Q2	\N	2021-06-30	747982100000.0000	TWD	ifrs-full:CashAndCashEquivalents	223
3623	9	11	2021	FY	\N	2021-12-31	1064990200000.0000	TWD	ifrs-full:CashAndCashEquivalents	220
3624	9	11	2022	FY	\N	2022-12-31	1342814100000.0000	TWD	ifrs-full:CashAndCashEquivalents	220
3625	9	11	2023	FY	\N	2023-12-31	1465427800000.0000	TWD	ifrs-full:CashAndCashEquivalents	220
3626	9	11	2024	FY	\N	2024-12-31	2127627000000.0000	TWD	ifrs-full:CashAndCashEquivalents	220
3627	9	11	2019	FY	\N	2019-12-31	16217900000.0000	USD	ifrs-full:CashAndCashEquivalents	222
3628	9	11	2020	FY	\N	2020-12-31	23798500000.0000	USD	ifrs-full:CashAndCashEquivalents	217
3629	9	11	2021	Q2	\N	2021-06-30	26799800000.0000	USD	ifrs-full:CashAndCashEquivalents	223
3630	9	11	2021	FY	\N	2021-12-31	34656400000.0000	USD	ifrs-full:CashAndCashEquivalents	218
3631	9	11	2022	FY	\N	2022-12-31	43854200000.0000	USD	ifrs-full:CashAndCashEquivalents	219
3632	9	11	2023	FY	\N	2023-12-31	44691300000.0000	USD	ifrs-full:CashAndCashEquivalents	220
3633	9	11	2024	FY	\N	2024-12-31	64886500000.0000	USD	ifrs-full:CashAndCashEquivalents	220
3634	9	12	2020	FY	\N	2020-12-31	1967600000.0000	TWD	ifrs-full:LongtermBorrowings	217
3635	9	12	2021	Q2	\N	2021-06-30	3171300000.0000	TWD	ifrs-full:LongtermBorrowings	223
3636	9	12	2021	FY	\N	2021-12-31	3309100000.0000	TWD	ifrs-full:LongtermBorrowings	218
3637	9	12	2022	FY	\N	2022-12-31	4760000000.0000	TWD	ifrs-full:LongtermBorrowings	219
3638	9	12	2023	FY	\N	2023-12-31	4383000000.0000	TWD	ifrs-full:LongtermBorrowings	220
3639	9	12	2024	FY	\N	2024-12-31	31824400000.0000	TWD	ifrs-full:LongtermBorrowings	220
3640	9	12	2020	FY	\N	2020-12-31	70100000.0000	USD	ifrs-full:LongtermBorrowings	222
3641	9	12	2021	Q2	\N	2021-06-30	113600000.0000	USD	ifrs-full:LongtermBorrowings	223
3642	9	12	2021	FY	\N	2021-12-31	119300000.0000	USD	ifrs-full:LongtermBorrowings	217
3643	9	12	2022	FY	\N	2022-12-31	154900000.0000	USD	ifrs-full:LongtermBorrowings	218
3644	9	12	2023	FY	\N	2023-12-31	143100000.0000	USD	ifrs-full:LongtermBorrowings	219
3645	9	12	2024	FY	\N	2024-12-31	970500000.0000	USD	ifrs-full:LongtermBorrowings	220
3646	9	13	2019	FY	\N	2019-12-31	82981200000.0000	TWD	ifrs-full:Inventories	222
3647	9	13	2020	FY	\N	2020-12-31	137353400000.0000	TWD	ifrs-full:Inventories	217
3648	9	13	2021	Q2	\N	2021-06-30	170438700000.0000	TWD	ifrs-full:Inventories	223
3649	9	13	2021	FY	\N	2021-12-31	193102300000.0000	TWD	ifrs-full:Inventories	218
3650	9	13	2022	FY	\N	2022-12-31	221149100000.0000	TWD	ifrs-full:Inventories	219
3651	9	13	2023	FY	\N	2023-12-31	250997100000.0000	TWD	ifrs-full:Inventories	220
3652	9	13	2024	FY	\N	2024-12-31	287868800000.0000	TWD	ifrs-full:Inventories	220
3653	9	13	2019	FY	\N	2019-12-31	2774400000.0000	USD	ifrs-full:Inventories	221
3654	9	13	2020	FY	\N	2020-12-31	4891500000.0000	USD	ifrs-full:Inventories	222
3655	9	13	2021	Q2	\N	2021-06-30	6106700000.0000	USD	ifrs-full:Inventories	223
3656	9	13	2021	FY	\N	2021-12-31	6961200000.0000	USD	ifrs-full:Inventories	217
3657	9	13	2022	FY	\N	2022-12-31	7196500000.0000	USD	ifrs-full:Inventories	218
3658	9	13	2023	FY	\N	2023-12-31	8197200000.0000	USD	ifrs-full:Inventories	219
3659	9	13	2024	FY	\N	2024-12-31	8779200000.0000	USD	ifrs-full:Inventories	220
3660	9	14	2019	FY	2019-01-01	2019-12-31	91418700000.0000	TWD	ifrs-full:ResearchAndDevelopmentExpense	217
3661	9	14	2020	FY	2020-01-01	2020-12-31	109486000000.0000	TWD	ifrs-full:ResearchAndDevelopmentExpense	218
3662	9	14	2021	FY	2021-01-01	2021-12-31	124734800000.0000	TWD	ifrs-full:ResearchAndDevelopmentExpense	219
3663	9	14	2022	FY	2022-01-01	2022-12-31	163262200000.0000	TWD	ifrs-full:ResearchAndDevelopmentExpense	220
3664	9	14	2023	FY	2023-01-01	2023-12-31	182370200000.0000	TWD	ifrs-full:ResearchAndDevelopmentExpense	220
3665	9	14	2024	FY	2024-01-01	2024-12-31	204181800000.0000	TWD	ifrs-full:ResearchAndDevelopmentExpense	220
3666	9	14	2019	FY	2019-01-01	2019-12-31	3056500000.0000	USD	ifrs-full:ResearchAndDevelopmentExpense	221
3667	9	14	2020	FY	2020-01-01	2020-12-31	3899100000.0000	USD	ifrs-full:ResearchAndDevelopmentExpense	222
3668	9	14	2021	FY	2021-01-01	2021-12-31	4496600000.0000	USD	ifrs-full:ResearchAndDevelopmentExpense	217
3669	9	14	2022	FY	2022-01-01	2022-12-31	5312900000.0000	USD	ifrs-full:ResearchAndDevelopmentExpense	218
3670	9	14	2023	FY	2023-01-01	2023-12-31	5955900000.0000	USD	ifrs-full:ResearchAndDevelopmentExpense	219
3671	9	14	2024	FY	2024-01-01	2024-12-31	6227000000.0000	USD	ifrs-full:ResearchAndDevelopmentExpense	220
3672	9	15	2019	FY	2019-01-01	2019-12-31	2800000.0000	TWD	ifrs-full:AdjustmentsForSharebasedPayments	217
3673	9	15	2020	FY	2020-01-01	2020-12-31	6600000.0000	TWD	ifrs-full:AdjustmentsForSharebasedPayments	218
3674	9	15	2021	FY	2021-01-01	2021-12-31	7800000.0000	TWD	ifrs-full:AdjustmentsForSharebasedPayments	219
3675	9	15	2022	FY	2022-01-01	2022-12-31	302400000.0000	TWD	ifrs-full:AdjustmentsForSharebasedPayments	220
3676	9	15	2023	FY	2023-01-01	2023-12-31	483000000.0000	TWD	ifrs-full:AdjustmentsForSharebasedPayments	220
3677	9	15	2024	FY	2024-01-01	2024-12-31	1242700000.0000	TWD	ifrs-full:AdjustmentsForSharebasedPayments	220
3678	9	15	2019	FY	2019-01-01	2019-12-31	100000.0000	USD	ifrs-full:AdjustmentsForSharebasedPayments	221
3679	9	15	2020	FY	2020-01-01	2020-12-31	200000.0000	USD	ifrs-full:AdjustmentsForSharebasedPayments	222
3680	9	15	2021	FY	2021-01-01	2021-12-31	300000.0000	USD	ifrs-full:AdjustmentsForSharebasedPayments	217
3681	9	15	2022	FY	2022-01-01	2022-12-31	9800000.0000	USD	ifrs-full:AdjustmentsForSharebasedPayments	218
3682	9	15	2023	FY	2023-01-01	2023-12-31	15800000.0000	USD	ifrs-full:AdjustmentsForSharebasedPayments	219
3683	9	15	2024	FY	2024-01-01	2024-12-31	37900000.0000	USD	ifrs-full:AdjustmentsForSharebasedPayments	220
3684	9	17	2019	FY	2019-01-01	2019-12-31	35835100000.0000	TWD	ifrs-full:IncomeTaxExpenseContinuingOperations	217
3685	9	17	2020	FY	2020-01-01	2020-12-31	73738300000.0000	TWD	ifrs-full:IncomeTaxExpenseContinuingOperations	218
3686	9	17	2021	FY	2021-01-01	2021-12-31	70155400000.0000	TWD	ifrs-full:IncomeTaxExpenseContinuingOperations	219
3687	9	17	2022	FY	2022-01-01	2022-12-31	150777500000.0000	TWD	ifrs-full:IncomeTaxExpenseContinuingOperations	220
3688	9	17	2023	FY	2023-01-01	2023-12-31	128288800000.0000	TWD	ifrs-full:IncomeTaxExpenseContinuingOperations	220
3689	9	17	2024	FY	2024-01-01	2024-12-31	248316100000.0000	TWD	ifrs-full:IncomeTaxExpenseContinuingOperations	220
3690	9	17	2019	FY	2019-01-01	2019-12-31	1198100000.0000	USD	ifrs-full:IncomeTaxExpenseContinuingOperations	221
3691	9	17	2020	FY	2020-01-01	2020-12-31	2626000000.0000	USD	ifrs-full:IncomeTaxExpenseContinuingOperations	222
3692	9	17	2021	FY	2021-01-01	2021-12-31	2529000000.0000	USD	ifrs-full:IncomeTaxExpenseContinuingOperations	217
3693	9	17	2022	FY	2022-01-01	2022-12-31	4906500000.0000	USD	ifrs-full:IncomeTaxExpenseContinuingOperations	218
3694	9	17	2023	FY	2023-01-01	2023-12-31	4189700000.0000	USD	ifrs-full:IncomeTaxExpenseContinuingOperations	219
3695	9	17	2024	FY	2024-01-01	2024-12-31	7572900000.0000	USD	ifrs-full:IncomeTaxExpenseContinuingOperations	220
3696	9	18	2019	FY	2019-01-01	2019-12-31	13.6500	TWD/shares	ifrs-full:DilutedEarningsLossPerShare	217
3697	9	18	2020	FY	2020-01-01	2020-12-31	19.7000	TWD/shares	ifrs-full:DilutedEarningsLossPerShare	218
3698	9	18	2021	FY	2021-01-01	2021-12-31	22.8400	TWD/shares	ifrs-full:DilutedEarningsLossPerShare	219
3699	9	18	2022	FY	2022-01-01	2022-12-31	38.2900	TWD/shares	ifrs-full:DilutedEarningsLossPerShare	220
3700	9	18	2023	FY	2023-01-01	2023-12-31	32.8500	TWD/shares	ifrs-full:DilutedEarningsLossPerShare	220
3701	9	18	2024	FY	2024-01-01	2024-12-31	44.6700	TWD/shares	ifrs-full:DilutedEarningsLossPerShare	220
3702	9	18	2019	FY	2019-01-01	2019-12-31	0.4600	USD/shares	ifrs-full:DilutedEarningsLossPerShare	221
3703	9	18	2020	FY	2020-01-01	2020-12-31	0.7000	USD/shares	ifrs-full:DilutedEarningsLossPerShare	222
3704	9	18	2021	FY	2021-01-01	2021-12-31	0.8200	USD/shares	ifrs-full:DilutedEarningsLossPerShare	217
3705	9	18	2022	FY	2022-01-01	2022-12-31	1.2500	USD/shares	ifrs-full:DilutedEarningsLossPerShare	218
3706	9	18	2023	FY	2023-01-01	2023-12-31	1.0700	USD/shares	ifrs-full:DilutedEarningsLossPerShare	219
3707	9	18	2024	FY	2024-01-01	2024-12-31	1.3600	USD/shares	ifrs-full:DilutedEarningsLossPerShare	220
3708	9	19	2019	FY	2019-01-01	2019-12-31	259303800000.0000	TWD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	217
3709	9	19	2020	FY	2020-01-01	2020-12-31	259303800000.0000	TWD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	218
3710	9	19	2021	FY	2021-01-01	2021-12-31	265786400000.0000	TWD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	219
3711	9	19	2022	FY	2022-01-01	2022-12-31	285234200000.0000	TWD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	220
3712	9	19	2023	FY	2023-01-01	2023-12-31	291721900000.0000	TWD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	220
3713	9	19	2024	FY	2024-01-01	2024-12-31	363055200000.0000	TWD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	220
3714	9	19	2019	FY	2019-01-01	2019-12-31	8669500000.0000	USD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	221
3715	9	19	2020	FY	2020-01-01	2020-12-31	9234500000.0000	USD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	222
3716	9	19	2021	FY	2021-01-01	2021-12-31	9581300000.0000	USD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	217
3717	9	19	2022	FY	2022-01-01	2022-12-31	9282000000.0000	USD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	218
3718	9	19	2023	FY	2023-01-01	2023-12-31	9527200000.0000	USD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	219
3719	9	19	2024	FY	2024-01-01	2024-12-31	11072100000.0000	USD	ifrs-full:DividendsPaidClassifiedAsFinancingActivities	220
3720	10	1	2019	FY	2019-01-01	2019-12-31	9556000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	224
3721	10	1	2020	FY	2020-01-01	2020-12-31	10219000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	225
3722	10	1	2021	FY	2021-01-01	2021-12-31	12761000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	226
3723	10	1	2022	FY	2022-01-01	2022-12-31	16128000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	227
3724	10	1	2023	FY	2023-01-01	2023-12-31	17286000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	10
3725	10	1	2024	FY	2024-01-01	2024-12-31	13269000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	10
3726	10	1	2025	FY	2025-01-01	2025-12-31	11800000000.0000	USD	us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax	10
3727	10	2	2019	FY	2019-01-01	2019-12-31	5860000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	224
3728	10	2	2020	FY	2020-01-01	2020-12-31	6430000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	225
3729	10	2	2021	FY	2021-01-01	2021-12-31	7435000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	226
3730	10	2	2022	FY	2022-01-01	2022-12-31	8493000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	227
3731	10	2	2023	FY	2023-01-01	2023-12-31	8999000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	10
3732	10	2	2024	FY	2024-01-01	2024-12-31	8049000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	10
3733	10	2	2025	FY	2025-01-01	2025-12-31	7801000000.0000	USD	us-gaap:CostOfGoodsAndServicesSold	10
3734	10	3	2019	FY	2019-01-01	2019-12-31	3696000000.0000	USD	us-gaap:GrossProfit	224
3735	10	3	2020	FY	2020-01-01	2020-12-31	3789000000.0000	USD	us-gaap:GrossProfit	225
3736	10	3	2021	FY	2021-01-01	2021-12-31	5326000000.0000	USD	us-gaap:GrossProfit	226
3737	10	3	2022	FY	2022-01-01	2022-12-31	7635000000.0000	USD	us-gaap:GrossProfit	227
3738	10	3	2023	FY	2023-01-01	2023-12-31	8287000000.0000	USD	us-gaap:GrossProfit	10
3739	10	3	2024	FY	2024-01-01	2024-12-31	5220000000.0000	USD	us-gaap:GrossProfit	10
3740	10	3	2025	FY	2025-01-01	2025-12-31	3999000000.0000	USD	us-gaap:GrossProfit	10
3741	10	4	2019	FY	2019-01-01	2019-12-31	1203000000.0000	USD	us-gaap:OperatingIncomeLoss	224
3742	10	4	2020	FY	2020-01-01	2020-12-31	1323000000.0000	USD	us-gaap:OperatingIncomeLoss	225
3743	10	4	2021	FY	2021-01-01	2021-12-31	2419000000.0000	USD	us-gaap:OperatingIncomeLoss	226
3744	10	4	2022	FY	2022-01-01	2022-12-31	4439000000.0000	USD	us-gaap:OperatingIncomeLoss	227
3745	10	4	2023	FY	2023-01-01	2023-12-31	4611000000.0000	USD	us-gaap:OperatingIncomeLoss	10
3746	10	4	2024	FY	2024-01-01	2024-12-31	1676000000.0000	USD	us-gaap:OperatingIncomeLoss	10
3747	10	4	2025	FY	2025-01-01	2025-12-31	175000000.0000	USD	us-gaap:OperatingIncomeLoss	10
3748	10	5	2019	FY	2019-01-01	2019-12-31	1032000000.0000	USD	us-gaap:NetIncomeLoss	224
3749	10	5	2020	FY	2020-01-01	2020-12-31	1106000000.0000	USD	us-gaap:NetIncomeLoss	225
3750	10	5	2021	FY	2021-01-01	2021-12-31	2000000000.0000	USD	us-gaap:NetIncomeLoss	226
3751	10	5	2022	FY	2022-01-01	2022-12-31	3960000000.0000	USD	us-gaap:NetIncomeLoss	227
3752	10	5	2023	FY	2023-01-01	2023-12-31	4211000000.0000	USD	us-gaap:NetIncomeLoss	10
3753	10	5	2024	FY	2024-01-01	2024-12-31	1557000000.0000	USD	us-gaap:NetIncomeLoss	10
3754	10	5	2025	FY	2025-01-01	2025-12-31	166000000.0000	USD	us-gaap:NetIncomeLoss	10
3755	10	6	2019	FY	2019-01-01	2019-12-31	1869000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	224
3756	10	6	2020	FY	2020-01-01	2020-12-31	2093000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	225
3757	10	6	2021	FY	2021-01-01	2021-12-31	3060000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	226
3758	10	6	2022	FY	2022-01-01	2022-12-31	5202000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	227
3759	10	6	2023	FY	2023-01-01	2023-12-31	5992000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	10
3760	10	6	2024	FY	2024-01-01	2024-12-31	2965000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	10
3761	10	6	2025	FY	2025-01-01	2025-12-31	2152000000.0000	USD	us-gaap:NetCashProvidedByUsedInOperatingActivities	10
3762	10	8	2019	FY	\N	2019-12-31	11868000000.0000	USD	us-gaap:Assets	228
3763	10	8	2020	FY	\N	2020-12-31	14454000000.0000	USD	us-gaap:Assets	224
3764	10	8	2021	FY	\N	2021-12-31	15540000000.0000	USD	us-gaap:Assets	225
3765	10	8	2022	FY	\N	2022-12-31	19982000000.0000	USD	us-gaap:Assets	226
3766	10	8	2023	FY	\N	2023-12-31	24453000000.0000	USD	us-gaap:Assets	227
3767	10	8	2024	FY	\N	2024-12-31	24743000000.0000	USD	us-gaap:Assets	10
3768	10	8	2025	FY	\N	2025-12-31	24800000000.0000	USD	us-gaap:Assets	10
3769	10	9	2019	FY	\N	2019-12-31	4757000000.0000	USD	us-gaap:Liabilities	228
3770	10	9	2020	FY	\N	2020-12-31	5948000000.0000	USD	us-gaap:Liabilities	224
3771	10	9	2021	FY	\N	2021-12-31	6267000000.0000	USD	us-gaap:Liabilities	225
3772	10	9	2022	FY	\N	2022-12-31	7224000000.0000	USD	us-gaap:Liabilities	226
3773	10	9	2023	FY	\N	2023-12-31	7601000000.0000	USD	us-gaap:Liabilities	227
3774	10	9	2024	FY	\N	2024-12-31	7064000000.0000	USD	us-gaap:Liabilities	10
3775	10	9	2025	FY	\N	2025-12-31	6575000000.0000	USD	us-gaap:Liabilities	10
3776	10	10	2019	FY	\N	2019-12-31	7043000000.0000	USD	us-gaap:StockholdersEquity	228
3777	10	10	2020	FY	\N	2020-12-31	8448000000.0000	USD	us-gaap:StockholdersEquity	224
3778	10	10	2021	FY	\N	2021-12-31	9209000000.0000	USD	us-gaap:StockholdersEquity	225
3779	10	10	2022	FY	\N	2022-12-31	12693000000.0000	USD	us-gaap:StockholdersEquity	226
3780	10	10	2023	FY	\N	2023-12-31	16729000000.0000	USD	us-gaap:StockholdersEquity	227
3781	10	10	2024	FY	\N	2024-12-31	17449000000.0000	USD	us-gaap:StockholdersEquity	10
3782	10	10	2025	FY	\N	2025-12-31	17828000000.0000	USD	us-gaap:StockholdersEquity	10
3783	10	11	2019	FY	\N	2019-12-31	2597000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	228
3784	10	11	2020	FY	\N	2020-12-31	3006000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	224
3785	10	11	2021	FY	\N	2021-12-31	3225000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	225
3786	10	11	2022	FY	\N	2022-12-31	3258000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	226
3787	10	11	2023	FY	\N	2023-12-31	3222000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	227
3788	10	11	2024	FY	\N	2024-12-31	2282000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	10
3789	10	11	2025	FY	\N	2025-12-31	2837000000.0000	USD	us-gaap:CashAndCashEquivalentsAtCarryingValue	10
3790	10	12	2019	FY	\N	2019-12-31	1899000000.0000	USD	us-gaap:LongTermDebtNoncurrent	228
3791	10	12	2020	FY	\N	2020-12-31	1826000000.0000	USD	us-gaap:LongTermDebtNoncurrent	224
3792	10	12	2021	FY	\N	2021-12-31	2396000000.0000	USD	us-gaap:LongTermDebtNoncurrent	225
3793	10	12	2022	FY	\N	2022-12-31	2542000000.0000	USD	us-gaap:LongTermDebtNoncurrent	226
3794	10	12	2023	FY	\N	2023-12-31	2710000000.0000	USD	us-gaap:LongTermDebtNoncurrent	227
3795	10	12	2024	FY	\N	2024-12-31	1963000000.0000	USD	us-gaap:LongTermDebtNoncurrent	10
3796	10	12	2025	FY	\N	2025-12-31	1835000000.0000	USD	us-gaap:LongTermDebtNoncurrent	10
3797	10	13	2019	FY	\N	2019-12-31	1691000000.0000	USD	us-gaap:InventoryNet	228
3798	10	13	2020	FY	\N	2020-12-31	1841000000.0000	USD	us-gaap:InventoryNet	224
3799	10	13	2021	FY	\N	2021-12-31	1972000000.0000	USD	us-gaap:InventoryNet	225
3800	10	13	2022	FY	\N	2022-12-31	2583000000.0000	USD	us-gaap:InventoryNet	226
3801	10	13	2023	FY	\N	2023-12-31	2698000000.0000	USD	us-gaap:InventoryNet	227
3802	10	13	2024	FY	\N	2024-12-31	2794000000.0000	USD	us-gaap:InventoryNet	10
3803	10	13	2025	FY	\N	2025-12-31	3136000000.0000	USD	us-gaap:InventoryNet	10
3804	10	14	2019	FY	2019-01-01	2019-12-31	1498000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	224
3805	10	14	2020	FY	2020-01-01	2020-12-31	1548000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	225
3806	10	14	2021	FY	2021-01-01	2021-12-31	1723000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	226
3807	10	14	2022	FY	2022-01-01	2022-12-31	1901000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	227
3808	10	14	2023	FY	2023-01-01	2023-12-31	2100000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	10
3809	10	14	2024	FY	2024-01-01	2024-12-31	2077000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	10
3810	10	14	2025	FY	2025-01-01	2025-12-31	2044000000.0000	USD	us-gaap:ResearchAndDevelopmentExpense	10
3811	10	15	2019	FY	2019-01-01	2019-12-31	145000000.0000	USD	us-gaap:ShareBasedCompensation	224
3812	10	15	2020	FY	2020-01-01	2020-12-31	155000000.0000	USD	us-gaap:ShareBasedCompensation	225
3813	10	15	2021	FY	2021-01-01	2021-12-31	221000000.0000	USD	us-gaap:ShareBasedCompensation	226
3814	10	15	2022	FY	2022-01-01	2022-12-31	215000000.0000	USD	us-gaap:ShareBasedCompensation	227
3815	10	15	2023	FY	2023-01-01	2023-12-31	236000000.0000	USD	us-gaap:ShareBasedCompensation	10
3816	10	15	2024	FY	2024-01-01	2024-12-31	222000000.0000	USD	us-gaap:ShareBasedCompensation	10
3817	10	15	2025	FY	2025-01-01	2025-12-31	193000000.0000	USD	us-gaap:ShareBasedCompensation	10
3818	10	17	2019	Q3	2019-07-01	2019-09-30	20000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	229
3819	10	17	2019	FY	2019-01-01	2019-12-31	156000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	224
3820	10	17	2020	FY	2020-01-01	2020-12-31	159000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	225
3821	10	17	2021	FY	2021-01-01	2021-12-31	331000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	226
3822	10	17	2022	FY	2022-01-01	2022-12-31	520000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	227
3823	10	17	2023	FY	2023-01-01	2023-12-31	541000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	10
3824	10	17	2024	FY	2024-01-01	2024-12-31	313000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	10
3825	10	17	2025	FY	2025-01-01	2025-12-31	220000000.0000	USD	us-gaap:IncomeTaxExpenseBenefit	10
3826	10	18	2019	FY	2019-01-01	2019-12-31	1.1400	USD/shares	us-gaap:EarningsPerShareDiluted	224
3827	10	18	2020	FY	2020-01-01	2020-12-31	1.2000	USD/shares	us-gaap:EarningsPerShareDiluted	225
3828	10	18	2021	FY	2021-01-01	2021-12-31	2.1600	USD/shares	us-gaap:EarningsPerShareDiluted	226
3829	10	18	2022	FY	2022-01-01	2022-12-31	4.1900	USD/shares	us-gaap:EarningsPerShareDiluted	227
3830	10	18	2023	FY	2023-01-01	2023-12-31	4.4600	USD/shares	us-gaap:EarningsPerShareDiluted	10
3831	10	18	2024	FY	2024-01-01	2024-12-31	1.6600	USD/shares	us-gaap:EarningsPerShareDiluted	10
3832	10	18	2025	FY	2025-01-01	2025-12-31	0.1800	USD/shares	us-gaap:EarningsPerShareDiluted	10
3833	10	19	2019	FY	2019-01-01	2019-12-31	214000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	224
3834	10	19	2020	FY	2020-01-01	2020-12-31	168000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	225
3835	10	19	2021	FY	2021-01-01	2021-12-31	205000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	226
3836	10	19	2022	FY	2022-01-01	2022-12-31	212000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	227
3837	10	19	2023	FY	2023-01-01	2023-12-31	223000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	10
3838	10	19	2024	FY	2024-01-01	2024-12-31	288000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	10
3839	10	19	2025	FY	2025-01-01	2025-12-31	321000000.0000	USD	us-gaap:PaymentsOfDividendsCommonStock	10
3840	10	19	2022	Q2	2022-04-01	2022-06-30	55000000.0000	USD	us-gaap:PaymentsOfDividends	227
3841	10	19	2022	Q3	2022-07-01	2022-09-30	54000000.0000	USD	us-gaap:PaymentsOfDividends	227
3842	10	19	2022	Q4	2022-10-01	2022-12-31	48000000.0000	USD	us-gaap:PaymentsOfDividends	227
3843	10	19	2023	Q2	2023-04-01	2023-06-30	55000000.0000	USD	us-gaap:PaymentsOfDividends	10
3844	10	19	2023	Q3	2023-07-01	2023-09-30	54000000.0000	USD	us-gaap:PaymentsOfDividends	10
3845	10	19	2023	Q4	2023-10-01	2023-12-31	54000000.0000	USD	us-gaap:PaymentsOfDividends	227
3846	10	19	2024	Q1	2024-01-01	2024-03-31	54000000.0000	USD	us-gaap:PaymentsOfDividends	227
3847	10	19	2024	Q2	2024-04-01	2024-06-30	81000000.0000	USD	us-gaap:PaymentsOfDividends	10
3848	10	19	2024	Q3	2024-07-01	2024-09-30	81000000.0000	USD	us-gaap:PaymentsOfDividends	10
3849	10	19	2024	Q4	2024-10-01	2024-12-31	72000000.0000	USD	us-gaap:PaymentsOfDividends	10
3850	10	19	2025	Q2	2025-04-01	2025-06-30	81000000.0000	USD	us-gaap:PaymentsOfDividends	10
3851	10	19	2025	Q3	2025-07-01	2025-09-30	80000000.0000	USD	us-gaap:PaymentsOfDividends	10
3852	10	19	2025	Q4	2025-10-01	2025-12-31	71000000.0000	USD	us-gaap:PaymentsOfDividends	10
3853	10	20	2019	FY	2019-01-01	2019-12-31	250000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	224
3854	10	20	2020	FY	2020-01-01	2020-12-31	125000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	225
3855	10	20	2021	FY	2021-01-01	2021-12-31	485000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	226
3856	10	20	2022	FY	2022-01-01	2022-12-31	346000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	227
3857	10	20	2023	FY	2023-01-01	2023-12-31	346000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	10
3858	10	20	2024	FY	2024-01-01	2024-12-31	359000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	10
3859	10	20	2025	FY	2025-01-01	2025-12-31	367000000.0000	USD	us-gaap:PaymentsForRepurchaseOfCommonStock	10
3860	10	21	2019	Q1	2019-01-01	2019-03-31	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	224
3861	10	21	2019	Q2	\N	2019-05-31	0.2400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	225
3862	10	21	2019	Q3	2019-07-01	2019-09-30	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	225
3863	10	21	2019	Q4	2019-10-01	2019-12-31	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	225
3864	10	21	2020	Q1	2020-01-01	2020-03-31	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	225
3865	10	21	2020	Q2	\N	2020-06-17	0.1680	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	225
3866	10	21	2020	Q3	2020-07-01	2020-09-30	0.0420	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	225
3867	10	21	2020	Q4	2020-10-01	2020-12-31	0.0420	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	225
3868	10	21	2021	Q1	2021-01-01	2021-03-31	0.0420	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	225
3869	10	21	2021	Q2	\N	2021-05-27	0.2400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	226
3870	10	21	2021	Q3	2021-07-01	2021-09-30	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	226
3871	10	21	2021	Q4	2021-10-01	2021-12-31	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	226
3872	10	21	2022	Q1	2022-01-01	2022-03-31	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	226
3873	10	21	2022	Q2	\N	2022-05-25	0.2400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	226
3874	10	21	2022	Q3	2022-07-01	2022-09-30	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	227
3875	10	21	2022	FY	2022-01-01	2022-12-31	0.2400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	227
3876	10	21	2022	Q4	2022-10-01	2022-12-31	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	227
3877	10	21	2023	Q1	2023-01-01	2023-03-31	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	227
3878	10	21	2023	Q2	\N	2023-05-25	0.2400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	226
3879	10	21	2023	Q3	2023-07-01	2023-09-30	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3880	10	21	2023	FY	2023-01-01	2023-12-31	0.2400	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3881	10	21	2023	Q4	2023-10-01	2023-12-31	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3882	10	21	2024	Q1	2024-01-01	2024-03-31	0.0600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3883	10	21	2024	Q2	2024-04-01	2024-06-30	0.0900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3884	10	21	2024	Q3	2024-07-01	2024-09-30	0.0900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3885	10	21	2024	FY	2024-01-01	2024-12-31	0.3600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3886	10	21	2024	Q4	2024-10-01	2024-12-31	0.0900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3887	10	21	2025	Q1	2025-01-01	2025-03-31	0.0900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3888	10	21	2025	Q2	2025-04-01	2025-06-30	0.0900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3889	10	21	2025	Q3	2025-07-01	2025-09-30	0.0900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3890	10	21	2025	FY	2025-01-01	2025-12-31	0.3600	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
3891	10	21	2025	Q4	2025-10-01	2025-12-31	0.0900	USD/shares	us-gaap:CommonStockDividendsPerShareDeclared	10
\.


--
-- Data for Name: footnote_related_parties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.footnote_related_parties (related_party_id, company_id, filing_id, related_party_name, related_company_id, related_person_id, relationship, transaction_type, amount_usd, fiscal_year, description) FROM stdin;
1	1	1	xAI	153	3	entity controlled by our CEO	sale of products	430000000.00	2025	Tesla recognized $430 million of revenues from xAI for its purchase of Megapack products in the ordinary course of business.
2	1	1	xAI	153	3	entity controlled by our CEO	investment	2000000000.00	2026	Tesla entered into an agreement to invest approximately $2 billion to acquire shares of Series E Preferred Stock of xAI.
3	2	2	Undisclosed related party	\N	\N	entity controlled by our CEO	interest expense on loan/financing	186000000.00	2026	SpaceX incurred $186 million in interest expense to a related party in the quarter ended March 31, 2026.
4	2	2	Undisclosed related party	\N	\N	entity controlled by our CEO	purchase of property, plant, and equipment	34000000.00	2026	SpaceX purchased $34 million of property, plant, and equipment from a related party in the quarter ended March 31, 2026.
5	2	2	Undisclosed related party	\N	\N	entity controlled by our CEO	purchase of property, plant, and equipment	84000000.00	2025	SpaceX purchased $84 million of property, plant, and equipment from a related party in the quarter ended March 31, 2025.
6	2	2	xAI	153	3	entity controlled by our CEO	conversion of preferred stock in merger	37476000000.00	2026	SpaceX converted $37.476 billion of redeemable convertible preferred stock into common stock as part of the xAI merger in the quarter ended March 31, 2026.
7	2	2	Valor	156	\N	related party (entity affiliated with management)	sale-leaseback / equipment lease	5365000000.00	2026	CTC entered into a failed sale-leaseback equipment lease agreement with Valor for AI infrastructure hardware, recording $5,365 million in related debt.
8	2	2	xAI	153	\N	entity controlled by CEO Elon Musk	merger / stock issuance and cash payment	2947000000.00	2026	SpaceX completed the xAI Merger, issuing 321.7 million Class A and 121.7 million Class B shares and paying $2,947 million cash to xAI equity holders.
9	2	2	Tesla	1	\N	entity controlled by CEO Elon Musk	stock issuance	\N	2026	SpaceX issued 3.8 million Class A common shares to Tesla following conversion of Tesla's xAI Series E preferred stock investment rights after the xAI Merger.
10	2	2	Tesla	1	\N	entity controlled by CEO Elon Musk	collaboration agreement	\N	2026	SpaceX announced a collaboration with Tesla to build a chip manufacturing facility called Terafab.
11	2	2	Valor	156	\N	related party (entity affiliated with management)	equipment lease / sale-leaseback	6587000000.00	2026	CTC entered into a five-year equipment lease agreement with Valor for AI infrastructure hardware with total undiscounted lease payments of $6,587 million.
12	2	2	Tesla, Inc.	1	\N	entity affiliated with CEO	purchase of Megapack products	34000000.00	2026	The Company purchased $34 million of Megapack products from Tesla during the three months ended March 31, 2026.
13	2	2	Tesla, Inc.	1	\N	entity affiliated with CEO	purchase of Megapack products	506000000.00	2025	As of December 31, 2025, the Company had purchased $506 million of Megapack products from Tesla.
14	2	2	Tesla, Inc.	1	\N	entity affiliated with CEO	purchase of Cybertrucks	131000000.00	2025	As of December 31, 2025, the Company had purchased $131 million of Cybertrucks from Tesla at manufacturer's suggested retail price.
15	2	2	Valor Equity Partners	157	12	entity controlled by director Antonio Gracias	equipment lease agreement for AI infrastructure hardware	\N	2026	CTC entered into an equipment lease agreement with Valor Equity Partners for AI infrastructure hardware in January 2026, amended February 18, 2026.
16	2	2	Valor Equity Partners	157	12	entity controlled by director Antonio Gracias	equipment lease agreement for AI infrastructure hardware	\N	\N	The Company previously entered into an equipment lease agreement with Valor Equity Partners for other AI infrastructure hardware.
17	2	2	Tesla, Inc.	1	3	entity controlled by our CEO	purchase of products	506000000.00	2025	SpaceX purchased $506 million of Megapack products from Tesla in 2025.
18	2	2	Tesla, Inc.	1	3	entity controlled by our CEO	purchase of products	191000000.00	2024	SpaceX purchased $191 million of Megapack products from Tesla in 2024.
19	2	2	Valor Equity Partners	157	12	entity whose founder/CEO/CIO serves as our director	equipment lease (failed sale-leaseback)	4507000000.00	2025	CTC entered a failed sale-leaseback with Valor Equity Partners, recording $4.507 billion debt and $66 million interest expense in 2025.
20	2	2	Elon Musk Trust	\N	3	CEO and major shareholder	purchase of common stock from employees	1421000000.00	2025	Elon Musk's trust purchased $1.421 billion of common stock from current and former employees in 2025.
21	3	3	the Trust	163	\N	Trust participating in Preferred Stock Exchange	issuance of preferred stock	\N	2025	The Company issued 50,951,250 shares of Preferred Stock to the Trust as part of the Preferred Stock Exchange.
22	3	3	the Trust	163	\N	Trust participating in Preferred Stock Exchange	conversion of preferred stock to common stock	\N	2025	The Trust converted 5,000,000 shares of Preferred Stock to common stock on a one-for-one basis.
23	9	9	Associates	197	\N	associate (entity with significant influence)	sale of products	\N	2023	TSMC recognized sales revenue of NT$13,406.0 million from associates in 2023.
24	9	9	Associates	197	\N	associate (entity with significant influence)	sale of products	\N	2024	TSMC recognized sales revenue of NT$15,034.1 million from associates in 2024.
25	9	9	Associates	197	\N	associate (entity with significant influence)	sale of products	\N	2025	TSMC recognized sales revenue of NT$33,226.4 million from associates in 2025.
26	9	9	GUC	198	\N	associate (entity with significant influence)	receivables	\N	2024	TSMC had receivables from GUC of NT$610.0 million as of December 31, 2024.
27	9	9	GUC	198	\N	associate (entity with significant influence)	receivables	\N	2025	TSMC had receivables from GUC of NT$1,651.0 million as of December 31, 2025.
28	9	9	VIS	199	\N	associate (entity with significant influence)	other receivables	\N	2024	TSMC had other receivables from VIS of NT$0 million as of December 31, 2024.
29	9	9	VIS	199	\N	associate (entity with significant influence)	other receivables	\N	2025	TSMC had other receivables from VIS of NT$267.8 million as of December 31, 2025.
30	9	9	Xintec	200	\N	associate (entity with significant influence)	payables	\N	2024	TSMC had payables to Xintec of NT$988.0 million as of December 31, 2024.
31	9	9	Xintec	200	\N	associate (entity with significant influence)	payables	\N	2025	TSMC had payables to Xintec of NT$1,298.7 million as of December 31, 2025.
32	9	9	Associates	197	\N	associate (entity with significant influence)	accrued expenses	\N	2024	TSMC recorded temporary receipts from associates of NT$4,271.5 million as of December 31, 2024.
33	9	9	Associates	197	\N	associate (entity with significant influence)	accrued expenses	\N	2025	TSMC recorded temporary receipts from associates of NT$638.8 million as of December 31, 2025.
34	9	9	Associates	197	\N	associate (entity with significant influence)	manufacturing expenses	\N	2023	TSMC incurred manufacturing expenses of NT$5,043.5 million with associates in 2023.
35	9	9	Associates	197	\N	associate (entity with significant influence)	manufacturing expenses	\N	2024	TSMC incurred manufacturing expenses of NT$5,232.8 million with associates in 2024.
36	9	9	Associates	197	\N	associate (entity with significant influence)	manufacturing expenses	\N	2025	TSMC incurred manufacturing expenses of NT$5,448.2 million with associates in 2025.
37	9	9	Associates	197	\N	associate (entity with significant influence)	lease	\N	2025	TSMC leased factory and office from associates with rental expenses classified under manufacturing expenses.
38	9	9	Key management personnel	201	\N	directors and key management personnel	compensation	\N	2023	TSMC paid total compensation of NT$4,022.0 million to directors and key management personnel in 2023.
39	9	9	Key management personnel	201	\N	directors and key management personnel	compensation	\N	2024	TSMC paid total compensation of NT$5,808.7 million to directors and key management personnel in 2024.
40	9	9	Key management personnel	201	\N	directors and key management personnel	compensation	\N	2025	TSMC paid total compensation of NT$9,224.4 million to directors and key management personnel in 2025.
41	9	9	Vanguard International Semiconductor Corporation (VIS)	202	\N	affiliate (27.6% equity interest)	investment (capital increase)	\N	2024	TSMC acquired additional shares in VIS' capital increase transaction in October 2024.
42	9	9	TSMC Arizona	\N	\N	wholly-owned subsidiary	guarantee	\N	2024	TSMC provided irrevocable guarantees to the U.S. Department of Commerce for TSMC Arizona's obligations under CHIPS Act direct funding and loan agreements.
43	10	10	Capgemini, Dassault Systèmes, Orange, Politecnico di Milano and Sopra Steria	213	\N	Companies for which certain members of STMicroelectronics management perform similar policymaking functions	purchase of services	49000000.00	2025	STMicroelectronics purchased services from related parties Capgemini, Dassault Systèmes, Orange, Politecnico di Milano and Sopra Steria totaling $49 million in 2025.
44	10	10	Capgemini, Dassault Systèmes, Orange, Politecnico di Milano and Sopra Steria	213	\N	Companies for which certain members of STMicroelectronics management perform similar policymaking functions	purchase of services	29000000.00	2024	STMicroelectronics purchased services from related parties Capgemini, Dassault Systèmes, Orange, Politecnico di Milano and Sopra Steria totaling $29 million in 2024.
45	10	10	Capgemini, Dassault Systèmes, Orange, Politecnico di Milano and Sopra Steria	213	\N	Companies for which certain members of STMicroelectronics management perform similar policymaking functions	purchase of services	27000000.00	2023	STMicroelectronics purchased services from related parties Capgemini, Dassault Systèmes, Orange, Politecnico di Milano and Sopra Steria totaling $27 million in 2023.
46	10	10	Capgemini, Dassault Systèmes, Orange, Politecnico di Milano and Sopra Steria	213	\N	Companies for which certain members of STMicroelectronics management perform similar policymaking functions	sale of products and services	5000000.00	2023	STMicroelectronics sold products and services to related parties Capgemini, Dassault Systèmes, Orange, Politecnico di Milano and Sopra Steria totaling $5 million in 2023.
47	10	10	ST Foundation	214	\N	Non-profit organization where certain members of the Foundation’s Board are senior members of STMicroelectronics management	cash contribution	1000000.00	2024	STMicroelectronics made a $1.0 million cash contribution to the ST Foundation in 2024.
48	10	10	ST Foundation	214	\N	Non-profit organization where certain members of the Foundation’s Board are senior members of STMicroelectronics management	cash contribution	1000000.00	2023	STMicroelectronics made a $1.0 million cash contribution to the ST Foundation in 2023.
\.


--
-- Data for Name: institutional_holders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institutional_holders (institution_id, cik, name) FROM stdin;
1	102909	VANGUARD GROUP INC
2	1364742	BlackRock Finance, Inc.
3	93751	STATE STREET CORP
4	315066	FMR LLC
5	1214717	GEODE CAPITAL MANAGEMENT, LLC
6	895421	MORGAN STANLEY
7	19617	JPMORGAN CHASE & CO
8	1422849	Capital World Investors
9	80255	PRICE T ROWE ASSOCIATES INC /MD/
10	73124	NORTHERN TRUST CORP
11	886982	GOLDMAN SACHS GROUP INC
12	70858	BANK OF AMERICA CORP /DE/
13	1374170	NORGES BANK
14	902219	WELLINGTON MANAGEMENT GROUP LLP
15	1697748	ARK Investment Management LLC
16	1088875	BAILLIE GIFFORD & CO
17	914208	Invesco Ltd.
18	1037389	RENAISSANCE TECHNOLOGIES LLC
19	1423053	CITADEL ADVISORS LLC
20	1350694	Bridgewater Associates, LP
\.


--
-- Data for Name: institutional_holdings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.institutional_holdings (holding_id, institution_id, company_id, report_period, shares, value_usd, source_filing_id) FROM stdin;
1	1	5	2025-12-31	70989438	15413226779.00	1545
2	1	3	2025-12-31	47420192	3308032594.00	1545
3	1	9	2025-12-31	109489	33272612.00	1545
4	1	1	2025-12-31	258925024	116443761793.00	1545
5	1	7	2025-12-31	14529573	2055062805.00	1545
6	1	4	2025-12-31	21271281	10288280481.00	1545
7	1	6	2025-12-31	2266683275	422736430797.00	1545
8	1	8	2025-12-31	46385185	26572680931.00	1545
9	1	7	2025-09-30	14604074	1184098320.00	1546
10	1	5	2025-09-30	67529417	14574874072.00	1546
11	1	8	2025-09-30	45943021	21921712596.00	1546
12	1	4	2025-09-30	21288650	10627506967.00	1546
13	1	6	2025-09-30	2223533800	414866936311.00	1546
14	1	3	2025-09-30	41809723	2003103828.00	1546
15	1	9	2025-09-30	118468	33086928.00	1546
16	1	1	2025-09-30	252386304	112241237115.00	1546
17	2	7	2024-06-30	14686151	1172075114.00	1547
18	2	5	2024-06-30	36289983	6605139733.00	1547
19	2	8	2024-06-30	36212981	12062543851.00	1547
20	2	4	2024-06-30	17003130	7942162065.00	1547
21	2	6	2024-06-30	1839270238	227223445280.00	1547
22	2	3	2024-06-30	27182758	130477237.00	1547
23	2	10	2024-06-30	5595899	219806909.00	1547
24	2	9	2024-06-30	15055901	2616866125.00	1547
25	2	1	2024-06-30	190084412	37613903389.00	1547
26	2	7	2024-03-31	14640369	1584803892.00	1548
27	2	5	2024-03-31	37171275	7173684411.00	1548
28	2	8	2024-03-31	33534129	12287910918.00	1548
29	2	4	2024-03-31	18563076	8443786486.00	1548
30	2	6	2024-03-31	182238925	164663803133.00	1548
31	2	3	2024-03-31	23912574	98280679.00	1548
32	2	10	2024-03-31	5082655	219774020.00	1548
33	2	9	2024-03-31	15001131	2040903915.00	1548
34	2	1	2024-03-31	188368567	33113310377.00	1548
35	3	7	2026-09-30	6936442	699292086.00	1549
36	3	5	2026-09-30	39733430	7192930841.00	1549
37	3	8	2026-09-30	34141192	27681337062.00	1549
38	3	4	2026-09-30	33048935	16830170149.00	1549
39	3	6	2026-09-30	1025075347	234355573846.00	1549
40	3	3	2026-09-30	16077984	1120313925.00	1549
41	3	2	2026-09-30	19336612	2917121286.00	1549
42	3	10	2026-09-30	104064	5552855.00	1549
43	3	9	2026-09-30	670480	306613746.00	1549
44	3	1	2026-09-30	118773869	42142156460.00	1549
45	3	7	2026-06-30	6204186	783774150.00	1550
46	3	5	2026-06-30	39785797	8354089088.00	1550
47	3	8	2026-06-30	34392316	36624377308.00	1550
48	3	4	2026-06-30	32975170	16799530108.00	1550
49	3	6	2026-06-30	1009783437	202047567909.00	1550
50	3	3	2026-06-30	14442067	1468036111.00	1550
51	3	10	2026-06-30	105070	7868692.00	1550
52	3	9	2026-06-30	922710	441347400.00	1550
53	3	1	2026-06-30	117456756	49402311574.00	1550
54	4	7	2026-09-30	5096348	509817886.00	1551
55	4	5	2026-09-30	64141617	11173868610.00	1551
56	4	8	2026-09-30	5867194	4757061851.00	1551
57	4	4	2026-09-30	1432764	729634887.00	1551
58	4	6	2026-09-30	932807820	213034649836.00	1551
59	4	3	2026-09-30	4099752	285670737.00	1551
60	4	2	2026-09-30	248291710	36327436092.00	1551
61	4	10	2026-09-30	1138713	60761726.00	1551
62	4	9	2026-09-30	65370233	29821246558.00	1551
63	4	1	2026-09-30	38820605	13773938962.00	1551
64	4	7	2026-06-30	3187645	390468912.00	1552
65	4	5	2026-06-30	66535434	13275236654.00	1552
66	4	8	2026-06-30	5781969	6157218434.00	1552
67	4	4	2026-06-30	1667767	849660894.00	1552
68	4	6	2026-06-30	1026051548	205302654261.00	1552
69	4	3	2026-06-30	3701770	376284990.00	1552
70	4	2	2026-06-30	302555831	51655459728.00	1552
71	4	10	2026-06-30	1734640	129907234.00	1552
72	4	9	2026-06-30	58937551	28146806368.00	1552
73	4	1	2026-06-30	39766224	16725673841.00	1552
74	5	7	2026-09-30	3141782	331731267.00	1553
75	5	5	2026-09-30	18232517	3377085190.00	1553
76	5	8	2026-09-30	11254230	9104474296.00	1553
77	5	4	2026-09-30	5235061	2660750286.00	1553
78	5	6	2026-09-30	613740577	139797352249.00	1553
79	5	3	2026-09-30	10919528	768892442.00	1553
80	5	2	2026-09-30	22266495	3354943090.00	1553
81	5	9	2026-09-30	645601	294516720.00	1553
82	5	1	2026-09-30	69899419	24696848820.00	1553
83	5	7	2026-06-30	3129997	421870561.00	1554
84	5	5	2026-06-30	17976472	3874006579.00	1554
85	5	8	2026-06-30	11175493	11916757022.00	1554
86	5	4	2026-06-30	5216758	2663494814.00	1554
87	5	6	2026-06-30	606216492	120957505504.00	1554
88	5	3	2026-06-30	10503238	1076957022.00	1554
89	5	2	2026-06-30	13529026	2306997291.00	1554
90	5	9	2026-06-30	626103	299008009.00	1554
91	5	1	2026-06-30	68914720	28864073379.00	1554
92	6	6	2026-09-30	362006252	82674988489.00	1555
93	6	1	2026-09-30	41777151	14822951856.00	1555
94	6	4	2026-09-30	5917607	3013542559.00	1555
95	6	5	2026-09-30	10584888	1965147758.00	1555
96	6	9	2026-09-30	16194256	7387658775.00	1555
97	6	7	2026-09-30	4205751	375406592.00	1555
98	6	2	2026-09-30	37302405	5627441205.00	1555
99	6	3	2026-09-30	7110734	495476138.00	1555
100	6	10	2026-09-30	6863950	366260572.00	1555
101	6	8	2026-09-30	8479030	6874714687.00	1555
102	6	6	2026-06-30	356420089	71316096193.00	1556
103	6	1	2026-06-30	38872087	16349601265.00	1556
104	6	4	2026-06-30	5706408	2907187687.00	1556
105	6	5	2026-06-30	10908153	2347596649.00	1556
106	6	9	2026-06-30	15847816	7568443224.00	1556
107	6	7	2026-06-30	3551778	427335779.00	1556
108	6	2	2026-06-30	13532773	2312209947.00	1556
109	6	3	2026-06-30	6895400	700917732.00	1556
110	6	10	2026-06-30	6390403	478577456.00	1556
111	6	8	2026-06-30	7504426	7991466469.00	1556
112	7	7	2026-09-30	1590213	160349739.00	1557
113	7	5	2026-09-30	4484767	810125189.00	1557
114	7	8	2026-09-30	5005806	4138001924.00	1557
115	7	4	2026-09-30	1036903	531113230.00	1557
116	7	6	2026-09-30	462163595	105008191161.00	1557
117	7	3	2026-09-30	7628239	531688397.00	1557
118	7	2	2026-09-30	17083279	2549508762.00	1557
119	7	10	2026-09-30	1488207	79232194.00	1557
120	7	9	2026-09-30	17728466	8100846192.00	1557
121	7	1	2026-09-30	33111574	11683088785.00	1557
122	7	7	2026-06-30	1681843	211316614.00	1558
123	7	5	2026-06-30	4539618	930631467.00	1558
124	7	8	2026-06-30	7325731	7568875009.00	1558
125	7	4	2026-06-30	900840	452285583.00	1558
126	7	6	2026-06-30	449404578	87620410963.00	1558
127	7	3	2026-06-30	13805113	1353039239.00	1558
128	7	2	2026-06-30	15563576	2555383782.00	1558
129	7	10	2026-06-30	3068232	229473116.00	1558
130	7	9	2026-06-30	23829286	10844709209.00	1558
131	7	1	2026-06-30	41972287	17285867586.00	1558
132	8	7	2026-09-30	11383096	1099886288.00	1559
133	8	5	2026-09-30	47970916	6157033647.00	1559
134	8	8	2026-09-30	2673243	2168343161.00	1559
135	8	4	2026-09-30	1846727	940445710.00	1559
136	8	6	2026-09-30	88822582	20285113737.00	1559
137	8	3	2026-09-30	7146140	497943250.00	1559
138	8	2	2026-09-30	3955600	596738361.00	1559
139	8	9	2026-09-30	33796063	15417541178.00	1559
140	8	1	2026-09-30	43734195	15517133009.00	1559
141	8	7	2026-06-30	12635268	1488317868.00	1560
142	8	5	2026-06-30	63562546	8852014242.00	1560
143	8	8	2026-06-30	3060432	3256656964.00	1560
144	8	4	2026-06-30	1844218	939555249.00	1560
145	8	6	2026-06-30	109129403	21834390351.00	1560
146	8	3	2026-06-30	7370414	749187414.00	1560
147	8	2	2026-06-30	3694511	631244149.00	1560
148	8	9	2026-06-30	34372274	16410842195.00	1560
149	8	1	2026-06-30	45735669	19235629659.00	1560
150	9	7	2026-06-30	973486	131452.00	1561
151	9	5	2026-06-30	13444565	2558102.00	1561
152	9	8	2026-06-30	6171628	6572168.00	1561
153	9	4	2026-06-30	302426	154075.00	1561
154	9	3	2026-06-30	2410922	245072.00	1561
155	9	10	2026-06-30	2158025	161615.00	1561
156	9	9	2026-06-30	11320845	5406497.00	1561
157	9	6	2026-06-30	369829781	73999242.00	1561
158	9	2	2026-06-30	10709016	1829743.00	1561
159	9	1	2026-06-30	25141239	10574406.00	1561
160	9	7	2026-03-31	271001	48655.00	1562
161	9	5	2026-03-31	14269079	2518451.00	1562
162	9	8	2026-03-31	5582018	3954638.00	1562
163	9	4	2026-03-31	302356	182742.00	1562
164	9	3	2026-03-31	1751152	112460.00	1562
165	9	9	2026-03-31	8160104	2757709.00	1562
166	9	6	2026-03-31	370102688	64545910.00	1562
167	9	1	2026-03-31	24808882	9222703.00	1562
168	10	7	2026-06-30	1218132	164484364.00	1563
169	10	5	2026-06-30	6498426	1406714276.00	1563
170	10	8	2026-06-30	5664155	6031758660.00	1563
171	10	4	2026-06-30	1961038	999070420.00	1563
172	10	6	2026-06-30	251042789	50231151651.00	1563
173	10	1	2026-06-30	25815785	10858119171.00	1563
174	10	9	2026-06-30	6184369	2953469103.00	1563
175	10	3	2026-06-30	3311777	336642131.00	1563
176	10	2	2026-06-30	2782782	475466133.00	1563
177	10	10	2026-06-30	704460	52757009.00	1563
178	10	7	2026-03-31	1218722	218797160.00	1564
179	10	5	2026-03-31	6472901	1288301486.00	1564
180	10	8	2026-03-31	5678795	4023199106.00	1564
181	10	4	2026-03-31	1941095	1173178408.00	1564
182	10	6	2026-03-31	252741836	44078176199.00	1564
183	10	1	2026-03-31	25659609	9538959648.00	1564
184	10	9	2026-03-31	6509047	2199732434.00	1564
185	10	3	2026-03-31	3090151	198449498.00	1564
186	10	10	2026-03-31	614900	21244796.00	1564
187	11	7	2026-06-30	1663086	224566568.00	1565
188	11	5	2026-06-30	3763442	811537086.00	1565
189	11	8	2026-06-30	3570493	3802217827.00	1565
190	11	4	2026-06-30	1902778	969389403.00	1565
191	11	6	2026-06-30	192146665	38446626224.00	1565
192	11	3	2026-06-30	5559472	565120294.00	1565
193	11	2	2026-06-30	1427816	243956684.00	1565
194	11	10	2026-06-30	5150378	385711784.00	1565
195	11	9	2026-06-30	16125333	7700975273.00	1565
196	11	1	2026-06-30	31060669	13064117894.00	1565
197	11	7	2026-03-31	1672609	300283583.00	1566
198	11	5	2026-03-31	3682994	730201645.00	1566
199	11	8	2026-03-31	3210971	2274844961.00	1566
200	11	4	2026-03-31	1701825	1028565604.00	1566
201	11	6	2026-03-31	180908765	31550488745.00	1566
202	11	3	2026-03-31	2556299	164165521.00	1566
203	11	10	2026-03-31	4271819	147591345.00	1566
204	11	9	2026-03-31	9401594	3177268636.00	1566
205	11	1	2026-03-31	29398294	10928815969.00	1566
206	12	7	2026-06-30	2826313	359088510.00	1567
207	12	5	2026-06-30	11652657	2469157164.00	1567
208	12	8	2026-06-30	5463565	5818149989.00	1567
209	12	4	2026-06-30	2284661	1163943766.00	1567
210	12	6	2026-06-30	195366864	39090955802.00	1567
211	12	3	2026-06-30	4301823	437280258.00	1567
212	12	2	2026-06-30	3643266	622488430.00	1567
213	12	10	2026-06-30	2662941	199427669.00	1567
214	12	9	2026-06-30	15282620	7298520678.00	1567
215	12	1	2026-06-30	18117418	7620186051.00	1567
216	12	7	2026-03-31	3489475	571210565.00	1568
217	12	5	2026-03-31	11731714	2311637504.00	1568
218	12	8	2026-03-31	5677578	4022337028.00	1568
219	12	4	2026-03-31	2695689	1629247688.00	1568
220	12	6	2026-03-31	191200989	33345452534.00	1568
221	12	3	2026-03-31	4533362	291132482.00	1568
222	12	10	2026-03-31	918591	31737334.00	1568
223	12	9	2026-03-31	14107771	4767721198.00	1568
224	12	1	2026-03-31	18962828	7049431133.00	1568
225	13	7	2026-06-30	1394324	188275570.00	1570
226	13	6	2026-06-30	325951734	65219682456.00	1570
227	13	3	2026-06-30	5437031	552674201.00	1570
228	13	2	2026-06-30	7277285	1243396915.00	1570
229	13	9	2026-06-30	28610	13663278.00	1570
230	13	1	2026-06-30	38812422	16324504693.00	1570
231	14	7	2026-06-30	49412	6672102.00	1571
232	14	5	2026-06-30	2805938	575761102.00	1571
233	14	8	2026-06-30	1144800	1219097521.00	1571
234	14	4	2026-06-30	746194	380155995.00	1571
235	14	6	2026-06-30	122084399	24427867396.00	1571
236	14	3	2026-06-30	1173469	119283124.00	1571
237	14	2	2026-06-30	6154854	1051618353.00	1571
238	14	9	2026-06-30	6383164	3048407631.00	1571
239	14	1	2026-06-30	9841129	4139178857.00	1571
240	14	7	2026-03-31	18871	3387911.00	1572
241	14	5	2026-03-31	2558208	474739571.00	1572
242	14	8	2026-03-31	1118722	792569789.00	1572
243	14	4	2026-03-31	812459	491042095.00	1572
244	14	6	2026-03-31	133855881	23344465647.00	1572
245	14	9	2026-03-31	7597163	2567461236.00	1572
246	14	1	2026-03-31	9150977	3401875699.00	1572
247	15	1	2026-09-30	3371681	1196306136.00	1573
248	15	8	2026-09-30	32029	25968793.00	1573
249	15	4	2026-09-30	12511	6371227.00	1573
250	15	6	2026-09-30	2561223	584932116.00	1573
251	15	9	2026-09-30	532668	242997815.00	1573
252	15	3	2026-09-30	3557458	247883675.00	1573
253	15	2	2026-09-30	6746417	1017764417.00	1573
254	15	1	2026-06-30	2759800	1160772073.00	1574
255	15	8	2026-06-30	56008	59642919.00	1574
256	15	4	2026-06-30	14806	7543065.00	1574
257	15	6	2026-06-30	1381247	276373746.00	1574
258	15	9	2026-06-30	482286	230325325.00	1574
259	15	3	2026-06-30	1631207	165812192.00	1574
260	15	2	2026-06-30	4478013	765113281.00	1574
261	16	7	2026-09-30	414694	36643131.00	1575
262	16	6	2026-09-30	42573061	9722835670.00	1575
263	16	3	2026-09-30	10451797	728281215.00	1575
264	16	2	2026-09-30	39005040	5884300334.00	1575
265	16	1	2026-09-30	642296	227893044.00	1575
266	16	7	2026-06-30	416531	46694981.00	1576
267	16	6	2026-06-30	41888806	8381531192.00	1576
268	16	3	2026-06-30	10384512	1055585645.00	1576
269	16	2	2026-06-30	51397806	8781829133.00	1576
270	16	1	2026-06-30	730641	307307604.00	1576
271	17	7	2026-09-30	2392688	242465786.00	1577
272	17	5	2026-09-30	6360205	1124296546.00	1577
273	17	8	2026-09-30	3180305	2578559273.00	1577
274	17	4	2026-09-30	2749225	1400043048.00	1577
275	17	6	2026-09-30	320718984	73245801657.00	1577
276	17	3	2026-09-30	17579001	1224904789.00	1577
277	17	2	2026-09-30	116889012	17633876350.00	1577
278	17	10	2026-09-30	3598284	192004428.00	1577
279	17	9	2026-09-30	3568228	1627789840.00	1577
280	17	1	2026-09-30	58042026	20593891127.00	1577
281	17	7	2026-06-30	1966820	256512120.00	1578
282	17	5	2026-06-30	5684177	1159237902.00	1578
283	17	8	2026-06-30	3284093	3497230434.00	1578
284	17	4	2026-06-30	2426642	1236276896.00	1578
285	17	6	2026-06-30	329593488	65948361031.00	1578
286	17	3	2026-06-30	18343547	1864621551.00	1578
287	17	2	2026-06-30	3859467	659428534.00	1578
288	17	10	2026-06-30	4745181	355366597.00	1578
289	17	9	2026-06-30	3564033	1702075460.00	1578
290	17	1	2026-06-30	55464442	23328344382.00	1578
291	18	7	2026-09-30	28910	3058100.00	1579
292	18	4	2026-09-30	116840	59500770.00	1579
293	18	6	2026-09-30	23170	5327269.00	1579
294	18	2	2026-09-30	4113200	620517529.00	1579
295	18	10	2026-09-30	805526	42774842.00	1579
296	18	9	2026-09-30	126320	57625921.00	1579
297	18	1	2026-09-30	684145	242741487.00	1579
298	18	7	2026-06-30	456145	61593259.00	1580
299	18	5	2026-06-30	142784	30908452.00	1580
300	18	4	2026-06-30	298520	152083999.00	1580
301	18	6	2026-06-30	7091256	1418869170.00	1580
302	18	3	2026-06-30	48600	4940190.00	1580
303	18	10	2026-06-30	332974	24536285.00	1580
304	18	9	2026-06-30	849080	405495136.00	1580
305	18	1	2026-06-30	1110960	467270040.00	1580
306	19	7	2026-06-30	875071	118160837.00	1581
307	19	5	2026-06-30	857294	185578432.00	1581
308	19	8	2026-06-30	355861	378956379.00	1581
309	19	4	2026-06-30	671430	342066728.00	1581
310	19	6	2026-06-30	11815467	2364156792.00	1581
311	19	2	2026-06-30	5129884	876491980.00	1581
312	19	10	2026-06-30	3852113	288484742.00	1581
313	19	9	2026-06-30	525939	251172688.00	1581
314	19	1	2026-06-30	1226238	515755703.00	1581
315	19	7	2026-03-31	181725	32625089.00	1582
316	19	5	2026-03-31	1001461	199320783.00	1582
317	19	8	2026-03-31	309529	219288915.00	1582
318	19	4	2026-03-31	749241	452833768.00	1582
319	19	6	2026-03-31	18664861	3255151758.00	1582
320	19	3	2026-03-31	816681	52447254.00	1582
321	19	10	2026-03-31	6909118	238710027.00	1582
322	19	9	2026-03-31	4035762	1363885768.00	1582
323	19	1	2026-03-31	2092309	777815871.00	1582
324	20	7	2026-06-30	116250	15697238.00	1583
325	20	5	2026-06-30	4995	1081268.00	1583
326	20	8	2026-06-30	7329	7804652.00	1583
327	20	4	2026-06-30	38715	19723744.00	1583
328	20	6	2026-06-30	3866195	773586958.00	1583
329	20	3	2026-06-30	11267	1145291.00	1583
330	20	2	2026-06-30	11597	1981463.00	1583
331	20	9	2026-06-30	34525	16488104.00	1583
332	20	7	2026-03-31	32926	5911205.00	1584
333	20	8	2026-03-31	82502	58449367.00	1584
334	20	4	2026-03-31	11302	6830816.00	1584
335	20	6	2026-03-31	4693003	818459723.00	1584
336	20	3	2026-03-31	16727	1074208.00	1584
337	20	9	2026-03-31	1077079	363998848.00	1584
338	20	1	2026-03-31	2017	749820.00	1584
\.


--
-- Data for Name: legal_proceedings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.legal_proceedings (legal_proceeding_id, company_id, filing_id, case_name, proceeding_type, forum, counterparty, counterparty_company_id, status, amount_usd, description) FROM stdin;
1	1	1	Litigation Relating to 2018 CEO Performance Award	securities	Delaware Court of Chancery; Delaware Supreme Court	Elon Musk and Tesla's board of directors; purported Tesla stockholder	\N	judgment	345000000.00	A putative class and derivative action challenged the 2018 CEO Performance Award, resulting in a Delaware Supreme Court decision reinstating the award and awarding nominal damages.
2	1	1	Litigation Related to Directors' Compensation	securities	Delaware Court of Chancery; Delaware Supreme Court	Certain current and former directors of Tesla; purported Tesla stockholder	\N	settled	176000000.00	A derivative action regarding director compensation awards from 2017-2020 was settled, with the court approving the settlement and awarding approximately $176 million in attorney fees, which Tesla has appealed.
3	1	1	IRS Examination for Tax Years 2015-2018	government_investigation	Internal Revenue Service (IRS)	Internal Revenue Service	\N	pending	\N	Tesla is under examination by the IRS for federal income tax years 2015 through 2018.
4	2	2	Vidstream LLC v. Twitter, Inc. (Youtoo Technologies patent suit)	intellectual_property	United States District Court for the Northern District of Texas	Vidstream LLC	\N	appeal	172000000.00	A jury found Twitter willfully infringed one claim of the '304 patent, awarding $105 million in damages plus $67 million in prejudgment interest; both parties have appealed.
5	2	2	NMPA Copyright Infringement Suit v. X	intellectual_property	U.S. District Court for the Middle District of Tennessee	National Music Publishers' Association member companies	\N	pending	\N	Music publishers sued X for copyright infringement; the court dismissed some claims and granted a stay for a renewed motion to dismiss based on a Supreme Court ruling.
6	2	2	SDBN Class Action v. Twitter Entities (MoPub GDPR)	regulatory	District Court of Amsterdam, Netherlands	Stichting Data Bescherming Nederland (SDBN)	\N	pending	\N	A Dutch foundation filed a putative class action alleging MoPub's real-time bidding violated GDPR; the court declined class certification and is considering a stay.
7	2	2	SOMI Collective Action v. X Entities (GDPR/DSA)	regulatory	District Court of Amsterdam, Netherlands	Stichting Onderzoek Marktinformatie (SOMI)	\N	pending	\N	A Dutch foundation brought a collective action on behalf of 7.8 million users alleging GDPR and DSA violations; the court held a hearing and expects to decide by May 27, 2026.
8	2	2	Search and Share Technologies, LLC v. X Corp. (Patent)	intellectual_property	Federal District Court for the Western District of Texas	Search and Share Technologies, LLC	\N	pending	\N	A non-practicing entity sued X Corp. for patent infringement; X Corp. moved to dismiss certain claims and filed IPR petitions challenging the patents.
9	2	2	Jane Doe v. X.AI Corp. and X.AI LLC (Grok image generation)	product_liability	U.S. District Court for the Northern District of California	Jane Doe	\N	pending	\N	A putative class action alleges Grok's image-generation features enabled creation of nonconsensual explicit images; plaintiffs seek compensatory, statutory, and punitive damages.
10	2	2	Baltimore City v. X Corp., X.AI Corp., X.AI LLC, and Space Exploration Technologies Corp. (Grok image generation)	product_liability	Baltimore City Circuit Court	Mayor and City Council of Baltimore	\N	pending	\N	Baltimore sued under its Consumer Protection Ordinances alleging Grok's image-generation features created harmful content; seeks statutory penalties and injunctive relief.
11	2	2	NAACP v. X.AI Corp. and MZX Tech, LLC (Clean Air Act)	environmental	\N	National Association for the Advancement of Colored People and NAACP Mississippi State Conference	\N	pending	\N	The NAACP sued alleging mobile gas turbines at the COLOSSUS II data center violate the Clean Air Act; a preliminary injunction motion was filed to halt turbine operation.
12	2	2	Southaven, Mississippi natural gas turbine permit lawsuits	environmental	\N	various parties	\N	pending	\N	Lawsuits allege unlawful operation of natural gas-fired turbines without required permits at data center facilities in Southaven, Mississippi.
13	3	3	Putative Securities Class Action (Neutron Rocket Development)	securities	United States District Court for the Central District of California	Putative class of shareholders	\N	pending	\N	A putative securities class action alleging misstatements about Neutron rocket development progress was filed in February 2025, dismissed, then an amended complaint was filed in December 2025.
14	3	3	Putative Shareholder Derivative Actions	securities	United States District Court for the Central District of California	Directors and certain officers	\N	pending	\N	Two shareholders filed derivative actions on behalf of the company against directors and officers in April 2025, which are stayed pending resolution of the securities class action.
15	4	4	Securities Class Action (Southern District of New York)	securities	United States District Court for the Southern District of New York	Putative class of shareholders	\N	pending	\N	A putative class action alleging securities fraud under Sections 10(b) and 20(a) of the Exchange Act based on alleged misstatements about classified programs and the F-35 program.
16	4	4	Shareholder Derivative Action (District of Maryland)	securities	United States District Court for the District of Maryland	Current and former members of Board of Directors and senior management	\N	pending	\N	A shareholder derivative complaint asserting claims under the Exchange Act and for breach of fiduciary duty, abuse of control, gross mismanagement, corporate waste, unjust enrichment, and contribution.
17	4	4	Lockheed Martin v. Metropolitan Transportation Authority	contract	U.S. District Court for the Southern District of New York	New York Metropolitan Transportation Authority and its Capital Construction Company	\N	pending	190000000.00	Declaratory judgment action and counterclaims regarding alleged material breach of a $323 million contract, with MTA seeking approximately $190 million in damages and Lockheed Martin claiming approximately $95 million.
18	5	5	MAX accident victim civil lawsuits	product_liability	\N	family members of MAX accident victims	\N	pending	\N	Fewer than five civil lawsuits filed by family members of those who died in the 737 MAX accidents remain pending against Boeing.
19	5	5	Federal securities class action (Northern District of Illinois)	securities	U.S. District Court for the Northern District of Illinois	shareholders	\N	pending	\N	A federal securities class action with a pending motion for class certification is proceeding in the Northern District of Illinois related to the 737 MAX accidents.
20	5	5	FAA investigation of 737 quality control system	government_investigation	Federal Aviation Administration (FAA)	Federal Aviation Administration	\N	pending	\N	The FAA investigated Boeing's 737 quality control system following the January 2024 737-9 door plug accident and increased oversight of production and safety management systems.
21	6	6	In Re NVIDIA Corporation Securities Litigation	securities	United States District Court for the Northern District of California	plaintiffs (investors)	\N	pending	\N	Securities class action alleging false statements about channel inventory and cryptocurrency mining impact on GPU demand between May 2017 and November 2018.
22	6	6	In re NVIDIA Corporation Consolidated Derivative Litigation	securities	United States District Court for the Northern District of California	plaintiffs (shareholders)	\N	pending	\N	Derivative suit alleging breach of fiduciary duty, unjust enrichment, waste, and securities violations based on false statements about channel inventory and cryptocurrency mining.
23	6	6	Lipchitz v. Huang, et al. and Nelson v. Huang, et al.	securities	United States District Court for the District of Delaware	plaintiffs (shareholders)	\N	pending	\N	Two derivative actions alleging breach of fiduciary duty, insider trading, misappropriation, corporate waste, and securities violations based on false statements about channel inventory and cryptocurrency mining.
24	6	6	Horanic v. Huang, et al.	securities	Court of Chancery of the State of Delaware	plaintiffs (shareholders)	\N	pending	\N	Derivative action alleging breach of fiduciary duty and insider trading based on false statements about channel inventory and cryptocurrency mining, stayed pending resolution of the securities class action.
25	6	6	Securities Class Action Lawsuit (Channel Inventory and Cryptocurrency Mining)	securities	\N	multiple shareholders	\N	pending	\N	NVIDIA is defending a securities class action lawsuit alleging false and misleading statements about channel inventory and cryptocurrency mining's impact on GPU demand in 2017 and 2018.
26	7	7	FCPA Investigation regarding Refining Solutions/Ketjen segment third-party sales representatives	government_investigation	U.S. Department of Justice, SEC, Dutch Public Prosecutor	U.S. Department of Justice, SEC, Dutch Public Prosecutor	\N	pending	\N	Company self-reported potential FCPA violations by third-party sales representatives in Refining Solutions (now Ketjen) to DOJ, SEC, and Dutch Public Prosecutor, cooperated with investigations, and implemented remedial measures.
27	8	8	Brazil tax and customs disputes (Caterpillar Brasil Ltda. export activities)	government_investigation	Brazil (federal, state, and municipal authorities)	Federal, state, and municipal authorities in Brazil	\N	pending	\N	Caterpillar is involved in tax and customs disputes with Brazilian authorities related to export activities of Caterpillar Brasil Ltda.
28	9	9	Longitude Licensing Ltd. and Marlin Semiconductor Limited v. TSMC	intellectual_property	U.S. International Trade Commission; U.S. District Court for the Eastern District of Texas	Longitude Licensing Ltd. and Marlin Semiconductor Limited	\N	pending	\N	Marlin filed complaints with the ITC and Eastern District of Texas alleging TSMC and its customers infringe five U.S. patents; ITC instituted investigation, district court stayed pending ITC.
29	9	9	Export Control Investigation - Customer Chip Diversion (October 2024)	government_investigation	U.S. and Taiwan authorities	U.S. and Taiwan authorities	\N	pending	\N	TSMC notified U.S. and Taiwan authorities that a customer's chip may have been diverted to a restricted entity and is cooperating with investigations.
30	10	10	Consolidated Securities Class Action (SDNY)	securities	United States District Court for the Southern District of New York	Plaintiff investors (class action)	\N	pending	\N	Consolidated securities class action alleging false or misleading statements about 2024 expected revenue.
31	10	10	Purdue University v. STMicroelectronics	intellectual_property	United States District Court for the Western District of Texas (Waco)	Purdue University	\N	judgment	32000000.00	Patent infringement lawsuit resulting in a $32 million judgment for Purdue University.
\.


--
-- Data for Name: metric_definitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.metric_definitions (metric_id, metric_code, name, category, unit, description, us_gaap_tags, ifrs_tags) FROM stdin;
1	revenue	Revenue	Financials	currency	Total revenue recognized in the period.	{Revenues,RevenueFromContractWithCustomerExcludingAssessedTax,SalesRevenueNet}	{Revenue}
2	cost_of_revenue	Cost of revenue	Financials	currency	Cost of goods and services sold.	{CostOfRevenue,CostOfGoodsAndServicesSold}	{CostOfSales}
3	gross_profit	Gross profit	Financials	currency	Revenue minus cost of revenue, as reported.	{GrossProfit}	{GrossProfit}
4	operating_income	Operating income	Financials	currency	Operating income (loss).	{OperatingIncomeLoss}	{ProfitLossFromOperatingActivities}
5	net_income	Net income	Financials	currency	Net income (loss) attributable to the parent.	{NetIncomeLoss}	{ProfitLossAttributableToOwnersOfParent,ProfitLoss}
6	operating_cash_flow	Operating cash flow	Financials	currency	Net cash provided by operating activities.	{NetCashProvidedByUsedInOperatingActivities}	{CashFlowsFromUsedInOperatingActivities}
7	capital_expenditure	Capital expenditure	Financials	currency	Payments to acquire property, plant and equipment.	{PaymentsToAcquirePropertyPlantAndEquipment}	{PurchaseOfPropertyPlantAndEquipmentClassifiedAsInvestingActivities}
8	total_assets	Total assets	Financials	currency	Total assets at period end.	{Assets}	{Assets}
9	total_liabilities	Total liabilities	Financials	currency	Total liabilities at period end.	{Liabilities}	{Liabilities}
10	stockholders_equity	Stockholders' equity	Financials	currency	Equity attributable to the parent at period end.	{StockholdersEquity}	{EquityAttributableToOwnersOfParent}
11	cash_and_equivalents	Cash and cash equivalents	Financials	currency	Cash and cash equivalents at period end.	{CashAndCashEquivalentsAtCarryingValue}	{CashAndCashEquivalents}
12	long_term_debt	Long-term debt	Financials	currency	Long-term debt, non-current portion where reported.	{LongTermDebtNoncurrent,LongTermDebt}	{NoncurrentPortionOfNoncurrentBorrowings,LongtermBorrowings}
13	inventory	Inventory	Financials	currency	Inventories, net, at period end.	{InventoryNet}	{Inventories}
14	rd_expense	Research and development expense	Accounting	currency	Research and development expense.	{ResearchAndDevelopmentExpense,ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost}	{ResearchAndDevelopmentExpense}
15	share_based_compensation	Share-based compensation	Accounting	currency	Non-cash share-based compensation expense.	{ShareBasedCompensation,AllocatedShareBasedCompensationExpense}	{AdjustmentsForSharebasedPayments}
16	depreciation_amortization	Depreciation and amortization	Accounting	currency	Depreciation, depletion and amortization.	{DepreciationDepletionAndAmortization,DepreciationAmortizationAndAccretionNet}	{DepreciationAndAmortisationExpense}
17	income_tax_expense	Income tax expense	Accounting	currency	Income tax expense (benefit).	{IncomeTaxExpenseBenefit}	{IncomeTaxExpenseContinuingOperations}
18	eps_diluted	Diluted EPS	Shareholder Return	currency/share	Diluted earnings per share.	{EarningsPerShareDiluted}	{DilutedEarningsLossPerShare}
19	dividends_paid	Dividends paid	Shareholder Return	currency	Cash dividends paid to shareholders.	{PaymentsOfDividendsCommonStock,PaymentsOfDividends}	{DividendsPaidClassifiedAsFinancingActivities,DividendsPaid}
20	share_repurchases	Share repurchases	Shareholder Return	currency	Cash paid to repurchase own shares.	{PaymentsForRepurchaseOfCommonStock}	{PaymentsToAcquireOrRedeemEntitysShares}
21	dividends_per_share	Dividends declared per share	Shareholder Return	currency/share	Dividends declared per common share.	{CommonStockDividendsPerShareDeclared}	{}
\.


--
-- Data for Name: persons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.persons (person_id, owner_cik, full_name) FROM stdin;
1	1242782	DENHOLM ROBYN M
2	1331680	Wilson-Thompson Kathleen
3	1494730	Musk Elon
4	1771340	Taneja Vaibhav
5	1412598	Ehrenpreis Ira Matthew
6	1494731	Musk Kimbal
7	1420590	MURDOCH JAMES R
8	1834171	Gebbia Joseph
9	1350874	Hartung Jack
10	1790565	Baglino Andrew D
11	1972928	Zhu Xiaotong
12	1495158	Gracias Antonio J.
13	1768956	Shotwell Gwynne
14	1413147	Johnsen Bret W
15	1579233	Glein Randall
16	2133078	Harrison Donald Stewart
17	1314917	Jurvetson Stephen T
18	1835310	Nosek Luke
19	1222287	BOTHA ROELOF
20	1671507	Kampani Arjun
21	1509421	Spice Adam C.
22	1551426	KHOSLA VENTURES SEED B, L.P.
23	1551427	KHOSLA VENTURES SEED B (CF), L.P.
24	1845461	Khosla Ventures Seed Associates B, LLC
25	1611146	Khosla Ventures V, L.P.
26	1611145	Khosla Ventures Associates V, LLC
27	1501927	VK Services, LLC
28	1032453	KHOSLA VINOD
29	1872947	Strohband Sven
30	1589827	Frank Edward H.
31	1331263	Olson Jon A
32	1699497	Saintil Merline
33	1357262	Slusky Alexander R
34	1045849	GRIFFIN MICHAEL D
35	1991365	Armagno Nina
36	1524478	Possenriede Kenneth R
37	2037530	Klein Frank
38	1836089	Ocko Matthew
39	1881842	Beck Peter
40	1880895	Beck Kerryn
41	1880893	Butler Warren
42	1881791	Equatorial Trust
43	1881857	Peek Street Equatorial Trustee Ltd
44	2127567	Clevenger Marvin Bradford
45	1710066	Ricupati Agostino
46	1204586	BURRITT DAVID B
47	1353825	Donovan John
48	1588752	Hollub Vicki A.
49	1661900	Lee Maria Ricciardone
50	1209431	AKERSON DANIEL F
51	1647496	Carlson Bruce A
52	1803694	Dunford Joseph F Jr
53	1222890	FALK THOMAS J
54	1049959	GORDON ILENE S
55	1707516	Johnson Jeh C.
56	1225947	REED DEBRA L
57	1452775	Yarrington Patricia E
58	1309357	Ellis James O Jr
59	1950531	Cahill Timothy S
60	1218672	TAICLET JAMES D JR
61	1728300	St John Frank A
62	1781886	MALAVE JESUS JR
63	1696020	Hill Stephanie C.
64	1900809	Lightfoot Robert M JR
65	1834781	Ulmer Gregory M
66	1495449	Lavan Maryanne
67	1934141	Paul Harry Edward III
68	1584466	Wilson Heather A
69	2050038	Aquilino John C
70	1808321	O'Connor Kevin J.
71	1933300	Scott Evan T
72	2137942	Sanchez Orlando Jr.
73	1396482	Bradway Robert A
74	2016263	Amuluru Uma M
75	1754955	Soussan Sabrina
76	1786800	Richardson John M
77	1434806	MOLLENKOPF STEVEN M
78	1685062	Joyce David Leon
79	1517450	JOHRI AKHIL
80	1860749	Harris Stayce D.
81	1230175	GOOD LYNN J
82	1631473	Gitlin David L.
83	1841605	Doughtie Lynne M
84	1377692	Ortberg Robert Kelly
85	1510709	West Brian
86	2005679	Raymond David Christopher
87	1920795	Pope Stephanie F
88	1967796	McKenzie Howard E
89	1971210	Cleary Michael J
90	2050274	Schmidt Ann M
91	1256891	DEASY DANA S
92	2041310	Buckley Mortimer J
93	1775883	Gerry Brett C.
94	1947835	Nelson Brendan J.
95	2058337	Shockey Jeffrey S
96	2076543	Parker Stephen Kenneth
97	1188835	TILDEN BRADLEY D
98	2139225	Ruhmann Donald W.
99	1197649	HUANG JEN HSUN
100	1199039	STEVENS MARK A
101	1641111	Ochoa Ellen
102	1818224	Dabiri John
103	1347842	Puri Ajay K
104	1526111	Robertson Donald F Jr
105	1283854	Shoquist Debora
106	1696841	Teter Timothy S.
107	1588670	Kress Colette
108	1198782	BURGESS ROBERT K
109	1725292	Shah Aarti S.
110	1197652	SEAWELL A BROOKE
111	1768670	Neal Stephen C
112	1636665	Drell Persis
113	1284116	LORA MELISSA
114	1219888	HUDSON DAWN E
115	1197650	JONES HARVEY C
116	1197647	COXE TENCH
117	1243821	GAWEL SCOTT
118	1310264	NORA JOHNSON SUZANNE M
119	2152188	Parker Nicholas P.
120	1792555	Barichivich John Clarence III
121	1594784	Johnson Netha N.
122	1976771	Fourie Jacobus G.
123	1624621	Norris Eric
124	1396415	Masters J Kent
125	1631925	Anderson Melissa H.
126	1464051	Coleman Kristin M.
127	1998940	Sheorey Neal Ravi
128	2001108	Lima Cynthia Renee
129	2014946	Mummert Mark Richard
130	1414921	Van Deursen Holly
131	1143210	STEINER GERALD A
132	1403296	Seavers Dean
133	1730941	OConnell Diarmuid B.
134	1023582	OBRIEN JAMES J /KY
135	1585657	Wolff Alejandro Daniel
136	1254782	MINOR GLENDA J
137	1913598	Cramer Ralf Hans
138	1235612	BRLAS LAURIE
139	2040725	Grant Stacy Goto
140	1568721	LaBauve Donald J. Jr.
141	2077449	Krupa Ander C.
142	2082528	Gagarinas Autumn M.
143	1362208	Widmar Mark R
144	2142817	DESALLES BARTOLOMEO EDUARDO
145	1968506	Hood Max
146	2047429	Collins Michelle T
147	1608229	Johnson Denise C
148	2005183	Kaiser Jason
149	1739859	Creed Joseph E
150	1202958	SCHWAB SUSAN C
151	1498535	MacLennan David
152	1839757	Fassino Anthony D.
153	1694342	De Lange Bob
154	1199292	BONFIELD ANDREW R J
155	1772226	Johnson Gerald
156	1552649	Johnson Cheryl H
157	2006879	Owens Derek
158	1739758	Schaupp William E
159	1566320	Umpleby III Donald J
160	1606707	Pambianchi Christine M
161	1579223	KEENE NAZZIC S
162	1665490	Marks Judith Fran
163	1184395	WILKINS RAYFORD JR
164	1523568	Fish James C Jr
165	2110101	Shurman Rodney Michael
166	2131716	Epley Kyle Joseph
167	2162809	York Derrick Lading
168	2113756	Lin Chris Horng-Dar
169	2114023	Tien Bor-Zen
170	2113784	Wu Shien-Yang
171	2113717	Wei Che-Chia
172	2113729	Mii Yuh-Jier
173	2118010	Wang Ying-Lang
174	2113775	Yoo Chue-San
175	2113762	Yeap Choh Fei
176	2114024	Yuan Lipen
177	2136731	Wu Yi-Huang
178	2115263	Zhang Kevin Xiaoqiang
179	2114030	Chuang Tzu-Sou
180	2113710	Chang Tzonz-Sheng
181	2114064	Hwang Yuan-Ko
182	2114025	Lin Shyue-Shyh
183	2114032	Lu Lee-Chung
184	2113031	Cao Min
185	2135942	Lu Chin-Sheng
186	2113699	Huang Jen-Chau
187	2113771	He Jun
188	2113698	Fang Shu-Hua
189	2113705	Liaw Yung-Haw
190	2114026	Chen Chih-Ho
191	2114031	Hsu Kuo-Chin
192	2117998	Chin Yung-Pei
193	2113680	Hou Yung-Chin
194	2114027	Chen Pei-Hung
195	2113739	Lee Chun-Hsien
196	2114029	Chuang Juiping
197	2135989	Ku Yao-Ching
198	2113688	Jang Syun-Ming
199	2113720	Tseng Fang Churng
200	1188935	SPLINTER MICHAEL R
\.


--
-- Data for Name: risk_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.risk_categories (risk_category_id, name, description) FROM stdin;
1	Supply chain and raw materials	Dependence on suppliers, components, commodities and logistics.
2	Geopolitical and trade	Tariffs, export controls, sanctions, conflicts and cross-border tensions.
3	Government contracts and regulation	Government customers, budgets, procurement rules and regulatory approvals.
4	Competition	Competitive pressure on prices, share and technology.
5	Technology and product	Product development, defects, recalls and technology transitions.
6	Cybersecurity and IT	Cyber attacks, data breaches and IT system failures.
7	Key personnel and governance	Dependence on key people, control by insiders, board and governance structure.
8	Financial and liquidity	Debt, capital needs, liquidity, currency and interest rates.
9	Macroeconomic and demand	Economic cycles, customer demand and end-market conditions.
10	Legal and litigation	Lawsuits, investigations and legal liabilities.
11	Environmental and climate	Environmental regulation, climate and sustainability.
12	Intellectual property	Protection of and claims against intellectual property.
13	Operations and manufacturing	Production ramp, facilities, quality and operational execution.
14	Stock and capital markets	Share price volatility, dilution and capital-markets access.
\.


--
-- Data for Name: risk_factors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.risk_factors (risk_factor_id, company_id, risk_category_id, filing_id, title, summary, mentioned_company_id) FROM stdin;
1	1	13	1	We may experience issues or delays in developing, launching and ramping the production of our products, services and features, or we may be unable to control our manufacturing costs.	Tesla faces risk of production delays and cost overruns when developing and scaling new products like Cybercab and AI-based services.	\N
2	1	1	1	Our suppliers may fail to deliver components according to schedules, prices, quality and volumes that are acceptable to us, or we may be unable to manage these components effectively.	Tesla's reliance on hundreds of global suppliers, including single-source providers, creates vulnerability to shortages, price swings, and supplier insolvency.	\N
3	1	1	1	As the scale and variants of our production increases, we will also need to accurately forecast, purchase, warehouse and transport components at high volumes to our manufacturing facilities and servicing locations internationally.	Growing production complexity risks inventory mismatches, logistics bottlenecks, and write-offs if supply chain systems cannot scale effectively.	\N
4	1	13	1	We may be unable to meet our projected construction timelines, costs and production ramps at new factories, or we may experience difficulties in generating and maintaining demand for products manufactured there and related services.	New factory construction and production ramps face regulatory, supply chain, hiring, and demand uncertainties that could delay output and hurt profitability.	\N
5	1	13	1	We may be unable to grow our global product sales, delivery and installation capabilities and our servicing and vehicle charging networks, or we may be unable to accurately project and effectively manage our growth.	Tesla's direct sales model and expanding service and charging infrastructure require massive investment and accurate demand forecasting to avoid overburdening operations.	\N
6	1	1	1	We will need to maintain and significantly grow our access to battery cells, including through the development and manufacture of our own cells, and control our related costs.	Securing sufficient battery cell supply through internal production and external sources is critical to Tesla's vehicle and energy product scaling and cost targets.	\N
7	1	1	1	We are dependent on the continued supply of lithium-ion battery cells for our vehicles and energy storage products, and we will require substantially more cells to grow our business according to our plans.	Tesla relies on a limited number of battery cell suppliers like Panasonic and CATL, and any supply disruption could constrain vehicle and energy storage production.	152
8	1	9	1	Our future growth and success are dependent upon demand for our electric vehicles and adoption of autonomous driving solutions.	Tesla's growth depends on consumer demand for EVs and autonomous driving, which could be harmed by slow market development, competition, or macroeconomic factors.	\N
9	1	4	1	We face strong competition for our products and services from a growing list of established and new competitors.	Tesla faces intensifying competition from established and new automakers in EVs, self-driving tech, and energy products, which could reduce sales, pricing, and market share.	\N
10	1	5	1	Growth of our business is also dependent upon our ability to develop and commercialize Bots, including Optimus, which is in a nascent industry that has yet to develop commercially.	Tesla's future growth depends on successfully developing and commercializing humanoid robots like Optimus, but the industry is nascent and success is uncertain.	\N
11	1	13	1	We may experience issues with lithium-ion cells or other components manufactured at our Gigafactories, which may harm the production and profitability of our vehicle and energy storage products.	Manufacturing issues at Tesla's Gigafactories with battery cells or components could disrupt production and reduce profitability of vehicles and energy products.	\N
12	1	2	1	We face risks associated with maintaining and expanding our international operations, including unfavorable and uncertain regulatory, political, economic, tax and labor conditions.	Tesla's international operations face unpredictable regulatory, political, tax, and trade risks across jurisdictions, including tariffs and trade policy changes.	\N
13	1	5	1	Our business may suffer if our products or features contain defects, fail to perform as expected or take longer than expected to become fully functional.	Product defects or delayed feature functionality in Tesla's vehicles could harm the business through repairs, reputational damage, and customer dissatisfaction.	\N
14	1	10	1	We may be required to defend or insure against product liability claims.	Tesla faces significant product liability risk from vehicle collisions and battery fires, with potential for lawsuits, recalls, and substantial costs since it largely self-insures for vehicle exposure.	\N
15	1	14	1	We will need to maintain public credibility and confidence in our long-term business prospects in order to succeed.	Tesla must sustain credibility with customers, investors, and analysts to support its brand and fundraising, but negative publicity and criticism could damage its reputation and financial flexibility.	\N
16	1	8	1	We may be unable to effectively grow, or manage the compliance, residual value, financing and credit risks related to, our various financing programs.	Tesla's vehicle and energy financing programs are exposed to regulatory compliance, residual value volatility, funding constraints, and customer credit defaults that could impair profitability and growth.	\N
17	1	7	1	If we are unable to attract, hire and retain key employees and qualified personnel, our ability to compete may be harmed.	Tesla's competitive position depends on recruiting and retaining specialized talent in a tight labor market, with risks from compensation challenges and negative publicity affecting retention.	\N
18	1	7	1	We are highly dependent on the services of Elon Musk, Technoking of Tesla and our Chief Executive Officer.	Tesla's operations and strategy are heavily reliant on CEO Elon Musk, who divides his time among multiple other ventures, creating significant key-person risk.	2
19	1	6	1	Our information technology systems or data, or those of our service providers or customers or users could be subject to cyber-attacks or other security incidents, which could result in data breaches, intellectual property theft, claims, litigation, regulatory investigations, significant liability, reputational damage and other adverse consequences.	Tesla's expanding IT infrastructure faces diverse cyber threats that could lead to data breaches, IP theft, legal liability, and reputational harm across its operations and partner networks.	\N
20	1	6	1	Any unauthorized control or manipulation of our products' systems could result in loss of confidence in us and our products.	Unauthorized access or manipulation of Tesla's product systems could erode customer confidence and damage the company's reputation.	\N
21	1	13	1	Our business may be adversely affected by any disruptions caused by union activities.	Union activities, including organizing efforts, work stoppages, or strikes at Tesla or its suppliers, could disrupt operations and increase costs.	\N
22	1	13	1	We may choose to or be compelled to undertake product recalls or take other similar actions.	Tesla may face voluntary or involuntary product recalls due to safety defects or non-compliance, leading to significant expenses and reputational harm.	\N
23	1	8	1	Our current and future warranty reserves may be insufficient to cover future warranty claims.	Tesla's warranty reserves may prove inadequate to cover future claims, particularly for newer or higher-volume products, potentially harming financial results.	\N
24	1	8	1	Our insurance coverage strategy may not be adequate to protect us from all business risks.	Tesla's limited insurance coverage, with high deductibles and exclusions, may leave the company exposed to uninsured losses that could harm its financial condition.	\N
25	1	8	1	Our debt agreements contain covenant restrictions that may limit our ability to operate our business.	Covenant restrictions in Tesla's debt agreements could limit operational flexibility and additional financing, with non-compliance risking debt acceleration.	\N
26	1	8	1	Additional funds may not be available to us when we need or want them.	Tesla's capital-intensive growth plans may require additional funding that might not be available on favorable terms, potentially harming its financial condition and prospects.	\N
27	1	13	1	We may be negatively impacted by any early obsolescence of our manufacturing and other equipment.	Rapid technology changes or production improvements could render manufacturing equipment obsolete earlier than expected, accelerating depreciation and harming operating results.	\N
28	1	8	1	There is no guarantee that we will have sufficient cash flow from our business to pay our indebtedness or that we will not incur additional indebtedness.	Tesla may lack sufficient cash flow to service its debt obligations or may need to take on additional debt, creating financial risk.	\N
29	1	8	1	We are exposed to fluctuations in currency exchange rates.	Tesla faces financial risk from foreign currency fluctuations affecting revenues, costs, and net income due to global operations in multiple currencies.	\N
30	1	12	1	We may not be able to adequately protect or defend ourselves against intellectual property infringement claims, which may be time-consuming and expensive, or affect the freedom to operate our business.	Tesla risks costly IP litigation and potential restrictions on its ability to make, use, or sell products if third parties assert patent or other proprietary rights.	\N
31	1	13	1	Our operations could be adversely affected by events outside of our control, such as natural disasters, wars or health epidemics.	Tesla's production facilities and operations are vulnerable to disruption from natural disasters, geopolitical conflicts, pandemics, and climate-related events.	\N
32	1	3	1	Demand for our products and services may be impacted by the status of government and economic incentives supporting the development and adoption of such products.	Changes or elimination of government EV incentives, tax credits, and rebates could reduce demand for Tesla's vehicles and energy products.	\N
33	1	3	1	We are subject to evolving laws and regulations that could impose substantial costs, legal prohibitions or unfavorable changes upon our operations or products.	Tesla faces increasing compliance costs and operational constraints from complex, evolving environmental, safety, and vehicle regulations across multiple jurisdictions.	\N
34	1	10	1	Any failure by us to comply with a variety of U.S. and international privacy and consumer protection laws may harm us.	Non-compliance with privacy and consumer protection laws could lead to regulatory actions, fines, and reputational damage.	\N
35	1	10	1	We could be subject to liability, penalties and other restrictive sanctions and adverse consequences arising out of certain governmental investigations and proceedings.	Ongoing government investigations may result in liability, penalties, sanctions, and other adverse consequences.	\N
36	1	3	1	We may face regulatory challenges to or limitations on our ability to sell vehicles directly.	Regulatory challenges in various jurisdictions could restrict Tesla's direct-to-consumer vehicle sales model.	\N
37	1	14	1	The trading price of our common stock is likely to continue to be volatile.	Tesla's stock price is highly volatile and subject to wide fluctuations due to market factors and short selling.	\N
38	1	8	1	Our financial results may vary significantly from period to period due to fluctuations in our operating costs and other factors.	Tesla's financial results may fluctuate significantly between periods due to varying operating costs and product introductions.	\N
39	1	14	1	We may fail to meet our publicly announced guidance or other expectations about our business, which could cause our stock price to decline.	Failure to meet public guidance or market expectations could cause a significant decline in Tesla's stock price.	\N
40	1	5	1	There is a risk that the technologies and initiatives associated with the 2025 CEO Performance Award, including the product goals, are misaligned with current or future consumer demand, resulting in our failure to invest in or pursue another opportunity that generates significant financial returns or leads to greater shareholder value.	The technologies and initiatives tied to the 2025 CEO Performance Award may not align with consumer demand, potentially causing missed investment opportunities.	\N
41	2	5	2	Any failure or delay in the development of Starship at scale or in achieving the required launch cadence, reusability and capabilities thereafter would delay or limit our ability to execute our growth strategy, including the deployment of next-generation satellites, global satellite-to-mobile connectivity, and orbital AI compute, which could materially adversely affect our business, financial condition, results of operations, and future prospects.	Delays or failures in Starship development, launch cadence, or reusability could hinder deployment of next-generation satellites, satellite-to-mobile connectivity, and orbital AI compute, materially harming growth and financial performance.	\N
42	2	3	2	Any delays or difficulties in obtaining, maintaining or renewing required regulatory approvals and licenses required for our space-related activities, including FAA launch and reentry licenses, would materially delay or disrupt our operations, harm our business, or limit our ability to execute our business strategy.	Delays or difficulties in securing FAA launch and reentry licenses or other regulatory approvals could disrupt launch operations, constrain growth, and adversely affect the business strategy.	\N
43	2	3	2	Any delays or difficulties in obtaining, maintaining or renewing required communications licenses and spectrum authorizations for our satellite connectivity services, including international and FCC satellite spectrum licenses, could materially delay or disrupt our operations, harm our business, or limit our ability to execute our business strategy.	Failure to obtain or maintain FCC and international spectrum licenses for satellite connectivity services could disrupt operations and limit execution of the business strategy.	\N
44	2	3	2	Our Starlink and other satellite services are subject to complex and evolving U.S. and foreign laws and regulations, particularly relating to data privacy, cybersecurity, and telecommunications.	SpaceX's Starlink and satellite services face compliance risks from complex, evolving global regulations on data privacy, cybersecurity, and telecommunications.	\N
45	2	3	2	Our Starlink and other satellite services are subject to a variety of laws and regulations in the United States and abroad covering cybersecurity, privacy, data use, data combination, data protection, data security, data retention and deletion, data localization and storage, and data disclosure to law enforcement agencies.	Starlink must comply with extensive data privacy, cybersecurity, and data handling laws across multiple jurisdictions, increasing compliance costs and operational complexity.	\N
46	2	13	2	Our business strategy depends on successfully designing, developing, and deploying our products and services, as well as related platforms, infrastructure, and other strategic initiatives, at an unprecedented scale, which presents significant execution, cost, and timing risks.	SpaceX's ambitious growth strategy involving Starship, orbital AI, and lunar infrastructure carries significant execution, cost, and timing risks due to unprecedented scale.	\N
47	2	13	2	We have experienced, and will likely continue to experience, launch delays and failures that could have a material adverse effect on our business, financial condition, results of operations, and future prospects.	SpaceX faces ongoing risk of launch delays and failures that could materially harm its business, finances, and reputation.	\N
48	2	13	2	Our satellites, launch vehicles, and other space-related technologies operate, and in the case of orbital AI compute, will operate, in the harsh and unpredictable environment of space, exposing them to a wide and unique range of space-related risks that could cause them to malfunction or fail, and any such malfunction or failure could adversely affect our business, financial condition, results of operations, and future prospects.	SpaceX's space assets are exposed to extreme space environmental hazards like radiation, debris, and thermal cycles that could cause malfunctions or failures.	\N
49	2	1	2	Our ability to scale our AI products relies on our terrestrial and orbital AI compute infrastructure, which depends on the availability of power, water, AI processors, and other critical components, and telecommunications services, and any shortages or disruptions thereof would materially adversely affect our business, financial condition, results of operations, and future prospects.	Scaling AI products depends on reliable access to power, water, processors, and telecom services, and any disruption could severely harm the business.	\N
50	2	1	2	Our ability to scale our data center infrastructure, which supports our AI segment, is increasingly constrained by the availability of power and water at economically feasible prices, long lead times, availability of materials, and changing regulatory requirements.	Data center expansion is limited by power and water availability, long lead times, material supply, and evolving regulations.	\N
51	2	1	2	Our AI products also rely on GPUs and other processors, servers, network equipment and other critical components sourced from third-party suppliers for use in our data centers.	AI products depend on GPUs, servers, and network gear from third-party suppliers, creating supply chain vulnerability.	\N
52	2	1	2	Our ability to achieve orbital AI at scale depends on our ability to access a sufficient number of AI chips, significantly more than are currently available to us.	Orbital AI scaling requires far more AI chips than currently accessible, and internal fabrication plans may not succeed.	1
53	2	1	2	We also rely on third-party cloud compute providers for a portion of the compute used for our AI segment and may from time to time rely on third-party data center providers, which exposes us to several risks that are beyond our direct control, including vulnerability to outages, cooling capacity constraints, performance issues, and cyberattacks.	Dependence on external cloud and data center providers introduces risks of outages, cooling limits, performance problems, and cyberattacks.	\N
54	2	4	2	We face intense competition in the markets in which we operate, and while we have historically outperformed certain competitors in our Space and Connectivity segments, we may not continue to do so, which could adversely affect our business, financial condition, results of operations, and future prospects.	Intense competition across markets threatens future performance despite past success in Space and Connectivity segments.	\N
55	2	4	2	The markets in which we operate are rapidly evolving and intensely competitive, and we face competition from a range of established and emerging companies, including large, well-capitalized technology companies and aerospace firms, including foreign competitors.	Rapidly evolving markets feature strong competition from large tech and aerospace firms, including foreign rivals.	\N
56	2	4	2	Some of our current and potential competitors, particularly in our AI segment, have greater financial, technical, manufacturing, or other resources than we do, and may devote more resources to the development and commercialization of competing products and services.	Competitors in AI may have superior resources and invest more heavily in competing offerings.	\N
57	2	4	2	Competition continues to intensify as new technologies are developed and new entrants emerge.	Ongoing technological innovation and new market entrants are increasing competitive pressure.	\N
58	2	7	2	We depend on our ability to recruit and retain employees who have advanced engineering and technical skills, and intense competition for such employees may increase costs and affect our ability to meet development and production timelines.	Hiring and retaining advanced engineering talent is critical but difficult due to intense competition, potentially raising costs and delaying projects.	\N
59	2	10	2	From time to time, we are involved in litigation, investigations, and other regulatory proceedings which could be costly, time-consuming, and divert management attention, materially adversely affecting our business.	Ongoing and future litigation, investigations, and regulatory actions could impose significant costs and distract management.	\N
60	2	10	2	From time to time, we have been and may in the future become involved in various legal proceedings relating to a variety of matters, including intellectual property, commercial, regulatory, product liability, employment, personal injury, class action, employee or contractor health and safety, environmental, whistleblower, securities and other litigation and claims, and governmental and other regulatory investigations and proceedings, including tax examinations.	The company faces a broad spectrum of legal and regulatory proceedings across multiple domains, increasing exposure to adverse outcomes.	\N
381	8	3	8	Our global operations are subject to a wide range of trade and anti-corruption laws and regulations.	Caterpillar faces compliance risks from numerous international trade and anti-corruption laws across its global operations.	\N
61	2	5	2	Certain of our hardware products are new and relatively unproven. If a product defect were to arise, especially one leading to product liability claims, the resulting warranty and damage claims, together with any associated harm to our reputation, could have a material adverse effect on our business, financial condition, results of operations, and future prospects.	New, unproven hardware products carry risk of defects and liability claims that could damage finances and reputation.	\N
62	2	6	2	Any significant disruption in, or unauthorized access to, our computer and data systems or those of third parties that we utilize in our operations could result in a loss or degradation of service, loss of trust in us and harm to our business.	Cybersecurity incidents or unauthorized access to SpaceX's or third-party systems could disrupt operations, compromise sensitive data, and damage the company's reputation and competitive position.	\N
63	2	8	2	The development and maintenance of the technologies and infrastructure necessary to support our current and future operations will require significant capital expenditures, and if we are unable to generate sufficient cash flow from operations or obtain additional financing on acceptable terms, our business, financial condition, results of operations, and future prospects could be materially and adversely affected.	SpaceX's substantial capital expenditure requirements for satellite constellations, launch vehicles, and AI infrastructure could strain financial resources if cash flow or financing is insufficient.	\N
64	2	14	2	If we raise additional capital through further issuances of equity or convertible debt securities, our shareholders could suffer significant dilution and any new equity securities we issue could have rights, preferences, and privileges superior to those of holders of our Class A common stock.	Future equity or convertible debt issuances to fund operations could dilute existing shareholders and create securities with superior rights to Class A common stock.	\N
65	2	8	2	Our substantial level of indebtedness could materially adversely affect our financial condition.	SpaceX's significant debt load increases vulnerability to economic conditions, limits financial flexibility, and could lead to higher interest costs or default risk.	\N
66	2	4	2	Our future revenue and operating results depend upon our ability to develop new technologies and respond to changes in customer demands and industry standards in highly competitive markets, and if we are unable to do so, our business, financial condition, results of operations, and future prospects may be materially and adversely affected.	SpaceX's growth depends on successfully innovating and commercializing new technologies amid rapid market changes and intense competition, particularly in AI and space services.	\N
67	2	3	2	Our services are subject to risks related to supplying services to the U.S. government.	Supplying services to the U.S. government exposes the company to complex regulations, funding volatility, contractual disputes, and potential termination or reduction of contracts at the government's convenience.	\N
68	2	3	2	We derive significant revenue from U.S. government contracts that are subject to competitive bidding, funding approvals and other government budgetary processes, which factors could adversely affect our business, financial condition, results of operations, and future prospects.	Revenue from U.S. government contracts depends on competitive bidding outcomes, Congressional appropriations, and budgetary processes that create uncertainty and risk.	\N
69	2	3	2	We derive significant revenue from U.S. government contracts that were awarded through a competitive bidding process.	Competitive bidding for government contracts involves risks such as cost overruns, bid preparation expenses, protest challenges, and potential contract modifications or terminations.	\N
70	2	3	2	Our business with governmental entities is subject to changes in policies, priorities, regulations, mandates, and funding levels, any of which could materially impact our operations and financial results.	Government business is vulnerable to shifts in political leadership, policy priorities, regulatory changes, and funding fluctuations including continuing resolutions and budget deficits.	\N
71	2	8	2	In addition, our Space segment revenue is primarily derived from fixed-price contracts, under which we agree to deliver specified products or services at a predetermined price regardless of the actual costs incurred.	Fixed-price contracts in the Space segment require the company to absorb all cost overruns from inflation, supply chain issues, or technical challenges, potentially reducing profitability and straining cash flows.	\N
72	2	4	2	Our ability to expand our Starlink consumer and enterprise connectivity services depends on our ability to increase market awareness and acceptance of connectivity through Starlink, and any failure to do so could materially and adversely affect our business, financial condition, results of operations and future prospects.	Starlink's growth depends on overcoming consumer hesitation, competitive pricing pressures, terminal distribution constraints, and competition from established terrestrial broadband alternatives.	\N
73	2	5	2	The expansion of our satellite-to-mobile connectivity services depends substantially on our ability to secure and maintain partnerships with mobile network operators and on the adoption of necessary hardware and software modifications by device manufacturers, and any failure to do so could materially and adversely affect our business, financial condition, results of operations and future prospects.	Satellite-to-mobile expansion relies on partnerships with telecom carriers, spectrum authorizations, and device manufacturers implementing hardware changes for 5G NR-NTN compliance.	155
74	2	3	2	The provision of our satellite-to-mobile services also requires regulatory approvals from the FCC and foreign regulatory authorities.	The company's satellite-to-mobile services depend on obtaining regulatory approvals from the FCC and foreign authorities, which may be delayed or denied.	155
75	2	5	2	If the recommendations, forecasts, content, analyses or other output that our AI technologies, including Grok, assist in producing are or are alleged to be deficient, inaccurate, harmful, illegal, or used for an improper purpose, we could continue to be subjected to claims and investigations, and we could be subjected to legal liability and brand, reputational, or competitive harm.	AI technologies like Grok may produce deficient or harmful outputs leading to legal liability, investigations, and reputational damage.	\N
76	2	11	2	Environmental laws, regulations, litigation, liabilities and proceedings may adversely affect our operations, including our launch operations, manufacturing activities, fuel storage and handling operations, launch facilities and ground infrastructure, and data center operations and expansion plans.	Environmental laws and litigation could adversely affect launch, manufacturing, fuel handling, and data center operations.	\N
382	8	2	8	International trade policies may impact demand for our products and our competitive position.	Government trade policies like tariffs and import quotas could reduce demand for Caterpillar's products and weaken its competitive position.	\N
77	2	12	2	We may face substantial potential liability and operational disruptions if we violate the intellectual property rights or other rights of third parties, and if we fail to adequately protect, maintain, defend or enforce our intellectual property and other similar rights, we could lose an important competitive advantage, in each case which could have a material adverse effect on our business, financial condition, results of operations, customer trust and future prospects.	Intellectual property infringement risks and failure to protect IP could lead to liability and loss of competitive advantage.	\N
78	2	13	2	Acquisitions, divestitures, or other strategic transactions we pursue may not achieve the anticipated benefits, synergies or strategic objectives.	The company may fail to achieve expected benefits, synergies, or strategic objectives from acquisitions, divestitures, or other strategic transactions, including recent deals with xAI, EchoStar, Tesla, Intel, and Cursor.	153
79	2	13	2	We have experienced, and will likely continue to experience, development and manufacturing delays and damage or destruction during pre-launch operations, any of which could have a material adverse effect on our business, financial condition, results of operations, and future prospects.	The company faces ongoing risks of development and manufacturing delays, damage, or destruction during pre-launch operations of launch vehicles and satellites, which could materially harm its business.	\N
80	2	13	2	Our operations also involve significant risks during pre-launch preparation.	Pre-launch activities such as transport, fueling, integration, and ground testing pose risks of damage or destruction to launch vehicles and satellites, potentially causing delays and cost increases.	\N
81	2	2	2	Our ability to continue and expand launch and satellite operations depends upon our ability to obtain new and leverage existing U.S. export control and sanctions authorizations, and any significant changes to the geopolitical landscape or U.S. government regulatory approach to licensing could materially and adversely impact our international business operations by compromising existing licenses or limiting our ability to engage in commercial dealings in or involving geopolitically sensitive countries.	International launch and satellite operations depend on U.S. export control and sanctions authorizations that could be compromised by geopolitical changes or regulatory shifts.	\N
82	2	3	2	The launch and satellite operations are subject to stringent export control and economic and trade sanctions laws, including the U.S. International Traffic in Arms Regulations ("ITAR"), the Export Administration Regulations, and sanctions administered and enforced by the U.S. Treasury Department's Office of Foreign Assets Control ("OFAC").	Launch and satellite operations must comply with strict U.S. export control regimes including ITAR, EAR, and OFAC sanctions, requiring authorizations for controlled technology transfers.	\N
83	2	12	2	Our use of open source technology could impose limitations on our ability to commercialize our space-based internet and mobile phone services, AI products, and X platform, or otherwise negatively affect our business.	Use of open source software in Starlink, AI products, and X platform could trigger unfavorable licensing terms, require proprietary code disclosure, or lead to litigation.	\N
84	2	3	2	Payment, banking, and other financial service-related activities may subject us to additional regulatory requirements, regulatory actions, and other risks that could be costly and difficult to comply with or that could harm our business.	The planned Money Product for payment and banking services will expose the company to complex global financial regulations including anti-money laundering, consumer protection, and sanctions laws.	\N
85	2	5	2	Our efforts to support the creation of permanent installations on the Moon and Mars depend on the successful development and deployment of next-generation capabilities.	Moon and Mars colonization goals rely on developing novel, untested technologies like Starship and in-space refueling, requiring massive capital and facing significant technical hurdles.	\N
86	2	4	2	Our AI segment is recently formed, is still being fully integrated and optimized, operates in a rapidly evolving industry and is subject to significant execution, competitive and operational risks.	The newly acquired xAI-based AI segment is in early integration stages and faces significant execution, competitive, and operational risks in a fast-evolving industry.	153
87	2	8	2	Our testing, or the subsequent testing (if required) by our independent registered public accounting firm, may reveal deficiencies in our internal controls over financial reporting that are deemed to be material weaknesses.	Material weaknesses in internal controls over financial reporting could lead to material misstatements in financial statements.	\N
88	2	8	2	Our insurance coverage strategy may not be adequate to protect us from all business risks.	Insufficient insurance coverage, including for in-orbit satellites, could expose the company to substantial uninsured losses.	\N
89	2	7	2	Conflicts of interest could arise in the future between us, on the one hand, and Mr. Musk and entities owned by or affiliated with him, on the other hand, concerning among other things, business transactions, potential competitive activities or other business opportunities.	Conflicts of interest with Elon Musk and his affiliates, including collaborations with Tesla, could harm the company.	1
90	2	7	2	Mr. Musk or his affiliates may become aware, from time to time, of certain business opportunities (such as acquisition opportunities or technological developments) and may direct such opportunities to other businesses in which they have invested, in which case we may not become aware of or otherwise have the ability to pursue such opportunity.	Elon Musk may divert business opportunities to his other ventures, such as Tesla, Neuralink, or The Boring Company.	1
91	2	4	2	Under our charter, Mr. Musk and his affiliates are not restricted from owning assets or engaging in businesses that compete directly or indirectly with us and will not have any duty to refrain from engaging, directly or indirectly, in the same or similar business activities or lines of business as us, including those business activities or lines of business deemed to be competing with us, or doing business with any of our customers or vendors.	The corporate charter permits Elon Musk and his affiliates to compete directly with the company without any fiduciary duty to refrain.	\N
92	2	7	2	Certain of our directors and key employees may have conflicts of interest because they are also employees or directors of affiliates of Mr. Musk or other large shareholders. The resolution of these conflicts of interest may not be in our or your best interests.	Directors and key employees with roles at Musk-affiliated entities may face conflicts of interest that could be resolved unfavorably.	\N
133	3	13	3	The expansion of our operations subjects us to additional risks that can adversely affect our operating results.	Expanding operations introduces risks including talent retention, competition, regulatory hurdles, geopolitical instability, and access to launch sites that could harm financial performance.	\N
93	2	7	2	We are highly dependent on the continued services of Mr. Musk, our Chief Executive Officer and Chief Technical Officer, and other key personnel, and the loss or reduced involvement of one or more of these individuals could adversely affect our ability to execute our business strategy.	The company's heavy reliance on Elon Musk, who also leads Tesla and other ventures, creates significant key-person risk.	1
94	2	14	2	We, Mr. Musk, and other companies Mr. Musk is affiliated with frequently receive an immense amount of media attention. The actions and statements of Mr. Musk and his affiliated ventures, whether or not directly relating to us, may draw significant public attention and scrutiny to us and could potentially have a positive or negative impact on our business, relationships with customers and regulators, or stock price.	Intense media scrutiny of Elon Musk and his affiliated companies like Tesla could positively or negatively affect the company's stock price and reputation.	1
95	2	7	2	In addition to Mr. Musk, we have key personnel who are invaluable to our businesses. We rely upon their knowledge, expertise, and leadership to develop, manufacture, launch, sell, and support our products and services. None of our key employees are bound by an employment agreement for any specific term and we may not be able to successfully attract and retain the senior leadership necessary to continue to grow our business.	The inability to retain key personnel without long-term employment agreements could materially harm the business.	\N
96	2	14	2	A significant reduction by Mr. Musk or other existing shareholders of their ownership interest in us could adversely affect us.	Large sales of shares by Elon Musk or other major shareholders could depress the stock price and reduce Musk's incentive to support the company.	\N
97	2	14	2	Following the consummation of this offering, we will be a “controlled company” within the meaning of the Nasdaq and Nasdaq Texas listing rules and, as a result, will qualify for and rely on exemptions from certain corporate governance requirements.	As a controlled company, SpaceX will be exempt from certain Nasdaq corporate governance standards, potentially reducing shareholder protections.	\N
98	2	14	2	Our ability to provide returns to shareholders will depend on appreciation in our share price, as we do not plan to pay dividends for the foreseeable future.	The company does not intend to pay dividends, so shareholder returns depend entirely on stock price appreciation, which may not occur.	\N
99	2	7	2	Upon completion of this offering, Mr. Musk will serve as our Chief Executive Officer, Chief Technical Officer, and Chairman of our board and control the election of our directors, and our dual class structure concentrates voting control with Mr. Musk and other holders of our Class B common stock. This will limit or preclude your ability to influence corporate matters and the election of our directors.	Elon Musk will hold multiple leadership roles and control voting power through a dual-class structure, limiting Class A shareholders' influence over corporate governance.	\N
100	2	10	2	The TBOC and our charter include provisions that may limit shareholders' ability to bring a cause of action against our directors or officers for certain acts or omissions in their capacity as directors or officers of the Company, including minimum share ownership for derivative proceedings and the presumption of the business judgment rule.	Texas law and the company's charter impose high ownership thresholds and a strong business judgment rule presumption, making it difficult for shareholders to sue directors or officers.	\N
101	2	7	2	Our bylaws will impose minimum stock ownership and solicitation requirements on shareholders seeking to submit proposals for shareholder approval, which could limit the ability of our shareholders to bring matters before a meeting of shareholders.	The bylaws require shareholders to hold 3% of voting shares for six months and solicit 67% of voting power to submit proposals, significantly restricting shareholder proposal rights.	\N
102	3	13	3	We have experienced rapid growth in recent periods and those growth rates may not be indicative of our future growth. If we fail to manage our growth effectively, we may be unable to execute our business plan and our business, results of operations, and financial condition could be harmed.	Rapid growth may not continue and failure to manage growth effectively could harm business execution and financial condition.	\N
103	3	8	3	We have a limited operating history in an evolving industry, which makes it difficult to forecast our revenue, plan our expenses and evaluate our business and future prospects.	Limited operating history in a rapidly evolving industry makes revenue forecasting and expense planning difficult.	\N
104	3	8	3	We have a history of losses, we anticipate increasing operating expenses and capital expenditures in the future, and we may not be able to achieve and, if ever achieved, maintain profitability.	History of losses and expected increasing expenses may prevent achieving or maintaining profitability.	\N
105	3	5	3	Our future revenue and operating results are dependent on our ability to generate a sustainable order rate for our products and services and develop new technologies to meet the needs of our customers or potential new customers.	Future revenue depends on sustainable order rates and successful technology development for customers.	\N
106	3	9	3	The cyclical nature of the rocket launch services, mission services, spacecraft and spacecraft component markets could negatively impact our ability to accurately forecast customer demand.	Cyclical markets for launch and space services could impair demand forecasting accuracy.	\N
107	3	5	3	We have previously experienced, and may experience in the future, delays or other complications in the design, manufacture and commercialization of new rocket launch services, including the development and launch of our Neutron launch vehicle, mission services, spacecraft, spacecraft components and related technology.	Past and potential future delays in developing and commercializing new launch vehicles and space technologies could harm business.	\N
108	3	3	3	Our business with various governmental entities is subject to the policies, priorities, regulations, mandates and funding levels of such governmental entities and may be negatively or positively impacted by any change thereto.	Government business is subject to changing policies, priorities, regulations and funding levels which could negatively impact contracts.	\N
109	3	3	3	The U.S. government has been aggressively pursuing cost reductions policies and elimination of government agencies and programs that could negatively impact the funding of government projects and programs in which we or our customers participate or compete for new contracts.	U.S. government cost-cutting and program eliminations could reduce funding for projects Rocket Lab or its customers rely on.	\N
110	3	3	3	We are subject to the procurement policies and procedures set forth in the Federal Acquisition Regulation ("FAR").	Compliance with the Federal Acquisition Regulation is mandatory for U.S. government contracts and non-compliance risks contract termination.	\N
111	3	3	3	In addition, contracts with any government, including the U.S. government, may be terminated or suspended by the government at any time and could result in significant liability obligations for us.	Government contracts can be terminated or suspended at any time, potentially leaving Rocket Lab with liabilities and lost revenue.	\N
112	3	3	3	Our ability to participate in and continue to pursue many of our business activities is regulated by various agencies and departments of the U.S. government and, in certain circumstances, the governments of other countries.	Rocket Lab's operations require licenses and clearances from multiple U.S. and foreign government agencies, and failure to maintain them could halt business.	\N
113	3	8	3	We derive a substantial amount of our revenues from only a few of our customers.	Revenue concentration among a small number of customers creates risk if any major customer reduces orders or defaults.	\N
114	3	3	3	Disruptions in U.S. government operations and funding could have a material adverse effect on our revenues, earnings and cash flows, and otherwise adversely affect our financial condition.	Government shutdowns or funding lapses could delay contract awards, payments, and regulatory approvals, hurting financial performance.	\N
115	3	3	3	Any disruptions in federal government operations could have a material adverse effect on our revenues, earnings, and cash flows.	Federal government operational disruptions, including shutdowns, can negatively impact Rocket Lab's revenue, earnings, and cash flow.	\N
116	3	5	3	We may not be successful in developing new technology, including our Neutron launch vehicle, and the technology we are successful in developing may not meet the needs of our customers or potential new customers.	Failure to successfully develop or market new technologies like the Neutron launch vehicle could limit growth and competitiveness.	\N
117	3	5	3	The markets in which we operate are characterized by changing technology and evolving industry standards, and we may not be successful in identifying, developing and marketing products and services that respond to rapid technological change, evolving technical standards and systems developed by others.	Rapid technological change and evolving standards risk Rocket Lab's ability to offer competitive products and services.	\N
118	3	4	3	We operate in highly competitive industries and in various jurisdictions across the world which may cause us to have to reduce our prices.	Global competition across multiple jurisdictions pressures Rocket Lab to lower prices, potentially compressing margins.	\N
119	3	4	3	We operate in highly competitive industries and many of our competitors are larger and have substantially greater resources than we have.	Larger, better-resourced competitors pose a significant competitive threat to Rocket Lab's market position.	\N
120	3	4	3	We may also face competition in the future from emerging low-cost competitors.	Future low-cost competitors could further intensify price competition and erode Rocket Lab's market share.	\N
121	3	4	3	In addition, some of our foreign competitors currently benefit from, and others may benefit in the future from, protective measures by their home countries where governments are providing financial support, including significant investments in the development of new technologies.	Foreign government subsidies for competitors reduce their commercial risk and increase competitive pressure on Rocket Lab.	\N
122	3	13	3	Acquisitions or divestitures could result in adverse impacts on our operations.	Integrating acquisitions like GEOST or executing divestitures may disrupt operations, distract management, and create unexpected liabilities.	161
123	3	9	3	Uncertain global macro-economic and political conditions could materially adversely affect our results of operations and financial condition.	Global economic and political instability could negatively impact Rocket Lab's financial performance and operations.	\N
124	3	9	3	Our results of operations are materially affected by economic and political conditions in the United States and internationally	Macroeconomic and geopolitical instability, including inflation, wars, and trade policies, could reduce customer spending and impair the company's financial performance.	\N
125	3	1	3	We often rely on a single vendor or a limited number of vendors to provide certain key products or services and the inability of these key vendors to meet our needs could have a material adverse effect on our business	Dependence on sole-source suppliers for critical components like composites and inertial measurement units creates vulnerability to supply disruptions and price changes.	\N
126	3	13	3	Launch vehicles are subject to manufacturing delays, damage or destruction during pre-launch operations, and launch failures, the occurrence of which can materially and adversely affect our operations	Manufacturing delays, pre-launch damage, or launch failures of rockets could cause significant revenue delays and harm the business.	\N
127	3	13	3	Spacecraft are subject to manufacturing and launch delays, damage or destruction during pre-launch operations, launch failures and incorrect orbital placement, the occurrence of which can materially and adversely affect our operations	Spacecraft face risks from manufacturing delays, launch failures, and orbital placement errors that could delay or eliminate anticipated revenue.	\N
128	3	5	3	If our launch vehicles and spacecraft fail to operate as intended, it could have a material adverse effect on our business, financial condition and results of operations	Complex technology and environmental stresses could cause hardware or software failures, human error, or space debris collisions that degrade or destroy vehicles.	\N
129	3	8	3	Our contracts may include performance-based payment terms that expose us to financial risks	Payment terms tied to ongoing product performance could lead to reduced or ceased payments, refund obligations, or unexpected losses if performance criteria are not met.	\N
130	3	5	3	Our revenue, results of operations and reputation may be negatively impacted if our products contain defects or fail to operate in the expected manner	Defects in sophisticated software, components, or products operating in harsh environments could cause lost revenue, reputational damage, and loss of future contracts.	\N
131	3	13	3	Any inability to operate Electron at our anticipated launch rate could adversely impact our business, financial condition and results of operations	The launch services business depends on maintaining Electron's launch rate, which could be disrupted by production issues, regulatory delays, or launch failures.	\N
132	3	1	3	Disruptions in the supply of key raw materials or components, including restrictions on our ability to obtain rare earth minerals, and difficulties in the supplier qualification process, as well as increases in prices of raw materials, could adversely impact us	Single-source procurement of critical materials like rare earth minerals, combined with price volatility and qualification challenges, threatens production and contract fulfillment.	\N
134	3	11	3	Space is a harsh and unpredictable environment where our products and service offerings are exposed to a wide and unique range of environmental risks, including, among others, coronal mass ejections, solar flares and other extreme space weather events and potential collision with space debris or another spacecraft, which could adversely affect our launch vehicle and spacecraft performance.	Space environmental hazards such as solar flares, space weather, and orbital debris collisions pose significant risks to launch vehicle and spacecraft performance.	\N
135	3	8	3	Our business involves significant risks and uncertainties that may not be covered by insurance.	The company faces substantial operational risks that may exceed insurance coverage limits or be uninsurable, potentially leading to uncovered liabilities.	\N
136	3	13	3	Interruption or failure of our infrastructure could hurt our ability to effectively perform our daily operations and provide and produce our products and services, which could damage our reputation and harm our operating results.	Infrastructure failures from natural disasters, aging systems, or other disruptions could halt operations, destroy facilities, and negatively impact financial performance.	\N
137	3	6	3	The availability of many of our products and services depends on the continuing operation of our information technology and communications systems.	Dependence on IT and communications systems creates vulnerability to downtime, damage, or failure from various threats, potentially reducing revenue and profits.	\N
138	3	6	3	Any significant disruption in or unauthorized access to our computer systems or those of third parties that we utilize in our operations, including those relating to cybersecurity or arising from cyber-attacks, could result in a loss or degradation of service, unauthorized disclosure of data, or theft or tampering of intellectual property, any of which could materially adversely impact our business.	Cybersecurity breaches or system disruptions could lead to data loss, IP theft, service degradation, and material business harm.	\N
139	3	6	3	Our operations, products, services and intellectual property are inherently at risk of disruption, loss, inappropriate access, or tampering by both insider threats and external bad actors.	Insider and external threats pose risks to operations, IP, and assets, including cyber attacks, physical security threats, and terrorism.	\N
140	3	12	3	If we cannot successfully protect our intellectual property, our business could suffer.	Failure to adequately protect intellectual property through patents, trade secrets, and contracts could erode competitive advantage and harm the business.	\N
141	3	12	3	To protect our intellectual property rights, we may be required to spend significant resources to monitor and protect these rights, and we may or may not be able to detect infringement by third parties.	The company may incur substantial costs to monitor and enforce its intellectual property rights, with no guarantee of detecting or preventing third-party infringement.	\N
142	3	12	3	Third parties may allege that our technology violates their proprietary data rights, which could have a negative impact on our operations.	Third parties could claim the company's technology infringes their proprietary rights, potentially disrupting operations.	\N
143	3	10	3	Indemnity provisions in various agreements potentially expose us to substantial liability for intellectual property infringement and other losses.	Perpetual indemnification clauses in agreements could require large payments for IP infringement claims, harming financial condition.	\N
144	3	7	3	We are highly dependent on the services of Sir Peter Beck, our President, Chief Executive Officer and Chairman, and if we are unable to retain Mr. Beck, our ability to compete could be harmed.	The company's heavy reliance on CEO Sir Peter Beck, who engages in high-risk activities and lacks key person insurance, creates significant key-person risk.	\N
145	3	7	3	Our inability to hire or retain key personnel could adversely affect our business, operating results and financial condition.	Difficulty attracting and retaining skilled personnel, especially in engineering and sales, could seriously harm the business.	\N
146	3	7	3	Labor-related matters, including labor disputes, may adversely affect our operations.	Potential unionization, work stoppages, and employee claims could disrupt operations and increase labor costs.	\N
147	3	8	3	Given the relative contribution and materiality of our New Zealand operations, fluctuations in foreign exchange rates or future hedging activities could have a negative impact on our business.	Significant New Zealand dollar-denominated expenses versus U.S. dollar revenues create foreign exchange risk that could disproportionately increase costs.	\N
148	3	8	3	We may require additional capital to support business growth, and this capital might not be available on company favorable terms, if at all, or may be available only by diluting existing stockholders or putting excessive debt leverage and insolvency risk on the business.	Future capital needs may not be met on favorable terms, potentially forcing dilutive equity raises or restrictive debt that limits flexibility.	162
149	3	14	3	We are incurring, and will continue to incur, significant increased expenses and administrative burdens as a public company, which could have an adverse effect on its business, financial condition and results of operations.	Public company compliance costs, including Sarbanes-Oxley and SEC requirements, increase expenses and divert resources from growth initiatives.	\N
150	3	13	3	The release, unplanned ignition, explosion, or improper handling of dangerous materials used in our business could disrupt our operations and adversely affect our financial results.	Accidents involving hazardous materials used in launch vehicles and spacecraft could disrupt operations and harm financial performance.	\N
151	3	13	3	Our business operations involve the handling, production and disposition of potentially explosive and ignitable energetic materials and other dangerous chemicals, including materials used in rocket propulsion.	Handling hazardous energetic materials and chemicals poses risks of explosions, injuries, property damage, regulatory sanctions, and production disruptions.	\N
152	3	8	3	If we experience cost overruns on our contracts, we would have to absorb the excess costs which could adversely affect our financial results.	Cost overruns on contracts would be absorbed by the company, adversely affecting financial results.	\N
153	3	3	3	Delays in project completion or failure to meet certain requirements could also result in liability for costs incurred by customers, including penalties, liquidated damages, or obligations to address deficiencies in order to meet contractual requirements.	Project delays or failure to meet requirements could result in customer liabilities, penalties, and liquidated damages.	\N
378	8	8	8	Currency exchange rate fluctuations affect our results of operations.	Foreign currency exchange rate movements impact Caterpillar's reported results and cash flows due to global operations in multiple currencies.	\N
154	3	8	3	Our indebtedness and liabilities could limit the cash flow available for our operations, expose us to risks that could adversely affect our business, financial condition and results of operations and impair our ability to satisfy our obligations under our debt instruments when they come due.	High indebtedness could limit cash flow, increase vulnerability, restrict financing, and impair debt repayment ability.	\N
155	3	8	3	Our business may not generate sufficient funds, and we may otherwise be unable to maintain sufficient cash reserves, to pay amounts due under our indebtedness and our cash needs may increase in the future.	The business may not generate enough cash to meet debt obligations and future cash needs.	\N
156	3	8	3	We may be unable to raise the funds necessary to repurchase our convertible senior notes for cash following a fundamental change, or to pay any cash amounts due upon conversion, and our other then-existing indebtedness may limit our ability to repurchase the notes or pay cash upon their conversion.	The company may lack funds to repurchase convertible notes or pay cash upon conversion, and existing debt may restrict such payments.	\N
157	3	14	3	Provisions in the indenture could delay or prevent an otherwise beneficial takeover of us.	Indenture provisions may delay or prevent a beneficial takeover, potentially discouraging acquisitions.	\N
158	3	14	3	The capped call transactions may affect the value of our convertible senior notes and our common stock.	Capped call transactions could affect the value of convertible senior notes and common stock.	\N
159	3	8	3	We are subject to counterparty risk with respect to the capped call transactions, and the capped call may not operate as planned.	Counterparty risk exists with capped call transactions, and they may not operate as planned.	\N
160	3	8	3	Changes in our accounting estimates and assumptions could negatively affect our financial position and results of operations.	Changes in accounting estimates and assumptions could materially impact financial position and results of operations.	\N
161	3	14	3	Our actual operating results may differ significantly from our guidance.	Actual operating results may differ significantly from management's unaudited guidance.	\N
162	3	8	3	Guidance is based upon a number of assumptions and estimates that, while presented with numerical specificity, is inherently subject to significant business, economic and competitive uncertainties and contingencies, many of which are beyond our control and are based upon specific assumptions with respect to future business decisions, some of which will change.	The company's financial guidance relies on uncertain assumptions and may differ materially from actual results.	\N
163	3	13	3	Certain future operational facilities may require significant expenditures in capital improvements and operating expenses to develop and foster basic levels of service needed for our operations, and the ongoing need to maintain existing operational facilities requires us to expend capital.	Developing and maintaining operational facilities demands substantial capital that may not be available.	\N
164	3	8	3	We currently have, and will continue to have, significant lease obligations, and our failure to meet those obligations could adversely affect our financial condition and business.	Significant lease obligations could strain cash flow and limit financial flexibility if not met.	\N
165	3	2	3	If we expand further outside the United States, we will be exposed to a variety of risks associated with international operations that could materially and adversely affect our business.	International expansion introduces regulatory, economic, and political risks that could harm the business.	\N
166	3	13	3	We are subject to many hazards and operational risks that can disrupt our business, including interruptions or disruptions in service at our primary facilities, which could have a material adverse effect on our business, financial condition and results of operations.	Operational hazards and facility disruptions could materially impact manufacturing and launch operations.	\N
167	3	11	3	Natural disasters, unusual weather conditions, epidemic outbreaks, terrorist acts and political events could disrupt our business and flight schedule.	Extreme weather, natural disasters, pandemics, and geopolitical events could interrupt operations and supply chains.	\N
168	3	13	3	Any acquisitions, partnerships or joint ventures that we enter into could disrupt our operations and have a material adverse effect on our business, financial condition and results of operations.	Strategic transactions may fail to integrate successfully, divert management, and impair financial performance.	\N
169	3	3	3	Our business is subject to various regulatory risks that could adversely affect our operations.	Complex and evolving regulations across jurisdictions could restrict operations and increase compliance costs.	\N
170	3	2	3	Import and Export Restrictions.	The company faces risks from import and export restrictions that could prevent obtaining necessary technologies or export permits, potentially harming revenues and margins.	\N
171	3	3	3	U.S. Government Approval Requirements.	Delays or failures in obtaining required U.S. government licenses and approvals for exports and defense services could lead to contract termination or penalties.	\N
172	3	3	3	Other Government Regulations.	The company must comply with numerous licensing and regulatory requirements for space launches, radio communications, and remote sensing, with non-compliance risking penalties and reputational harm.	\N
173	3	4	3	Competitive Impact of U.S. Regulations.	U.S. export controls and sanctions may limit business opportunities and give non-U.S. competitors a competitive advantage with foreign customers.	\N
174	3	10	3	Anti-Corruption Laws.	Non-compliance with global anti-corruption laws by employees or partners could result in fines, legal sanctions, and loss of contracting eligibility.	\N
175	3	2	3	Changes in trade policies, including tariffs, could cause adverse impacts to our business.	Recent U.S. tariff increases and potential retaliatory measures could raise supply chain costs and disrupt operations despite primarily domestic suppliers.	\N
176	3	3	3	Our operations in the U.S. government market are subject to significant regulatory risk.	The company's U.S. government market operations face regulatory risks including compliance with procurement regulations, audits, and potential debarment for non-compliance.	\N
177	3	8	3	Changes in tax law, in our tax rates or in exposure to additional income tax liabilities or assessments may materially and adversely affect our financial condition, results of operations and cash flows.	Changes in tax laws, such as the One Big Beautiful Bill Act, could increase tax obligations and adversely affect financial condition and cash flows.	\N
379	8	8	8	Restrictive covenants in our debt agreements could limit our financial and operating flexibility.	Debt covenants impose financial and operational restrictions that, if breached, could trigger acceleration of debt or loss of credit access.	\N
178	3	11	3	Our operations are subject to governmental law and regulations relating to environmental matters, which may expose us to significant costs and liabilities that could negatively impact our financial condition.	Environmental laws and regulations could result in significant liabilities and costs from contamination or non-compliance, negatively impacting financial condition.	\N
179	3	5	3	We may experience warranty claims for product failures, schedule delays or other problems with existing or new products.	The company faces risk of warranty claims due to product failures or schedule delays given the technologically advanced nature of its products.	\N
180	4	3	4	We depend heavily on contracts with the U.S. Government for a substantial portion of our business. Changes in the U.S. Government's priorities, or delays or reductions in spending could have a material adverse effect on our business.	The company's heavy reliance on U.S. Government contracts makes it vulnerable to changes in government priorities, spending delays, or reductions.	\N
181	4	3	4	The F-35 program comprises a material portion of our revenue and reductions or delays in funding for this program and risks related to performance, schedule, cost and requirements of the program could adversely affect our performance.	The F-35 program represents a significant portion of revenue and faces risks from funding reductions, delays, and performance, schedule, cost, and requirement challenges.	\N
182	4	3	4	We are subject to extensive procurement and other laws, regulations, and contract terms, including those that enable the U.S. Government to terminate contracts for convenience. Our business and reputation could be adversely affected if we or those we do business with fail to comply with these laws, regulations, or terms.	Compliance with extensive government procurement laws and regulations is critical, as violations could lead to fines, contract termination, or debarment.	\N
183	4	3	4	Undefinitized Contract Action (UCA).	Performing work under undefinitized contract actions exposes the company to unilateral definitization by the government, potentially imposing unfavorable terms.	\N
184	4	3	4	Contract Termination.	The U.S. Government can terminate contracts for convenience or default, which could adversely affect business and financial performance.	\N
185	4	4	4	Competition and changing customer procurement policies could adversely affect our business and financial results.	Intense competition from traditional and new entrants, as well as changing procurement policies, could result in lost business opportunities or recompetes.	\N
186	4	4	4	A substantial portion of our business is awarded through competitive bidding.	The company faces pricing pressure and increased costs due to the U.S. Government's reliance on competitive bidding and multi-award contracts, where competitors may accept lower profitability.	\N
187	4	3	4	U.S. Government procurement policies and procedures and the application thereof are regularly changing, and such changes could adversely affect our profitability or the ability to win new business.	Changes in government procurement policies, including increased use of fixed-price contracts and rapid acquisition pathways, could reduce profitability and make it harder to win contracts.	\N
188	4	8	4	Our profitability and cash flow may vary based on the mix of our contracts and programs, our performance, and our ability to estimate and control costs.	Profitability and cash flow are subject to variability due to contract mix, performance, cost estimation challenges, and the risk of reach-forward losses on fixed-price development and production contracts.	\N
189	4	3	4	We are routinely subject to audit by our customers on government contracts, including audits relating to our disclosed Cost Accounting Standards (CAS) rate structure or any changes to our CAS rate structure and the results of those audits could have an adverse effect on our business, reputation and results of operations	Routine government audits of contract pricing, cost structure, and compliance could lead to price reductions, payment delays, penalties, or debarment, impacting financial results.	\N
190	4	3	4	U.S. Government agencies, including the Defense Contract Audit Agency, the Defense Contract Management Agency and various agency Inspectors General, routinely audit and investigate government contractors.	Government agencies conduct audits and investigations that can result in contract price reductions, payment withholds, penalties, or debarment, materially affecting financial condition.	\N
191	4	1	4	We are heavily dependent on suppliers and if our subcontractors or other suppliers or teaming agreement or joint venture partners fail to perform their obligations, our performance and ability to win future business could be adversely affected.	Heavy reliance on subcontractors and suppliers creates risk that their failure to perform could disrupt contract execution, increase costs, and harm future business prospects.	\N
192	4	5	4	Our success depends, in part, on our ability to develop new technologies, products and services and efficiently produce and deliver existing products.	The company's performance relies on its capacity to innovate and efficiently manufacture advanced products to meet evolving customer needs.	\N
193	4	5	4	Our future success in delivering innovative and affordable solutions to our customers relies, in part, on our multi-year business transformation initiative that seeks to significantly enhance our digital infrastructure to increase efficiencies and collaboration throughout our business while reducing costs.	The company's digital transformation initiative is critical for improving efficiency and competitiveness but requires substantial investment and successful execution.	\N
194	4	2	4	Geopolitical, macroeconomic and public health events and conditions could adversely affect our business, financial condition and operating results.	Broad geopolitical, economic, and public health events pose risks to the company's business and financial performance.	\N
195	4	2	4	International sales may pose different economic, regulatory, competition and other risks.	International sales expose the company to unique economic, regulatory, and competitive risks that could affect performance.	\N
196	4	2	4	International sales present risks that are different and potentially greater than those encountered in our U.S. business.	International sales face heightened risks from political and economic factors, export regulations, foreign government relations, compliance with anti-corruption laws, and offset agreement obligations.	\N
197	4	12	4	We may be unable to benefit fully from or adequately protect our intellectual property rights or use third-party intellectual property, which could negatively affect our business.	The company risks losing competitive advantage if it cannot protect its patents, trade secrets, and other IP, or if government rights and third-party claims limit its ability to exploit intellectual property.	\N
383	8	3	8	We may incur additional tax expense or become subject to additional tax exposure.	Changes in tax laws, rates, or audit outcomes could increase Caterpillar's effective tax rate and tax liabilities.	\N
198	4	7	4	Our business and financial performance depends on us identifying, attracting and retaining a highly skilled workforce.	Performance relies on recruiting and retaining specialized talent, including security-cleared personnel, amid intense competition from commercial tech firms offering more flexible arrangements.	\N
199	4	6	4	Cyber-attacks and other security threats and disruptions could have a material adverse effect on our business.	The company faces persistent, sophisticated cyber threats from nation-state actors and other adversaries that could compromise classified data, intellectual property, and critical infrastructure.	\N
200	4	1	4	Our customers (including sites that we operate and manage for our customers), suppliers, subcontractors, joint venture partners and acquired entities that we do not fully integrate face similar security threats and an incident at one of these entities could adversely impact our business.	Cybersecurity incidents at suppliers, subcontractors, joint venture partners, or acquired entities outside the company's control could compromise data and disrupt customer deliverables.	\N
201	4	8	4	If we fail to successfully complete or manage acquisitions, divestitures, equity investments and other transactions or if acquired entities or equity investments fail to perform as expected, our financial results, business and future prospects could be harmed.	Failure to successfully execute or integrate acquisitions, divestitures, or equity investments could harm financial results and future prospects.	\N
202	4	13	4	Joint ventures and other noncontrolling investments operate under shared control with other parties.	Joint ventures and noncontrolling investments expose the company to additional risks from shared control, including partner decisions inconsistent with its interests and liability for partner actions.	\N
203	4	5	4	We make investments in early-stage companies that we believe are advancing or developing new technologies applicable to our business.	Investments in early-stage technology companies are illiquid, non-controlling, and subject to fair value adjustments or impairments based on factors outside the company's control.	\N
204	4	8	4	Risks Related to Significant Contingencies, Uncertainties and Estimates, including Pension, Taxes, Environmental and Litigation Costs	Significant contingencies and uncertainties related to pension, tax, environmental, and litigation costs could materially affect financial condition and results of operations.	\N
205	4	8	4	Pension funding requirements and costs are dependent on return on pension assets and other economic and actuarial assumptions which, if changed, may cause our future earnings and cash flow to fluctuate significantly and affect the affordability of our products and services.	Pension funding requirements and costs are sensitive to changes in economic and actuarial assumptions, potentially causing significant fluctuations in earnings, cash flow, and product affordability.	\N
206	4	8	4	Our estimates and projections may prove to be inaccurate and certain of our assets may be at risk of future impairment.	Accounting estimates and projections, including goodwill impairment testing, involve significant judgments that could prove inaccurate and lead to material write-offs.	\N
207	4	3	4	Changes in tax laws and regulations and interpretations or exposure to additional tax liabilities could adversely affect our financial results.	Changes in tax laws, regulations, or interpretations, as well as tax audit outcomes, could increase tax expense and affect profitability and cash flows.	\N
208	4	10	4	Our business involves significant risks and uncertainties that may not be covered by indemnity or insurance.	The company faces significant liabilities from advanced defense products that may not be fully covered by government indemnifications or insurance.	\N
209	5	9	5	We depend heavily on commercial airlines, subjecting us to unique risks.	Boeing's heavy reliance on commercial airline customers exposes it to cyclical industry dynamics, economic downturns, and individual carrier financial health that can reduce orders and delay deliveries.	\N
210	5	8	5	We enter into firm fixed-price aircraft sales contracts with indexed price escalation clauses, which subjects us to losses if we have cost overruns or if increases in our costs exceed the applicable escalation rate.	Firm fixed-price contracts with price escalation clauses transfer cost overrun risk to Boeing when actual cost increases exceed contractual escalation rates.	\N
211	5	9	5	We derive a significant portion of our revenues from a limited number of commercial airlines.	Revenue concentration among a few major airlines means fleet decisions or financial distress at any single customer could significantly reduce Boeing's sales and profitability.	\N
212	5	13	5	Our Commercial Airplanes business depends on our ability to maintain a healthy production system, ensure every airplane in our production system conforms to exacting specifications, achieve planned production rate targets, successfully develop and certify new aircraft or new derivative aircraft, and meet or exceed stringent performance and reliability standards.	Boeing's Commercial Airplanes segment requires a stable, high-quality production system and successful certification of new derivatives to meet delivery targets and maintain program profitability.	\N
213	5	5	5	The introduction of new aircraft programs and/or derivatives, such as the 777X, 737-7 and 737-10, takes years and involves significant risks associated with meeting development, testing, certification, and production schedules.	New aircraft programs like the 777X and 737 variants face multi-year development, testing, and certification risks that can delay entry into service and trigger customer penalties.	\N
214	5	13	5	We must minimize disruption caused by production changes, achieve and maintain operational stability and implement productivity improvements to meet customer demand and maintain our profitability.	Planned production rate increases on key programs risk disruption if safety metrics, supplier readiness, or FAA concurrence do not support the accelerated schedule.	\N
215	5	13	5	Operational challenges impacting the production system for one or more of our commercial aircraft programs could result in additional production delays and/or failure to meet customer demand for new aircraft, either of which would negatively impact our revenues and operating margins.	Operational issues including quality defects, labor instability, and supply chain constraints—exacerbated by the Spirit AeroSystems acquisition—can cause production delays and margin erosion.	176
216	5	5	5	If our commercial aircraft fail to satisfy performance and reliability requirements and/or potentially required sustainability standards, we could face additional costs and/or lower revenues.	Failure to meet performance, reliability, or emerging sustainability standards could increase warranty costs, disrupt operations, and reduce demand for Boeing aircraft.	\N
380	8	8	8	Sustained increases in funding obligations under our pension plans may impair our liquidity or financial condition.	Growing pension funding requirements could strain Caterpillar's liquidity and overall financial health.	\N
217	5	3	5	Changes in levels of U.S. government defense spending or acquisition priorities, as well as significant delays in U.S. government appropriations, could negatively impact our business, financial position, results of operations and cash flows.	Unpredictable U.S. defense budgets and shifting acquisition priorities threaten revenue from major government contracts with the Department of War and NASA.	\N
218	5	3	5	The timeliness of annual appropriations for U.S. government departments and agencies remains a recurrent risk.	Recurring delays in congressional appropriations and potential government shutdowns risk payment delays, certification hold-ups, and operational disruptions for Boeing.	\N
219	5	3	5	In addition, there continues to be uncertainty with respect to future acquisition priorities and program-level appropriations for the DoW, NASA and other government agencies, including changes to national security and defense priorities, and tension between modernization investments, sustainment investments, and investments in new technologies or emergent capabilities.	Uncertainty around future defense program funding and technology investment priorities could lead to contract reductions, cancellations, or delays affecting Boeing's government business.	\N
220	5	3	5	As a result of the significant ongoing uncertainty with respect to both U.S. defense spending and the evolving nature of the national security threat environment, we also expect the DoW to continue to emphasize affordability, innovation, cybersecurity and delivery of technical data and software in its procurement processes, including the implementation of cybersecurity compliance requirements on the Defense Industrial Base, for which the supply chain may not be fully prepared.	Boeing faces risk that changing U.S. defense procurement priorities emphasizing affordability and cybersecurity may outpace the supply chain's readiness, potentially impacting revenues and market share.	\N
221	5	1	5	Our ability to deliver products and services that satisfy customer requirements is heavily dependent on the performance and financial stability of our subcontractors and suppliers, as well as on the availability of highly skilled labor, raw materials and other components.	Boeing's ability to meet customer commitments depends heavily on supplier performance, financial stability, and availability of skilled labor and raw materials, with disruptions potentially harming financial results.	\N
222	5	13	5	Some of our and our suppliers' workforces are represented by labor unions.	Work stoppages by unionized employees at Boeing or its suppliers have historically disrupted production and could continue to materially affect operations and financial performance.	\N
223	5	4	5	Competition within our markets and with respect to our products and services may reduce our future contracts and sales.	Intense competition across Boeing's commercial, defense, and services segments from both traditional and new entrants could reduce future contracts, sales, and market share.	\N
224	5	2	5	We derive a significant portion of our revenues from non-U.S. sales and are subject to the risks of doing business in other countries, including those related to tariffs, trade restrictions and government actions.	A significant portion of Boeing's revenue comes from international sales, exposing the company to geopolitical, trade, regulatory, and currency risks that could adversely affect operations.	\N
225	5	2	5	The global trade environment remains highly dynamic and continues to evolve.	Dynamic global trade policies, including tariffs and retaliatory measures, could increase product costs, reduce demand for commercial aircraft, and lead to order cancellations.	\N
226	5	2	5	China is a significant market for commercial aircraft and we have long-standing relationships with our Chinese customers.	Boeing's significant commercial aircraft market in China faces risks from U.S.-China trade tensions, tariffs, and export restrictions that could reduce deliveries and market share.	\N
227	5	8	5	We use estimates and make assumptions in accounting for contracts and programs.	Boeing's financial results depend on estimates and assumptions in contract and program accounting, and changes to these estimates could negatively impact future financial performance.	\N
228	5	13	5	We may not realize the anticipated benefits of mergers, acquisitions, joint ventures/strategic alliances or divestitures.	Boeing may fail to achieve expected benefits from mergers, acquisitions, joint ventures, or divestitures due to integration challenges, legacy liabilities, or partner performance issues.	176
229	5	3	5	Risks Related to Our Contracts	Boeing faces multiple risks associated with its extensive portfolio of U.S. government contracts, including regulatory, termination, and audit risks.	\N
230	5	3	5	We conduct a significant portion of our business pursuant to U.S. government contracts, which are subject to unique risks.	A significant portion of Boeing's revenue comes from U.S. government contracts that carry unique regulatory and compliance risks.	\N
231	5	3	5	Our sales to the U.S. government are subject to extensive procurement regulations, and changes to those regulations could increase our costs.	Changes in U.S. government procurement regulations could increase compliance costs and reduce operating margins for Boeing's defense and government services businesses.	\N
232	5	3	5	The U.S. government may modify, curtail or terminate one or more of our contracts.	The U.S. government can modify, curtail, or terminate contracts without notice, and funding reductions could materially harm Boeing's financial performance.	\N
233	5	3	5	We are subject to U.S. government inquiries and investigations, including periodic audits of costs that we determine are reimbursable under U.S. government contracts.	Boeing is subject to U.S. government audits and investigations that could result in cost disallowances, penalties, or contract termination.	\N
234	5	3	5	Our fixed-price contracts subject us to losses when we have cost overruns.	Fixed-price contracts expose Boeing to losses if costs exceed estimates, as seen in significant reach-forward losses on major defense programs.	\N
235	5	3	5	We enter into cost-type contracts, which also carry risks.	Cost-type contracts carry risks of reduced award fees, lower profit rates, or program cancellation due to cost, schedule, or technical performance issues.	\N
236	5	5	5	We enter into contracts that include in-orbit incentive payments that subject us to risks.	Contracts with in-orbit incentive payments for satellites create long-term financial risk if satellites fail to meet performance specifications over 15 years.	\N
237	5	6	5	Risks Related to Technology, Security and Business Disruptions	Boeing's complex global technology infrastructure exposes it to cybersecurity threats and operational disruption risks.	\N
238	5	6	5	Managing a complex, global IT infrastructure exposes us to a variety of risks that could negatively impact our business.	Boeing's decentralized global IT infrastructure creates risks of inefficiencies, operational disruptions, and noncompliance with data privacy regulations.	\N
239	5	6	5	Compromised or unauthorized access of our, our customers' and/or our suppliers' systems or data could negatively impact our business.	Cybersecurity threats from sophisticated actors could compromise Boeing's systems, leading to data breaches, operational disruption, and reputational harm.	\N
240	5	13	5	Business disruptions could seriously affect our future sales and financial condition or increase our costs and expenses.	Business disruptions from various threats could harm sales, increase costs, and damage reputation.	\N
241	5	10	5	The outcome of litigation and of government inquiries and investigations involving our business is unpredictable, and an adverse decision in any such matter could have a material effect on our financial position, results of operations and cash flows.	Unpredictable litigation and government investigations could materially impact financial position and operations.	\N
242	5	11	5	Our operations expose us to the risk of material environmental liabilities.	Operations carry risk of significant environmental liabilities including cleanup costs and fines.	\N
243	5	11	5	We may be adversely affected by global climate change or by legal, regulatory or market responses to such change.	Climate change and related regulatory responses could negatively impact business outlook, costs, and supply chain.	\N
244	5	8	5	We may be unable to effectively manage our liquidity, which could adversely affect our business, financial position and results of operations.	Inability to manage liquidity could harm business, financial position, and operations.	\N
245	5	8	5	We have in the past experienced and could in the future experience downgrades in our credit ratings.	Credit rating downgrades could increase borrowing costs and limit access to capital markets.	\N
246	5	8	5	Substantial pension and other postretirement benefit obligations have a material impact on our earnings, shareholders' equity and cash flows from operations, and could have significant adverse impacts in future periods.	Large pension and postretirement obligations significantly affect earnings, equity, and cash flows, with potential future adverse impacts.	\N
247	5	8	5	Our insurance coverage may be inadequate to cover all significant risk exposures.	Insurance may not cover all liabilities, particularly for unique products like aircraft and defense systems, potentially leaving Boeing with substantial costs.	\N
248	5	14	5	The issuance of our common stock upon conversion of our Mandatory convertible preferred stock, and the exchange of the Spirit Exchangeable Notes, as well as any other issuances of our common stock, could dilute the interests of our existing shareholders.	Conversion of preferred stock and exchange of Spirit Exchangeable Notes could dilute existing shareholders.	176
249	6	5	6	Failure to meet the evolving needs of our industry and markets may adversely impact our financial results.	Rapid technology changes and shifting customer requirements could render NVIDIA's products obsolete or incompatible, harming financial performance.	180
250	6	4	6	Competition could adversely impact our market share and financial results.	Intense competition from rivals with greater resources or proprietary manufacturing could erode NVIDIA's market position and pricing power.	\N
251	6	1	6	Long manufacturing lead times and uncertain supply and capacity availability, combined with a failure to estimate customer demand accurately has led and could lead to mismatches between supply and demand.	Extended semiconductor lead times and demand forecasting errors create risk of inventory excess or product shortages, hurting margins.	\N
252	6	1	6	Dependency on third-party suppliers and their technology to manufacture, assemble, test, or package our products reduces our control over product quantity and quality, manufacturing yields, and product delivery schedules and could harm our business.	Reliance on external foundries and assembly partners limits NVIDIA's control over supply, quality, and delivery timelines.	\N
253	6	5	6	Defects in our products have caused and could cause us to incur significant expenses to remediate and could damage our business.	Product defects may trigger costly recalls, repairs, or liability claims, damaging reputation and financial results.	\N
254	6	9	6	Adverse economic conditions may harm our business.	Macroeconomic downturns could reduce customer spending on NVIDIA's products and services, lowering revenue.	\N
255	6	2	6	International sales and operations are a significant part of our business, which exposes us to risks that could harm our business.	Global operations expose NVIDIA to geopolitical instability, trade restrictions, and currency fluctuations.	\N
256	6	6	6	Product, system security and data protection incidents or breaches, as well as cyber-attacks could disrupt our operations and adversely affect our financial condition, stock price and reputation.	Cybersecurity breaches or data leaks could interrupt operations, trigger legal liability, and damage investor confidence.	\N
257	6	13	6	Business disruptions could harm our operations and financial results.	Natural disasters, pandemics, or other disruptions could interrupt manufacturing, logistics, or workforce availability.	\N
258	6	11	6	Climate change may have a long-term impact on our business.	Long-term climate risks such as extreme weather or regulatory changes could affect facilities, supply chain, and energy costs.	\N
259	6	8	6	We may not be able to realize the potential benefits of business investments or acquisitions, nor successfully integrate acquisition targets.	Acquisitions and strategic investments may fail to deliver expected synergies or may face integration challenges.	\N
260	6	9	6	A significant amount of our revenue stems from a limited number of partners and distributors and we have a concentration of sales to customers who purchase directly or indirectly from us, and our revenue could be adversely affected if we lose or are prevented from selling to any of these customers.	Heavy reliance on a few key partners and customers creates revenue concentration risk if relationships deteriorate.	\N
261	6	8	6	Commercial arrangements expose us to counterparty risks, which may negatively impact our business, financial condition, or results of operations.	Contractual counterparties may default or fail to perform, leading to financial losses or operational disruption.	\N
262	6	7	6	We may be unable to attract, retain, and motivate our executives and key employees.	Loss of key talent or inability to hire skilled personnel could impede innovation and execution.	\N
263	6	13	6	Modification or interruption of our business processes and information systems may disrupt our business and internal controls.	Changes or failures in critical IT systems and business processes could impair operations and financial reporting.	\N
264	6	14	6	Our operating results have in the past fluctuated and may in the future fluctuate, and if our operating results are below the expectations of securities analysts or investors, our stock price could decline.	Volatile quarterly results may disappoint market expectations, leading to share price declines.	\N
265	6	2	6	We are subject to complex laws, rules, regulations, and political and other actions, including restrictions on the export of our products, which may adversely impact our business.	Export controls and evolving international regulations could limit NVIDIA's ability to sell products in key markets.	\N
266	6	11	6	Scrutiny regarding our corporate sustainability practices could result in financial, reputational, or operational harm and liability.	Increased stakeholder focus on ESG performance may lead to regulatory penalties, reputational damage, or operational constraints.	\N
267	6	5	6	Issues relating to the responsible use of our technologies, including AI, may result in reputational or financial harm and liability.	Misuse or ethical concerns around AI and other technologies could trigger backlash, regulation, or lawsuits.	\N
268	6	12	6	Adequately protecting our IP rights could be costly, and our ability to compete could be harmed if we are unsuccessful or if we are prohibited from making or selling our products.	Failure to secure or defend intellectual property could result in competitive disadvantage or injunctions against product sales.	\N
269	6	3	6	We are subject to stringent and changing data privacy and security laws, rules, regulations, and other obligations. These areas could damage our reputation, deter customers, affect product design, or result in legal or regulatory proceedings and liability.	Compliance with evolving global data privacy laws increases costs and legal risk, and may constrain product features.	\N
270	6	3	6	Our operating results may be adversely impacted by additional tax liabilities, higher than expected tax rates, changes in tax laws, and other tax-related factors.	Changes in tax regulations or adverse audit outcomes could increase effective tax rates and reduce net income.	\N
271	6	10	6	Our business is exposed to the burden and risks associated with litigation, investigations, and regulatory proceedings.	Ongoing and future legal disputes may result in significant expenses, damages, or operational restrictions.	\N
272	6	14	6	Delaware law, provisions in our governing documents and our agreement with Microsoft could delay or prevent a change in control.	Anti-takeover provisions and a commercial agreement with Microsoft may hinder or block acquisition attempts.	181
273	6	5	6	rapidly changing technology or customer requirements	The risk that rapid technological shifts or evolving customer needs could render NVIDIA's products less competitive or obsolete.	\N
274	6	9	6	the availability of sufficient data center capacity or energy for customers to procure	The risk that customers may lack adequate data center capacity or energy to deploy NVIDIA's AI infrastructure, potentially reducing demand.	\N
275	6	5	6	new product introductions and transitions resulting in less demand for existing products	The risk that new product launches and architecture transitions could cannibalize demand for current-generation products.	\N
276	6	5	6	new or unexpected end-use cases	The risk that novel or unforeseen applications for NVIDIA's products could create unpredictable demand patterns.	\N
277	6	4	6	increase in demand for competitive products	The risk that growing customer preference for competitors' offerings could erode NVIDIA's market share.	\N
278	6	9	6	changes in end-user demand	The risk that shifts in end-user demand could lead to revenue volatility and forecasting challenges.	\N
279	6	1	6	purchasing decisions made, and inventory levels held by, distributors, ODMs, OEMs, system integrators, other channel partners and other third parties	The risk that channel partners' inventory and purchasing decisions could cause demand fluctuations and supply chain imbalances.	\N
280	6	5	6	the ability of developers, end customers and other third parties to build, enhance, and maintain accelerated computing applications that leverage our platforms	The risk that the ecosystem's ability to develop applications on NVIDIA's platforms may affect adoption and demand.	\N
281	6	9	6	the demand for accelerated computing, AI-related cloud services, or large language models	The risk that demand for AI and accelerated computing services may not materialize as expected, impacting revenue.	\N
282	6	5	6	changes that impact the ecosystem for the architectures underlying our products and technologies	The risk that shifts in the architectural ecosystem could undermine the value proposition of NVIDIA's products.	\N
283	6	2	6	government actions or changes in governmental policies, such as export controls, increased restrictions on gaming usage, or tariffs	The risk that government policies like export controls or tariffs could restrict NVIDIA's market access or increase costs.	\N
284	6	9	6	our customers' and partners' ability to secure capital and energy and to build complex datacenter infrastructure timely	The risk that customers and partners may face financing or energy constraints delaying datacenter buildouts and reducing demand.	\N
285	6	5	6	the availability of third-party content on our platforms, such as GeForce NOW	The risk that insufficient third-party content on NVIDIA's platforms could diminish their attractiveness and usage.	\N
286	6	5	6	Undiscovered vulnerabilities in our products or services could result in loss of data or intangible property, or expose our customers to unscrupulous third parties who develop and deploy malicious software programs that could attack our products or services.	Undiscovered product vulnerabilities could lead to data loss, expose customers to malicious attacks, and result in significant warranty, recall, and reputational costs.	\N
287	6	13	6	Risks Related to Our Global Operating Business	Global operations expose the company to a broad range of economic, political, and regulatory risks across multiple jurisdictions.	\N
288	6	13	6	Business disruptions could harm our operations, lead to a decline in revenue and increase our costs.	NVIDIA faces operational risks from natural disasters, geopolitical conflicts, infrastructure failures, and other catastrophic events that could disrupt worldwide operations and reduce revenue.	\N
289	6	3	6	Our business and those of our suppliers and customers is subject to sustainability-related laws, regulations and lawsuits.	New sustainability regulations and potential litigation could increase compliance costs, require operational changes, and create financial burdens across NVIDIA's supply chain.	\N
290	6	8	6	Our investments in companies could create volatility and fluctuations in our results.	NVIDIA's investment portfolio, including illiquid early-stage companies, may generate significant unrealized gains or losses, creating earnings volatility and potential impairment charges.	\N
291	6	8	6	We are finalizing an investment and partnership agreement with OpenAI.	The pending investment and partnership with OpenAI may not be completed, creating uncertainty about strategic benefits and financial commitments.	182
292	6	8	6	Our investment portfolio contains industry sector concentration risks, and a decline in any one or multiple industry sectors could increase our impairment losses.	Concentrated investments in specific industry sectors expose NVIDIA to higher impairment risk if those sectors experience downturns.	\N
293	6	8	6	We face additional risks related to acquisitions and strategic investments, including the diversion of capital and other resources, including management's attention; difficulty in realizing a satisfactory return and uncertainties to realize the benefits of an acquisition or strategic investment, if at all; difficulty or inability in obtaining governmental, regulatory approval or restrictions or other consents and approvals or financing; legal proceedings initiated as a result of an acquisition or investment; and potential failure of our due diligence processes to identify significant issues with the assets or company in which we are investing or are acquiring.	Acquisitions and strategic investments carry multifaceted risks including resource diversion, regulatory hurdles, legal challenges, and due diligence failures that could negatively impact NVIDIA's financial performance.	\N
294	6	13	6	Additional risks relating to acquisitions include, but are not limited to:	Acquisitions pose integration challenges across technology, personnel, operations, and financial systems that could disrupt business and increase costs.	\N
295	6	9	6	We receive a significant amount of our revenue from a limited number of partners and distributors and we have a concentration of sales to customers who purchase directly or indirectly from us, and our revenue could be adversely affected if we lose or are prevented from selling to any of these customers.	Revenue concentration among a few large customers and partners creates significant risk if any reduce purchases or become inaccessible due to trade restrictions.	\N
296	6	8	6	Commercial arrangements expose us to counterparty risks.	Long-term purchase obligations and potential financing arrangements create exposure to counterparty financial distress, project delays, and credit risk.	\N
297	6	7	6	If we are unable to attract, retain and motivate our executives and key employees, our business may be harmed.	Competition for talent, immigration changes, and stock price volatility threaten the ability to retain key executives and employees critical to strategy execution.	\N
298	6	6	6	Our business is dependent upon the proper functioning of our business processes and information systems and modification or interruption of such systems may disrupt our business and internal controls.	ERP implementation and reliance on information systems for critical functions create risk of operational disruption, reporting errors, and control failures.	\N
299	6	14	6	Identification of material weaknesses in our internal controls, even if quickly remediated once disclosed, may cause investors to lose confidence in our financial statements and our stock price may decline.	Material weaknesses in internal controls could undermine investor confidence, trigger restatements, restrict capital access, and depress the stock price.	\N
300	6	5	6	Concerns relating to the responsible use of new and evolving technologies, such as AI, in our products and services may result in reputational or financial harm and liability and may cause us to incur costs to resolve such issues.	NVIDIA faces reputational, legal, and financial risks from the responsible development and deployment of AI technologies across its products and services.	\N
301	6	12	6	Actions to adequately protect our IP rights could result in substantial costs to us and our ability to compete could be harmed if we are unsuccessful or if we are prohibited from making or selling our products.	Protecting intellectual property rights may incur significant costs and unsuccessful efforts could impair NVIDIA's competitive position and product sales.	\N
302	6	10	6	From time to time, we are involved in lawsuits or other legal proceedings alleging patent infringement or other IP rights violations by us, our employees or parties that we have agreed to indemnify.	NVIDIA faces ongoing patent infringement and IP litigation that could result in damages, injunctions, and diversion of management resources.	\N
303	6	10	6	We may commence legal proceedings to protect our IP rights, which may increase our operating expenses.	Initiating IP enforcement actions may raise operating costs and expose NVIDIA to countersuits and licensing obligations.	\N
304	6	12	6	We rely on patents, trademarks, trade secrets, employee and third-party nondisclosure agreements, licensing arrangements and the laws of the countries in which we operate to protect our IP.	NVIDIA's IP protection depends on a mix of legal tools and international laws, which may be insufficient to prevent theft or unauthorized use.	\N
305	6	2	6	In the ordinary course of business, we transfer personal data from Europe, China, and other jurisdictions to the United States or other countries.	Cross-border data transfers face regulatory hurdles and localization requirements that could disrupt operations and increase costs.	\N
306	6	10	6	We are also bound by certain contractual obligations related to data privacy and security, and our efforts to comply with such obligations may not be successful or may be claimed to be non-compliant.	Contractual data privacy obligations with customers and partners create compliance risks that could lead to litigation, fines, and damaged relationships.	\N
307	6	6	6	Data protection laws around the world are quickly changing and may be interpreted and applied in an increasingly stringent fashion and in a manner that is inconsistent with our data practices.	NVIDIA faces risks from evolving global data protection laws that could require changes to its products and practices, with non-compliance potentially leading to enforcement actions, litigation, and reputational harm.	\N
308	6	8	6	We may have exposure to additional tax liabilities and our operating results may be adversely impacted by changes in tax laws, higher than expected tax rates and other tax-related factors.	NVIDIA is exposed to additional tax liabilities from changing tax laws, higher tax rates, and international tax reforms like the OECD's Two-Pillar framework, which could increase its effective tax rate and harm financial results.	\N
309	6	14	6	Delaware law and our certificate of incorporation, bylaws and agreement with Microsoft could delay or prevent a change in control.	Anti-takeover provisions under Delaware law, NVIDIA's charter documents, and its agreement with Microsoft could delay or prevent a change in control, limiting shareholder ability to influence corporate actions.	181
310	7	2	7	Our substantial international operations subject us to risks of doing business in foreign countries, which could adversely affect our business, financial condition and results of operations.	Albemarle's global operations face risks from civil, political, and security instability in regions like Asia, the Middle East, and South America that could disrupt operations and impact growth.	\N
311	7	2	7	Because we conduct substantial operations in China, risks associated with regulatory activity and political and social events in China could negatively affect our business and operating results.	Albemarle's significant operations and sales in China expose it to regulatory, political, and trade risks including tariffs, energy restrictions, and geopolitical tensions.	\N
312	7	1	7	Our inability to secure key raw materials, or to pass through increases in costs and expenses for other raw materials and energy, on a timely basis or at all could have an adverse effect on the margins of our products and our results of operations.	Albemarle's profitability depends on securing raw materials like chlorine and soda ash and passing through cost increases, but supply constraints and price volatility could hurt margins.	\N
313	7	4	7	Competition within our industry may place downward pressure on the prices and margins of our products and may adversely affect our businesses and results of operations.	Intense competition from larger global chemical producers could force price reductions and margin compression, threatening Albemarle's market share and profitability.	\N
314	7	5	7	Our research and development efforts may not succeed in addressing changes in our customers' needs, and our competitors may develop more effective or successful products.	Albemarle's future growth depends on successful R&D and innovation, but there's no guarantee new products will meet customer needs, gain regulatory approval, or outperform competitors' offerings.	\N
315	7	5	7	The development of non-lithium battery technologies could adversely affect us.	Emerging battery technologies that reduce or eliminate lithium usage could significantly undermine Albemarle's lithium business and future revenue prospects.	\N
316	7	13	7	Development projects are inherently risky and may require more capital than anticipated or not prove to be economically viable based on ultimate costs and returns of a project, which could adversely affect our business. The development of our mines and operations are also subject to other unique risks.	Mine and facility development projects face geological, construction, cost overrun, and safety risks that could delay projects, increase capital costs, and negatively impact financial performance.	\N
317	7	13	7	New development projects have no operating history upon which to base estimates of future cash flow.	New development projects lack operating history, making cash flow estimates unreliable and potentially leading to material adverse impacts on financial results.	\N
318	7	3	7	We are subject to risks related to brine extraction limits, particularly with respect to our early warning plan at our facilities in Chile.	Brine extraction limits and early warning plans in Chile could force production reductions or halts, significantly decreasing lithium output.	\N
319	7	9	7	Downturns in our customers' industries, which may be cyclical or affected by changes in governing administrations, could adversely affect our sales and profitability.	Cyclical downturns in customer industries like electronics, construction, oilfield, and automotive, potentially exacerbated by political changes, could reduce demand for Albemarle's products.	\N
320	7	9	7	The results of the Refining Solutions business are subject to fluctuation because of irregularities in the demand for our HPC catalysts and certain of our agrichemicals.	Refining Solutions business results fluctuate due to irregular demand for HPC catalysts tied to replacement cycles and agrichemicals affected by climate and crop pricing.	\N
321	7	3	7	Regulation, or the threat of regulation, of some of our products could have an adverse effect on our sales and profitability.	Regulatory scrutiny of brominated fire safety solutions and other products could lead to restrictions, bans, or market reactions that reduce sales.	\N
322	7	10	7	We could be subject to damages based on claims brought against us by our customers or lose customers as a result of the failure of our products to meet certain quality specifications.	Product quality failures could lead to customer claims, damages, recall participation costs, and loss of customers.	\N
323	7	13	7	Our business is subject to hazards common to chemical and natural resource extraction businesses, any of which could injure our employees or other persons, damage our facilities or other properties, interrupt our production and adversely affect our reputation and results of operations.	Chemical manufacturing and resource extraction hazards like explosions, fires, spills, and natural disasters could cause injuries, property damage, production interruptions, and reputational harm.	\N
324	7	11	7	Our business could be adversely affected by environmental, health and safety laws and regulations.	Environmental, health, and safety regulations could impose significant compliance costs and operational restrictions on Albemarle's business.	\N
325	7	1	7	Our inability to develop lithium or bromine reserves that are economically viable could have a material adverse effect on our future profitability.	Failure to develop economically viable lithium or bromine reserves would materially harm future profitability.	\N
326	7	9	7	Demand and market prices for lithium will greatly affect the value of our investment in our lithium resources and conversion facilities, and our revenues and profitability generally.	Lithium demand and price volatility significantly impact the value of lithium investments and overall financial performance.	\N
327	7	7	7	If we are unable to retain key personnel or attract new skilled personnel, it could have an adverse effect on our business.	Inability to retain or attract key skilled personnel could adversely affect business operations and strategy execution.	\N
328	7	7	7	Some of our employees are unionized, represented by works councils or are employed subject to local laws that are less favorable to employers than the laws of the U.S.	Unionized workforce and favorable foreign labor laws could lead to operational disruptions or higher labor costs.	\N
329	7	13	7	Our joint ventures may not operate according to their business plans if our partners fail to fulfill their obligations, which may adversely affect our results of operations and may force us to dedicate additional resources to these joint ventures.	Joint venture partners' failure to meet obligations could disrupt operations and require additional resource commitments.	\N
330	7	8	7	Our required capital expenditures can be complex, may experience delays or other difficulties, and the costs may exceed our estimates.	Capital projects face complexity, delays, and cost overruns that could exceed budgeted estimates.	\N
331	7	8	7	Our indebtedness could adversely affect our financial health and our ability to execute our business strategy, and we will need a significant amount of cash to service our indebtedness.	High debt levels could impair financial health, limit strategic execution, and require substantial cash for debt service.	\N
332	7	8	7	Write-offs or impairment of our goodwill, intangible assets or long-lived assets can result in significant charges to earnings.	The company faces risk of significant non-cash charges if goodwill, intangible assets, or long-lived assets become impaired due to declining stock price, reduced cash flow estimates, or slower industry growth.	\N
333	7	13	7	Our business could suffer if we are not successful in executing our strategy and initiatives in connection with our comprehensive review of our cost and operating structure.	Cost optimization efforts including plant idling and workforce reductions may not achieve expected savings within anticipated timeframes, potentially harming financial performance.	\N
334	7	8	7	We are exposed to fluctuations in currency exchange rates, which may adversely affect our operating results and net income.	Foreign currency fluctuations, particularly in Chinese Renminbi, Euro, and Australian Dollar, can negatively impact reported assets, liabilities, sales, costs, and debt service ability.	\N
335	7	8	7	Significant or prolonged periods of higher interest rates may have an adverse effect on our results of operations, financial condition and cash flows.	Rising interest rates increase borrowing costs on variable-rate debt facilities and commercial paper, potentially materially affecting financial results and cash flows.	\N
336	7	1	7	Inflationary trends in the price of our input costs, such as raw materials, transportation and energy, could adversely affect our business and financial results.	Volatility and increases in raw material, transportation, and energy costs due to global supply chain disruptions and inflation could compress margins and hurt financial performance.	\N
337	7	9	7	If we are unable to increase the prices to our customers of our products to offset inflationary cost trends, or if we are unable to achieve cost savings to offset such cost increases, we could fail to meet our cost expectations, and our profits and operating results could be adversely affected.	Inflationary cost increases may not be fully passed to customers, potentially compressing margins and reducing profitability.	\N
338	7	3	7	Changes in, or the interpretation of, tax legislation or rates throughout the world could materially impact our results.	Global tax law changes or reinterpretations could significantly affect the company's financial results.	\N
339	7	3	7	Our effective tax rate and related tax balance sheet attributes could be impacted by changes in tax legislation throughout the world.	Worldwide tax legislation changes may alter the effective tax rate and related balance sheet items.	\N
340	7	3	7	We have not accrued income taxes or foreign withholding taxes on undistributed earnings for most non-U.S. subsidiaries, because those earnings are intended to be indefinitely reinvested in the operations of those subsidiaries.	Undistributed foreign earnings are not taxed due to indefinite reinvestment intent, but tax proposals could change this.	\N
341	7	3	7	Our future effective tax rates could be affected by changes in the mix of earnings in countries with differing statutory tax rates, rules governing transfer pricing for transactions between our affiliates, expirations of tax holidays or rulings, changes in the assessment regarding the realization of the valuation of deferred tax assets, or changes in tax laws and regulations or their interpretation.	Multiple factors including earnings mix, transfer pricing, tax holidays, and deferred tax valuations could alter future effective tax rates.	\N
342	7	3	7	We are subject to the regular examination of our income tax returns by various tax authorities.	Ongoing tax audits and challenges to transfer pricing or income allocation could result in material adverse outcomes.	\N
343	7	8	7	Future events may impact our deferred tax asset position and U.S. deferred federal income taxes on undistributed earnings of international affiliates that are considered to be indefinitely reinvested.	Changes in circumstances could affect deferred tax asset valuations and trigger U.S. tax on foreign earnings.	\N
344	7	10	7	Our business and financial results may be adversely affected by various legal and regulatory proceedings.	Legal and regulatory proceedings could lead to adverse judgments, fines, and diversion of management resources.	\N
345	7	8	7	Although our pension plans currently meet minimum funding requirements, events could occur that would require us to make significant contributions to the plans and reduce the cash available for our business.	Pension funding obligations may increase significantly due to market conditions or actuarial changes, reducing available cash.	\N
346	7	13	7	We may discontinue or divest all or part of a particular business or plant as we periodically assess our business structure.	Divestitures and plant closures carry risks including disruption, loss of key employees, and failure to achieve expected benefits.	\N
347	7	13	7	We may not be able to consummate future acquisitions or integrate acquisitions into our business, which could result in unanticipated expenses and losses.	Acquisition integration risks include management distraction, unforeseen liabilities, cultural challenges, and failure to realize anticipated benefits.	\N
348	7	9	7	Adverse conditions in the economy, and volatility and disruption of financial markets can negatively impact our customers, suppliers and other business partners and therefore have a material adverse effect on our business and results of operations.	Economic downturns and financial market volatility can reduce customer demand, disrupt supply chains, and impair the company's ability to raise capital.	\N
349	7	6	7	Our business and operations could suffer in the event of cybersecurity breaches, information technology system failures, or network disruptions.	Cybersecurity attacks, IT system failures, or network disruptions could harm operations, compromise data, and increase costs.	\N
350	7	5	7	Integration of AI technologies into our operations may introduce new risks, require significant additional investment, and materially impact our competitive position if unsuccessful.	AI integration carries risks of model inaccuracy, governance issues, regulatory compliance burdens, and potential competitive disadvantage if deployments fail.	\N
351	7	2	7	The occurrence or threat of extraordinary events, including domestic and international terrorist attacks, may disrupt our operations and increase costs.	Terrorist attacks on chemical facilities could disrupt operations, increase security costs, and exceed insurance coverage.	\N
352	7	2	7	National or international disputes, political instability, terrorism war or armed hostilities, could impact our results of operations.	Geopolitical instability, wars, and political disputes can disrupt operations, supply chains, and increase costs across multiple risk areas.	\N
353	7	2	7	The U.S. government and other nations have imposed significant restrictions on most companies' ability to do business in Russia as a result of the military conflict between Russia and Ukraine.	Sanctions and restrictions from the Russia-Ukraine conflict could escalate and materially affect operations in countries where Albemarle does business.	\N
354	7	11	7	Natural disasters or other unanticipated catastrophes could impact our operations and could have a material adverse effect on our results of operations, financial position, and cash flows.	Natural disasters and catastrophes could disrupt operations and materially harm financial results.	\N
355	7	11	7	The occurrence of natural disasters, such as hurricanes, floods, droughts, heat and extreme temperatures, thunderstorms or earthquakes; pandemics; or other unanticipated catastrophes at any of the locations in which we or our key partners, suppliers, or customers do business could cause interruptions in our operations.	Natural disasters and pandemics could disrupt Albemarle's operations and those of its key partners, suppliers, and customers, negatively affecting production volumes and costs.	\N
356	7	8	7	Our insurance may not fully cover all potential exposures.	Albemarle's insurance and self-insurance programs may not cover all business hazards, leaving the company exposed to losses beyond policy limits or outside coverage scope.	\N
357	7	8	7	We are potentially at risk if one or more of our insurance carriers fail.	Failure or downgrade of insurance carriers could reduce the availability and increase the cost of coverage for Albemarle.	\N
358	7	11	7	We may be exposed to certain physical, transitional, regulatory and financial risks related to climate change.	Climate change poses physical risks to Albemarle's operations in water-stressed regions like Chile and Jordan, as well as transition risks from carbon pricing and evolving regulations.	189
359	7	11	7	Failure to meet sustainability expectations or standards or achieve our sustainability goals could adversely affect our business, results of operations, financial condition, or stock price.	Missing sustainability targets or facing greenwashing allegations could harm Albemarle's reputation, reduce revenue, and trigger legal or regulatory actions.	\N
360	7	3	7	We may be unable to satisfactorily meet evolving standards, regulations and disclosure requirements related to sustainability.	Inability to comply with new sustainability regulations and disclosure rules could affect investor willingness, regulatory compliance, and overall business performance.	\N
361	8	9	8	Our business relies on continued global demand for our brands and products.	The company's success depends on maintaining global demand through innovation, quality, dealer relationships, and effective marketing.	\N
362	8	4	8	We operate in a highly competitive environment, which could adversely affect our sales and pricing.	Intense competition on product performance, service, quality, and price could reduce market share and pressure pricing.	\N
363	8	9	8	Lack of customer acceptance of price increases we announce from time to time, changes in customer requirements for price discounts, changes in our customers' behavior or a weak pricing environment could have an adverse impact on our business, results of operations and financial condition.	Customer resistance to price increases or demands for discounts in a weak pricing environment could hurt financial results.	\N
364	8	9	8	In addition, our results and ability to compete may be impacted negatively by changes in our geographic and product mix of sales.	Shifts in the geographic and product composition of sales could negatively affect results and competitiveness.	\N
365	8	6	8	Increased information technology security threats and more sophisticated computer crime pose a risk to our systems, networks, products and services.	Growing cybersecurity threats and sophisticated attacks risk the security of systems, networks, data, and product integrity.	\N
366	8	1	8	Our business is subject to the inventory management decisions and sourcing practices of our dealers and our OEM customers.	Dealer and OEM inventory decisions and sourcing practices can cause sales fluctuations and impact results.	\N
367	8	13	8	We may not realize all of the anticipated benefits of our acquisitions, joint ventures or divestitures, or these benefits may take longer to realize than expected.	Acquisitions, joint ventures, and divestitures may fail to deliver expected benefits or face integration challenges and unexpected costs.	\N
368	8	7	8	Union disputes or other labor matters could adversely affect our operations and financial results.	Labor union disputes, strikes, or work stoppages at company, customer, or supplier facilities could disrupt operations.	\N
369	8	13	8	Unexpected events may increase our cost of doing business or disrupt our operations.	Wars, terrorism, natural disasters, pandemics, or other unexpected events could damage facilities, disrupt supply chains, and increase costs.	\N
370	8	8	8	Disruptions or volatility in global financial markets could limit our sources of liquidity, or the liquidity of our customers, dealers and suppliers.	Financial market volatility could restrict liquidity for the company and its customers, dealers, and suppliers.	\N
371	8	8	8	Continuing to meet our cash requirements over the long-term requires substantial liquidity and access to varied sources of funds, including capital and credit markets.	Caterpillar's long-term cash needs depend on continued access to capital and credit markets, which could be disrupted by global economic conditions.	\N
372	8	8	8	Failure to maintain our credit ratings could increase our cost of borrowing and could adversely affect our cost of funds, liquidity, competitive position and access to capital markets.	A downgrade of Caterpillar's or Cat Financial's credit ratings would raise borrowing costs and limit access to capital markets.	\N
373	8	8	8	Our Financial Products segment is subject to risks associated with the financial services industry.	Caterpillar's Financial Products segment faces industry-specific risks that could impact its ability to support global sales.	\N
374	8	8	8	Continuing to meet Cat Financial's cash requirements over the long-term could require substantial liquidity and access to sources of funds, including capital and credit markets.	Cat Financial's long-term funding needs rely on continued access to global capital markets, which may become unreliable during economic downturns.	\N
375	8	8	8	Market disruption and volatility may also lead to numerous risks in connection with these events, including but not limited to:	Financial market disruptions create multiple risks for Cat Financial, including higher credit losses, funding difficulties, and counterparty failures.	\N
376	8	8	8	Changes in interest rates or market liquidity conditions could adversely affect Cat Financial's and our earnings and/or cash flow.	Fluctuations in interest rates and market liquidity could negatively impact earnings and cash flows for both Caterpillar and Cat Financial.	\N
377	8	8	8	An increase in delinquencies, repossessions or net losses of Cat Financial customers could adversely affect its results.	Rising customer delinquencies and defaults would increase Cat Financial's credit losses and hurt its financial performance.	\N
384	8	10	8	Costs associated with lawsuits or investigations or adverse rulings in enforcement or other legal proceedings may have an adverse effect on our results of operations.	Caterpillar faces diverse legal proceedings worldwide that could result in costly judgments, fines, or settlements.	\N
385	8	3	8	New regulations or changes in financial services regulation could adversely impact Caterpillar and Cat Financial.	Increased regulation of financial services, including under Dodd-Frank, could raise costs and constrain Cat Financial's operations.	\N
386	8	11	8	We are subject to stringent environmental laws and regulations that impose significant compliance costs.	Caterpillar must comply with strict global environmental laws that carry significant costs and potential liabilities for non-compliance.	\N
387	8	10	8	The Company's amended and restated bylaws provide that the Court of Chancery of the State of Delaware will be the exclusive forum for certain legal actions between the Company and its shareholders, which could discourage claims or limit the ability of the Company's shareholders to bring a claim in a judicial forum viewed by the shareholders as more favorable for disputes with the Company or the Company's directors, officers or other employees.	Caterpillar's bylaws designate Delaware Chancery Court as the exclusive forum for certain shareholder lawsuits, potentially limiting shareholders' litigation options.	\N
388	9	9	9	Any global systemic political, economic and financial crisis (as well as the indirect effects flowing therefrom) could negatively affect our business, results of operations, and financial condition.	Global systemic crises could negatively impact TSMC's business, operations, and financial condition.	\N
389	9	2	9	Our global manufacturing, design and sales activities subject us to risks associated with political, economic, financial, military or other conditions or developments in various jurisdictions, including in particular the R.O.C., as well as in international trade, which could negatively affect our business and financial status and therefore the market value of your investment.	TSMC's global operations expose it to political, economic, and military risks in various jurisdictions, particularly Taiwan, which could harm its business and investment value.	\N
390	9	3	9	Any law or government policy that encourages our customers to relocate their manufacturing capacity or supply chain to their own countries or require their respective contractors, subcontractors and relevant agents to do so could also impair our ability to sustain our current level of productivity and manufacturing efficiency.	Government policies encouraging customer supply chain relocation could impair TSMC's productivity and manufacturing efficiency.	\N
391	9	14	9	In addition, the financial markets have viewed certain past developments in relations between the R.O.C. and the P.R.C. as occasions to depress general market prices of the securities of R.O.C. companies, including our own.	Cross-strait tensions between Taiwan and China have historically depressed market prices of Taiwanese companies' securities, including TSMC's.	\N
392	9	2	9	may face potential operational risks arising from applicable export controls which impose license requirements on our P.R.C. fab's acquisition of certain manufacturing tools.	Export control restrictions on manufacturing tool acquisitions for TSMC's China fab could disrupt operations.	\N
393	9	13	9	If we are unable to successfully manage the complexity of our global operations and deal with the challenges and risks related to our global expansion, our business, financial condition and results of operations could be adversely affected.	Managing global expansion across multiple new fabs presents complex challenges including cost overruns, supply chain issues, talent shortages, and regulatory compliance that could harm financial performance.	\N
394	9	9	9	Decreases in demand and average selling prices for products that contain semiconductors may adversely affect demand for our products and may result in a decrease in our revenue and earnings.	Declining demand and average selling prices for semiconductor-containing products could reduce TSMC's revenue and earnings due to high fixed costs.	\N
395	9	9	9	The electronics industries and semiconductor market are cyclical and subject to significant and often rapid fluctuations in product demand, which could impact our semiconductor foundry business.	The cyclical nature of the semiconductor industry leads to demand fluctuations that can cause significant revenue and margin volatility for TSMC.	\N
396	9	5	9	If we are unable to remain a technological leader in the semiconductor industry, unable to timely respond to fast-changing semiconductor market dynamics, or unable to maintain our edge in product quality, we may become less competitive.	Failure to maintain technological leadership and adapt to rapid market changes, especially in AI, could erode TSMC's competitive position and revenue.	\N
397	9	4	9	If we are unable to compete effectively in the highly competitive foundry segment of the semiconductor industry, including through equal access to governmental financial incentives, especially those available to our competitors, we may lose customers and/or our profit margin and earnings may decrease.	Intense competition in the foundry segment, exacerbated by government incentives available to rivals, could cause TSMC to lose customers and see lower margins.	\N
398	9	13	9	If we are unable to manage our capacity and production facilities effectively, our competitiveness may be weakened.	Ineffective capacity management and forecasting could lead to underutilization or inability to ramp up quickly, hurting financial performance and competitiveness.	\N
399	9	9	9	Having one or more large customers that account for a significant percentage of our revenue may render us vulnerable to the loss of or significant curtailment of purchases by such customers that could in turn adversely affect our results of operations.	TSMC faces significant revenue concentration risk as its top ten customers accounted for 78% of net revenue in 2025, making it vulnerable to customer loss or purchase reductions.	\N
400	9	6	9	If our information technology systems or those of our service providers with whom we share our confidential information succumb to cyberattacks by third parties worldwide, our business and operations may be severely interrupted or even shut down, and our results of operations, financial condition, prospects and reputation may also be materially and adversely affected.	Cyberattacks on TSMC's IT systems or those of its service providers could severely disrupt operations, compromise sensitive data, and damage financial performance and reputation.	\N
401	9	7	9	We may not be able to implement our planned growth and development or maintain our leading position if we are unable to recruit and retain key executives, managers, and skilled technical and service personnel.	TSMC's growth and competitive position depend on attracting and retaining key talent, but faces challenges from talent shortages, poaching, and immigration controls.	\N
402	9	1	9	We may be unable to obtain in a timely manner and at a reasonable cost equipment that is necessary for us to remain competitive.	TSMC's expansion plans depend on timely procurement of specialized equipment from limited suppliers, with trade tensions potentially causing delays or cost increases.	\N
403	9	1	9	Our revenue and profitability may decline if we are unable to obtain adequate supplies of raw materials in a timely manner and at commercially reasonable prices.	TSMC relies on timely, cost-effective supply of critical raw materials like silicon wafers and chemicals, but faces risks from sole-source suppliers, natural disasters, and trade barriers.	\N
404	9	12	9	Any inability to obtain, preserve, enforce, defend and protect our technologies, intellectual property rights and third-party licenses could harm our competitive position.	TSMC's competitive strength depends on its IP portfolio, but faces risks from infringement claims, licensing challenges, and potential misappropriation as it expands globally.	\N
405	9	12	9	If we fail to obtain or maintain certain technologies or intellectual property licenses or fail to prevent our intellectual property from being misappropriated and, if litigation relating to alleged intellectual property matters occurs, it could:	Failure to secure IP licenses or protect IP from misappropriation could lead to litigation that restricts manufacturing, reduces competitiveness, and hurts revenue.	\N
406	9	13	9	Our operational results could also be materially and adversely affected by disruptive events or industrial accidents, in the locations in which we, our customers or our suppliers operate.	Natural disasters, pandemics, cyberattacks, geopolitical tensions, and other disruptive events at TSMC, customer, or supplier sites could halt production and reduce demand.	\N
407	9	13	9	Our operations may be interrupted, and our expansion may be limited, by power or other utility outages or shortages, and our financial results may be adversely affected by increased prices of power or other utilities.	Power outages, utility shortages, and rising energy costs could disrupt manufacturing, delay expansion, and increase operating expenses.	\N
408	9	8	9	Adverse fluctuations in exchange rates could decrease our operating margin and/or revenue.	A weaker U.S. dollar against the NT dollar reduces revenue and operating margin, while a stronger dollar may dampen customer demand.	\N
409	9	3	9	Our failure to comply with applicable laws and regulations material to our operations, such as export control, antitrust, environmental and climate related laws and regulations, or the inability to timely obtain requisite approvals necessary for the conduct of our business, such as fab land and construction approvals, could harm our business and operational results or subject us to potential significant legal liability.	Non-compliance with export controls, antitrust, environmental, and other regulations, or delays in obtaining permits, could result in penalties, production suspensions, and reputational damage.	\N
410	9	8	9	Any impairment charges may have a material adverse effect on our net income.	Future impairment charges on tangible, right-of-use, or intangible assets could significantly reduce net income, especially during downturns.	\N
411	9	7	9	Any failure to achieve and maintain effective internal controls could have a material adverse effect on our business and results of operations.	Ineffective internal controls over financial reporting could lead to misstatements, fraud, regulatory non-compliance, and harm to share price.	\N
412	9	14	9	Your voting rights as a holder of ADSs will be limited.	ADS holders have limited voting rights and can only vote collectively through the depositary bank per the deposit agreement.	\N
413	9	14	9	You may not be able to participate in rights offerings and may experience dilution of your holdings.	ADS holders may be excluded from rights offerings if registration exemptions cannot be secured, leading to potential dilution.	\N
414	9	14	9	The value of your investment may be reduced by possible future sales of common shares or ADSs by us or our shareholders or fluctuations in foreign exchange.	Large share sales by major shareholders like the National Development Fund or currency fluctuations could depress ADS value.	196
415	9	14	9	The market value of our shares may fluctuate due to the volatility of, and government intervention in, the R.O.C. securities market.	Taiwan stock market volatility and government stabilization fund activities may cause share price fluctuations.	\N
416	10	9	10	The semiconductor industry is cyclical and downturns in the semiconductor industry can negatively affect our results of operations and financial condition.	The cyclical nature of the semiconductor industry leads to periodic downturns that can significantly harm STMicroelectronics' financial performance.	\N
417	10	1	10	The recent increase in inflation rates in the markets in which we operate may lead us to experience higher costs related to labor, energy, water, transportation, wafer and other raw materials costs from suppliers.	Rising inflation across operating markets increases input costs for labor, energy, and raw materials, potentially squeezing margins if price increases cannot be passed to customers.	\N
418	10	9	10	Epidemics or pandemics may impact the global economy and could also adversely affect our business, financial condition and results of operations.	Epidemics or pandemics can disrupt global supply chains, reduce consumer demand, and create economic uncertainty that negatively impacts STMicroelectronics' operations and financial performance.	\N
419	10	13	10	We may not be able to match our production capacity to demand.	STMicroelectronics faces difficulty aligning manufacturing capacity with volatile semiconductor demand, risking unused capacity charges, inventory write-offs, or inability to meet customer needs.	\N
420	10	4	10	Competition in the semiconductor industry is intense, and we may not be able to compete successfully if our product design technologies, process technologies and products do not meet market requirements. Furthermore, the competitive environment of the industry has resulted, and is expected to continue to result, in vertical and horizontal consolidation among our suppliers, competitors and customers, which may lead to erosion of our market share, impact our ability to compete and require us to restructure our operations.	Intense competition and industry consolidation threaten STMicroelectronics' market share and may force restructuring if its technologies and products fail to meet evolving market demands.	\N
421	10	13	10	Our high fixed costs could adversely impact our results.	High fixed costs from manufacturing facilities and skilled workforce make it difficult to reduce expenses during demand downturns, leading to lower gross margins and unused capacity charges.	\N
461	10	14	10	Our shareholder structure and our preference shares may deter a change of control.	Anti-takeover provisions including preference shares and an independent foundation option agreement could impede change of control and depress share price.	\N
422	10	8	10	Our capital needs are high compared to those competitors who do not manufacture their own products and we may need additional funding in the coming years to finance our investments, to purchase other companies or technologies developed by third parties or to refinance our maturing indebtedness.	STMicroelectronics' capital-intensive manufacturing model requires significant funding for facility upgrades, acquisitions, and debt refinancing, which may necessitate additional financing under uncertain market conditions.	\N
423	10	8	10	If we are unable to access capital on acceptable terms, this may adversely affect our business and results of operations.	The company may face adverse business impacts if it cannot secure financing on favorable terms.	\N
424	10	1	10	Our operating results depend on our ability to obtain quality supplies on commercially reasonable terms.	The company's performance relies on securing quality supplies from a limited supplier base at reasonable prices.	\N
425	10	1	10	Our ability to meet our customers' demand to manufacture our products depends upon obtaining adequate supplies of quality materials on a timely basis and on commercially reasonable terms.	Meeting customer demand requires timely access to quality materials from limited sources at reasonable costs.	\N
426	10	1	10	We also purchase semiconductor manufacturing equipment and third-party licensed technology from a limited number of suppliers and providers and, because such equipment and technology are complex, it is difficult to replace any one supplier or provider with another or to substitute one piece of equipment or type of technology for another.	Dependence on few suppliers for complex equipment and licensed technology creates substitution risks.	\N
427	10	1	10	Consolidation among our suppliers or vertical integration among our competitors may limit our ability to obtain sufficient quantities of materials, equipment and/or technology on commercially reasonable terms and restrict the terms under which we engage in mergers and acquisitions.	Supplier consolidation and competitor vertical integration could restrict access to materials and M&A flexibility.	\N
428	10	8	10	Our financial results can be affected by fluctuations in exchange rates, principally in the value of the U.S. dollar.	Exchange rate fluctuations, especially USD/EUR, can materially impact financial results despite hedging.	\N
429	10	9	10	Our operating results may vary significantly from quarter to quarter and annually and may also differ significantly from our expectations or guidance.	Operating results are highly variable due to demand shifts, competition, manufacturing issues, and other factors.	\N
430	10	13	10	If our external silicon foundries or back-end subcontractors fail to perform, this could adversely affect our business prospects, financial condition and results of operations.	Reliance on external foundries and subcontractors creates risk if they cannot meet demand or if costs surge.	\N
431	10	13	10	Our manufacturing processes are highly complex, costly and potentially vulnerable to impurities, disruptions or inefficient implementation of production changes or interruptions that can significantly increase our costs and delay product shipments to our customers.	Complex manufacturing processes are vulnerable to yield issues, disruptions, and change implementation problems.	\N
432	10	5	10	We may experience quality problems from time to time that can result in decreased sales and operating margin and product liability or warranty claims.	Product quality issues could lead to liability claims, warranty costs, and reduced sales and margins.	\N
433	10	4	10	Disruptions in our relationships with any one of our key customers or distributors, and/or material changes in their strategy or financial condition or business prospects, could adversely affect our results of operations.	Concentration of sales among few key customers creates risk if relationships deteriorate or their conditions change.	\N
434	10	5	10	We may experience delays in delivering our product and technology roadmaps as well as transformation initiatives.	Delays in product roadmaps and transformation initiatives could hinder strategic execution.	\N
435	10	5	10	Our industry adapts to technological advancements and it is likely that new products, equipment, processes and service methods, including transformation initiatives related to digitalization, are in the process of being implemented.	Failure to manage digitalization and technology roadmaps could delay new solutions and cause loss of competitiveness.	\N
436	10	6	10	Our computer systems, including hardware, software, information and cloud-based initiatives, are subject to attempted security breaches and other cybersecurity threats, which, if successful, could adversely impact our business.	Cybersecurity threats to computer systems and cloud initiatives could adversely impact business operations.	\N
437	10	5	10	We may not be able to integrate or optimize the use of new technologies in a timely manner, which may place us at a competitive disadvantage against other industry players.	Inability to timely integrate new technologies could create competitive disadvantage.	\N
438	10	4	10	The semiconductor industry is highly competitive and characterized by constant and rapid technological change, short product lifecycles, significant price erosion and evolving standards.	Intense competition and rapid technological change in semiconductor industry threaten financial performance.	\N
439	10	5	10	We have invested significant resources to the integration of AI capabilities to our operations. Should we be unable to successfully leverage the opportunities presented by AI and any other such new technological advances or should our governance processes prove to be insufficient to support the AI opportunities available to us, benefits of the implementation of any new such technologies may not materialize.	Failure to leverage AI opportunities or insufficient governance could prevent realization of AI benefits.	\N
440	10	6	10	We may be subject to theft, loss, or misuse of personal data about our employees, customers, or other third parties, which could increase our expenses, damage our reputation, or result in legal or regulatory proceedings.	Theft or misuse of personal data could lead to increased costs, reputational damage, and legal proceedings.	\N
441	10	9	10	Our business is dependent in large part on continued growth in the industries and segments into which our products are sold and on our ability to retain existing customers and attract new ones.	Business depends on industry growth and customer retention/acquisition, with market declines posing material risk.	\N
442	10	9	10	The demand for our products depends significantly on the demand for our customers' end products.	STMicroelectronics' revenue is heavily influenced by end-market demand for its customers' products, which fluctuates due to consumer spending, preferences, technology adoption, and economic conditions.	212
443	10	9	10	Our business is dependent upon our ability to retain existing customers.	The company relies on retaining key customers, with Apple accounting for 17.7% of 2025 revenue, and loss of major customers or design wins could materially harm results.	212
444	10	5	10	Our existing customers' product strategy may change from time to time and/or product specifications may change on short-time product life cycles and we have no certainty that our business, financial position and results of operations will not be affected.	Rapid changes in customer product strategies and short product life cycles create uncertainty and could adversely affect STMicroelectronics' business and financial performance.	\N
445	10	4	10	Market dynamics have driven, and continue to drive us, to a strategic repositioning.	Ongoing market dynamics compel STMicroelectronics to continuously reposition its business through acquisitions, divestitures, and partnerships, which carries execution and integration risks.	\N
446	10	4	10	Acquisitions, divestitures, partnerships and joint ventures involve a number of risks that could adversely affect our operating results and financial condition, including, in respect of acquisitions and divestitures, the inability for us to successfully integrate businesses or teams that we acquire with our culture and strategies on a timely basis or at all, and the potential requirement for us to record charges related to the goodwill or other long-term assets associated with the acquired businesses.	M&A and partnership activities pose integration, goodwill impairment, financing, and operational coordination risks that could negatively impact financial results and credit standing.	\N
447	10	4	10	We do not, and in the future may not, have a majority shareholding in all our joint ventures, and may have limited opportunity to intervene in the decision-making process of our joint ventures.	Limited control in joint ventures exposes STMicroelectronics to partner-related risks including disputes, litigation, regulatory sanctions, and misaligned objectives that could harm operations and reputation.	\N
448	10	4	10	Other risks associated with acquisitions include the assumption of potential liabilities, disclosed or undisclosed, associated with the business acquired, which liabilities may exceed the amount of indemnification available from the seller, potential inaccuracies in the financials of the business acquired, and our ability to retain customers of an acquired entity, its business or industrialize an acquired process or technology.	Acquisitions carry risks of undisclosed liabilities, financial inaccuracies, customer retention challenges, and technology integration difficulties that may exceed seller indemnifications.	\N
449	10	5	10	We depend on collaboration with other semiconductor industry companies, research organizations, universities, customers and suppliers to further our R&D efforts, and our business and prospects could be materially adversely affected by the failure or termination of such alliances.	STMicroelectronics relies on external R&D collaborations for cost-sharing and technology access, and termination of these alliances could materially harm its innovation pipeline and business prospects.	\N
450	10	5	10	Our success depends on our ability to introduce innovative new products and technologies to the marketplace on a timely basis.	Timely innovation is critical for STMicroelectronics, and failure to develop or access new technologies independently or through partnerships could erode market share and competitive position.	\N
451	10	12	10	We depend on patents to protect our rights to our technology and may face claims of infringing the IP rights of others.	The company depends on patent protection for its technology but faces risks of insufficient patent scope, unenforceable rights in some jurisdictions, and inability to secure favorable cross-license agreements.	\N
452	10	12	10	We have from time to time received, and may in the future receive, communications alleging possible infringement of third-party patents and other IP rights.	STMicroelectronics faces ongoing IP infringement claims, including from non-practicing entities, which could lead to costly litigation, product injunctions, unfavorable licensing terms, or customer order reductions.	\N
453	10	12	10	The outcome of IP litigation is inherently uncertain and may divert the efforts and attention of our management and other specialized technical personnel.	IP litigation outcomes are unpredictable, potentially diverting management focus and incurring significant costs that could materially harm the business if not resolved favorably.	\N
454	10	3	10	We operate in many jurisdictions with highly complex and varied tax regimes.	Operating across multiple complex tax jurisdictions exposes STMicroelectronics to adverse impacts from tax rule changes, new legislation, and audit outcomes, including OECD Pillar II global minimum tax implementation.	\N
455	10	11	10	Any of the above requirements may in the future overlap in scope and diverge in content with each other and/or the rules of other jurisdictions to which we may be subject.	Overlapping and diverging climate disclosure requirements across jurisdictions could create reputational risk and financial repercussions if metrics are deemed insufficient.	\N
456	10	3	10	In parallel, environmental, social and governance ("ESG") practices, especially regarding equal opportunity, have been increasingly subject to political controversy in the United States, most recently as a result of various executive orders signed by the current U.S. administration, aimed at limiting equal opportunities initiatives in the workplace.	U.S. political controversy and executive orders targeting ESG and equal opportunity initiatives expose the company to legal, reputational, and stakeholder risks.	\N
457	10	3	10	This enhanced focus and increased regulations and initiatives, as well as related stakeholder expectations, have been and may continue to be subject to rapid and extensive change or reversal, and have resulted and may result in conflicts between regulatory regimes and stakeholders.	Rapidly changing ESG regulations and stakeholder expectations may create conflicts between regulatory regimes, increasing compliance complexity and risk.	\N
458	10	11	10	Individual customer use of certain products, which may differ from the anticipated uses of such products and result in differences in performance, including energy consumption, may lead to a failure to achieve our disclosed emission-reduction goals, adverse legal action or additional research costs.	Customer misuse of products deviating from anticipated uses could undermine emission-reduction targets, trigger legal action, and increase costs.	\N
459	10	7	10	Loss of key employees and the inability to continuously recruit and retain qualified employees could hurt our competitive position.	Inability to retain or recruit key talent, especially in specialized areas, could materially harm competitive position and growth.	\N
460	10	14	10	The interests of our controlling shareholder, which is in turn indirectly controlled by the French and Italian governments, may conflict with other investors' interests. In addition, our controlling shareholder may sell our existing common shares or issue financial instruments exchangeable into our common shares at any time.	The controlling shareholder, indirectly owned by the French and Italian governments, may have conflicting interests and can sell shares or issue exchangeable instruments, potentially affecting share price and governance.	\N
462	10	8	10	Any decision to reduce or discontinue paying cash dividends to our shareholders could adversely impact the market price of our common shares.	Reducing or discontinuing cash dividends could cause the market price of common shares to decline.	\N
463	10	8	10	We are required to prepare financial statements under IFRS and we also prepare Consolidated Financial Statements under U.S. GAAP, and such dual reporting may impair the clarity of our financial reporting.	Dual reporting under IFRS and U.S. GAAP increases complexity and may cause confusion due to inconsistencies between the two standards.	\N
464	10	13	10	There are inherent limitations on the effectiveness of our risk management and internal control(s) systems	Risk management and internal control systems cannot provide absolute assurance and may become inadequate due to changing circumstances or compliance deterioration.	\N
465	10	3	10	If we fail to comply with laws, regulations, permits and other authorizations or licenses, we could be fined or otherwise sanctioned by regulators, which may include directives to cease operations, fines and penalties as well as prosecution, which could harm our reputation and relationships with stakeholders and, in turn, have a material adverse impact on our business.	Non-compliance with laws and regulations could result in fines, operational shutdowns, prosecution, reputational harm, and material adverse business impact.	\N
466	10	10	10	Because we are subject to the corporate law of The Netherlands, U.S. investors might have more difficulty protecting their interests in a court of law or otherwise than if we were a U.S. company.	Dutch corporate law may offer U.S. investors less protection and make it harder to enforce rights against management, boards, or controlling shareholders compared to U.S. law.	\N
467	10	10	10	Our executive offices and a substantial portion of our assets are located outside the United States. In addition, ST Holding and most members of our Managing and Supervisory Boards are residents of jurisdictions other than the United States.	Location of executives, assets, and board members outside the U.S. may hinder service of process and enforcement of U.S. judgments against the company and its insiders.	\N
\.


--
-- Data for Name: supply_chain_relations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supply_chain_relations (relation_id, supplier_company_id, customer_company_id, relation_type, product_category, contract_value_usd, since_year, evidence, source_filing_id) FROM stdin;
1	152	1	supplier	lithium-ion battery cells	\N	\N	Currently, we rely on suppliers such as Panasonic and Contemporary Amperex Technology Co. Limited (CATL) for these cells.	1
2	154	1	supplier	lithium-ion battery cells	\N	\N	Currently, we rely on suppliers such as Panasonic and Contemporary Amperex Technology Co. Limited (CATL) for these cells.	1
3	1	2	manufacturing_partner	ai chip manufacturing	\N	\N	While we have a framework agreement with Tesla, neither Tesla nor Intel are obligated to remain a part of the project, and we may not enter into any such definitive agreements.	2
4	158	2	manufacturing_partner	ai chip manufacturing	\N	\N	While we have a framework agreement with Tesla, neither Tesla nor Intel are obligated to remain a part of the project, and we may not enter into any such definitive agreements.	2
5	159	2	joint_venture	coding and knowledge work ai models	\N	\N	We are also partnering with Cursor to advance Grok and potentially to create jointly-owned coding and knowledge work AI models, trained on our compute infrastructure.	2
6	155	2	licensor	spectrum licenses (aws-4 and h-block)	19600000000.00	2025	On September 7, 2025, the Company entered into a License Purchase Agreement (the “Spectrum License Purchase Agreement”) with Spectrum Business Trust 2025-1, a Nevada Business Trust (“Trust”) and EchoStar Corporation (“EchoStar”	2
7	160	2	joint_venture	off-grid power for data center campus	\N	2025	In April 2025, the Company, through its wholly-owned subsidiary CTC Property LLC (“CTC”), entered into a joint venture Stateline Power, LLC (“Stateline”), with Solaris Power Solutions Stateline, LLC (“Stateline Power Solutions”), a wholly owned subsidiary of Solaris Energy Infrastructure, Inc. (“Solaris”).	2
8	3	164	launch_provider	launch services	\N	\N	and a number of domestic and international commercial spacecraft operators including Blacksky Holdings, Canon, Kinéis, Capella Space, Planet, OHB Group and Synspective.	3
9	3	165	launch_provider	launch services	\N	\N	and a number of domestic and international commercial spacecraft operators including Blacksky Holdings, Canon, Kinéis, Capella Space, Planet, OHB Group and Synspective.	3
10	3	166	launch_provider	launch services	\N	\N	and a number of domestic and international commercial spacecraft operators including Blacksky Holdings, Canon, Kinéis, Capella Space, Planet, OHB Group and Synspective.	3
11	3	167	launch_provider	launch services	\N	\N	and a number of domestic and international commercial spacecraft operators including Blacksky Holdings, Canon, Kinéis, Capella Space, Planet, OHB Group and Synspective.	3
12	3	168	launch_provider	launch services	\N	\N	and a number of domestic and international commercial spacecraft operators including Blacksky Holdings, Canon, Kinéis, Capella Space, Planet, OHB Group and Synspective.	3
13	3	169	launch_provider	launch services	\N	\N	and a number of domestic and international commercial spacecraft operators including Blacksky Holdings, Canon, Kinéis, Capella Space, Planet, OHB Group and Synspective.	3
14	3	170	launch_provider	launch services	\N	\N	and a number of domestic and international commercial spacecraft operators including Blacksky Holdings, Canon, Kinéis, Capella Space, Planet, OHB Group and Synspective.	3
15	171	3	supplier	spacecraft components	\N	\N	including legacy missions enabled by Sinclair Interplanetary (acquired April 2020), Advanced Solutions, Incorporated (acquired October 2021), Planetary Systems Corporation (acquired November 2021)	3
16	172	3	supplier	spacecraft components	\N	\N	including legacy missions enabled by Sinclair Interplanetary (acquired April 2020), Advanced Solutions, Incorporated (acquired October 2021), Planetary Systems Corporation (acquired November 2021)	3
17	173	3	supplier	spacecraft components	\N	\N	including legacy missions enabled by Sinclair Interplanetary (acquired April 2020), Advanced Solutions, Incorporated (acquired October 2021), Planetary Systems Corporation (acquired November 2021)	3
18	174	3	supplier	spacecraft components	\N	\N	SolAero Technologies Corp. (acquired January 2022) and GEOST LLC ("GEOST") (acquired August 2025).	3
19	161	3	supplier	optical systems	\N	\N	SolAero Technologies Corp. (acquired January 2022) and GEOST LLC ("GEOST") (acquired August 2025).	3
20	3	175	supplier	satellite design, manufacture, operations and sustainment	816000000.00	2025	entered into an agreement with the Space Development Agency (“SDA”) to design, manufacture and provide operations and sustainment for 18 satellites for the Tracking Layer Tranche 3 program	3
21	176	5	manufacturing_partner	aircraft components	\N	\N	our recent acquisition of Spirit (Spirit Acquisition), significantly impacted our financial position, results of operations and cash flows.	5
22	5	177	supplier	defense related programs	\N	\N	We derive a substantial portion of our revenue from the U.S. government, primarily from defense related programs with the United States Department of War (DoW)	5
23	5	178	supplier	government contracts	\N	\N	We derive a substantial portion of our revenue from the U.S. government, primarily from defense related programs with the United States Department of War (DoW) and contracts with other government agencies, including NASA.	5
24	176	5	manufacturing_partner	787 tooling and aircraft components	\N	2023	Since 2023, Boeing has provided funding in the form of loans and advance payments to Spirit to support its liquidity, rate readiness, and 787 tooling and capital expenditures.	5
25	5	179	supplier	digital aviation solutions business	10550.00	2025	On October 31, 2025, we closed on the sale of portions of our BGS segment's Digital Aviation Solutions business (Digital Aviation Solutions Divestiture) to Thoma Bravo for proceeds of $ 10,550.	5
26	9	6	manufacturing_partner	wafer foundry services	\N	\N	We utilize foundries, such as Taiwan Semiconductor Manufacturing Company Limited, or TSMC, and Samsung Electronics Co., Ltd., or Samsung, to produce our semiconductor wafers.	6
27	183	6	manufacturing_partner	wafer foundry services	\N	\N	We utilize foundries, such as Taiwan Semiconductor Manufacturing Company Limited, or TSMC, and Samsung Electronics Co., Ltd., or Samsung, to produce our semiconductor wafers.	6
28	183	6	supplier	memory	\N	\N	We purchase memory from SK Hynix Inc., Micron Technology, Inc., and Samsung.	6
29	184	6	supplier	memory	\N	\N	We purchase memory from SK Hynix Inc., Micron Technology, Inc., and Samsung.	6
30	185	6	supplier	memory	\N	\N	We purchase memory from SK Hynix Inc., Micron Technology, Inc., and Samsung.	6
31	186	6	manufacturing_partner	assembly, testing and packaging services	\N	\N	We engage with independent subcontractors and contract manufacturers such as Hon Hai Precision Industry Co., Ltd., Wistron Corporation, and Fabrinet to perform assembly, testing and packaging of our final products.	6
32	187	6	manufacturing_partner	assembly, testing and packaging services	\N	\N	We engage with independent subcontractors and contract manufacturers such as Hon Hai Precision Industry Co., Ltd., Wistron Corporation, and Fabrinet to perform assembly, testing and packaging of our final products.	6
33	188	6	manufacturing_partner	assembly, testing and packaging services	\N	\N	We engage with independent subcontractors and contract manufacturers such as Hon Hai Precision Industry Co., Ltd., Wistron Corporation, and Fabrinet to perform assembly, testing and packaging of our final products.	6
34	190	7	joint_venture	lithium concentrate	\N	\N	We purchase lithium concentrate from Windfield, and our investment in the joint venture is reported as an unconsolidated equity investment on our balance sheet.	7
35	191	7	joint_venture	lithium concentrate	\N	\N	following the restructuring of the MARBL joint venture with MRL.	7
36	192	7	joint_venture	aluminum alkyls	\N	\N	Nippon Aluminum Alkyls - a joint venture with Mitsui Chemicals, Inc. that produces aluminum alkyls	7
37	193	7	joint_venture	refinery catalysts	\N	\N	Nippon Ketjen Company Limited - a joint venture with Sumitomo Metal Mining Company Limited that produces refinery catalysts	7
38	194	7	joint_venture	refinery catalysts regeneration services	\N	\N	Eurecat S.A. - a joint venture with Axens Group for refinery catalysts regeneration services	7
39	195	7	joint_venture	catalysts and catalysts research and product development	\N	\N	Fábrica Carioca de Catalisadores S.A. - a joint venture with Petrobras Quimica S.A. - PETROQUISA that produces catalysts and includes catalysts research and product development activities	7
40	191	7	joint_venture	lithium hydroxide and spodumene	\N	\N	On October 18, 2023, the Company closed on the restructuring of the MARBL joint venture with MRL.	7
41	191	7	joint_venture	lithium joint venture	\N	\N	Gain recorded during the year ended December 31, 2023 resulting from the restructuring of the MARBL joint venture with MRL.	7
42	203	9	joint_venture	ssmc joint venture formation	\N	1999	Under a Shareholders Agreement entered into with Philips and EDB Investments Pte Ltd. on March 30, 1999, the parties formed a joint venture company, SSMC, which is an integrated circuit foundry in Singapore.	9
43	204	9	joint_venture	ssmc joint venture formation	\N	1999	Under a Shareholders Agreement entered into with Philips and EDB Investments Pte Ltd. on March 30, 1999, the parties formed a joint venture company, SSMC, which is an integrated circuit foundry in Singapore.	9
44	205	9	joint_venture	ssmc joint venture shares	\N	2006	TSMC and NXP B.V. purchased all the SSMC shares owned by EDB Investments Pte Ltd. pro rata according to the Shareholders Agreement on November 15, 2006. After the purchase, TSMC and NXP B.V. currently own approximately 39% and 61% of the SSMC shares.	9
45	203	9	joint_venture	wafer foundry services	\N	1999	In March 1999, we entered into an agreement with Koninklijke Philips NV (“Philips”) and EDB Investment Pte. Ltd. (“EDB”) to found a joint venture, SSMC, and build a fab in Singapore.	9
46	204	9	joint_venture	wafer foundry services	\N	1999	In March 1999, we entered into an agreement with Koninklijke Philips NV (“Philips”) and EDB Investment Pte. Ltd. (“EDB”) to found a joint venture, SSMC, and build a fab in Singapore.	9
47	206	9	joint_venture	back-end service for cmos image sensor manufacturing	\N	2003	In October 2003, we and OmniVision Technologies Inc. (“OVT”), entered into an agreement to form VisEra Technologies, a joint venture in Taiwan, for the purpose of providing back-end service for CMOS image sensor manufacturing business.	9
48	207	9	joint_venture	semiconductor manufacturing	\N	2021	In December 2021, we established JASM (of which the manufacturing entity is Fab 23) in Kumamoto, Japan, which is expected to be primarily engaged in the manufacture and sale of integrated circuits. In January 2022, Sony Semiconductor Solution Corporation (“Sony”) acquired a less than 20% equity interest in JASM.	9
49	208	9	joint_venture	semiconductor manufacturing	\N	2022	In April 2022, DENSO Corporation (“DENSO”) acquired a more than 10% minority equity interest in JASM.	9
50	209	9	joint_venture	semiconductor manufacturing	\N	2024	In February 2024, we, Sony, DENSO and Toyota Motor Corporation (“Toyota”) announced further investment into JASM to build and operate a second semiconductor manufacturing facility. By way of such investment, Toyota also took a minority stake in JASM.	9
51	210	9	joint_venture	semiconductor manufacturing	\N	2024	In January 2024, Robert Bosch GmbH, Infineon Technologies AG, and NXP Semiconductors Germany GmbH, a wholly-owned subsidiary of NXP Semiconductors N.V. (“NXP”), each acquired 10% equity interest and together acquired 30% equity interest in ESMC.	9
52	211	9	joint_venture	semiconductor manufacturing	\N	2024	In January 2024, Robert Bosch GmbH, Infineon Technologies AG, and NXP Semiconductors Germany GmbH, a wholly-owned subsidiary of NXP Semiconductors N.V. (“NXP”), each acquired 10% equity interest and together acquired 30% equity interest in ESMC.	9
53	205	9	joint_venture	semiconductor manufacturing	\N	2024	In January 2024, Robert Bosch GmbH, Infineon Technologies AG, and NXP Semiconductors Germany GmbH, a wholly-owned subsidiary of NXP Semiconductors N.V. (“NXP”), each acquired 10% equity interest and together acquired 30% equity interest in ESMC.	9
54	200	9	supplier	wafer level packaging service	\N	2007	In January 2007, we acquired a 51.2% equity interest in Xintec, a supplier of wafer level packaging service, to support our CMOS image sensor manufacturing business.	9
55	215	10	joint_venture	front-end semiconductor production facility	\N	2023	On April 28, 2023, the European Commission approved, under EU State Aid rules, a French aid measure to support the Company and GlobalFoundries in the construction and operation of a front-end semiconductor production facility in Crolles, France.	10
56	216	10	joint_venture	high-volume 200mm sic device manufacturing	3200000000.00	2023	On June 7, 2023, the Company and Sanan Optoelectronics jointly created SANAN, STMicroelectronics Co. Ltd. (“Sanan ST JV”), for high-volume 200mm SiC device manufacturing in China.	10
57	216	10	joint_venture	200mm sic device manufacturing	\N	2023	In 2023, the Company and Sanan Optoelectronics jointly created Sanan ST JV. for high-volume 200mm SiC device manufacturing activities in China.	10
58	215	10	manufacturing_partner	300mm semiconductor manufacturing facility	\N	\N	The joint 300mm semiconductor manufacturing facility with GlobalFoundries Inc in Crolles, France, which has received European Commission approval	10
59	217	10	joint_venture	semiconductor manufacturing facility	\N	\N	Jointly owned with Shenzhen SEG Hi-Tech Industrial Company Limited, a subsidiary of Shenzhen Electronics Group.	10
60	218	10	manufacturing_partner	fab 3 wafer fabrication	\N	\N	Fab 3 is currently shared between the Company and Tower Semiconductor.	10
\.


--
-- Name: companies_company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.companies_company_id_seq', 218, true);


--
-- Name: company_executives_company_executive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.company_executives_company_executive_id_seq', 205, true);


--
-- Name: filings_filing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filings_filing_id_seq', 1584, true);


--
-- Name: financial_metrics_financial_metric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.financial_metrics_financial_metric_id_seq', 3891, true);


--
-- Name: footnote_related_parties_related_party_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.footnote_related_parties_related_party_id_seq', 48, true);


--
-- Name: institutional_holders_institution_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.institutional_holders_institution_id_seq', 20, true);


--
-- Name: institutional_holdings_holding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.institutional_holdings_holding_id_seq', 338, true);


--
-- Name: legal_proceedings_legal_proceeding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.legal_proceedings_legal_proceeding_id_seq', 31, true);


--
-- Name: metric_definitions_metric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.metric_definitions_metric_id_seq', 21, true);


--
-- Name: persons_person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.persons_person_id_seq', 200, true);


--
-- Name: risk_categories_risk_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.risk_categories_risk_category_id_seq', 14, true);


--
-- Name: risk_factors_risk_factor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.risk_factors_risk_factor_id_seq', 467, true);


--
-- Name: supply_chain_relations_relation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.supply_chain_relations_relation_id_seq', 60, true);


--
-- Name: companies companies_cik_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_cik_key UNIQUE (cik);


--
-- Name: companies companies_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_name_key UNIQUE (name);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (company_id);


--
-- Name: company_executives company_executives_company_id_person_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_executives
    ADD CONSTRAINT company_executives_company_id_person_id_key UNIQUE (company_id, person_id);


--
-- Name: company_executives company_executives_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_executives
    ADD CONSTRAINT company_executives_pkey PRIMARY KEY (company_executive_id);


--
-- Name: filings filings_accession_no_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filings
    ADD CONSTRAINT filings_accession_no_key UNIQUE (accession_no);


--
-- Name: filings filings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filings
    ADD CONSTRAINT filings_pkey PRIMARY KEY (filing_id);


--
-- Name: financial_metrics financial_metrics_company_id_metric_id_fiscal_year_fiscal_p_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_company_id_metric_id_fiscal_year_fiscal_p_key UNIQUE (company_id, metric_id, fiscal_year, fiscal_period, unit);


--
-- Name: financial_metrics financial_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_pkey PRIMARY KEY (financial_metric_id);


--
-- Name: footnote_related_parties footnote_related_parties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.footnote_related_parties
    ADD CONSTRAINT footnote_related_parties_pkey PRIMARY KEY (related_party_id);


--
-- Name: institutional_holders institutional_holders_cik_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_holders
    ADD CONSTRAINT institutional_holders_cik_key UNIQUE (cik);


--
-- Name: institutional_holders institutional_holders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_holders
    ADD CONSTRAINT institutional_holders_pkey PRIMARY KEY (institution_id);


--
-- Name: institutional_holdings institutional_holdings_institution_id_company_id_report_per_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_holdings
    ADD CONSTRAINT institutional_holdings_institution_id_company_id_report_per_key UNIQUE (institution_id, company_id, report_period);


--
-- Name: institutional_holdings institutional_holdings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_holdings
    ADD CONSTRAINT institutional_holdings_pkey PRIMARY KEY (holding_id);


--
-- Name: legal_proceedings legal_proceedings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legal_proceedings
    ADD CONSTRAINT legal_proceedings_pkey PRIMARY KEY (legal_proceeding_id);


--
-- Name: metric_definitions metric_definitions_metric_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metric_definitions
    ADD CONSTRAINT metric_definitions_metric_code_key UNIQUE (metric_code);


--
-- Name: metric_definitions metric_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metric_definitions
    ADD CONSTRAINT metric_definitions_pkey PRIMARY KEY (metric_id);


--
-- Name: persons persons_owner_cik_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persons
    ADD CONSTRAINT persons_owner_cik_key UNIQUE (owner_cik);


--
-- Name: persons persons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.persons
    ADD CONSTRAINT persons_pkey PRIMARY KEY (person_id);


--
-- Name: risk_categories risk_categories_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_categories
    ADD CONSTRAINT risk_categories_name_key UNIQUE (name);


--
-- Name: risk_categories risk_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_categories
    ADD CONSTRAINT risk_categories_pkey PRIMARY KEY (risk_category_id);


--
-- Name: risk_factors risk_factors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_factors
    ADD CONSTRAINT risk_factors_pkey PRIMARY KEY (risk_factor_id);


--
-- Name: supply_chain_relations supply_chain_relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_chain_relations
    ADD CONSTRAINT supply_chain_relations_pkey PRIMARY KEY (relation_id);


--
-- Name: company_executives_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_executives_company_id_idx ON public.company_executives USING btree (company_id);


--
-- Name: company_executives_person_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_executives_person_id_idx ON public.company_executives USING btree (person_id);


--
-- Name: company_executives_source_filing_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX company_executives_source_filing_id_idx ON public.company_executives USING btree (source_filing_id);


--
-- Name: filings_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filings_company_id_idx ON public.filings USING btree (company_id);


--
-- Name: filings_form_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filings_form_date_idx ON public.filings USING btree (form_type, filing_date);


--
-- Name: financial_metrics_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_metrics_company_id_idx ON public.financial_metrics USING btree (company_id);


--
-- Name: financial_metrics_metric_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_metrics_metric_id_idx ON public.financial_metrics USING btree (metric_id);


--
-- Name: financial_metrics_period_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_metrics_period_idx ON public.financial_metrics USING btree (fiscal_year, fiscal_period);


--
-- Name: financial_metrics_source_filing_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_metrics_source_filing_id_idx ON public.financial_metrics USING btree (source_filing_id);


--
-- Name: footnote_related_parties_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX footnote_related_parties_company_id_idx ON public.footnote_related_parties USING btree (company_id);


--
-- Name: footnote_related_parties_filing_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX footnote_related_parties_filing_id_idx ON public.footnote_related_parties USING btree (filing_id);


--
-- Name: footnote_related_parties_related_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX footnote_related_parties_related_company_id_idx ON public.footnote_related_parties USING btree (related_company_id);


--
-- Name: footnote_related_parties_related_person_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX footnote_related_parties_related_person_id_idx ON public.footnote_related_parties USING btree (related_person_id);


--
-- Name: institutional_holdings_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutional_holdings_company_id_idx ON public.institutional_holdings USING btree (company_id);


--
-- Name: institutional_holdings_institution_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutional_holdings_institution_id_idx ON public.institutional_holdings USING btree (institution_id);


--
-- Name: institutional_holdings_source_filing_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX institutional_holdings_source_filing_id_idx ON public.institutional_holdings USING btree (source_filing_id);


--
-- Name: legal_proceedings_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX legal_proceedings_company_id_idx ON public.legal_proceedings USING btree (company_id);


--
-- Name: legal_proceedings_counterparty_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX legal_proceedings_counterparty_company_id_idx ON public.legal_proceedings USING btree (counterparty_company_id);


--
-- Name: legal_proceedings_filing_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX legal_proceedings_filing_id_idx ON public.legal_proceedings USING btree (filing_id);


--
-- Name: risk_factors_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX risk_factors_company_id_idx ON public.risk_factors USING btree (company_id);


--
-- Name: risk_factors_filing_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX risk_factors_filing_id_idx ON public.risk_factors USING btree (filing_id);


--
-- Name: risk_factors_mentioned_company_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX risk_factors_mentioned_company_id_idx ON public.risk_factors USING btree (mentioned_company_id);


--
-- Name: risk_factors_risk_category_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX risk_factors_risk_category_id_idx ON public.risk_factors USING btree (risk_category_id);


--
-- Name: supply_chain_relations_customer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supply_chain_relations_customer_idx ON public.supply_chain_relations USING btree (customer_company_id);


--
-- Name: supply_chain_relations_source_filing_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supply_chain_relations_source_filing_id_idx ON public.supply_chain_relations USING btree (source_filing_id);


--
-- Name: supply_chain_relations_supplier_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supply_chain_relations_supplier_idx ON public.supply_chain_relations USING btree (supplier_company_id);


--
-- Name: company_executives company_executives_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_executives
    ADD CONSTRAINT company_executives_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(company_id);


--
-- Name: company_executives company_executives_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_executives
    ADD CONSTRAINT company_executives_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.persons(person_id);


--
-- Name: company_executives company_executives_source_filing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_executives
    ADD CONSTRAINT company_executives_source_filing_id_fkey FOREIGN KEY (source_filing_id) REFERENCES public.filings(filing_id);


--
-- Name: filings filings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filings
    ADD CONSTRAINT filings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(company_id);


--
-- Name: financial_metrics financial_metrics_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(company_id);


--
-- Name: financial_metrics financial_metrics_metric_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_metric_id_fkey FOREIGN KEY (metric_id) REFERENCES public.metric_definitions(metric_id);


--
-- Name: financial_metrics financial_metrics_source_filing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_metrics
    ADD CONSTRAINT financial_metrics_source_filing_id_fkey FOREIGN KEY (source_filing_id) REFERENCES public.filings(filing_id);


--
-- Name: footnote_related_parties footnote_related_parties_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.footnote_related_parties
    ADD CONSTRAINT footnote_related_parties_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(company_id);


--
-- Name: footnote_related_parties footnote_related_parties_filing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.footnote_related_parties
    ADD CONSTRAINT footnote_related_parties_filing_id_fkey FOREIGN KEY (filing_id) REFERENCES public.filings(filing_id);


--
-- Name: footnote_related_parties footnote_related_parties_related_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.footnote_related_parties
    ADD CONSTRAINT footnote_related_parties_related_company_id_fkey FOREIGN KEY (related_company_id) REFERENCES public.companies(company_id);


--
-- Name: footnote_related_parties footnote_related_parties_related_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.footnote_related_parties
    ADD CONSTRAINT footnote_related_parties_related_person_id_fkey FOREIGN KEY (related_person_id) REFERENCES public.persons(person_id);


--
-- Name: institutional_holdings institutional_holdings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_holdings
    ADD CONSTRAINT institutional_holdings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(company_id);


--
-- Name: institutional_holdings institutional_holdings_institution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_holdings
    ADD CONSTRAINT institutional_holdings_institution_id_fkey FOREIGN KEY (institution_id) REFERENCES public.institutional_holders(institution_id);


--
-- Name: institutional_holdings institutional_holdings_source_filing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.institutional_holdings
    ADD CONSTRAINT institutional_holdings_source_filing_id_fkey FOREIGN KEY (source_filing_id) REFERENCES public.filings(filing_id);


--
-- Name: legal_proceedings legal_proceedings_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legal_proceedings
    ADD CONSTRAINT legal_proceedings_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(company_id);


--
-- Name: legal_proceedings legal_proceedings_counterparty_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legal_proceedings
    ADD CONSTRAINT legal_proceedings_counterparty_company_id_fkey FOREIGN KEY (counterparty_company_id) REFERENCES public.companies(company_id);


--
-- Name: legal_proceedings legal_proceedings_filing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.legal_proceedings
    ADD CONSTRAINT legal_proceedings_filing_id_fkey FOREIGN KEY (filing_id) REFERENCES public.filings(filing_id);


--
-- Name: risk_factors risk_factors_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_factors
    ADD CONSTRAINT risk_factors_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(company_id);


--
-- Name: risk_factors risk_factors_filing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_factors
    ADD CONSTRAINT risk_factors_filing_id_fkey FOREIGN KEY (filing_id) REFERENCES public.filings(filing_id);


--
-- Name: risk_factors risk_factors_mentioned_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_factors
    ADD CONSTRAINT risk_factors_mentioned_company_id_fkey FOREIGN KEY (mentioned_company_id) REFERENCES public.companies(company_id);


--
-- Name: risk_factors risk_factors_risk_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.risk_factors
    ADD CONSTRAINT risk_factors_risk_category_id_fkey FOREIGN KEY (risk_category_id) REFERENCES public.risk_categories(risk_category_id);


--
-- Name: supply_chain_relations supply_chain_relations_customer_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_chain_relations
    ADD CONSTRAINT supply_chain_relations_customer_company_id_fkey FOREIGN KEY (customer_company_id) REFERENCES public.companies(company_id);


--
-- Name: supply_chain_relations supply_chain_relations_source_filing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_chain_relations
    ADD CONSTRAINT supply_chain_relations_source_filing_id_fkey FOREIGN KEY (source_filing_id) REFERENCES public.filings(filing_id);


--
-- Name: supply_chain_relations supply_chain_relations_supplier_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supply_chain_relations
    ADD CONSTRAINT supply_chain_relations_supplier_company_id_fkey FOREIGN KEY (supplier_company_id) REFERENCES public.companies(company_id);


--
-- PostgreSQL database dump complete
--

\unrestrict mQzcu8AAXDWdfamAqfsKBqY6t2YsfdjzmCOUkYfpiJKlwjDcpp98xWbk0zOwtRq

